import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './public/login/login.component';
import { OnlineOrderingCustomizeComponent } from './main/online-ordering/online-ordering-customize/online-ordering-customize.component';
import { MainComponent } from "./main/main.component";
import {HelpAndSupportComponent} from "./main/help-and-support/help-and-support.component";

const routes: Routes = [
  { path: "", redirectTo: "login", pathMatch: "full" },
  { path: "login", component: LoginComponent, pathMatch: "full" },
  {
    path: 'customization',
    component: OnlineOrderingCustomizeComponent,
    pathMatch: 'full'
  },
  {

    path: '', component: MainComponent, children: [

  ]
  },

  {path: '**', redirectTo: '/login', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
