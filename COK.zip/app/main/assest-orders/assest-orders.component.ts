import {Component, ElementRef, Injector, OnInit, ViewChild} from '@angular/core';
import {BaseComponent} from "../../common/commonComponent";
import {Router} from "@angular/router";
import {OnlineOrderingPreviewService} from "../online-ordering/online-ordering-preview/online-ordering-preview.service";
import {OnlineOrderingSummaryService} from '../online-ordering/online-ordering-summary/online-ordering-summary.service';
import {AccountService} from '../account/account.service';
declare var $;

@Component({
  selector: 'app-assest-orders',
  templateUrl: './assest-orders.component.html',
  styleUrls: ['./assest-orders.component.css']
})
export class AssestOrdersComponent extends BaseComponent implements OnInit {

  // @ViewChild('demo') accordianElememnt:ElementRef;

  ordersDetails: any;
  totalprice: any = 0;
  jobBagDate: any;
  successMessage: any;
  errorMessage: any;
  test: any = {
    open: false
  };
  public order: any = 'DESC';
  isLoading: boolean = true;
  public paginaton: any = {
    page: 1,
    fetchSize: 12
  };
  totalCount: number;

  // conditionalTextOrderSummary : any = 'Show Details';
  constructor(inj: Injector, public router: Router, public accountService: AccountService,
              public onlineOrderingPreviewService: OnlineOrderingPreviewService,
              private onlineOrderingSummaryService : OnlineOrderingSummaryService) {
    super(inj);
  }


  ngOnInit() {
    this.getPreviousOrderDetails();
  }

  sortBy() {
    this.getPreviousOrderDetails();
  }

  getPreviousOrderDetails() {
    let filters = "sort:" + this.order;
    this.accountService.getPreviousOrderDetails(this.paginaton, filters).subscribe((res: any) => {
      if (res.instanceList) {
        this.ordersDetails = res.instanceList;
        this.totalCount = Math.ceil(parseInt(res.key) / this.paginaton.fetchSize);
        this.ordersDetails.map(itemArray => {
          itemArray['conditionalText'] = 'Show Details';
          itemArray.totalprice = 0;
          var array = itemArray.orderDate.split(".");
          itemArray.jobBagDate = array[1] + '/' + array[2] + '/' + array[0];
          this.getUnitPriceAndTotal();
          // itemArray.items.map(res => {
          //   itemArray.totalprice = itemArray.totalprice + (res.qtys[0] * res.price);
          // })
        })


        this.isLoading = false;
      }
    })
  }

  //it will send product data for unit price and send object for total price
  // it will update total and add handling in total;
  getUnitPriceAndTotal() {
    let data = [];

    this.ordersDetails.map(res => {
      res.items.map(res1 =>{
        data.push({
          product_id: Number(res1.itemCode),
          quantity: res1.qtys[0],
          itemID: res1.itemID
        });

      })


    })
    this.onlineOrderingSummaryService.getUnitPriceAndTotal(data).subscribe((res: any) => {
      if (res) {
        let tempKeys = Object.values(res.instance);
        this.ordersDetails.map(res =>{
          res.items.map(resItem => {
            tempKeys.map((res1: any) => {
              if (resItem.itemCode === res1.product_id && resItem.qtys[0] === Number(res1.quantity)) {
                resItem.cost = <any>res1.total_price.toFixed(2);
              }
            })
          });
        })
      }
      this.ordersDetails.map(itemArray => {
        let item
        item  = itemArray.items.reduce((a, {cost}) => a + parseFloat(cost), 0);
        itemArray.totalprice = <any>item.toFixed(2);
      })
    });
  }

  fixDecimals(value: number) {
    value = Math.ceil(value)
    return value;
  }

  next() {
    this.paginaton.page = this.paginaton.page + 1
    this.getPreviousOrderDetails();
  }

  prev() {
    this.paginaton.page = this.paginaton.page - 1;
    this.getPreviousOrderDetails();
  }

  reOrdersDetails(jobBagId) {
    this.accountService.reOrdersDetails(jobBagId).subscribe((res: any) => {

      if (res.statusCode === 200) {
        this.onlineOrderingPreviewService.setCartTotal(res);
        this.translate.get('ReorderSuccessfully').subscribe((res: string) => {
          this.successMessage = res;
        });
        this.commonService.displayToaster('success', this.successMessage);
        this.router.navigate(['/onlineOrdering/cart']);
      }

    })
  }

  showPdf(pdfResponse) {
    if (pdfResponse != null) {
      window.open(pdfResponse);
    } else {
      this.translate.get('PdfNotFound').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster('error', this.errorMessage);
    }
  }

  ngDoCheck() {

  }

  toggleClass(index) {
    if (document.getElementById('demo' + index).classList.contains('show')) {
      this.ordersDetails[index].conditionalText = 'Show Details';
    } else {
      this.ordersDetails[index].conditionalText = 'Hide Details';
    }
  }
}
