import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssestOrdersComponent } from './assest-orders.component';

describe('AssestOrdersComponent', () => {
  let component: AssestOrdersComponent;
  let fixture: ComponentFixture<AssestOrdersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssestOrdersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssestOrdersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
