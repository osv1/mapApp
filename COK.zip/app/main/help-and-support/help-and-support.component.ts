import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-help-and-support',
  templateUrl: './help-and-support.component.html',
  styleUrls: ['./help-and-support.component.css']
})
export class HelpAndSupportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
