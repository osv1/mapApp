import {Component, OnInit, Injector} from '@angular/core';
import {BaseComponent} from "../../common/commonComponent";
import {AssetTilesService} from '../asset-tiles/asset-tiles.service';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'app-assets-folder',
  templateUrl: './assets-folder.component.html',
  styleUrls: ['./assets-folder.component.css']
})
export class AssetsFolderComponent extends BaseComponent implements OnInit {

  basketAssetsDetails: any;
  basketlength: any = 0;
  assetsIdArray: any = [];
  url: any;
  public constants = this.constants;
  public env = environment;
  displayMessage: any;
  errorMessage: any;
  selectedAssetsId;
  isCCEP: any = false;

  constructor(inj: Injector, public assetTilesService: AssetTilesService) {
    super(inj)
  }

  ngOnInit() {
      if (environment.envnName === this.constants.enviromentValues.cokeMain) {
          this.isCCEP = true;
      }
    this.selectedAssetsId =[];
    this.assetTilesService.getAssetsBasketTotal().subscribe(res => {
      console.log('res===>>?/', res);
      if (res) {
        this.getAllbasketAssets();
      }
    });
    this.getAllbasketAssets();

  }


  getAllbasketAssets() {
    const data = {
      token: this.getToken('accessToken'),
      fetchSize: 10,
      page: 1
    };
    this.assetTilesService.getAllbasketAssets(data).subscribe((res: any) => {
      if (res) {
        this.basketAssetsDetails = res.instance.assets;
        this.assetsIdArray = [];
        this.basketAssetsDetails.forEach((obj) => {
          obj.check = true;
          this.assetsIdArray.push(obj.assetID);
          this.selectedAssetsId.push({
            assetId : obj.assetID,
            cid : obj.cid
          })
        });
        console.log(this.basketAssetsDetails)
        this.basketlength = res.instance.assets.length;
      }
    });
  }

  downloadSelectedAssets(assetsId,assetCategory) {
    const data = {
      token: this.getToken('accessToken'),
      catalouge: this.isCCEP(), // Remove Hard coded
      assetsIds: assetsId
    };
    let event = {
      event_id: this.constants.ASSET_DOWNLOAD.event_id,
      event_desc: this.constants.ASSET_DOWNLOAD.event_desc,
      attributes: assetsId,
      categoryId: assetCategory.cid
    };
    this.logService.createLog(event);
    this.url = this.env.apiUrl + 'AssetService/v1/asset/' + data.catalouge + '/download?token=' + data.token + '&fileName=&assetIDs=' + data.assetsIds+ '&timestamp=' + new Date().getTime().toString();
    window.open(this.url);

    const assetData = {
      token: this.getToken('accessToken'),
      catalouge: this.isCCEP(), // Remove Hard coded
      assetID: assetsId
    };
    this.deleteSingleAsset(assetData)
  }

  downloadMultiSelectedAssets() {
    console.log("downloadMultiSelectedAssets-====", this.assetsIdArray)
    if (this.assetsIdArray.length > 0) {
      const data = {
        token: this.getToken('accessToken'),
        catalouge: this.isCCEP(), // Remove Hard coded
        assetsIds: this.assetsIdArray.toString(),
      };

      for(let i =0 ; i < this.selectedAssetsId.length ; i++){
        let event = {
          event_id: this.constants.ASSET_DOWNLOAD.event_id,
          event_desc: this.constants.ASSET_DOWNLOAD.event_desc,
          attributes: this.selectedAssetsId[i].assetId,
          categoryId : this.selectedAssetsId[i].cid
        };
        this.logService.createLog(event);
      }
      console.log('data', data);
      this.url = this.env.apiUrl + 'AssetService/v1/asset/' + data.catalouge + '/download?token=' + data.token + '&fileName=&assetIDs=' + data.assetsIds + '&timestamp=' + new Date().getTime().toString();
      window.open(this.url);
      // this.assetsIdArray = [];
      this.assetsIdArray.forEach((obj) => {
        var assestDelete = {
          assetID: obj
        }
        console.log("obj", assestDelete);
        this.deleteSingleAsset(assestDelete);
      })
      // this.deleteSingleAsset(data);
      // this.clearAllAssetsBasket();
    } else {
      this.translate.get('PleaseSelectAtleastOneAsset').subscribe((res: string) => {
        this.displayMessage = res;
      });
      this.translate.get('Error').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
    }

  }


  clearAllAssetsBasket() {
    const data = {
      token: this.getToken('accessToken')
    };
    this.assetTilesService.clearAssetsbasket(data).subscribe((res: any) => {
      this.getAllbasketAssets();
    });
  }

  selectAssets(assets, event, index) {
    if (assets.check === true) {
      this.assetsIdArray.push(assets.assetID);
      this.selectedAssetsId.push({
        assetId : assets.assetID,
        cid : assets.cid
      })
    } else if (assets.check === false) {
      let indexs = this.assetsIdArray.indexOf(assets.assetID);
      let assetsIndex = this.selectedAssetsId.findIndex(res => res.assetId === assets.assetID)
      this.assetsIdArray.splice(indexs, 1);
      this.selectedAssetsId.splice(assetsIndex, 1);
    }
  }

  deleteSingleAsset(data) {
    let category = {
      token: this.getToken('accessToken'),
      catalogue: this.isCCEP(), // Remove Hard coded
      assetID: data.assetID,
      fetchSize: 5,
      page: 1
    }

    this.assetTilesService.deleteSingleAsset(category).subscribe((assetsDelete: any) => {
      if (assetsDelete.statusCode === this.constants.SUCCESS_CODE) {
        let indexs = this.basketAssetsDetails.indexOf(data);
        this.basketAssetsDetails.splice(indexs, 1);
        this.basketlength = this.basketAssetsDetails.length;
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, assetsDelete.message)
      }
    })
  }

}
