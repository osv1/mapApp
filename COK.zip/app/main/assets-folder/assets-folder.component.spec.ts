import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsFolderComponent } from './assets-folder.component';

describe('AssetsFolderComponent', () => {
  let component: AssetsFolderComponent;
  let fixture: ComponentFixture<AssetsFolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetsFolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetsFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
