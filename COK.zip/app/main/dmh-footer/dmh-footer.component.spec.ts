import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmhFooterComponent } from './dmh-footer.component';

describe('DmhFooterComponent', () => {
  let component: DmhFooterComponent;
  let fixture: ComponentFixture<DmhFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmhFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmhFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
