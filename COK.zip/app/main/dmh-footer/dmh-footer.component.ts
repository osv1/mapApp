import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dmh-footer',
  templateUrl: './dmh-footer.component.html',
  styleUrls: ['./dmh-footer.component.css']
})
export class DmhFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
