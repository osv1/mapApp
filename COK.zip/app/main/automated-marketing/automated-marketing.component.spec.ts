import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutomatedMarketingComponent } from './automated-marketing.component';

describe('AutomatedMarketingComponent', () => {
  let component: AutomatedMarketingComponent;
  let fixture: ComponentFixture<AutomatedMarketingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutomatedMarketingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutomatedMarketingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
