import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from '../../common/commonComponent';

@Component({
  selector: 'app-automated-marketing',
  templateUrl: './automated-marketing.component.html',
  styleUrls: ['./automated-marketing.component.css']
})
export class AutomatedMarketingComponent extends BaseComponent implements OnInit {
  registerUrl: any;

  constructor(inj: Injector) {
    super(inj);
  }

  ngOnInit() {
  }

  registerYourInterest() {
    this.registerUrl = this.constants.AMP_REGISTER_URL;
    window.open(this.registerUrl);
  }
}
