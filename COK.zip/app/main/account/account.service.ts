// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {from, Observable, Subject} from "rxjs";
import {CommonService} from "../../common/common.service";
@Injectable()
export class AccountService {


  private subject = new Subject<any>();

  constructor(private commonService : CommonService) {
  }

  getPreviousOrderDetails(pagination,filters) : Observable<any>{
    const observable = from(this.commonService.callApi('jobbagService/v1/reorder/jobbags?page='+pagination.page + '&fetchSize='+ pagination.fetchSize + '&filters='+filters, '','get', true));
    return observable;
  }

  reOrdersDetails(jobBagId): Observable<any>{
    const observable = from(this.commonService.callApi('jobbagService/v1/reorder/jobbag/'+jobBagId, '', 'post', true));
    return observable;
  }



}
