import {Component, OnInit, Injector} from '@angular/core';
import {Router, ActivatedRoute} from "@angular/router";
import {BaseComponent} from './../common/commonComponent';
import {UpdatePasswordComponent} from "../public/update-password/update-password.component";

declare var jQuery: any;

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html'
})
export class MainComponent extends BaseComponent implements OnInit {

  public firstIntialize: boolean = true;
  public passwordTimeout;
  public userDetails;
  public accessMain;
  constructor(inj: Injector, public activatedRoute: ActivatedRoute, public router: Router) {
    super(inj)
  }

  ngOnInit() {

    // setTimeout(() => {
    //   this.userDetails = JSON.parse(this.getToken('userDetail'))
    //   if(this.userDetails) {
    //    this.validatePasswordTimeOut();
    //   }
    // },1000)
  }

  validatePasswordTimeOut(){
    this.passwordTimeout = this.userDetails.passwordExpireDate;
    console.log(this.passwordTimeout);
    let updatedTimeStamp  = new Date().getTime();
    if(updatedTimeStamp > this.passwordTimeout){
      this.convertComponentToDom(UpdatePasswordComponent,'updateUserPassword-modal');
    }
  }

  ngAfterViewInit() {
    // customInput();
  }
}
