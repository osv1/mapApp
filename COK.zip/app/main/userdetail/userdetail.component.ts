import {Component, OnInit, Injector} from '@angular/core';
import {BaseComponent} from '../../common/commonComponent';
declare var $: any;


@Component({
    selector: 'app-user-detail',
    templateUrl: './userdetail.component.html',
    styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent extends BaseComponent implements OnInit {
    public previewUrl;
    public token;
    public breadcrumb = [];
    public getdetail;
    public userResponse;
    public userPreference;
    isEdit = false;

    constructor(inj: Injector) {
        super(inj);
        this.getuserdetail();
        this.getuserDetailImage();
    }

    ngOnInit() {
       this.getUserPreferance();
       this.getUserRoles();
    }


    getUserPreferance(){
      let data ={
        token : this.getToken('accessToken')
      }
      this.commonService.callApi('UserService/v1/user/preferences', data,'get',true).then((res: any) => {
        if(res) {
          if (res.statusCode === 200) {
            this.userPreference = res.instance;
          } else {
            this.commonService.displayToaster('error', res.message);
          }
        }
      })
    }

    getUserRoles(){
      let data ={
        token : this.getToken('accessToken')
      }
      this.commonService.callApi('UserService/v1/user/roles', data,'get',true).then((res: any) => {
        if (res.statusCode === 200) {
          this.userPreference = res.instance;
        } else {
          this.commonService.displayToaster('error',res.message);
        }
      })
    }
    getuserdetail() {
      let data ={
        token : this.getToken('accessToken')
      }
      this.commonService.callApi('UserService/v1/user/3589', data,'get',true).then((res: any) => {
        if (res.statusCode === 200) {
          this.userResponse = res.instance;
          this.userResponse.clientChoice = res.instance.clients[0].name;
        } else {
          this.commonService.displayToaster('error',res.message);
        }
      })
    }

    getuserDetailImage(){
      let data ={
        token : this.getToken('accessToken')
      }
      this.commonService.callApi('UserService/v1/user/avatar/3589', data,'get',true).then((res: any) => {
        console.log(res)
      })
    }

  // Crop image functionality
  imageChangedEvent: any = '';
  imageCoverChangedEvent: any = '';
  croppedImage: any = '';
  sliceSize: any;

  // modalRef: BsModalRef;



  hideModal(){
    this.closeModel();
  }
  loadImageFailed() {
    // this.modalRef.hide();
  }


  imageCoverCropped(event) {
    console.log(event);
    //this.count++;
    this.croppedImage = event.base64;
    var ImageURL = event.base64;
    // Split the base64 string in data and contentType
    var block = ImageURL.split(";");
    // Get the content type of the image
    var contentType = block[0].split(":")[1];// In this case "image/gif"
    // get the real base64 content of the file
    var realData = block[1].split(",")[1];// In this case "R0lGODlhPQBEAPeoAJosM...."

    // Convert it to a blob to upload
    this.b64toBlob(realData, contentType, this.sliceSize);

  }

  public file: any;
  b64toBlob(b64Data, contentType, sliceSize) {
    contentType = contentType || '';
    sliceSize = sliceSize || 512;
    var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, { type: contentType });
    this.file = new File([blob], "uploaded_file.jpg", { type: contentType, lastModified: Date.now() });
  }

  error;
  public filesize: any;
  public imageData2: any;
  validateProfileImage(event, template) {

    if (event.target.files.length) {
      var input = event.target;
      this.error = "";
      var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
      this.filesize = event.target.files[0].size / 1024 / 1024;
      console.log(this.filesize)
      if (this.filesize <= 15 && allowedExtensions.exec(event.target.value)) {
        this.imageChangedEvent = event;
        $('#parentLargeModal').modal('show');
        return true;
      } else if (!allowedExtensions.exec(event.target.value)) {
        this.error = "Please select jpeg, jpg or png file.";
        return false;
      }
      else if (this.filesize > 15) {
        this.error = "Please upload image less than 15MB.";
        return false;
      }
      return true;
    }
  }

  submitcropped() {
    this.closeModel();
    console.log(this.file);
    let data ={
      token : this.getToken('accessToken'),
      fileName : this.file.name
    }
    this.commonService.callApi('UserService/v1/user/avatar/upload/3589', data,'get',true,false).then((res: any) => {
      if (res.statusCode === 200) {
        console.log(res);
      } else {
        this.commonService.displayToaster('error', res.message)
      }
    });
  }


}
