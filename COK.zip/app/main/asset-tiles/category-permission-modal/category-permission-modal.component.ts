import {
  Component,
  OnInit,
  ChangeDetectorRef,
  Injector,
  ViewChild,
  ElementRef
} from '@angular/core';
import {FileUploader} from 'ng2-file-upload';
import {AssetTilesService} from '../asset-tiles.service';
import {BaseComponent} from '../../../common/commonComponent';

declare var $: any;
declare var moment: any;



@Component({
  selector: 'app-category-permission-modal',
  templateUrl: './category-permission-modal.component.html',
  styleUrls: ['./category-permission-modal.component.css'],
})


export class CategoryPermissionModalComponent extends BaseComponent implements OnInit {
  permModalCategoryName: any;
  clientPermStakeHolders: any = [];
  searchGroupVal = '';
  userPermStakeHoldersByClientCopy: any = [];
  searchUserVal = '';
  displayMessage: any;
  groupPermStakeHoldersByClientBup = {};
  errorMessage;
  permStakeHolders = [];
  userPermStakeHoldersByClientBup = {};
  groupPermStakeHoldersByClientCopy: any = [];
  groupPermStakeHoldersByClient: any = [];
  currentPermModalCategoryId = '';
  currentPermModalCatalogue = '';
  successMessage;
  groupPermByClients = {};
  userPermByClients = {};
  selectedClients = {};
  groupPermStakeHoldersByClientFinal: any = [];
  userPermStakeHoldersByClient: any = [];
  selectedClientIds = [];
  token: any;

  listPage: any = {
    rows: [],
    page: 1,
    pageSize: 100,
    totalSize: 0,
    sort: 'AssetName',
    dir: 'up',
    search: '',
    catalogue: this.isCCEP(),
    categoryID: 0,
    findDuplicate: false,
    searchCurrent: false
  };
  categories;
  permisisonCategories;
  public groupPermission :any ={};
  public groupOptions:any = {};
  public userOptions : any ={};
  public userPermissions : any ={};
  public catalogPermissions : any ={};
  public userPermissionGrants : any = {};
  public groupPermissionGrants : any ={};
  public groupPermissions : any ={};

  public selectedCategory;
  constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService) {
    super(inj);
  }


  ngOnInit() {
    // this.assetTilesService.tokenItems.subscribe((success: any) => {
    //   this.setTokenValue(success);
    // });
    // this.assetTilesService.permissionItems.subscribe((success: any) => {
    //   this.setPermisionValue(success);
    // });
    this.groupOptions.groups = [];
    this.getCategories()


  }

  clearAssetCategoryPermStakeHolders() {
    this.permStakeHolders = [];
    this.clientPermStakeHolders = [];
    this.groupPermByClients = {};
    this.userPermByClients = {};
    this.groupPermStakeHoldersByClient = {};
    this.userPermStakeHoldersByClient = [];
    this.groupPermStakeHoldersByClientBup = {};
    this.userPermStakeHoldersByClientBup = {};
    this.selectedClients = {};
    this.selectedClientIds = [];
  }

  setTokenValue(data) {
    this.token = data;
  }

  getCategories(){
    this.listPage.token = this.getToken('accessToken');
    this.listPage.uid = 0;
    this.listPage.fromDate = '';
    this.listPage.toDate = '';
    this.listPage.fetchSize = 100;
    this.listPage.order ='AssetName'

    let data = this.listPage
    const categoriesParams = this.serialize(data)
    this.assetTilesService.getAssetsCategoriesInRange(categoriesParams).subscribe((categoryAndAssetListPage: any) => {
      this.permisisonCategories = categoryAndAssetListPage.instance;
      this.categories = categoryAndAssetListPage.instance.categories;
      this.currentPermModalCategoryId = this.categories[0].categoryID
      console.log(this.categories);
      this.setPermisionValue()
    });
  }

  setPermisionValue() {
    this.searchGroupVal = '';
    this.searchUserVal = '';
    this.updateCategoryPermissionModalData(this.permisisonCategories, this.categories[0].categoryID);
    this.permModalCategoryName = this.categories[0].categoryName;
  }

  setNewCategory(data){
    console.log(data);
    this.searchGroupVal = '';
    this.searchUserVal = '';
    // this.updateCategoryPermissionModalData(this.permisisonCategories, data.target.value);
    this.currentPermModalCategoryId = data.target.value
    this.getUserPerrmissionsKey(data.target.value);
    this.permModalCategoryName = data.categoryName;
  }


  setNewGroupCategory(data){
    console.log(data);
    this.searchGroupVal = '';
    this.searchUserVal = '';
    // this.updateCategoryPermissionModalData(this.permisisonCategories, data.target.value);
    this.currentPermModalCategoryId = data.target.value
    this.getGroupsPerrmissionsKey(data.target.value);
    this.permModalCategoryName = data.categoryName;
  }

  getUserPerrmissionsKey(categoryId){
      let data = {
        categoryId: parseInt(categoryId, 0),
        catalog : this.isCCEP(),
      }

    let serializeData = {
      token : this.getToken('accessToken'),
      clientIDs : ','+ Number(this.catalogPermissions[0].key) + ','
    }
    const serializeParams = this.serialize(serializeData)
    this.assetTilesService.getUserPermission(data,serializeParams).subscribe((res :any) => {
      console.log(res);
      if(res.statusCode === 200){
        this.userPermissionGrants = res.instance;
        this.checkAllCommonHighlighted();
      }
    })
  }

  getGroupsPerrmissionsKey(categoryId){

    let data = {
      categoryId: parseInt(categoryId, 0),
      catalog : this.isCCEP(),
    }

    let serializeData = {
      token : this.getToken('accessToken'),
      clientIDs : ','+ Number(this.catalogPermissions[0].key) + ','
    }
    const serializeParams = this.serialize(serializeData)
    this.assetTilesService.getGroupPermission(data,serializeParams).subscribe((res :any) => {
      console.log(res);
      if(res.statusCode === 200){
        this.groupPermissionGrants = res.instance;
        this.checkAllCommonGroupHighlighted();
      }
    })
  }

  updateCategoryPermissionModalData(catalogue, categoryId) {
    this.clearAssetCategoryPermStakeHolders();
    // var ret = assetService.getPermissionStakeholders();
    let data = {
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getPermissionStakeholders(data).subscribe((permStakeHolders: any) => {
      this.permStakeHolders = permStakeHolders;
      this.catalogPermissions = this.permStakeHolders.filter(catalog => catalog.displayName === 'DMH');
      this.getUserPerrmissionsKey(categoryId);
      this.getGroupsPerrmissionsKey(categoryId);
      if (permStakeHolders) {
        for (let i = 0; i < permStakeHolders.length; i++) {
          if (permStakeHolders[i].description === 'client') {
            permStakeHolders[i].selected = false;
            this.clientPermStakeHolders[permStakeHolders[i].id] = permStakeHolders[i];
          }/*else if(permStakeHolders[i].description == ASSET_GROUP){
                         this.groupPermStakeHolders.push(permStakeHolders[i]);
                         }else if(permStakeHolders[i].description == ASSET_USER){
                         this.userPermStakeHolders.push(permStakeHolders[i]);
                         }*/
        }

        // fetch all the clients given permission
        // var retPermissionGrants = assetService.getFilestorCategoryPermissions(catalogue, categoryId, true);
        // TODO true or false
        let dataObj = {
          catalogue: catalogue.catalogue,
          categoryID: parseInt(categoryId, 0),
          reqAll: true,
          token: this.getToken('accessToken')
        }

        this.assetTilesService.getFilestorCategoryPermissions(dataObj).subscribe((permissionGrants: any) => {
          // this.commonService.callApiRestV2('RestService/category/getFilestorCategoryPermissions', this.attachToken({
          //   catalogue: catalogue,
          //   categoryID: parseInt(categoryId, 0),
          //   reqAll: true
          // }, this.token), 'post')
          //   .then((permissionGrants: any) => {
          if (permissionGrants) {

            // permissionGrants = $filter('orderBy')(permissionGrants, 'dispName');//sorting
            for (let i = 0; i < permissionGrants.length; i++) {
              if (permissionGrants[i].type === '1') {
                const clientId = permissionGrants[i].key;
                const clientDetail = this.clientPermStakeHolders[clientId];
                if (clientDetail) {
                  clientDetail.selected = true;
                  permissionGrants[i].modDate = this.utcToLocalDate(permissionGrants[i].modDate);
                  clientDetail.permission = permissionGrants[i];
                  this.selectedClients[clientId] = clientDetail;
                  this.selectedClientIds.push(clientId);
                }
              } else if (permissionGrants[i].type === '2') {
                const refIds = permissionGrants[i].refIDs;
                if (refIds) {
                  for (let innerIndex = 0; innerIndex < refIds.length; innerIndex++) {
                    const clientId = refIds[innerIndex];

                    let clientGroupPermByGroupIds = this.groupPermByClients[clientId];

                    if (!clientGroupPermByGroupIds) {
                      clientGroupPermByGroupIds = {};
                    }

                    clientGroupPermByGroupIds[permissionGrants[i].key] = permissionGrants[i];

                    this.groupPermByClients[clientId] = clientGroupPermByGroupIds;
                  }
                }

              } else if (permissionGrants[i].type === '3') {
                const refIds = permissionGrants[i].refIDs;
                if (refIds) {
                  for (let innerIndex = 0; innerIndex < refIds.length; innerIndex++) {
                    const clientId = refIds[innerIndex];

                    let clientUserPermByUserIds = this.userPermByClients[clientId];

                    if (!clientUserPermByUserIds) {
                      clientUserPermByUserIds = {};
                    }

                    clientUserPermByUserIds[permissionGrants[i].key] = permissionGrants[i];

                    this.userPermByClients[clientId] = clientUserPermByUserIds;
                  }
                }
              }
            }
            // fetch all the users and groups of selected clients
            this.userPermStakeHoldersByClient = [];
            if (this.selectedClientIds.length > 0) {
              let groupsData = {
                paramClientIDColl: this.selectedClientIds,
                token: this.getToken('accessToken')
              }
              this.assetTilesService.getGroupsAndUsersByMultipleClientID(groupsData).subscribe((clientUserGroups: any) => {
                // var clientUserGroupsRet = assetService.getGroupsAndUsersByMultipleClientID(this.selectedClientIds);
                // this.commonService.callApiRestV2('RestService/category/getGroupsAndUsersByMultipleClientID',
                //   this.attachToken({}, this.token), 'post')
                //   .then((clientUserGroups: any) => {
                console.log(clientUserGroups)
                if (clientUserGroups) {
                  for (const clientId in clientUserGroups) {
                    if (clientUserGroups.hasOwnProperty(clientId)) {
                      const userGroups = clientUserGroups[clientId];
                      if (userGroups && userGroups.length > 0) {
                        const clientPermGroups = this.groupPermByClients[clientId];
                        const clientPermUsers = this.userPermByClients[clientId];
                        const clientName = this.selectedClients[clientId].displayName;
                        const clientUsers = {};
                        const clientGroups = {};

                        for (let i = 0; i < userGroups.length; i++) {
                          const key = userGroups[i].key;
                          userGroups[i].clientName = clientName;
                          if (userGroups[i].description === 'group') {
                            if (clientPermGroups) {
                              const permissionVal = clientPermGroups[key];
                              if (permissionVal) {
                                if (permissionVal.r && permissionVal.w
                                  && permissionVal.d && permissionVal.n) {
                                  permissionVal.fullPerm = true;
                                } else {
                                  permissionVal.fullPerm = false;
                                }
                                permissionVal.modDate =
                                  this.utcToLocalDate(permissionVal.modDate);
                              }
                              userGroups[i].permission = permissionVal;
                            }
                            clientGroups[key] = userGroups[i];
                          } else if (userGroups[i].description === 'user') {
                            if (clientPermUsers) {
                              const permissionVal = clientPermUsers[key];
                              if (permissionVal) {
                                if (permissionVal.r && permissionVal.w && permissionVal.d
                                  && permissionVal.n) {
                                  permissionVal.fullPerm = true;
                                } else {
                                  permissionVal.fullPerm = false;
                                }
                                permissionVal.modDate =
                                  this.utcToLocalDate(permissionVal.modDate);
                              }
                              userGroups[i].permission = permissionVal;
                            }
                            clientUsers[key] = userGroups[i];
                          }
                        }

                        this.userPermStakeHoldersByClient[clientId] = clientUsers;
                        this.groupPermStakeHoldersByClient[clientId] = clientGroups;
                      }
                    }
                  }
                  // this.sortGroupAndUserStakeHolder();
                  // Reordering UI data
                  // this.groupPermStakeHoldersByClientBup = this.groupPermStakeHoldersByClient;

                  const displayClientPermStakeHolders = [];
                  for (const key in this.clientPermStakeHolders) {
                    if (key) {
                      displayClientPermStakeHolders.push(this.clientPermStakeHolders[key]);
                    }
                  }
                  const displaygroupPermStakeHoldersByClient = [];
                  for (const key in this.groupPermStakeHoldersByClient) {
                    if (key) {
                      displaygroupPermStakeHoldersByClient.push(this.groupPermStakeHoldersByClient[key]);
                    }
                  }
                  this.groupPermStakeHoldersByClientFinal = displaygroupPermStakeHoldersByClient;
                  console.log(this.groupPermStakeHoldersByClientFinal)
                  const displayData = [];
                  this.groupPermStakeHoldersByClientFinal.forEach((data: any) => {
                    for (const key in data) {
                      if (key) {
                        displayData.push(data[key]);
                      }
                    }
                  });
                  console.log(this.groupPermStakeHoldersByClientFinal)
                  const displayuserPerm: any = [];
                  this.userPermStakeHoldersByClient.forEach(data => {
                    for (const key in data) {
                      if (key) {
                        //setting multiple client in Single user.
                        if (displayuserPerm.length !== 0 && displayuserPerm.length >= 0) {
                          for (const dup in displayuserPerm) {
                            if (displayuserPerm[dup].key === data[key].key) { // checking user already exist or not
                              let user = data[key];
                              displayuserPerm[dup].clientNames = displayuserPerm[dup].clientNames + ', ' + user.clientName; // appending multiple clients
                            } else {
                              let user = data[key];
                              if (!user.clientNames && !this.isUserDuplicate(displayuserPerm, data[key].key)) {
                                data[key].clientNames = user.clientName;
                                displayuserPerm.push(data[key]);
                              }
                            }
                          }
                        } else {
                          let user = data[key];
                          data[key].clientNames = user.clientName;
                          displayuserPerm.push(data[key]);
                        }
                      }
                    }
                  });
                  this.userPermStakeHoldersByClient = displayuserPerm;
                  console.log(this.userPermStakeHoldersByClient);
                  this.userPermStakeHoldersByClientCopy = displayuserPerm;
                  this.groupPermStakeHoldersByClientFinal = displayData;
                  console.log(this.groupPermStakeHoldersByClientFinal)
                  this.groupPermStakeHoldersByClientCopy = displayData;
                  this.clientPermStakeHolders = displayClientPermStakeHolders;
                  this.userPermStakeHoldersByClientBup = this.userPermStakeHoldersByClient;
                  console.log(this.userPermStakeHoldersByClient);
                  this.currentPermModalCatalogue = catalogue;
                  this.currentPermModalCategoryId = categoryId;
                  // this.filterGroupBySearch();
                  // this.filterUserBySearch();
                }
              });
            }
          }
        });
      }
    });
  }

  // checking user exist in displayuserPerm
  isUserDuplicate(displayuserPerm, userId) {
    for (const dup in displayuserPerm) {
      if (userId && userId === displayuserPerm[dup].key) {
        return true;
      }
    }
    return false;
  }

  filterGroupBySearch() {


    this.groupPermStakeHoldersByClientFinal = JSON.parse(JSON.stringify(this.groupPermissionGrants));
    if (this.searchGroupVal) {
      this.groupPermissionGrants = this.groupPermStakeHoldersByClientFinal.filter(x => {
        if (x.name.toLowerCase().includes(this.searchGroupVal.toLowerCase())) {
          return true;
        }
        return false;
      });
    } else {
      this.groupPermissionGrants = this.groupPermStakeHoldersByClientFinal;
    }
  }

  filterUserBySearch() {
    this.userPermStakeHoldersByClientCopy = this.userPermStakeHoldersByClient;
    this.userPermStakeHoldersByClient = JSON.parse(JSON.stringify(this.userPermStakeHoldersByClientCopy));
    if (this.searchUserVal) {
      this.userPermStakeHoldersByClient = this.userPermStakeHoldersByClient.filter(x => {
        if (x.displayName.toLowerCase().includes(this.searchUserVal.toLowerCase())) {
          return true;
        }
        return false;
      });
    }
  }

  removeClientInCategoryPermission(event, clientId, dispName) {
    // var confirm = $mdDialog.confirm()
    //     .parent($('#categoryPermission_modal'))
    //     .title($translate('RemoveClientConfirmation'))
    //     .content($translate('content'))
    //     .ok($translate('ok'))
    //     .cancel($translate('cancel'))
    //     .targetEvent(event);
    //
    // $mdDialog.show(confirm).then(function () {   //Confirmed
    //     var permRet = assetService.removePermissionFromClient(clientId,dispName, $scope.currentPerm
    //     ModalCategoryId, $scope.currentPermModalCatalogue);
    //     permRet.then(function (response) {
    //         if( response.statusCode == '200' ) {
    //             $scope.updateCategoryPermissionModalData($scope.currentPermModalCatalogue, $scope.currentPermModalCategoryId);
    //             sharedService.displayToaster('success', [$translate('ClientPermissionDeleted')+
    //             $scope.currentPermModalCatalogue], 5000, $translate('Success'));
    //         }else{
    //             sharedService.displayToaster('error', [$translate('ErrorRemovingClientPermission')], 5000, $translate('Error'));
    //         }
    //     });
    // }, function () {
    //     //canceled
    // });
    let RemoveClientConfirmation: any;
    this.translate.get('RemoveClientConfirmation').subscribe((res: string) => {
      RemoveClientConfirmation = res;
    });
    let ok: any;
    this.translate.get('ok').subscribe((res: string) => {
      ok = res;
    });
    let Cancel: any;
    this.translate.get('Cancel').subscribe((res: string) => {
      Cancel = res;
    });
    let content: any;
    this.translate.get('content').subscribe((res: string) => {
      content = res;
    });
    this.swal({
      title: RemoveClientConfirmation,
      text: content,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      cancelButtonText: Cancel,
      confirmButtonText: ok
    }).then((result) => {
      if (result.value) {
        // var permRet = assetService.removePermissionFromClient(clientId,dispName, $scope.currentPerm
        //     ModalCategoryId, $scope.currentPermModalCatalogue);
        let upsertData ={
          token: this.getToken('accessToken'),
          categoryID: this.currentPermModalCategoryId,
          catalogue: this.currentPermModalCatalogue,
          doChildren: 1,
          clients: [{
            key: clientId,
            dispName: dispName,
            type: 1,
            downloadType: 'High',
            action: 3,
            r: true,
            w: true,
            d: true,
            n: true,
            e: true
          }]
        }

        this.assetTilesService.AssetsUpsertFilestorCategoryPermissions(upsertData).subscribe((response: any) => {
          // this.commonService.callApi(this.setSecurePath() + '/asset/upsertFilestorCategoryPermissions', this.attachToken({
          //   categoryID: this.currentPermModalCategoryId,
          //   catalogue: this.currentPermModalCatalogue,
          //   doChildren: 1,
          //   clients: [{
          //     key: clientId,
          //     dispName: dispName,
          //     type: 1,
          //     downloadType: 'High',
          //     action: 3,
          //     r: true,
          //     w: true,
          //     d: true,
          //     n: true,
          //     e: true
          //   }]
          // }), 'post').then((response: any) => {
          if (response.statusCode == '200') {
            this.updateCategoryPermissionModalData(this.currentPermModalCatalogue, this.currentPermModalCategoryId);
            let ClientPermissionDeleted: any;
            this.translate.get('ClientPermissionDeleted').subscribe((res: string) => {
              ClientPermissionDeleted = res;
            });
            this.translate.get('Success').subscribe((res: string) => {
              this.commonService.displayToaster('success', [ClientPermissionDeleted +
              this.currentPermModalCatalogue], 5000, res);
            });


          } else {
            let ErrorRemovingClientPermission: any;
            this.translate.get('ErrorRemovingClientPermission').subscribe((res: string) => {
              ErrorRemovingClientPermission = res;
            });
            this.translate.get('Error').subscribe((res: string) => {
              this.commonService.displayToaster('error', [ErrorRemovingClientPermission], 5000, res);
            });
          }
        });
      }
    });
  }

  givePermissionToClient(clientId, dispName) {
    let categoryData ={
      categoryID: parseInt(this.currentPermModalCategoryId, 0),
      token: this.getToken('accessToken'),
      catalogue: this.currentPermModalCatalogue,
      doChildren: 1,
      clients: [{
        key: clientId,
        dispName: dispName,
        type: 1,
        downloadType: 'High',
        action: 1,
        r: true,
        w: true,
        d: true,
        n: true,
        e: true
      }]
    }
    this.assetTilesService.categoryUpsertFilestorCategoryPermissions(categoryData).subscribe((response: any) => {
      // this.commonService.callApiRestV2('RestService/category/upsertFilestorCategoryPermissions', this.attachToken({
      //   categoryID: parseInt(this.currentPermModalCategoryId, 0),
      //   catalogue: this.currentPermModalCatalogue,
      //   doChildren: 1,
      //   clients: [{
      //     key: clientId,
      //     dispName: dispName,
      //     type: 1,
      //     downloadType: 'High',
      //     action: 1,
      //     r: true,
      //     w: true,
      //     d: true,
      //     n: true,
      //     e: true
      //   }]
      // }, this.token), 'post').then((response: any) => {
      if (response.statusCode === 200) {
        this.updateCategoryPermissionModalData(this.currentPermModalCatalogue, this.currentPermModalCategoryId);
        this.translate.get('ClientPermissionAdded').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('Success').subscribe((res: string) => {
          this.successMessage = res;
        });

        this.commonService.displayToaster('success', [this.displayMessage + this.currentPermModalCatalogue], 5000, this.successMessage);
      } else {
        this.translate.get('ErrorAddingClientPermission').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('Error').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
      }
    });
  }

  // assignFullPermissionToGroup(clientId, groupId, dispName, permission,event) {
  //   let groupData = {
  //     key: groupId,
  //     dispName: dispName,
  //     type: 2,
  //     downloadType: 'High',
  //     action: 2,
  //     r: true,
  //     w: true,
  //     d: true,
  //     n: true,
  //     e: true
  //   };
  //   console.log(permission,'permission')
  //   if(!event.target.checked) {
  //     groupData.r  = false;
  //     groupData.w = false;
  //     groupData.d = false;
  //     groupData.n =false;
  //   }
  //
  //   this.groupOptions.groups = [];
  //   this.groupPermStakeHoldersByClientFinal.map(res => {
  //     if (res.key.toString() === groupId.toString()) {
  //       res.permission = groupData;
  //       res.permission.fullPerm = true;
  //       if(!event.target.checked){
  //         res.permission.fullPerm = false;
  //       }
  //     }
  //
  //     if(res.permission){
  //       this.groupOptions.groups.push({
  //         action: res.permission.action,
  //         d: res.permission.d,
  //         dispName: res.permission.dispName,
  //         downloadType: res.permission.downloadType,
  //         e: res.permission.e,
  //         fullPerm: res.permission.fullPerm,
  //         key: res.permission.key,
  //         n: res.permission.n,
  //         r: res.permission.r,
  //         type: res.permission.type,
  //         w: res.permission.w,
  //       });
  //     } else{
  //       this.groupOptions.groups.push(groupData);
  //     }
  //   })
  //
  //
  //
  //   this.checkAllFullPermissionLength('full acess');
  //   console.log(this.groupOptions);
  //
  //
  //   let GroupPermissionUpdated;
  //   this.translate.get('GroupPermissionUpdated').subscribe((res: string) => {
  //     GroupPermissionUpdated = res;
  //   });
  //   let ErrorUpdatingPermission;
  //   this.translate.get('ErrorUpdatingPermission').subscribe((res: string) => {
  //     ErrorUpdatingPermission = res;
  //   });
  //   let GroupPermissionNotUpdated;
  //   this.translate.get('GroupPermissionNotUpdated').subscribe((res: string) => {
  //     GroupPermissionNotUpdated = res;
  //   });
  //   // this.updateGroupPermission(clientId, dispName, groupData, GroupPermissionUpdated
  //   //   , ErrorUpdatingPermission, GroupPermissionNotUpdated);
  // }

  savePermission(){
    this.updateGroupPermission('', '', this.groupOptions.groups, ''
      , '', '');
  }

  removeFullPermissionFromGroup(clientId, groupId, dispName, permission,event) {
    let actionVal;
    if (permission.e) {
      actionVal = 2;
    } else {
      actionVal = 3;
    }
    const groupData = {
      key: groupId,
      dispName: dispName,
      type: 2,
      downloadType: 'High',
      action: actionVal,
      r: false,
      w: false,
      d: false,
      n: false,
      e: permission.e
    };
    this.groupPermStakeHoldersByClientFinal.map(res => {
      console.log(res);
      if (res.key.toString() === groupId.toString() && event.target.checked) {
        res.permission = groupData;
        res.permission.fullPerm = false;
      }
    })
    // let GroupPermissionDeleted;
    // this.translate.get('GroupPermissionDeleted').subscribe((res: string) => {
    //   GroupPermissionDeleted = res;
    // });
    // let ErrorDeletingPermission;
    // this.translate.get('ErrorDeletingPermission').subscribe((res: string) => {
    //   ErrorDeletingPermission = res;
    // });
    // let GroupPermissionNotUpdated;
    // this.translate.get('GroupPermissionNotUpdated').subscribe((res: string) => {
    //   GroupPermissionNotUpdated = res;
    // });
    // this.updateGroupPermission(clientId, dispName, groupData, GroupPermissionDeleted
    //   , ErrorDeletingPermission, GroupPermissionNotUpdated);
  }


  allowGroupAllPermission(event,name){
    console.log(event.target.checked)
    let actionVal;
    if(event.target.checked){
      actionVal = 2;
      this.groupOptions.groups = [];
      if(name === 'full access'){
        const groupData = {
          type: 2,
          downloadType: 'High',
          action: actionVal,
          r: true,
          w: true,
          d: true,
          n: true,
          e: true
        };
        this.groupPermission.groupEmailAccess = true;
        this.groupPermission.groupFullDownloadAccess = false;
        this.groupPermStakeHoldersByClientFinal.map(res => {
          res.permission  = groupData;
          res.permission.fullPerm = true;
          this.assignPermission(res);
        })
      } else if(name === 'email'){
        this.groupPermStakeHoldersByClientFinal.map(res => {
          res.permission.e  = true;
          this.assignPermission(res);
        })
      }else if(name === 'download'){
        this.groupPermission.groupFullAccess = false;
        this.groupPermStakeHoldersByClientFinal.map(res => {
          if(res.permission) {
            res.permission.r = true;
            res.permission.w = false;
            res.permission.d = false;
            res.permission.n = true;
            res.permission.fullPerm = false;
            this.assignPermission(res);
          }
        })
      }
    } else {
      this.groupOptions.groups = [];
      if(name === 'full access'){
        this.groupPermStakeHoldersByClientFinal.map(res => {
          res.permission.r  = false;
          res.permission.w  = false;
          res.permission.d = false;
          res.permission.n = false;
          res.permission.fullPerm = false;
          this.assignPermission(res);
        })
      } else if(name === 'email'){
        this.groupPermStakeHoldersByClientFinal.map(res => {
          res.permission.e  = false;
          this.assignPermission(res);
        })
      }else if(name === 'download'){
        this.groupPermStakeHoldersByClientFinal.map(res => {
          res.permission.r = true;
          res.permission.w = false;
          res.permission.d = false;
          res.permission.n = false;
          this.assignPermission(res);
        })
      }
    }
    console.log(this.groupPermStakeHoldersByClientFinal);
  }


  assignPermission(res){
    console.log(res);
    if(res.permission) {
      this.groupOptions.groups.push({
        action: res.permission ? res.permission.action : 1,
        d: res.permission.d,
        dispName: res.displayName,
        downloadType: res.permission.downloadType,
        e: res.permission.e,
        key: res.key,
        n: res.permission.n,
        r: res.permission.r,
        type: res.permission.type,
        w: res.permission.w,
      });
    }
  }


  assignAllPermissionUsers(){

  }



  // assignDownloadPermissionToGroup(clientId, groupId, dispName, permission,event) {
  //   let actionVal;
  //   let emailPermission = false;
  //
  //   console.log(permission);
  //   if(event.target.checked) {
  //     if (permission) {
  //       actionVal = 2;
  //       emailPermission = permission.e;
  //     } else {
  //       actionVal = 1;
  //     }
  //     const groupData = {
  //       key: groupId,
  //       dispName: dispName,
  //       type: 2,
  //       downloadType: 'High',
  //       action: actionVal,
  //       r: true,
  //       w: false,
  //       d: false,
  //       n: true,
  //       e: emailPermission
  //     };
  //     this.groupOptions.groups = [];
  //     this.groupPermStakeHoldersByClientFinal.map(res => {
  //       console.log(res);
  //       if (res.key === groupId.toString()) {
  //         res.permission = groupData;
  //         res.permission.fullPerm = false;
  //       }
  //
  //       if(res.permission) {
  //         this.groupOptions.groups.push({
  //           action: res.permission ? res.permission.action : 1,
  //           d: res.permission.d,
  //           dispName: res.permission.dispName,
  //           downloadType: res.permission.downloadType,
  //           e: res.permission.e,
  //           fullPerm: res.permission.fullPerm,
  //           key: res.permission.key,
  //           n: res.permission.n,
  //           r: res.permission.r,
  //           type: res.permission.type,
  //           w: res.permission.w,
  //         });
  //       } else {
  //         this.groupOptions.groups.push(groupData);
  //       }
  //     })
  //
  //
  //   } else {
  //     const groupData: any = {key: groupId, dispName: dispName, type: 2, downloadType: 'High'};
  //     if (permission.r || permission.w || permission.d || permission.e) {
  //       groupData.action = 2;
  //       groupData.w = permission.w;
  //       groupData.d = permission.d;
  //       groupData.e = permission.e;
  //     } else {
  //       groupData.action = 3;
  //       groupData.w = false;
  //       groupData.d = false;
  //       groupData.e = false;
  //     }
  //     groupData.n = false;
  //     groupData.r = false;
  //     this.groupOptions.groups = [];
  //     this.groupPermStakeHoldersByClientFinal.map(res => {
  //       if (res.key.toString() === groupId.toString()) {
  //         res.permission = groupData;
  //         res.permission.fullPerm = false;
  //       }
  //       if(res.permission) {
  //         this.groupOptions.groups.push({
  //           action: res.permission.action,
  //           d: res.permission.d,
  //           dispName: res.permission.dispName,
  //           downloadType: res.permission.downloadType,
  //           e: res.permission.e,
  //           fullPerm: res.permission.fullPerm,
  //           key: res.permission.key,
  //           n: res.permission.n,
  //           r: res.permission.r,
  //           type: res.permission.type,
  //           w: res.permission.w,
  //         });
  //       } else {
  //         this.groupOptions.groups.push(groupData);
  //       }
  //     })
  //   }
  //   this.checkAllFullPermissionLength('download');
  // }


  checkAllFullPermissionLength(permission){
    let checkFullPerm =  [];
    let checkFullDownload = [];
    this.groupPermStakeHoldersByClientFinal.map(res => {
      if (res.permission) {
        if(permission === 'full access'){
          if (res.permission.r && res.permission.w && res.permission.d && res.permission.n) {
            checkFullPerm.push('true')
          }else {
            if (!res.permission.fullPerm && res.permission.n) {
              checkFullDownload.push('true')
            }
          }
        }
      }
    })
    if (checkFullDownload.length === this.groupPermStakeHoldersByClientFinal.length) {
      this.groupPermission.groupFullDownloadAccess = true;
    } else {
      this.groupPermission.groupFullDownloadAccess = false;
    }

    if(checkFullPerm.length === this.groupPermStakeHoldersByClientFinal.length){
      this.groupPermission.groupFullAccess = true;
    } else {
      this.groupPermission.groupFullAccess = false;
    }
  }

  removeDownloadPermissionFromGroup(clientId, groupId, dispName, permission) {
    const groupData: any = {key: groupId, dispName: dispName, type: 2, downloadType: 'High'};
    if (permission.r || permission.w || permission.d || permission.e) {
      groupData.action = 2;
      groupData.w = permission.w;
      groupData.d = permission.d;
      groupData.e = permission.e;
    } else {
      groupData.action = 3;
      groupData.w = false;
      groupData.d = false;
      groupData.e = false;
    }
    groupData.n = false;
    groupData.r = false;
    let GroupPermissionDeleted;
    this.translate.get('GroupPermissionDeleted').subscribe((res: string) => {
      GroupPermissionDeleted = res;
    });
    let ErrorDeletingPermission;
    this.translate.get('ErrorDeletingPermission').subscribe((res: string) => {
      ErrorDeletingPermission = res;
    });
    let GroupPermissionNotUpdated;
    this.translate.get('GroupPermissionNotUpdated').subscribe((res: string) => {
      GroupPermissionNotUpdated = res;
    });
    this.updateGroupPermission(clientId, dispName, groupData, GroupPermissionDeleted
      , ErrorDeletingPermission, GroupPermissionNotUpdated);
  }

  assignEmailPermissionToGroup(clientId, groupId, dispName, permission,event) {
    console.log(permission);
    if(event.target.checked) {
      const groupData: any = {key: groupId, dispName: dispName, type: 2, downloadType: 'High'};
      // if (permission) {
      //   groupData.action = 2;
      //   groupData.r = permission.r;
      //   groupData.w = permission.w;
      //   groupData.d = permission.d;
      // } else {
      //   groupData.action = 1;
      //   groupData.r = false;
      //   groupData.w = false;
      //   groupData.d = false;
      //   groupData.n = false;
      // }
      groupData.e = true;
      this.groupOptions.groups = [];
      this.groupPermStakeHoldersByClientFinal.map(res => {
        if (res.key.toString() === groupId.toString()) {
          // res.permission = groupData;
          res.permission.e = true;
        }
        if(res.permission) {
          this.groupOptions.groups.push({
            action: res.permission ? res.permission.action : 1,
            d: res.permission.d,
            dispName: res.permission.dispName,
            downloadType: res.permission.downloadType,
            e: res.permission.e,
            fullPerm: res.permission.fullPerm,
            key: groupData.key,
            n: res.permission.n,
            r: res.permission.r,
            type: res.permission.type,
            w: res.permission.w,
          });
        } else {
          groupData.action = 1;
          groupData.r = false;
          groupData.w = false;
          groupData.d = false;
          groupData.n = false;
          if (res.key.toString() === groupId.toString()) {
            groupData.e = true
          }
          this.groupOptions.groups.push(groupData);
        }
      })
      console.log(this.groupPermStakeHoldersByClientFinal);
      console.log(this.groupOptions);
    } else {
      const groupData: any = {key: groupId, dispName: dispName, type: 2, downloadType: 'High'};
      // if (permission.r || permission.w || permission.d || permission.n) {
      //   groupData.action = 2;
      //   groupData.r = permission.r;
      //   groupData.w = permission.w;
      //   groupData.d = permission.d;
      //   groupData.n = permission.n;
      // } else {
      //   groupData.action = 3;
      //   groupData.r = false;
      //   groupData.w = false;
      //   groupData.d = false;
      //   groupData.n = false;
      // }
      groupData.e = false;
      this.groupOptions.groups = [];
      this.groupPermStakeHoldersByClientFinal.map(res => {
        if (res.key.toString() === groupId.toString()) {
          // res.permission = groupData;
          res.permission.e = false;
        }
        if(res.permission) {
          this.groupOptions.groups.push({
            action: res.permission ? res.permission.action : 1,
            d: res.permission.d,
            dispName: res.permission.dispName,
            downloadType: res.permission.downloadType,
            e: res.permission.e,
            fullPerm: res.permission.fullPerm,
            key: groupData.key,
            n: res.permission.n,
            r: res.permission.r,
            type: res.permission.type,
            w: res.permission.w,
          });
        } else {
          groupData.action = 1;
          groupData.r = false;
          groupData.w = false;
          groupData.d = false;
          groupData.n = false;
          if (res.key.toString() === groupId.toString()) {
            groupData.e = true
          }
          this.groupOptions.groups.push(groupData);
        }
      })
    }

    let checkFullPerm =  [];
    this.groupPermStakeHoldersByClientFinal.map(res => {
      if(res.permission) {
        if (res.permission.e) {
          checkFullPerm.push('true')
        }
      }
    })
    if(checkFullPerm.length === this.groupPermStakeHoldersByClientFinal.length){
      this.groupPermission.groupEmailAccess = true;
    } else {
      this.groupPermission.groupEmailAccess = false;
    }
    let EmailGroupPermissionUpdated;
    this.translate.get('EmailGroupPermissionUpdated').subscribe((res: string) => {
      EmailGroupPermissionUpdated = res;
    });
    let ErrorUpdatingGroupEmailPermission;
    this.translate.get('ErrorUpdatingGroupEmailPermission').subscribe((res: string) => {
      ErrorUpdatingGroupEmailPermission = res;
    });
    let GroupPermissionNotUpdated;
    this.translate.get('GroupPermissionNotUpdated').subscribe((res: string) => {
      GroupPermissionNotUpdated = res;
    });
    // this.updateGroupPermission(clientId, dispName, groupData, EmailGroupPermissionUpdated
    //   , ErrorUpdatingGroupEmailPermission, GroupPermissionNotUpdated);
  }

  // removeEmailPermissionFromGroup(clientId, groupId, dispName, permission) {
  //   const groupData: any = {key: groupId, dispName: dispName, type: 2, downloadType: 'High'};
  //   if (permission.r || permission.w || permission.d || permission.n) {
  //     groupData.action = 2;
  //     groupData.r = permission.r;
  //     groupData.w = permission.w;
  //     groupData.d = permission.d;
  //     groupData.n = permission.n;
  //   } else {
  //     groupData.action = 3;
  //     groupData.r = false;
  //     groupData.w = false;
  //     groupData.d = false;
  //     groupData.n = false;
  //   }
  //   groupData.e = false;
  //   let EmailGroupPermissionDeleted;
  //   this.translate.get('EmailGroupPermissionDeleted').subscribe((res: string) => {
  //     EmailGroupPermissionDeleted = res;
  //   });
  //   let ErrorDeletingGroupEmailPermission;
  //   this.translate.get('ErrorDeletingGroupEmailPermission').subscribe((res: string) => {
  //     ErrorDeletingGroupEmailPermission = res;
  //   });
  //   let GroupPermissionNotUpdated;
  //   this.translate.get('GroupPermissionNotUpdated').subscribe((res: string) => {
  //     GroupPermissionNotUpdated = res;
  //   });
  //   this.updateGroupPermission(clientId, dispName, groupData, EmailGroupPermissionDeleted
  //     , ErrorDeletingGroupEmailPermission, GroupPermissionNotUpdated);
  // }






  // allUsersFullPermission(event){
  //   if(event.target.checked){
  //     this.userPermissions.noAccess = false;
  //     this.userPermissions.download = false;
  //     this.userPermissions.fullAccess = true;
  //     this.userPermStakeHoldersByClient.map(res => {
  //       const userData = {
  //         key: res.key,
  //         dispName: res.displayName,
  //         type: 3,
  //         downloadType: 'High',
  //         action: 2,
  //         r: true,
  //         w: true,
  //         d: true,
  //         n: true,
  //         e: true,
  //       };
  //       res.permission = userData;
  //       res.permission.fullPerm = true;
  //       res.permission.noAccess = false;
  //     })
  //   } else {
  //     this.userPermissions.download = false;
  //     this.userPermStakeHoldersByClient.map(res => {
  //         const userData = {
  //           key: res.key,
  //           dispName: res.displayName,
  //           type: 3,
  //           downloadType: 'High',
  //           action: 2,
  //           r: false,
  //           w: false,
  //           d: false,
  //           n: false,
  //           e: false,
  //           noAccess :false
  //         };
  //         res.permission = userData;
  //     })
  //   }
  // }
  //
  // allUsersNoAccessPermission(event){
  //   if(event.target.checked){
  //     this.userPermissions.download = false;
  //     this.userPermissions.fullAccess = false;
  //     this.userPermissions.noAccess = true;
  //     this.userPermStakeHoldersByClient.map(res => {
  //         const userData = {
  //           key: res.key,
  //           dispName: res.displayName,
  //           type: 3,
  //           downloadType: 'High',
  //           action: 2,
  //           r: false,
  //           w: false,
  //           d: false,
  //           n: false,
  //           e: false,
  //           noAccess :true
  //         };
  //         res.permission = userData;
  //         res.permission.fullPerm = false;
  //     })
  //   } else {
  //     this.userPermStakeHoldersByClient.map(res => {
  //       if(res.permission) {
  //         res.permission.r = false,
  //           res.permission.w = false,
  //           res.permission.d = false,
  //           res.permission.n = false,
  //           res.permission.e = false,
  //           res.permission.noAccess = false;
  //       } else {
  //         const userData = {
  //           key: res.key,
  //           dispName: res.displayName,
  //           type: 3,
  //           downloadType: 'High',
  //           action: 2,
  //           r: false,
  //           w: false,
  //           d: false,
  //           n: false,
  //           e: false,
  //           noAccess :false
  //         };
  //         res.permission = userData;
  //       }
  //     })
  //   }
  // }

  // assignFullPermissionToUser(clientId, userId, dispName, permission,event) {
  //     let actionVal;
  //     let emailPermission = false;
  //     if (permission) {
  //       actionVal = 2;
  //       emailPermission = permission.e;
  //     } else {
  //       actionVal = 1;
  //     }
  //   if(event.target.checked) {
  //     const userData = {
  //       key: userId,
  //       dispName: dispName,
  //       type: 3,
  //       downloadType: 'High',
  //       action: actionVal,
  //       r: true,
  //       w: true,
  //       d: true,
  //       n: true,
  //       e: true
  //     };
  //     this.userOptions.users = [];
  //     this.userPermStakeHoldersByClient.map(res => {
  //       if(res.key.toString() === userId.toString()){
  //           res.permission = userData;
  //           res.permission.fullPerm = true;
  //           res.permission.noAccess = false;
  //       }
  //       this.userOptions.users.push(userData);
  //     })
  //   } else {
  //     const userData = {
  //       key: userId,
  //       dispName: dispName,
  //       type: 3,
  //       downloadType: 'High',
  //       action: actionVal,
  //       r: false,
  //       w: false,
  //       d: false,
  //       n: false,
  //       e: false
  //     };
  //     this.userOptions.users = [];
  //     this.userPermStakeHoldersByClient.map(res => {
  //       if(res.key.toString() === userId.toString()){
  //         res.permission = userData;
  //         res.permission.fullPerm = false;
  //       }
  //       this.userOptions.users.push(userData);
  //     })
  //   }
  //   let UserPermissionUpdated;
  //   this.translate.get('UserPermissionUpdated').subscribe((res: string) => {
  //     UserPermissionUpdated = res;
  //   });
  //   let ErrorUpdatingUserPermission;
  //   this.translate.get('ErrorUpdatingUserPermission').subscribe((res: string) => {
  //     ErrorUpdatingUserPermission = res;
  //   });
  //   let UserPermissionNotUpdated;
  //   this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
  //     UserPermissionNotUpdated = res;
  //   });
  //   // this.updateUserPermission(clientId, dispName, userData, UserPermissionUpdated
  //   //   , ErrorUpdatingUserPermission, UserPermissionNotUpdated);
  // }

  removeFullPermissionFromUser(clientId, userId, dispName, permission) {
    let actionVal;
    if (permission.e) {
      actionVal = 2;
    } else {
      actionVal = 3;
    }
    const userData = {
      key: userId,
      dispName: dispName,
      type: 3,
      downloadType: 'High',
      action: actionVal,
      r: false,
      w: false,
      d: false,
      n: false,
      e: permission.e
    };
    let UserPermissionDeleted;
    this.translate.get('UserPermissionDeleted').subscribe((res: string) => {
      UserPermissionDeleted = res;
    });
    let ErrorDeletingUserPermission;
    this.translate.get('ErrorDeletingUserPermission').subscribe((res: string) => {
      ErrorDeletingUserPermission = res;
    });
    let UserPermissionNotUpdated;
    this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
      UserPermissionNotUpdated = res;
    });
    this.updateUserPermission(clientId, dispName, userData, UserPermissionDeleted
      , ErrorDeletingUserPermission, UserPermissionNotUpdated);
  }


  // ----------------------------------------------- START DOWNLOAD ONLY FUNCTIONALITY ------------------------------------

  assignDownloadPermissionToUser(clientId, userId, dispName, permission,event) {
    if(event.target.checked) {
      this.userOptions.users = [];
      this.userPermissionGrants.map(res => {
        if(res.uid.toString() === userId.toString()){
          res.r = true;
          res.w = false;
          res.d = false;
          res.n = true;
          res.noAccess = false
        }
      })
    } else {
      this.userPermissionGrants.map(res => {
        if(res.uid.toString() === userId.toString()){
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
          res.noAccess = false
        }
      })
    }

    this.checkAllCommonHighlighted();
  }

  allUsersDownloadPermission(event){
    if(event.target.checked) {
      this.userOptions.users = [];
      this.userPermissionGrants.map(res => {
        res.r = true;
        res.w = false;
        res.d = false;
        res.n = true;
        res.noAccess = false
      })
    } else {
      this.userPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
        res.noAccess = false
      })
    }
    this.checkAllCommonHighlighted();
  }

  // ------------------------------------------------------------------------------------------------------------


  // ----------------------------------------------- START NO ACCESS FUNCTIONALITY ------------------------------------
  assignNoAccessToUser(clientId, userId, dispName, permission,event){
    if(event.target.checked) {
      this.userPermissionGrants.map(res => {
        if(res.uid.toString() === userId.toString()){
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
          res.noAccess = true;
        }
      })
    } else {
      this.userPermissionGrants.map(res => {
        if(res.uid.toString() === userId.toString()){
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
          res.noAccess = false;
        }
      })
    }

    this.checkAllCommonHighlighted();
  }

  allUsersNoAccessPermission(event){
    if(event.target.checked) {
      this.userPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
        res.noAccess = true;
      })
    } else {
      this.userPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
        res.noAccess = false
      })
    }
    this.checkAllCommonHighlighted();
  }


  // ------------------------------------------------------------------------------------------------------------


  // ----------------------------------------------- START FULL PERMISSION FUNCTIONALITY ------------------------------------
  assignFullPermissionToUser(clientId, userId, dispName, permission,event){
    if(event.target.checked) {
      this.userPermissionGrants.map(res => {
        if(res.uid.toString() === userId.toString()) {
          res.r = true;
          res.w = true;
          res.d = true;
          res.n = true;
        }
      })
    } else {
      this.userPermissionGrants.map(res => {
        if(res.uid.toString() === userId.toString()) {
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
        }
      })
    }

    this.checkAllCommonHighlighted();
  }

  allUsersFullPermission(event){
    if(event.target.checked) {
      this.userOptions.users = [];
      this.userPermissionGrants.map(res => {
        res.r = true;
        res.w = true;
        res.d = true;
        res.n = true;
      })
    } else {
      this.userPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
      })
    }
    this.checkAllCommonHighlighted();
  }

  // ------------------------------------------------------------------------------------------------------------


  // Note : Common highlighted function is used to check which permission have all selected values

  checkAllCommonHighlighted(){
    let downloadSelectedArray = [];
    let noAccessSelectedArray = [];
    let fullAccessSelectedArray = []
    this.userPermissionGrants.map(res => {
      if((!res.n && !res.r && !res.d && !res.w) || res.noAccess){
        noAccessSelectedArray.push(res);
      }
      if(res.n  && res.r  && !res.d && !res.w){
        downloadSelectedArray.push(res);
      }
      if(res.n && res.r && res.d  && res.w ){
        fullAccessSelectedArray.push(res);
      }

    })

    if(this.userPermissionGrants.length == downloadSelectedArray.length){
      this.userPermissions.download = true;
    } else {
      this.userPermissions.download = false;
    }

    if(this.userPermissionGrants.length == noAccessSelectedArray.length){
      this.userPermissions.noAccess = false;
      this.userPermissions.noAccess = true;
    } else {
      this.userPermissions.noAccess = false;
    }

    if(this.userPermissionGrants.length == fullAccessSelectedArray.length){
      this.userPermissions.fullAccess = true;
    } else {
      this.userPermissions.fullAccess = false;
    }

    // ------------------------------------------------------------------------------------------------------------
  }




  // ------------------------------------------ GROUPS PERMISSION STARTED ---------------------------------------------

  // ----------------------------------------------- START DOWNLOAD ONLY FUNCTIONALITY ------------------------------------

  assignDownloadPermissionToGroup(clientId, userId, dispName, permission,event) {
    if(event.target.checked) {
      this.userOptions.users = [];
      this.groupPermissionGrants.map(res => {
        if(res.gid.toString() === userId.toString()){
          res.r = true;
          res.w = false;
          res.d = false;
          res.n = true;
          res.noAccess = false
        }
      })
    } else {
      this.groupPermissionGrants.map(res => {
        if(res.gid.toString() === userId.toString()){
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
          res.noAccess = false
        }
      })
    }

    this.checkAllCommonGroupHighlighted();
  }

  allGroupsDownloadPermission(event){
    if(event.target.checked) {
      this.userOptions.users = [];
      this.groupPermissionGrants.map(res => {
        res.r = true;
        res.w = false;
        res.d = false;
        res.n = true;
        res.noAccess = false
      })
    } else {
      this.groupPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
        res.noAccess = false
      })
    }
    this.checkAllCommonGroupHighlighted();
  }

  // ------------------------------------------------------------------------------------------------------------

  // ----------------------------------------------- START NO ACCESS FUNCTIONALITY ------------------------------------
  assignNoAccessToGroup(clientId, userId, dispName, permission,event){
    if(event.target.checked) {
      this.groupPermissionGrants.map(res => {
        if(res.gid.toString() === userId.toString()){
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
          res.noAccess = true;
        }
      })
    } else {
      this.groupPermissionGrants.map(res => {
        if(res.gid.toString() === userId.toString()){
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
          res.noAccess = false;
        }
      })
    }

    this.checkAllCommonGroupHighlighted();
  }

  allGroupsNoAccessPermission(event){
    if(event.target.checked) {
      this.groupPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
        res.noAccess = true;
      })
    } else {
      this.groupPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
        res.noAccess = false
      })
    }
    this.checkAllCommonGroupHighlighted();
  }


  // ------------------------------------------------------------------------------------------------------------


  // ----------------------------------------------- START FULL PERMISSION FUNCTIONALITY ------------------------------------
  assignFullPermissionToGroup(clientId, userId, dispName, permission,event){
    if(event.target.checked) {
      this.groupPermissionGrants.map(res => {
        if(res.gid.toString() === userId.toString()) {
          res.r = true;
          res.w = true;
          res.d = true;
          res.n = true;
        }
      })
    } else {
      this.groupPermissionGrants.map(res => {
        if(res.gid.toString() === userId.toString()) {
          res.r = false;
          res.w = false;
          res.d = false;
          res.n = false;
        }
      })
    }

    this.checkAllCommonGroupHighlighted();
  }

  allGroupsFullPermission(event){
    if(event.target.checked) {
      this.userOptions.users = [];
      this.groupPermissionGrants.map(res => {
        res.r = true;
        res.w = true;
        res.d = true;
        res.n = true;
        res.noAccess = false;
      })
    } else {
      this.groupPermissionGrants.map(res => {
        res.r = false;
        res.w = false;
        res.d = false;
        res.n = false;
      })
    }
    this.checkAllCommonGroupHighlighted();
  }

  // ------------------------------------------------------------------------------------------------------------



  // Note : Common highlighted function is used to check which  permission have all selected values

  checkAllCommonGroupHighlighted(){
    let downloadSelectedArray = [];
    let noAccessSelectedArray = [];
    let fullAccessSelectedArray = []
    this.groupPermissionGrants.map(res => {
      if((!res.n && !res.r && !res.d && !res.w)){
        noAccessSelectedArray.push(res);
      }
      if(res.n  && res.r  && !res.d && !res.w){
        downloadSelectedArray.push(res);
      }
      if(res.n && res.r && res.d  && res.w ){
        fullAccessSelectedArray.push(res);
      }

    })

    if(this.groupPermissionGrants.length == downloadSelectedArray.length){
      this.groupPermissions.download = true;
    } else {
      this.groupPermissions.download = false;
    }

    if(this.groupPermissionGrants.length == noAccessSelectedArray.length){
      this.groupPermissions.noAccess = false;
      this.groupPermissions.noAccess = true;
    } else {
      this.groupPermissions.noAccess = false;
    }

    if(this.groupPermissionGrants.length == fullAccessSelectedArray.length){
      this.groupPermissions.fullAccess = true;
    } else {
      this.groupPermissions.fullAccess = false;
    }

    // ------------------------------------------------------------------------------------------------------------
  }

  removeDownloadPermissionFromUser(clientId, userId, dispName, permission) {
    const userData: any = {key: userId, dispName: dispName, type: 3, downloadType: 'High'};
    if (permission.r || permission.w || permission.d || permission.e) {
      userData.action = 2;
      userData.w = permission.w;
      userData.d = permission.d;
      userData.e = permission.e;
    } else {
      userData.action = 3;
      userData.w = false;
      userData.d = false;
      userData.e = false;
    }
    userData.n = false;
    userData.r = false;
    let UserPermissionDeleted;
    this.translate.get('UserPermissionDeleted').subscribe((res: string) => {
      UserPermissionDeleted = res;
    });
    let ErrorDeletingUserPermission;
    this.translate.get('ErrorDeletingUserPermission').subscribe((res: string) => {
      ErrorDeletingUserPermission = res;
    });
    let UserPermissionNotUpdated;
    this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
      UserPermissionNotUpdated = res;
    });
    this.updateUserPermission(clientId, dispName, userData, UserPermissionDeleted
      , ErrorDeletingUserPermission, UserPermissionNotUpdated);
  }

  assignEmailPermissionToUser(clientId, userId, dispName, permission) {
    const userData: any = {key: userId, dispName: dispName, type: 3, downloadType: 'High'};

    if (permission) {
      userData.action = 2;
      userData.r = permission.r;
      userData.w = permission.w;
      userData.d = permission.d;
      userData.n = permission.n;
    } else {
      userData.action = 1;
      userData.r = false;
      userData.w = false;
      userData.d = false;
      userData.n = false;
    }
    userData.e = true;
    let EmailUserPermissionUpdated;
    this.translate.get('EmailUserPermissionUpdated').subscribe((res: string) => {
      EmailUserPermissionUpdated = res;
    });
    let ErrorUpdatingUserEmailPermission;
    this.translate.get('ErrorUpdatingUserEmailPermission').subscribe((res: string) => {
      ErrorUpdatingUserEmailPermission = res;
    });
    let UserPermissionNotUpdated;
    this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
      UserPermissionNotUpdated = res;
    });
    this.updateUserPermission(clientId, dispName, userData, EmailUserPermissionUpdated
      , ErrorUpdatingUserEmailPermission, UserPermissionNotUpdated);
  }

  removeEmailPermissionFromUser(clientId, userId, dispName, permission) {
    const userData: any = {key: userId, dispName: dispName, type: 3, downloadType: 'High'};
    if (permission.r || permission.w || permission.d || permission.n) {
      userData.action = 2;
      userData.r = permission.r;
      userData.w = permission.w;
      userData.d = permission.d;
      userData.n = permission.n;
    } else {
      userData.action = 3;
      userData.r = false;
      userData.w = false;
      userData.d = false;
      userData.n = false;
    }
    userData.e = false;
    let EmailUserPermissionDeleted;
    this.translate.get('EmailUserPermissionDeleted').subscribe((res: string) => {
      EmailUserPermissionDeleted = res;
    });
    let ErrorDeletingUserEmailPermission;
    this.translate.get('ErrorDeletingUserEmailPermission').subscribe((res: string) => {
      ErrorDeletingUserEmailPermission = res;
    });
    let UserPermissionNotUpdated;
    this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
      UserPermissionNotUpdated = res;
    });
    this.updateUserPermission(clientId, dispName, userData, EmailUserPermissionDeleted
      , ErrorDeletingUserEmailPermission, UserPermissionNotUpdated);
  }

  saveUserPermission(){
    let EmailUserPermissionDeleted;
    this.translate.get('UserPermissionUpdated').subscribe((res: string) => {
      EmailUserPermissionDeleted = res;
    });
    let ErrorDeletingUserEmailPermission;
    this.translate.get('ErrorDeletingUserEmailPermission').subscribe((res: string) => {
      ErrorDeletingUserEmailPermission = res;
    });
    let UserPermissionNotUpdated;
    this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
      UserPermissionNotUpdated = res;
    });
    this.updateUserPermission('', '', this.userPermissionGrants, EmailUserPermissionDeleted
      , ErrorDeletingUserEmailPermission, UserPermissionNotUpdated);
  }

  savePermissionGroups(){
    let EmailUserPermissionDeleted;
    this.translate.get('UserPermissionUpdated').subscribe((res: string) => {
      EmailUserPermissionDeleted = res;
    });
    let ErrorDeletingUserEmailPermission;
    this.translate.get('ErrorDeletingUserEmailPermission').subscribe((res: string) => {
      ErrorDeletingUserEmailPermission = res;
    });
    let UserPermissionNotUpdated;
    this.translate.get('UserPermissionNotUpdated').subscribe((res: string) => {
      UserPermissionNotUpdated = res;
    });
    this.updateGroupPermission('', '', this.groupPermissionGrants, EmailUserPermissionDeleted
      , ErrorDeletingUserEmailPermission, UserPermissionNotUpdated);
  }


  updateUserPermission(clientId, dispName, userData, successMessage, errorMessage, noUpdateMessage) {
    // key,dispName,type,downloadType,action,r,w,d,n,e


    let userPermisisonData = [];
    this.userPermissionGrants.map(res => {
      if(res){
        userPermisisonData.push({
          UID: Number(res.uid),
          key : Number(res.uid),
          dispName: res.name,
          downloadType : "High",
          action : 2,
          type : 3,
          r: res.r === 1 || res.r === true ? true : false,
          w: res.w === 1 || res.w === true ? true : false,
          d: res.d === 1 || res.d === true  ? true : false,
          n: res.n === 1 || res.n === true ? true : false,
        })
      }
    })

    console.log(userPermisisonData)
    let uId = JSON.parse(this.getToken('userDetail')).userID;
    // let categoryData ={
    //   token: this.getToken('accessToken'),
    //   categoryID: parseInt(this.currentPermModalCategoryId, 0),
    //   catalogue: this.isCCEP(),
    //   doChildren: 1,
    //   users: userPermisisonData,
    //   UID : uId
    // }


    let categoryData = {
      users: userPermisisonData,
      clientIDs : ','+ Number(this.catalogPermissions[0].key) + ','
    }

    this.assetTilesService.updateUserPermissions(this.isCCEP(),this.currentPermModalCategoryId,categoryData).subscribe((response: any) => {
      // this.commonService.callApiRestV2('RestService/category/upsertFilestorCategoryPermissions', this.attachToken({
      //   categoryID: parseInt(this.currentPermModalCategoryId, 0),
      //   catalogue: this.currentPermModalCatalogue,
      //   doChildren: 1,
      //   users: [userData]
      // }, this.token), 'post').then((response: any) => {
      this.commonService.displayToaster('success', response.message, 5000, this.successMessage);
      // if (response.instance.statusCode === 200) {
      //   if (response.key !== 'message.noChangesMade') {
      //     this.updateCategoryPermissionModalData(this.currentPermModalCatalogue, this.currentPermModalCategoryId);
      //     this.translate.get('Success').subscribe((res: string) => {
      //       this.successMessage = res;
      //     });
      //     this.commonService.displayToaster('success', response.message, 5000, this.successMessage);
      //   } else {
      //     this.translate.get('Success').subscribe((res: string) => {
      //       this.successMessage = res;
      //     });
      //     this.commonService.displayToaster('info', [noUpdateMessage], 5000, this.successMessage);
      //   }
      // } else {
      //   this.translate.get('Error').subscribe((res: string) => {
      //     this.errorMessage = res;
      //   });
      //   this.commonService.displayToaster('error', [errorMessage], 5000, this.errorMessage);
      // }
    });
  }

  updateGroupPermission(clientId, dispName, groupData, successMessage, errorMessage, noUpdateMessage) {
    // var permRet = assetService.updateGroupPermission(clientId, this.currentPermModalCategoryId,
    // $scope.currentPermModalCatalogue, groupData);

    // console.log(JSON.parse(this.getToken('userDetail')).userID)
    // let uId = JSON.parse(this.getToken('userDetail')).userID;
    // let categoryData ={
    //   token: this.getToken('accessToken'),
    //   categoryID: 0,
    //   catalogue: this.isCCEP(),
    //   doChildren: 1,
    //   groups: groupData,
    //   UID : uId
    // }

    // debugger;

    let groupPermissionData = [];
    this.groupPermissionGrants.map(res => {
      if(res){
        groupPermissionData.push({
          UID: Number(res.gid),
          key : Number(res.gid),
          dispName: res.name,
          downloadType : "High",
          action : 2,
          type : 3,
          r: res.r === 1 || res.r === true ? true : false,
          w: res.w === 1 || res.w === true ? true : false,
          d: res.d === 1 || res.d === true  ? true : false,
          n: res.n === 1 || res.n === true ? true : false,
        })
      }
    })


    console.log(this.groupPermissionGrants)

    console.log(groupPermissionData)
    let uId = JSON.parse(this.getToken('userDetail')).userID;
    // let categoryData ={
    //   token: this.getToken('accessToken'),
    //   categoryID: parseInt(this.currentPermModalCategoryId, 0),
    //   catalogue: this.isCCEP(),
    //   doChildren: 1,
    //   users: userPermisisonData,
    //   UID : uId
    // }


    let categoryData = {
      groups: groupPermissionData,
      clientIDs : ','+ Number(this.catalogPermissions[0].key) + ','
    }

    console.log(categoryData)

    this.assetTilesService.updateGroupPermissions(this.isCCEP(),this.currentPermModalCategoryId,categoryData).subscribe((response: any) => {

      this.commonService.displayToaster('success', response.message, 5000, this.successMessage);
      // this.commonService.callApiRestV2('RestService/category/upsertFilestorCategoryPermissions', this.attachToken({
      //   categoryID: parseInt(this.currentPermModalCategoryId, 0),
      //   catalogue: this.currentPermModalCatalogue,
      //   doChildren: 1,
      //   groups: [groupData]
      // }, this.token), 'post').then((response: any) => {
      // if (response.statusCode === 200) {
      //   if (response.key !== 'message.noChangesMade') {
      //     this.updateCategoryPermissionModalData(this.currentPermModalCatalogue, this.currentPermModalCategoryId);
      //     this.translate.get('Success').subscribe((res: string) => {
      //       this.successMessage = res;
      //     });
      //     this.commonService.displayToaster('success', [successMessage], 5000, this.successMessage);
      //   } else {
      //     this.translate.get('Success').subscribe((res: string) => {
      //       this.successMessage = res;
      //     });
      //     this.commonService.displayToaster('info', [noUpdateMessage], 5000, this.successMessage);
      //   }
      // } else {
      //   this.translate.get('Error').subscribe((res: string) => {
      //     this.errorMessage = res;
      //   });
      //   this.commonService.displayToaster('error', [errorMessage], 5000, this.errorMessage);
      // }
    });
  }
}
