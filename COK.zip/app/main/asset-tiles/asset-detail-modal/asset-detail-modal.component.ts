import {
    Component,
    OnInit,
    ChangeDetectorRef,
    Injector
} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {AssetTilesService} from "../asset-tiles.service";
import {AssetPublishModalComponent} from '../asset-publish-modal/asset-publish-modal.component';
import {constants} from '../../../common/constants';
declare var $: any;
declare var moment: any;

@Component({
    selector: 'app-asset-detail-modal',
    templateUrl: './asset-detail-modal.component.html',
    styleUrls: ['./asset-detail-modal.component.css'],
})
export class AssetDetailModalComponent extends BaseComponent implements OnInit {
    assetLisItems = [];
    assetIndex: any;
    publishAssetIdx = -1;
    errorMessage;
    successMessage;
    publishCategoryPoints;
    public userClientID: any;
    listPage: any = {
        rows: [],
        page: 0,
        pageSize: 100,
        totalSize: 0,
        sort: 'AssetName',
        dir: 'up',
        search: '',
        catalogue: 'Assets',
        categoryID: -1,
        findDuplicate: false,
        searchCurrent: false
    };
    publishAsset = null;
    allpublishCategoryPoints: any;
    assetShare: any = {emails: '', disabled: false, message: ''};
    assetDetails: any = {};
    assetThumbnailUrl = 'https://goworks.ergoengineering.com/CM/CM/previewService/get/asset';
    token;
    categoryPermission = {value: 0, read: false, write: false, 'delete': false, download: false, email: false};
    currentDate = new Date().getTime();
    public restPathAssetService = 'AssetService/v1';
    public assetHistoryDetails: any = {};
    public userDateFormatAng : any ='';

    constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService) {
        super(inj);
    }

    ngOnInit() {
      let token = this.getToken('accessToken')
        this.assetTilesService.updateDatePrefs(token).subscribe((res : any ) =>{
            if (res.statusCode == 200) {
                let userDateFormat: any = res.instance.userdateformat.value;
                if (userDateFormat) {
                    this.userDateFormatAng = userDateFormat.replace("aa", "a");
                }
            }
        });
        this.assetTilesService.assetDetailsItems.subscribe((success: any) => {
            this.setAssetDetailDataValue(success);
        });
        this.assetTilesService.tokenItems.subscribe((success: any) => {
            this.setTokenValue(success);
        });
        this.assetTilesService.listPageItems.subscribe((success: any) => {
            this.setListPageDataValue(success);
        });
        this.assetTilesService.assetListItems.subscribe((success: any) => {
            this.setAssetLisItemsValue(success);
        });
        this.assetTilesService.assetIndex.subscribe((success: any) => {
            this.setAssetIndexValue(success);
        });
        this.assetTilesService.categoryPermission.subscribe((success: any) => {
            this.setCategoryPermissionValue(success);
        });
        this.assetTilesService.userClientIDItems.subscribe((success: any) => {
            this.setUserClientID(success);
        });
    }
    setUserClientID(data){
      let userDetails = JSON.parse(this.getToken('userDetail'));
      console.log("data====",data);
        this.userClientID = userDetails.defaultClientID;
    }
    setAssetDetailDataValue(data) {
        this.assetDetails = Object.assign({}, data);
    }

    setAssetIndexValue(data) {
        this.assetIndex = data;
    }

    setCategoryPermissionValue(data) {
        this.categoryPermission = data;
    }

    setListPageDataValue(data) {
        this.listPage = data;
    }

    setTokenValue(data) {
        this.token = data;
    }

    setAssetLisItemsValue(data) {
        this.assetLisItems = data;
    }

    showAssetDetails(asset, assetIndex) {
        if (assetIndex && (assetIndex === 'forward' || assetIndex === 'backward')) {
            if (assetIndex === 'forward' && this.assetIndex < this.assetLisItems.length - 1) {
                this.assetIndex = (this.assetIndex + 1);
                asset = this.assetLisItems[this.assetIndex];
            } else if (assetIndex === 'backward' && this.assetIndex > 0) {
                this.assetIndex = (this.assetIndex - 1);
                asset = this.assetLisItems[this.assetIndex];
            }

        } else if (assetIndex >= 0) {
            this.assetIndex = assetIndex;
        }

        this.assetDetails = {};
      let data = {
        assetID: parseInt(asset.assetID, 0),
        catalogue: asset.catalogue,
        token: this.getToken('accessToken')
      };
      this.assetTilesService.getAsset(data).subscribe((assetDetails: any) => {
        // this.commonService.callApiRestV2('AssetService/asset/getAsset', this.attachToken({
        //     assetID: parseInt(asset.assetID, 0),
        //     catalogue: asset.catalogue
        // }, this.token), 'post').then(
        //     (assetDetails: any) => {
                if (assetDetails) {
                    assetDetails.metaList.forEach((obj, index) => {
                        if (obj.fieldDisplayType === 'multipleselect') {
                            if (obj.fieldValue) {
                                obj.fieldValue = obj.fieldValue.split(',');
                            }
                        } else if (obj.fieldDisplayType === 'date') {
                            if (obj.fieldValue) {
                                obj.fieldValue = obj.fieldValue != 'Invalid date' ? this.utcToLocalDate(obj.fieldValue) : '';

                            }
                        }
                    });
                    this.assetDetails = assetDetails;
                    // this.addAssetLogHistory(constants.ASSET_VIEWED); // Asset log for Viewed
                    // $('#assetDetail_modal').modal('show');  // ensure to fetch fresh assetDetails
                }
            }
        );
    }


    // addAssetLogHistory(action){
    //     this.commonService.assetHistoryDetails= [];
    //     this.commonService.callApi(this.setSecurePath() + '/shared/registerWipService',
    //         this.attachToken({reqNew: true}), 'post').then((response: any) => {
    //         if (response.statusCode === 200) {
    //             this.token = response.key;
    //             this.userClientID = response.instance.clientID;
    //             this.baseUrl = response.instance.baseUrl;
    //             this.commonService._restv2api = response.instance.baseUrl + '/';
    //
    //             this.commonService.callApiRestV2(this.restPathAssetService + '/insertAssetLogHistory'+ '?token=' + this.token, this.attachToken({
    //                 assetID: this.assetDetails.assetID,
    //                 catalogue: this.assetDetails.catalogue,
    //                 assetName: this.assetDetails.assetName ,
    //                 categoryID: this.assetDetails.cid,
    //                 actionInt: action
    //             }), 'post').then(
    //                 (logAsset: any) => {
    //                     if (logAsset.statusCode === 200) {
    //                         this.commonService.callApiRestV2(this.restPathAssetService + '/getAssetLogHistory'+ '?token=' + this.token, this.attachToken({
    //                             assetID: this.assetDetails.assetID,
    //                             catalogue: this.assetDetails.catalogue
    //                         }), 'post').then(
    //                             (assetHistoryDetails: any) => {
    //                                 this.commonService.assetHistoryDetails= assetHistoryDetails;
    //                             }
    //                         );
    //
    //                     }
    //                 }
    //             );
    //
    //         }
    //     });
    // }

    isZip(fileName) {
        if (fileName && fileName.indexOf('.') > 0 && fileName.split('.').pop().toLowerCase() === 'zip') {
            return true;
        }
        return false;
    }

    isIndd(fileName) {
        if (fileName && fileName.indexOf('.') > 0 && fileName.split('.').pop().toLowerCase() === 'indd') {
            return true;
        }
        return false;
    }

    openPublish(asset: any, index?) {
        if (!asset) {
            this.allpublishCategoryPoints = [];
            const startPromises = [];
            for (let i = 0; i < this.assetLisItems.length; i++) {
                const assetTemp = this.assetLisItems[i];
                if (assetTemp.checked) {
                    // get categoryPoint for checked assets...
                    // startPromises.push(assetService.getPublishCategoryPoints(assetTemp.assetID, this.listPage.catalogue));
                  let objData = {
                    userClientID: parseInt(this.userClientID, 0),
                    assetID: parseInt(assetTemp.assetID, 0),
                    catalogue: this.listPage.catalogue,
                    token : this.getToken('accessToken')
                  }


                  this.assetTilesService.getPublishCategoryPoints(objData).subscribe((categoryPoints: any) => {
                    // this.commonService.callApiRestV2('RestService/assetPublish/getPublishCategoryPoints', this.attachToken({
                    //     userClientID: parseInt(this.userClientID, 0),
                    //     assetID: parseInt(assetTemp.assetID, 0),
                    //     catalogue: this.listPage.catalogue
                    // }, this.token), 'post').then((categoryPoints: any) => {
                        startPromises.push(categoryPoints);
                    });
                }
            }
            if (startPromises.length > 0) {

                // $q.all(startPromises).then(function (allPublishCategoryPoints) {
                //     for (let s = 0; s < allPublishCategoryPoints.length; s++) {
                //         if (this.allpublishCategoryPoints.length > 0) {
                //             this.allpublishCategoryPoints.push(allPublishCategoryPoints[s]);
                //         } else {
                //             this.allpublishCategoryPoints = allPublishCategoryPoints[s];
                //         }
                //     }
                // });
            }
        } else {
            this.publishAsset = asset;
            this.publishAssetIdx = index;
          let objData = {
            userClientID: parseInt(this.userClientID, 0),
            assetID: parseInt(asset.assetID, 0),
            catalogue: this.listPage.catalogue,
            token : this.getToken('accessToken')
          }


          this.assetTilesService.getPublishCategoryPoints(objData).subscribe((categoryPoints: any) => {
            // this.commonService.callApiRestV2('RestService/assetPublish/getPublishCategoryPoints', this.attachToken({
            //     userClientID: parseInt(this.userClientID, 0),
            //     assetID: parseInt(asset.assetID, 0),
            //     catalogue: this.listPage.catalogue
            // }, this.token), 'post').then(
            //     (categoryPoints: any) => {
                    this.publishCategoryPoints = categoryPoints;
                    this.assetTilesService.setpublishCategoryPoints(this.publishCategoryPoints);
                    this.assetTilesService.setTokenData(this.token);
                    this.assetTilesService.setListPageData(this.listPage);
                    this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
                    this.assetTilesService.setPublishAsset(this.publishAsset);
                    this.assetTilesService.setPublishAssetIdx(this.publishAssetIdx);
                    this.assetTilesService.setUserClientID(this.userClientID);
                    this.convertComponentToDom(AssetPublishModalComponent);
                    // $('#assetPublish_modal').modal('show');
                }
            );
        }

    }

    updateAssetDetails(updatedAssetDetails) {
        // Call prepMetadataForSubmission function
        const returnAssetMetaDataUpdateList = this.prepMetadataForSubmission(updatedAssetDetails.metaList, undefined, undefined, true);

        if (returnAssetMetaDataUpdateList == null) {
            let PleaseKeyInMandatoryField;
            this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
                PleaseKeyInMandatoryField = res;
            });
            let MissingFields;
            this.translate.get('MissingFields').subscribe((res: string) => {
                MissingFields = res;
            });
            this.displayToaster('error', [PleaseKeyInMandatoryField], 5000, MissingFields);
            return;
        }
        // Service call to update the assets
        // var retAssetUpdate = this.updateFilestorAsset(updatedAssetDetails.assetID,
        // updatedAssetDetails.catalogue, returnAssetMetaDataUpdateList);
      let objData = {
        assetID: parseInt(updatedAssetDetails.assetID, 0),
        catalogue: updatedAssetDetails.catalogue,
        metadata: returnAssetMetaDataUpdateList,
        token: this.getToken('accessToken')
        }

      this.assetTilesService.updateAssetFields(objData).subscribe((restResponse: any) => {
        // this.commonService.callApiRestV2('AssetService/asset/updateAssetFields', this.attachToken({
        //     assetID: parseInt(updatedAssetDetails.assetID, 0),
        //     catalogue: updatedAssetDetails.catalogue,
        //     metadata: returnAssetMetaDataUpdateList
        // }, this.token), 'post').then(
        //     (restResponse: any) => {
                if (restResponse.statusCode === 200) {
                    this.closeModel();
                    // this.addAssetLogHistory(constants.ASSET_UPDATE); // AssetLog for Updation
                    // $('#assetDetail_modal').modal('hide');
                    let NewAssetHasBeenUpdatedSuccessfully;
                    this.translate.get('NewAssetHasBeenUpdatedSuccessfully').subscribe((res: string) => {
                        NewAssetHasBeenUpdatedSuccessfully = res;
                    });
                    this.translate.get('Success').subscribe((res: string) => {
                        this.successMessage = res;
                    });
                    this.displayToaster('success', [NewAssetHasBeenUpdatedSuccessfully], 5000, this.successMessage);
                    this.broadcaster.broadcast('openCategory', {catalogue:this.listPage.catalogue,categoryID:this.listPage.categoryID});
                } else {
                    let FailedToUpdateTheAsset;
                    this.translate.get('FailedToUpdateTheAsset').subscribe((res: string) => {
                        FailedToUpdateTheAsset = res;
                    });
                    this.translate.get('Error').subscribe((res: string) => {
                        this.errorMessage = res;
                    });
                    this.displayToaster('error', [FailedToUpdateTheAsset], 5000, this.errorMessage);
                }

            }
        );
    }

    prepMetadataForSubmission(metaList, id, isPressJob, isAddAsset, isTaskCopy?, isProcurement?, addNooshProjectId?) {
        // isPressJob used to allow noneditable fields to get values
        // create a array of string 'fieldID|,|fieldValue' pairs  TODO may just pass changed values by keeping a copy of original
        const metaIdValuePairs = [];
        // angular.forEach(metaList, function (meta, index) {
        if (metaList !== null || metaList !== undefined) {
            for (let index = 0; index < metaList.length; index++) {     // use for loop to break out of looping
                const meta = metaList[index];
                // extra care for date and other spcial display types
                if (typeof meta.fieldDisplayType === 'string') {
                    if (meta.fieldDisplayType.toLowerCase().indexOf('noneditable') === -1 || isPressJob || (addNooshProjectId
                        && addNooshProjectId === true && meta.fieldName === 'NooshProjectID') || (meta.fieldName === 'Project_Name')) {
                        // Press job needs to allow noneditable fields to be updated

                        if (meta.fieldDisplayType === 'date') { // update date format to make the field eligible for database insert
                            if (meta.fieldValue !== '') {
                                meta.fieldValue = this.localToUtcWithInputFormat(meta.fieldValue);
                            }
                            // jquery plugin version
                            /*meta.fieldValue = $('#date-' + id + '-' + meta.fieldID).val();
                             if ( meta.fieldValue == undefined ) {
                             meta.fieldValue = '';
                             }*/
                        } else if (meta.fieldDisplayType === 'multipleselect') {
                            if (isAddAsset) {
                                if (meta.fieldValue) {
                                    meta.fieldValue = meta.fieldValue.toString();
                                }
                            } else {
                                let checked = '';
                                meta.multiValues.forEach((selectOpt, metaIndex) => {
                                    if (selectOpt.selected !== '') {
                                        checked = checked + ',' + selectOpt.selected;
                                    }
                                });
                                meta.fieldValue = checked.substring(1);
                            }
                        }

                        // mandatory field checkup
                        if (meta.mandatory && (meta.fieldValue === '' || meta.fieldValue == null ||
                            (meta.fieldDisplayType === 'file' && meta.fieldValue === 0))) {
                            // updated to use fieldName
                            if (typeof meta.fieldName === 'string') {
                                if (isProcurement && meta.fieldName.toLowerCase() === 'contact' /*meta.fieldID=='62'*/) {
                                    // skip checking ergo contact ID if procurement channel is added after import
                                } else {
                                    return null;
                                }
                            } else {
                                return null;
                            }

                        }

                        // metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);

                        if (isTaskCopy) {
                            metaIdValuePairs.push(meta.fieldID + '_' + meta.jobMetaDataID /*taskCopyUD*/ + '|-|' + meta.fieldValue + '|,|');

                        } else {

                            if (meta.fieldID === undefined) {  // Filestor 3.7 metadata
                                metaIdValuePairs.push(meta.fieldName + '|=|' + meta.fieldValue);
                            } else {                            // JAS metadata
                                if (meta.fieldValue.id === undefined) {
                                    metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);
                                } else {  // in case of id is used for value
                                    metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue.id);
                                }
                            }
                        }
                    }
                } else {
                    return null;
                }
            }
        }
        // });
        return metaIdValuePairs;
    }

    localToUtcWithInputFormat(strLocalDateTime, inputFormat?) {
        // when input format is not set use default
        if (!inputFormat) {
            inputFormat = this.defultInputFormat; // 'DD/MM/YYYY HH:mm';
        }

        // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
        const momentTime = moment(strLocalDateTime).subtract(moment(strLocalDateTime).utcOffset(), 'm');
        const formattedUtcDateTime = momentTime;
        return formattedUtcDateTime.format(this.defaultFormat);
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Function to Delete  the asset details                //
    ///////////////////////////////////////////////////////////////////////////
    deleteAsset(deleteAssetdetail) {
        //Service call to delete the assets
        //assetService.deleteAsset(assetID, catalogue, token) Parameter required
        // var assetdelete = assetService.deleteAsset(deleteAssetdetail.assetID, deleteAssetdetail.catalogue);
      let objData = {
        assetID: parseInt(deleteAssetdetail.assetID, 0),
        catalogue: deleteAssetdetail.catalogue,
        token: this.getToken('accessToken')
      }
      this.assetTilesService.deleteAsset(objData).subscribe((restResponse: any) => {
        // this.commonService.callApiRestV2('AssetService/asset/deleteAsset', this.attachToken({
        //     assetID: parseInt(deleteAssetdetail.assetID, 0),
        //     catalogue: deleteAssetdetail.catalogue
        // }, this.token), 'post').then(
        //     (restResponse: any) => {
                if (restResponse.statusCode == 200) {
                    // $('#assetDetail_modal').modal('hide');
                    this.closeModel()
                    // this.addAssetLogHistory(constants.ASSET_DELETE); // Asset log History for delete
                    // $scope.refreshPage();
                    this.broadcaster.broadcast('openCategory', {catalogue:this.listPage.catalogue,categoryID:this.listPage.categoryID});
                    this.translate.get('Success').subscribe((res: string) => {
                        this.successMessage = res;
                    });
                    let AssetHasBeenDeletedSuccessfully;
                    this.translate.get('AssetHasBeenDeletedSuccessfully').subscribe((res: string) => {
                        AssetHasBeenDeletedSuccessfully = res;
                    });
                    this.displayToaster('success', [AssetHasBeenDeletedSuccessfully], 5000, this.successMessage);
                } else {
                    this.translate.get('Error').subscribe((res: string) => {
                        this.errorMessage = res;
                    });
                    let FailedToDeleteTheAsset;
                    this.translate.get('FailedToDeleteTheAsset').subscribe((res: string) => {
                        FailedToDeleteTheAsset = res;
                    });
                    this.displayToaster('error', [FailedToDeleteTheAsset], 5000, this.errorMessage);
                }

            }
        );
    }
}
