import {Injectable} from '@angular/core';
import {from, Observable, Subject} from 'rxjs';
import {CommonService} from '../../common/common.service';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import * as constants from '../../common/constants';

@Injectable()
export class AssetTilesService {
  public baseUrlAssets = 'AssetService/v1/assets';

  private subject = new Subject<any>();
  private selectedCategory = new Subject<any>();


  constructor(private commonService: CommonService) {
  }

  public user: any = {};
  public assetMetaData = new BehaviorSubject<any>([]);
  itemData = this.assetMetaData.asObservable();

  setAssetMetaDataData(data: any) {
    this.assetMetaData.next(data);
  }

  public assetListItems = new BehaviorSubject<any>([]);
  itemAssetLisItemsData = this.assetListItems.asObservable();

  setAssetLisItemsData(data: any) {
    this.assetListItems.next(data);
  }


  setSelectedCategory(data:any){
    this.selectedCategory.next(data);
  }

  getSelectedCategory(){
    return this.selectedCategory.asObservable();
  }

  public listPageItems = new BehaviorSubject<any>([]);
  itemListPageData = this.listPageItems.asObservable();

  setListPageData(data: any) {
    this.listPageItems.next(data);
  }

  public tokenItems = new BehaviorSubject<any>([]);
  itemTokenData = this.tokenItems.asObservable();

  setTokenData(data: any) {
    this.tokenItems.next(data);
  }

  public userClientIDItems = new BehaviorSubject<any>([]);
  itemUserClientID = this.userClientIDItems.asObservable();

  setUserClientID(data: any) {
    this.userClientIDItems.next(data);
  }

  public categoryItems: any = new BehaviorSubject<any>({});
  itemCategoryData = this.categoryItems.asObservable();

  setCategoryData(data: any) {
    this.categoryItems.next(data);
  }

  public categoryEditItems = new BehaviorSubject<any>([]);
  itemCategoryEditData = this.categoryEditItems.asObservable();

  setCategoryEditData(data: any) {
    this.categoryEditItems.next(data);
  }

  public assetDetailsItems = new BehaviorSubject<any>([]);
  itemAssetDetailsData = this.assetDetailsItems.asObservable();

  setAssetDetailsData(data: any) {
    this.assetDetailsItems.next(data);
  }

  public permissionItems = new BehaviorSubject<any>([]);
  itemPermissionData = this.permissionItems.asObservable();

  setPermissionData(data: any) {
    console.log('data', data);
    this.permissionItems.next(data);
  }

  setAssetsBasketTotal(data: any) {
    this.subject.next(data);
  }

  getAssetsBasketTotal() {
    return this.subject.asObservable();
  }

  public assetIndex = new BehaviorSubject<any>([]);
  itemAssetIndex = this.assetIndex.asObservable();

  setAssetIndexItems(data: any) {
    this.assetIndex.next(data);
  }

  public categoryPermission = new BehaviorSubject<any>([]);
  itemCategoryPermission = this.categoryPermission.asObservable();

  setCategoryPermission(data: any) {
    this.categoryPermission.next(data);
  }

  public assetShare = new BehaviorSubject<any>([]);
  itemassetShare = this.assetShare.asObservable();

  setAssetShare(data: any) {
    this.assetShare.next(data);
  }

  public publishCategoryPoints = new BehaviorSubject<any>([]);
  itemPublishCategoryPoints = this.publishCategoryPoints.asObservable();

  setpublishCategoryPoints(data: any) {
    this.publishCategoryPoints.next(data);
  }

  public publishAsset = new BehaviorSubject<any>([]);
  itemPublishAsset = this.publishAsset.asObservable();

  setPublishAsset(data: any) {
    this.publishAsset.next(data);
  }

  public publishAssetIdx = new BehaviorSubject<any>([]);
  itemPublishAssetIdx = this.publishAssetIdx.asObservable();

  setPublishAssetIdx(data: any) {
    this.publishAssetIdx.next(data);
  }

  public breadcumb = new BehaviorSubject<any>([]);
  itemBreadcumb = this.breadcumb.asObservable();

  setBreadcumb(data: any) {
    this.breadcumb.next(data);
  }

  public currentProgress = new BehaviorSubject<any>([]);
  itemCurrentProgress = this.currentProgress.asObservable();

  setCurrentProgress(data: any) {
    this.currentProgress.next(data);
  }

  getCategories(data): Observable<any> {
    const observable = from(this.commonService.callApi('AssetService/asset/categori', data, 'post', false));
    return observable;
  }

  getCategoryPermission(data): Observable<any> {
    const observable = from(this.commonService.callApi('AssetService/asset/getCategoryPermissions', data, 'post', false));
    return observable;
  }

  getUpdatedCategoryPermission(catalogue,data,clientId): Observable<any> {
    const observable = from(this.commonService.callApi('AssetService/v1/category/'+ catalogue+ '/usercategoriespermissions?'+clientId, data, 'post', false));
    return observable;
  }

  getAssetsCategoriesInRange(data): Observable<any> {
    const observable = from(this.commonService.callApi('AssetService/v1/assets/categories?' + data, '', 'get', false));
    return observable;
  }

  updateDatePrefs(token) {
    const observable = from(this.commonService.callApi('UserService/v1/user/preferences?token=' + token, '', 'get', false));
    return observable;
  }

  getFilestorCategoryDetails(categoryDup) {
    const observable = from(this.commonService.callApi('RestService/category/getFilestorCategoryDetails', categoryDup, 'post', false));
    return observable;
  }

  // getAssetMetaDataListWithoutValue(data) {
  //   const observable = from(this.commonService.callApi('AssetService/asset/getAssetMetaDataListWithoutValue', data, 'post', false));
  //   return observable;
  // }

  getPermissionStakeholders(data) {
    const observable = from(this.commonService.callApi('RestService/category/getPermissionStakeholders', data, 'post', false));
    return observable;
  }

  getFilestorCategoryPermissions(data) {
    const observable = from(this.commonService.callApi('RestService/category/getFilestorCategoryPermissions', data, 'post', false));
    return observable;
  }

  getGroupsAndUsersByMultipleClientID(data) {
    const observable = from(this.commonService.callApi('RestService/category/getGroupsAndUsersByMultipleClientID', data, 'post', false));
    return observable;
  }

  AssetsUpsertFilestorCategoryPermissions(data) {
    const observable = from(this.commonService.callApi('/asset/upsertFilestorCategoryPermissions', data, 'post', false));
    return observable;
  }

  saveCategoryOrder(data, catalog) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + catalog + '/order', data, 'post', true));
    return observable;
  }

  categoryUpsertFilestorCategoryPermissions(data) {
    const observable = from(this.commonService.callApi('category/upsertFilestorCategoryPermissions', data, 'post', false));
    return observable;
  }

  updateUpsertFilestorCategoryPermissions(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/categoryPermissions', data, 'post', true));
    return observable;
  }


  updateUserPermissions(catalog, categoryId, data) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + catalog + '/' + categoryId + '/userpermissions', data, 'post', true));
    return observable;
  }

  updateGroupPermissions(catalog, categoryId, data) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + catalog + '/' + categoryId + '/grouppermissions', data, 'post', true));
    return observable;
  }

  upsertFilestorCategory(data) {
    const observable = from(this.commonService.callApi('RestService/category/upsertFilestorCategoryPermissions', data, 'post', false));
    return observable;
  }

  getAsset(data) {
    const observable = from(this.commonService.callApi('AssetService/asset/getAsset', data, 'post', false));
    return observable;
  }

  prepAssetFileDownload(data) {
    const observable = from(this.commonService.callApi('AssetService/asset/prepAssetFileDownload', data, 'post', false));
    return observable;
  }

  getProgress(data) {
    const observable = from(this.commonService.callApiWithoutBase('/downloadService/getProgress', data, 'post', false));
    return observable;
  }

  registerWipService(data) {
    const observable = from(this.commonService.callApi('/shared/registerWipService', data, 'post', false));
    return observable;
  }

  getPublishCategoryPoints(data) {
    const observable = from(this.commonService.callApi('RestService/assetPublish/getPublishCategoryPoints', data, 'post', false));
    return observable;
  }

  updateAssetFields(data) {
    const observable = from(this.commonService.callApi('AssetService/asset/updateAssetFields', data, 'post', false));
    return observable;
  }

  deleteAsset(data) {
    const observable = from(this.commonService.callApi('AssetService/asset/deleteAsset', data, 'post', false));
    return observable;
  }

  share(data, token) {
    const observable = from(this.commonService.callApi('ShareService/v1' + '/share' + '?token=' + token, data, 'post', false));
    return observable;
  }

  publishAssets(data) {
    const observable = from(this.commonService.callApi('RestService/assetPublish/publishAssets', data, 'post', false));
    return observable;
  }

  validateCategoryPoint(data) {
    const observable = from(this.commonService.callApi('RestService/assetPublish/validateCategoryPoint', data, 'post', false));
    return observable;
  }

  updateFilesForAsset(data) {
    const observable = from(this.commonService.callApi('RestService/asset/updateFilesForAsset', data, 'post', false));
    return observable;
  }

  replaceAssetThumbnail(data) {
    const observable = from(this.commonService.callApi('AssetService/asset/replaceAssetThumbnail', data, 'post', false));
    return observable;
  }


  // addFilestorAsset(data, token) {
  //   const observable = from(this.commonService.callApi('AssetService/v1/asset?token=' + token, data, 'post', false));
  //   return observable;
  // }

  insertAssetLogHistory(data, token) {
    const observable = from(this.commonService.callApiWithoutBase('/insertAssetLogHistory' + '?token=' + token, data, 'post', false));
    return observable;
  }

  getAssetLogHistory(data, token) {
    const observable = from(this.commonService.callApiWithoutBase('/getAssetLogHistory' + '?token=' + token, data, 'post', false));
    return observable;
  }

  getAssetCategoryTreeItemsByParentID(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/asset/category/' + data.parentID + '?token=' + data.token + '&categoryID=' + data.categoryId + '&catalogue=' + data.catalogue + '&uid=' + data.uid, '', 'get', false));
    return observable;
  }

  addAssetFolder(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/asset/' + data.catalogue + '/' + data.assetID + '/basket?token=' + data.token, {}, 'post', false));
    return observable;
  }

  getAssetCategoryTreeItems(data) {
    const observable = from(this.commonService.callApi('AssetService/asset/getAssetCategoryTreeItems', data, 'post', false));
    return observable;
  }

  getAllAssetsDownloads(pagination, data) {
    const observable = from(this.commonService.callApi('AssetService/v1/assets/downloads?token=' + data.token + '&fetchSize=' + pagination.fetchSize + '&dir=' + pagination.dir + '&order=' + pagination.order + '&page=' + pagination.page, '', 'get', false));
    return observable;
  }

  addFilestorAsset(data, token) {
    const observable = from(this.commonService.callApi('AssetService/v1/asset/categories?token=' + token, data, 'post', false));
    return observable;
  }

  getAssetMetaDataListWithoutValue(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/assets/metadatalist?token=' + data.token + '&catalogue=' + this.commonService.isCCEP(), '', 'get', false));
    return observable;
  }

  getAssetsFilters(data, field) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + data.catalogue + '/' + data.categoryId + '/filters?' + field, '', 'get', false));
    return observable;
  }

  getSynced() {
    const observable = from(this.commonService.callApi('AssetService/v1/category/sync', '', 'get', true));
    return observable;
  }

  addNewCategory(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/category', data, 'post', true));
    return observable;
  }

  deleteCategory(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + data.catalogue + '/' + data.categoryId, '', 'delete', true));
    return observable;
  }

  getAllbasketAssets(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/assets/basket?token=' + data.token + '&fetchSize=' + data.fetchSize + '&page=' + data.page, '', 'get', false));
    return observable;
  }

  clearAssetsbasket(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/assets/basket?token=' + data.token, '', 'delete', false));
    return observable;
  }

  saveCategory(categoryData, token) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/sync?token=' + token, categoryData, 'put', false));
    return observable;
  }

  deleteSingleAsset(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/asset/' + data.catalogue + '/' + data.assetID + '/basket?token=' + data.token, '', 'delete', false));
    return observable;
  }

  getSingleAsset(data) {
    const observable = from(this.commonService.callApi('/AssetService/v1/assets/' + data.assetID + '?catalogue=' + data.catalogue + '&uid=' + data.uid + '&categoryID' + '&token=' + data.token, '', 'get', false));
    return observable;
  }

  updateAssetValue(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/asset/' + data.assetID + '/assetMetaData', data, 'put', true));
    return observable;
  }

  getUserPermission(data, categoryIds) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + data.catalog + '/' + data.categoryId + '/userpermissions?' + categoryIds, '', 'get', false));
    return observable;
  }

  getGroupPermission(data, categoryIds) {
    const observable = from(this.commonService.callApi('AssetService/v1/category/' + data.catalog + '/' + data.categoryId + '/grouppermissions?' + categoryIds, '', 'get', false));
    return observable;
  }

  getAllLatestAssets(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/assets/category/search/allPublications?' + data, '', constants.constants.method.get, false));
    return observable;
  }

  deleteAssetsDetail(data) {
    const observable = from(this.commonService.callApi('AssetService/v1/asset/' + data.catalog + '/' + data.assetsId + '?token=' + data.token, '', 'delete', false));
    return observable;
  }


  getFileMeta(assetId,data){
    const observable = from(this.commonService.callApi('AssetService/v1/asset/'+ assetId + '/original/file/?' + data, '', 'get', false));
    return observable;
  }


}
