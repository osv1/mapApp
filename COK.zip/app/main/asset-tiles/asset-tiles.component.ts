import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from '../../common/commonComponent';
import {AssetTilesService} from './asset-tiles.service';
import {AddCategoryModalComponent} from './add-category-modal/add-category-modal.component';
import {AddAssetModalComponent} from './add-asset-modal/add-asset-modal.component';
import {CategoryPermissionModalComponent} from './category-permission-modal/category-permission-modal.component';
import {EditAssetModalComponent} from './edit-asset-modal/edit-asset-modal.component';
import {DownloadAssetModalComponent} from './download-asset-modal/download-asset-modal.component';
import {AssetDetailModalComponent} from './asset-detail-modal/asset-detail-modal.component';
import {ShareAssetModalComponent} from "./share-asset-modal/share-asset-modal.component";
import {environment} from "../../../environments/environment";
import {NavigationEnd} from '@angular/router';

declare var moment: any;
declare var $: any;


@Component({
  selector: 'app-asset-tiles',
  templateUrl: './asset-tiles.component.html',
  styleUrls: ['./asset-tiles.component.css'],
})
export class AssetTilesComponent extends BaseComponent implements OnInit {
  showTree = false;
  listPage: any = {
    rows: [],
    page: 1,
    pageSize: 12,
    sort: this.constants.f_assetsName,
    dir: this.constants.defaultDirection,
    search: '',
    catalogue: this.isCCEP(),
    categoryID: 0,
    findDuplicate: false,
    searchCurrent: false,
    filter: ''
  };
  totalSize;
  sortName;
  shortByValue;
  fetchSize = this.constants.pageValue[0];
  pageValue;
  categoryPermission = {value: 0, read: false, write: false, 'delete': false, download: false, email: false};
  assetSearchIn = '';
  assetLisItems = [];
  noMoreAssets = false;
  categoryLisItems: any[];
  assetSearchLoading: boolean;
  loading: boolean;
  currentDate = new Date().getTime();
  breadcumb = [];
  treeListChildren = [];
  treeList: any = [];
  order: any;
  filterData = {fromdate: '', todate: ''};
  rootNodeDataForBreadcumb = {categoryID: -1, catalogue: ''};
  categoryInProcess = false;
  fileMetaList = [];
  isEditCategory;
  category: any = {};
  edit: any;
  assetDetails: any = {};
  assetMetaData = [];
  token;
  userClientID: any;
  accessID: any = 0;
  displayMessage;
  addAssetAjax = false;
  errorMessage;
  successMessage;
  currentProgress = 0;
  assetIndex: any;
  assetShare: any = {emails: '', disabled: false, message: ''};
  clickToggle: any;
  isAdmin: any;
  expandedNodes = [];
  public env = environment;
  bsValue = new Date();
  bsRangeValue: Date[];
  maxDate = new Date();
  public filterByAsset;
  public assetsFilter = [];
  public selectCategory;
  public sidemMenuCategory: any = [];
  url: string;
  openFilter: any;
  imageList: any;
  assetsImagePreview: any = '';
  assetsImageDescription: any = '';
  imageExtension: any = '';
  public video: any;
  isAssetsItem: boolean = true;
  categoryIDs: any = [];
  public basketAssetsDetails = [];
  public isAssetsDetails;
  searchBindvalue: any;
  openCategories: boolean = false;
  public isEditAccess;
  public isDownloadAccess;
  public userDetails : any ={};
  public isAdminAccess;
  public userPermissionGrants : any ={};
  public catalogPermissions :any ={};
  public allItemsCategoryPermission : any = {};
  filterType: boolean = false;

  constructor(public inj: Injector, public assetTilesService: AssetTilesService) {
    super(inj);
    this.titleService.setTitle('Assets');

    // For datepicker
    this.maxDate.setDate(this.maxDate.getDate() + 7);
    this.bsRangeValue = [this.bsValue, this.maxDate];

  }

  ngOnInit() {

    this.assetsFilter = []
    this.shortByValue = this.constants.shortByValueAssetsTiles;
    this.sortName = this.constants.shortByValueAssetsTiles[0];
    this.pageValue = this.constants.pageValue;
    this.listPage.dir = this.constants.shortByValueAssetsTiles[0].dir;
    this.listPage.pageSize = this.constants.pageValue[0].size;
    this.listPage.page = 1;
    this.assetLisItems = [];
    this.categoryLisItems = [];
    if (this.isAssetsItem) {
      this.getAllLatestAssets();
    } else {
      this.loadMoreCategoriesAndAssets();
    }
    this.getAssetCategoryTreeItemsByParentID();
    this.treeList = this.setTreeRoot();
    // this.getAssetsFilterFromServer();

    // this.getUserAccess();
    this.getUserPermissionStackholders();
  }




  getAllbasketAssets(assets) {
    this.basketAssetsDetails = [];
    const data = {
      token: this.getToken('accessToken'),
      fetchSize: 100,
      page: 1
    };
    this.assetTilesService.getAllbasketAssets(data).subscribe((res: any) => {
      if (res) {
        this.basketAssetsDetails = res.instance.assets;
        this.addAssetFolder(assets);
      }
    });

  }

  setTreeRoot() {
    return [{id: -1, title: 'Assets', catalogue: '', children: []}];
  }

  assetsFilterBy(data) {
    console.log(data);
    if (data.assign) {
      this.listPage.page = 1
      this.listPage.filter = undefined;
      this.filterByAsset = undefined;
      if (this.isAssetsItem) {
        this.getAllLatestAssets();
      } else {
        this.loadMoreCategoriesAndAssets();
      }
      data.assign = false;
    } else {
      this.filterByAsset = data.name
      this.assetsFilter.map(res => res.assign = false);
      this.listPage.page = 1
      this.listPage.filter = data.name;
      if (this.isAssetsItem) {
        this.getAllLatestAssets();
      } else {
        this.loadMoreCategoriesAndAssets();
      }
      data.assign = true;
    }
  }




  getAssetsFilterFromServer(categoryId?) {
    let data = {
      categoryId: categoryId ? categoryId : this.listPage.categoryID,
      catalogue: this.listPage.catalogue,
      token: this.getToken('accessToken')
    };
    let fields = {
      token: this.getToken('accessToken'),
      fieldName: 'F_AssetType'
    }
    console.log(data)
    const fieldsParams = this.serialize(fields);
    this.assetsFilter = [];
    this.assetTilesService.getAssetsFilters(data, fieldsParams).subscribe((assetmetaData: any) => {
      this.assetMetaData = assetmetaData.instance;
      this.assetMetaData.forEach((obj, index) => {
        this.assetsFilter.push({name: obj, value: obj});
      })
    });

  }


  getUserPermissionStackholders(){
    let data = {
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getPermissionStakeholders(data).subscribe((permStakeHolders: any) => {
      this.catalogPermissions = permStakeHolders.filter(catalog => catalog.displayName === 'DMH');
    })
  }

  getUserPerrmissionsKey(categoryId){
    let data = {
      categoryId: parseInt(categoryId, 0),
      catalog : this.isCCEP(),
    }

    let serializeData = {
      token : this.getToken('accessToken'),
      clientIDs : ','+ Number(this.catalogPermissions[0].key) + ','
    }
    const serializeParams = this.serialize(serializeData)
    this.assetTilesService.getUserPermission(data,serializeParams).subscribe((res :any) => {
      console.log(res);
      if(res.statusCode === 200){
        this.userPermissionGrants = res.instance;
        this.getUserAccess();
      }
    })
  }

  getUserAccess(){
    let userID;
    userID = JSON.parse(this.getToken('userDetail')).userID;
    let ssoAdmin = this.getToken('isSsoAdmin')
    console.log(userID);
    let currentUserAccessFromUserId;
    this.userDetails = JSON.parse(this.getToken('userDetail'));
    currentUserAccessFromUserId = this.userPermissionGrants.filter(user => Number(user.uid) === Number(userID));
    console.log(currentUserAccessFromUserId);

    console.log(this.userDetails);
    if (ssoAdmin) {
      this.isAdminAccess = true;
      this.isEditAccess = true;
      this.isDownloadAccess = true;
    } else {
      currentUserAccessFromUserId = currentUserAccessFromUserId[0];
      if(currentUserAccessFromUserId.d && currentUserAccessFromUserId.n && currentUserAccessFromUserId.r && currentUserAccessFromUserId.w){
        this.isEditAccess = true;
        this.isDownloadAccess = true;
      } else if(!currentUserAccessFromUserId.d && currentUserAccessFromUserId.n && currentUserAccessFromUserId.r &&
        !currentUserAccessFromUserId.w){
        this.isEditAccess = false;
        this.isDownloadAccess = true;
      } else {
        this.isEditAccess = false;
        this.isDownloadAccess = false;
      }
    }
  }


  sortBy(data, key) {
    console.log('data', data);
    if (key == 'sortby') {
      this.listPage.dir = data.dir;
      this.listPage.order = data.order;
    }
    if (key == 'show') {
      this.listPage.pageSize = data.size;
    }
    setTimeout(() => {
      if (this.isAssetsItem) {
        this.getAllLatestAssets();
      } else {
        this.loadMoreCategoriesAndAssets();
      }
    }, 300);

  }

  next() {
    this.listPage.page = this.listPage.page + 1;
    if (typeof window != 'undefined') {
      window.scrollTo(0, 0);
    }
    if (this.isAssetsItem) {
      this.getAllLatestAssets();
    } else {
      this.loadMoreCategoriesAndAssets();
    }
  }

  prev() {
    this.listPage.page = this.listPage.page - 1;
    if (typeof window != 'undefined') {
      window.scrollTo(0, 0);
    }
    if (this.isAssetsItem) {
      this.getAllLatestAssets();
    } else {
      this.loadMoreCategoriesAndAssets();
    }
  }

  getAssetCategoryTreeItemsByParentID() {
    let data = {
      page: this.listPage.page,              // page number
      fetchSize: this.listPage.pageSize,    // page size
      order: this.listPage.sort,             // sort column name
      dir: this.listPage.dir,                // sort direction up/down
      filter: '',
      search: this.listPage.search,
      catalogue: this.listPage.catalogue,
      fromDate: '',
      toDate: '',        // this.listPage.fromdate, this.listPage.todate,
      categoryID: parseInt(this.listPage.categoryID, 0),
      findDuplicate: this.listPage.findDuplicate,
      searchCurrent: this.listPage.searchCurrent,
      token: this.getToken('accessToken'),
      uid: 0
    };
    if (this.listPage.categoryID == 0) {
      data.fetchSize = this.constants.categoryFetchSize;
    }

    const categoriesParams = this.serialize(data)
    // let data = this.pagingDataObj(this.listPage.page + 1, this.listPage.pageSize, this.listPage.sort,
    //   this.listPage.dir, this.listPage.F_AssetType, this.listPage.catalogue, this.listPage.fromdate, this.listPage.todate);
    this.assetTilesService.getAssetsCategoriesInRange(categoriesParams).subscribe((subTreeList: any) => {
      this.sidemMenuCategory = subTreeList.instance.categories;
      console.log(this.sidemMenuCategory)
      this.sidemMenuCategory.map(category => {
        if (category.categoryID) {
          this.categoryIDs.push(category.categoryID.toString());
        }
      })
      this.allAssetsList();
      this.sidemMenuCategory.sort((a, b) => Number(a.rank) - Number(b.rank));
      this.treeList[0].children = this.sidemMenuCategory; // initial loading root level
      this.treeList[0].catalogue = this.treeList[0].categoryName;
      this.treeList[0].expanded = true;
      this.showSelected(this.treeList[0], false);
    })
  }

  showSelected(node, selected) {
    /*var parent = $parentNode ? ("child of: " + $parentNode.id) : "root node";
    var location = $first ? "first" : ($last ? "last" : ("middle node at index " + $index));
    var oddEven = $odd ? "odd" : "even";
    */
    let index = -1;
    for (let i = 0; i < this.expandedNodes.length; i++) {
      // id is all 0 for root level - need to check name as well
      if ((this.expandedNodes[i].id === node.id) && (this.expandedNodes[i].title === node.title)) {
        index = i;
        break;
      }
    }

    if (selected) {
      if (index === -1) {
        this.expandedNodes.push(node);
      }
      // else {
      //    this.expandedNodes.splice(index, 1); //remove
      // }
    } else {
      if (index !== -1) {
        this.expandedNodes.splice(index, 1); // remove
      }
    }

    // node.selected = isCollapsed;
    // when it's collapsed get child nodes
    if (selected) {
      // get child tree nodes
      this.getAssetCategoryTreeItemsNodeByNode(node, node.id, node.id);
    }
    // this.$emit('treeForBreadcumb', this.treeList[0].children, node, $parentNode); // for breadcumb
    // // refresh asset list with parent category details
    // $rootScope.$broadcast('refreshAssetTiles', node.catalogue, node.id);
  }

  nodeSelect(event) {
    console.log(event, 'event');
    if (!event.node.children.length) {
      let data = {
        parentID: event.node.id,
        catalogue: event.node.catalogue,
        token: this.getToken('accessToken')
      }
      this.assetTilesService.getAssetCategoryTreeItems(data).subscribe((subTreeList: any) => {
        event.node.children = subTreeList;
      });
    }
    if (event.node.expanded) {
      event.node.expanded = false;
    } else {
      event.node.expanded = true;
    }
    this.treeForBreadcumb(this.treeList[0].children, event.node, event.node.parent);
    this.refreshAssetTiles(event.node.catalogue, event.node.id);


  }

  refreshAssetTiles(catalogue, categoryID) {
    this.listPage.catalogue = catalogue;
    this.listPage.categoryID = categoryID;
    this.refreshPage();
  }

  treeForBreadcumb(treeNodes, selectedNode, parentNode) {
    this.treeListChildren = treeNodes;

    if (selectedNode && selectedNode.id === -1) {
      this.breadcumb = [];
      // root assets selected
    } else {
      // keep upto parent node
      const tempArray = [];
      for (let i = 0; i < this.breadcumb.length; i++) {
        const item = this.breadcumb[i];
        tempArray.push(item);
        if (selectedNode && parentNode) {
          if (item.categoryID === parentNode.id && item.title === parentNode.title) {
            break;
          }
        }
      }
      this.breadcumb = tempArray;

      // add up current node
      this.updateBreadcrumb(selectedNode.catalogue, selectedNode.id, selectedNode.title);

    }
  }

  getAssetCategoryTreeItemsNodeByNode(selectedNode, parentCategoryID, nodeID) {
    if (selectedNode.children.length === 0) {
      let data = {
        parentID: parseInt(parentCategoryID, 0),
        catalogue: selectedNode.catalogue
      }
      this.assetTilesService.getAssetCategoryTreeItems(data).subscribe((children: any) => {
        // this.commonService.callApiRestV2('AssetService/asset/getAssetCategoryTreeItems', this.attachToken({
        //   parentID: parseInt(parentCategoryID, 0),
        //   catalogue: selectedNode.catalogue
        // }, this.token), 'post').then((children: any) => {
        if (selectedNode != null && children.length > 0) {
          selectedNode.children = children;
        }
        if (nodeID === -1) {    // for the top level only
          // this.showSelected( this.treeList.children[0], false );   // open child level : 'False' to close tree
        }
      });
    }
  }

  showTreeFunc() {
    this.showTree = !this.showTree;

    if (this.showTree) {
      $('#menu-tree').addClass('menu-tree');
      $('.page-content').css('padding-left', '275px');
      setTimeout(function () {
        $('div.asset-files').find('div.col-lg-2').addClass('colOnTreeView');
      }, 1500);
    } else {
      $('#menu-tree').removeClass('menu-tree');
      $('.page-content').css('padding-left', '15px');
      setTimeout(function () {
        $('div.asset-files').find('div.col-lg-2').removeClass('colOnTreeView');
      }, 1500);
    }
    this.refreshPage();
  }

  refreshPage(listPageFilters?) {
    this.getAssetsFilterFromServer();
    this.filterByAsset = '';
    if (listPageFilters) {
      this.listPage.sort = listPageFilters.sort;
      this.listPage.dir = listPageFilters.dir;
      if (listPageFilters.fromdate) {
        this.listPage.fromdate = this.localToUtcWithInputFormat(new Date(listPageFilters.fromdate));
      }
      if (listPageFilters.todate) {
        this.listPage.todate = this.localToUtcWithInputFormat(new Date(listPageFilters.todate));
      }
      if (this.isAssetsItem) {
        this.getAllLatestAssets();
      } else {
        this.loadMoreCategoriesAndAssets();
      }
    } else {
      this.listPage.page = 1;
      // this.listPage.search = this.assetSearchIn;
      this.assetLisItems = [];
      this.categoryLisItems = [];
      this.noMoreAssets = false;

      if (this.isAssetsItem) {
        this.getAllLatestAssets();
      } else {
        this.loadMoreCategoriesAndAssets();
      }
    }
  }

  pagingDataObj(page, fetchSize, sort, dir, search, catalogue, fromDate, toDate) {
    return {
      // uid: uid,
      page: page,              // page number
      fetchSize: fetchSize,    // page size
      order: sort,             // sort column name
      dir: dir,                // sort direction up/down
      search: search,
      catalogue: catalogue,
      fromdate: fromDate,
      todate: toDate,        // this.listPage.fromdate, this.listPage.todate,
      categoryID: parseInt(this.listPage.categoryID, 0),
      findDuplicate: this.listPage.findDuplicate,
      searchCurrent: this.listPage.searchCurrent,
      token: this.getToken('accessToken')
    };
  }

  addAssetsCheck(data) {
    this.getAllbasketAssets(data)
  }

  addAssetFolder(data) {
    let index;
    index = this.basketAssetsDetails.findIndex(res => res.assetID === data.assetID);
    if (index === -1) {
      let category = {
        token: this.getToken('accessToken'),
        catalogue: data.catalogue,
        assetID: data.assetID,
        fetchSize: 5,
        page: 1
      }

      this.assetTilesService.addAssetFolder(category).subscribe((assetsAdd: any) => {
        if (assetsAdd.statusCode === 200) {
          this.assetTilesService.getAllbasketAssets(category).subscribe((res: any) => {
            this.setStorageValues(res);
            this.translate.get('AssetSuccessfullyAddedToAssetFolder').subscribe((res: string) => {
              this.displayMessage = res;
            });
            this.translate.get('Success').subscribe((res: string) => {
              this.successMessage = res;
            });
            this.commonService.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
          })
        } else {
          this.commonService.displayToaster(this.constants.TOAST_ERROR, assetsAdd.message)
        }
      })
    } else {
      this.translate.get('AssetAlreadyExistsInYourAssetFolder').subscribe((res: string) => {
        this.displayMessage = res;
      });
      this.translate.get('Error').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
    }
  }

  setStorageValues(res) {
    this.assetTilesService.setAssetsBasketTotal(res);
  }

  searchCategory(searchValue) {
    this.searchBindvalue = searchValue;
    this.listPage.search = searchValue;

    let event = {
        event_id: this.constants.ASSET_SEARCH.event_id,
        event_desc: this.constants.ASSET_SEARCH.event_desc,
        attributes: searchValue,
        categoryId : this.listPage.categoryID ? this.listPage.categoryID : ''
    };
      this.logService.createLog(event);
    if (searchValue) {
      this.listPage.searchCurrent = true;
    }
    if (this.isAssetsItem) {
      this.getAllLatestAssets();
    } else {
      this.loadMoreCategoriesAndAssets();
    }
  }

  loadMoreCategoriesAndAssets(assetCategoryObject?, breadcrumClick?) {
    let isUpdate = false;
    this.assetSearchLoading = true;
    this.listPage.filter = this.filterByAsset;
    this.assetLisItems = [];

    if (assetCategoryObject) {
      this.listPage.categoryID = assetCategoryObject.categoryID;
      this.listPage.catalogue = assetCategoryObject.catalogue;
      this.listPage.page = 1;
      this.assetLisItems = [];
      this.categoryLisItems = [];
    }
    this.loading = true;
    let data = {
      categoryID: parseInt(this.listPage.categoryID, 0),
      catalogue: this.listPage.catalogue,
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getCategoryPermission(data).subscribe((categoryPermission: any) => {
      this.categoryPermission = categoryPermission;
      console.log("====???====???", this.categoryIDs);
      let data = {
        page: this.listPage.page,              // page number
        fetchSize: this.listPage.pageSize,    // page size
        order: this.listPage.sort,             // sort column name
        dir: this.listPage.dir,                // sort direction up/down
        filter: this.listPage.filter ? ('F_AssetType:' + this.listPage.filter) : '',
        search: this.listPage.search,
        catalogue: this.listPage.catalogue,
        fromDate: '',
        toDate: '',        // this.listPage.fromdate, this.listPage.todate,
        categoryID: parseInt(this.listPage.categoryID, 0),
        findDuplicate: this.listPage.findDuplicate,
        searchCurrent: this.listPage.searchCurrent,
        token: this.getToken('accessToken'),
        uid: 0
      };

      const categoriesParams = this.serialize(data)
      // let data = this.pagingDataObj(this.listPage.page + 1, this.listPage.pageSize, this.listPage.sort,
      //   this.listPage.dir, this.listPage.F_AssetType, this.listPage.catalogue, this.listPage.fromdate, this.listPage.todate);
      this.assetTilesService.getAssetsCategoriesInRange(categoriesParams).subscribe((categoryAndAssetListPage: any) => {
        categoryAndAssetListPage = categoryAndAssetListPage.instance;

        this.totalSize = Math.ceil(categoryAndAssetListPage.totalSize / categoryAndAssetListPage.pageSize);
        this.loading = false;
        const self = this;
        let prevCategories = [];
        if (this.listPage.page && this.listPage.page > 1) {
          prevCategories = JSON.parse(JSON.stringify(this.listPage.categories));
        }
        this.assetSearchLoading = false;
        this.currentDate = new Date().getTime();
        this.listPage = categoryAndAssetListPage;
        if (prevCategories && prevCategories.length > 0) {
          const nextCategories = JSON.parse(JSON.stringify(this.listPage.categories));
          // next page categories
          this.listPage.categories = []; // empty
          prevCategories.forEach((categoryItem, categoryIndex) => {
            // copy prev set of categories into array
            self.listPage.categories.push(categoryItem);
          });
          nextCategories.forEach((categoryItem, catIndex) => {
            // copy next set of categories into array
            self.listPage.categories.push(categoryItem);
          });
        }
        let isPathSetByCategory = false;
        if (categoryAndAssetListPage.categories.length > 0) {
          if (categoryAndAssetListPage.categoryID > 0) {
            isUpdate = true;
          }

          // For breadcumb
          let duplicateCheckCategoryFlagBreadcumb = true;
          const cat = categoryAndAssetListPage.categories[0].categoryPath.replace(/\s\|\s$/gm, '')
            .replace(/\s/gm, '').split('|');
          const copyCat = JSON.parse(JSON.stringify(cat));
          const title = cat[cat.length - 2];
          const tempObj = {
            catalogue: this.listPage.catalogue,
            categoryID: this.listPage.categoryID,
            title: title
          };
          for (let i = 0; i < this.breadcumb.length; i++) {
            if (parseInt(this.breadcumb[i].categoryID) === parseInt(this.listPage.categoryID)
              && this.breadcumb[i].catalogue === this.listPage.catalogue) {
              duplicateCheckCategoryFlagBreadcumb = false;
              this.breadcumb.splice(i + 1, this.breadcumb.length - (i + 1));
            }
            if (this.breadcumb[i].catalogue && this.breadcumb[i].catalogue !== this.listPage.catalogue
              && this.listPage.categoryID !== -1) {
              cat.pop();
              this.breadcumb = [];
              for (let i = 0; i < this.treeListChildren.length; i++) {
                if (cat[0] === this.treeListChildren[i].catalogue) {
                  if (this.breadcumb.length !== cat.length) {
                    const breadObj = {
                      catalogue: this.treeListChildren[i].catalogue,
                      categoryID: this.treeListChildren[i].id,
                      title: this.treeListChildren[i].title
                    };
                    this.breadcumb.push(breadObj);
                    if (this.treeListChildren[i].children) {
                      this.createBreadcumbOnChangeOfCategory(this.treeListChildren[i].children, cat);
                      duplicateCheckCategoryFlagBreadcumb = false;
                      break;
                    }
                    duplicateCheckCategoryFlagBreadcumb = false;
                  } else {
                    break;
                  }
                }
              }
              break;
            }
          }


          // start
          const copyCopyCat = JSON.parse(JSON.stringify(copyCat));
          if (copyCat) {
            copyCat.pop();
            // remove last element
            for (let index = 0; index < copyCat.length; index++) {
              // Find elements that are not present in PATH
              this.breadcumb.forEach(function (elem, key) {
                if (elem.title === copyCat[index]) {
                  if (index > -1) {
                    copyCat.splice(index, 1);
                  }
                }
              });
            }
            if (copyCat && copyCat.length > 0) {
              // Add elements that are not present in PATH
              for (let index = 0; index < copyCat.length - 1; index++) {
                const result = this.find(this.treeListChildren, copyCat[index]);
                if (result) {
                  const breadObj = {
                    catalogue: result.catalogue,
                    categoryID: result.id,
                    title: result.title
                  };
                  // check if element is already present before pushing
                  let isDuplicate = false;
                  this.breadcumb.forEach(function (elem, key) {
                    if (elem.title === result.title) {
                      isDuplicate = true;
                    }
                  });
                  if (!isDuplicate) {
                    self.breadcumb.push(breadObj);
                  }
                }
              }
            }
          }

          if (duplicateCheckCategoryFlagBreadcumb) {
            let isDuplicate = false;
            this.breadcumb.forEach(function (elem, key) {
              if (elem.title === tempObj.title) {
                isDuplicate = true;
              }
            });
            if (!isDuplicate) {
              self.breadcumb.push(tempObj);
            }
          }
          isPathSetByCategory = true;
          this.categoryLisItems = [];
          this.assetLisItems = [];

          if (categoryAndAssetListPage.categories) {
            categoryAndAssetListPage.categories.forEach((category, index) => {
              // need to check duplicate items: must check name and id since all top level categories have id of 0
              const alreadyListed = this.categoryLisItems.find(function (existingCategory) {
                return existingCategory.categoryID === category.categoryID
                  && existingCategory.categoryName === category.categoryName;
              });

              if (!alreadyListed) {
                if (categoryAndAssetListPage.categoryID !== -1) {
                  // $rootScope.$broadcast('broadcastCategoryAndAsset', this.listPage.categoryID, category,
                }
                this.categoryLisItems.push(category);

              }
            });
          } else {
            this.categoryLisItems = [];
          }
        }

        if (categoryAndAssetListPage.assets.length > 0) {
          let duplicateCheckCategoryFlagBreadcumb = true;
          const cat = categoryAndAssetListPage.assets[0].categoryPath
            .replace(/\s\|\s$/gm, '').replace(/\s/gm, '').split('|');
          const title = cat[cat.length - 1];
          if (title && title !== '') {
            if (!isPathSetByCategory) {
              // set breadcumb if not set by category
              const tempObj = {
                catalogue: this.listPage.catalogue,
                categoryID: this.listPage.categoryID,
                title: title
              };
              for (let i = 0; i < this.breadcumb.length; i++) {
                if (parseInt(this.breadcumb[i].categoryID, 0) === this.listPage.categoryID
                  && this.breadcumb[i].catalogue === this.listPage.catalogue) {
                  duplicateCheckCategoryFlagBreadcumb = false;
                  this.breadcumb.splice(i + 1, this.breadcumb.length - (i + 1));
                }
                if (this.breadcumb[i].catalogue && this.breadcumb[i].catalogue !== this.listPage.catalogue
                  && this.listPage.categoryID !== -1) {
                  cat.pop();
                  this.breadcumb = [];
                  for (let i = 0; i < this.treeListChildren.length; i++) {
                    if (cat[0] === this.treeListChildren[i].catalogue) {
                      if (this.breadcumb.length !== cat.length) {
                        const breadObj = {
                          catalogue: this.treeListChildren[i].catalogue,
                          categoryID: this.treeListChildren[i].id,
                          title: this.treeListChildren[i].title
                        };
                        this.breadcumb.push(breadObj);
                        if (this.treeListChildren[i].children) {
                          this.createBreadcumbOnChangeOfCategory(this.treeListChildren[i].children,
                            cat);
                          duplicateCheckCategoryFlagBreadcumb = false;
                          break;
                        }
                        duplicateCheckCategoryFlagBreadcumb = false;
                      } else {
                        break;
                      }
                    }
                  }
                  break;
                }
              }
              if (duplicateCheckCategoryFlagBreadcumb) {
                this.breadcumb.push(tempObj);
              }
            }

            if (breadcrumClick) {
              this.assetLisItems = categoryAndAssetListPage.assets;
            } else {
              if (categoryAndAssetListPage.assets) {
                categoryAndAssetListPage.assets.forEach(function (asset, index) {
                  asset.assetThumbnailPath = asset.assetThumbnailPath + '?t=' + new Date().getTime();
                  self.assetLisItems.push(asset);
                });
              } else {
                this.assetLisItems = [];
              }
            }


            if ((categoryAndAssetListPage.assets.length + categoryAndAssetListPage.categories.length)
              < this.listPage.pageSize) {
              this.noMoreAssets = true;
            }

            const tempCategory = {
              catalogue: this.listPage.catalogue,
              categoryID: this.listPage.categoryID,
              categoryName: title,
              categoryPath: categoryAndAssetListPage.assets[0].categoryPath,
              isLeaf: !(categoryAndAssetListPage.categories.length > 0)
            };
            // $rootScope.$broadcast('broadcastCategoryAndAsset', this.listPage.categoryID, tempCategory
          }
        } else {
          this.noMoreAssets = true;
        }

      });
    });

  }

  checkUserCategoryDownloadAccess(asset,index){
    this.userDetails = JSON.parse(this.getToken('userDetail'));
    let ssoAdmin = this.getToken('isSsoAdmin')
    if (ssoAdmin) {
      return true
    } else {
      if (this.allItemsCategoryPermission && this.allItemsCategoryPermission.instance) {
        let flag =false;
        for(let i=0 ; i< this.allItemsCategoryPermission.instance.length ;i++){
          let permission = this.allItemsCategoryPermission.instance[i];
          if(permission.categoryId == asset.cid) {

            if ((permission.n || permission.n == 1 || permission.n == '1')
              && (permission.r || permission.r == 1 || permission.r == '1')
              && (!permission.w || permission.w != 1 || permission.w != '1')
              && (!permission.d || permission.d != 1 || permission.d != '1')) { // Download Only
              console.log(permission);
              flag = true;
              break;
            }
            if ((permission.n || permission.n == 1 || permission.n == '1')
              && (permission.r || permission.r == 1 || permission.r == '1')
              && (!permission.w || permission.w == 1 || permission.w == '1')
              && (!permission.d || permission.d == 1 || permission.d == '1')) { // Full Access
              console.log(permission);
              flag = true;
              break;
            }


          }else {
            flag = false;

          }
        }
        return flag;
      }
    }
  }


  checkUserCategoryEditAccess(asset,index){

    this.userDetails = JSON.parse(this.getToken('userDetail'));
    let ssoAdmin = this.getToken('isSsoAdmin')
    if (ssoAdmin) {
      return true
    } else {
      if (this.allItemsCategoryPermission && this.allItemsCategoryPermission.instance) {
        let flag =false;
        for(let i=0 ; i< this.allItemsCategoryPermission.instance.length ;i++){
          let permission = this.allItemsCategoryPermission.instance[i];
          if(permission.categoryId == asset.cid) {

            if ((permission.n || permission.n == 1 || permission.n == '1')
              && (permission.r || permission.r == 1 || permission.r == '1')
              && (permission.w || permission.w == 1 || permission.w == '1')
              && (permission.d || permission.d == 1 || permission.d == '1')) { // Full Access
              console.log(asset)
              console.log(permission);
              flag = true;
              break;
            } else {
              flag = false;

            }

            // if ((permission.n || permission.n == 1 || permission.n == '1')
            //   && (permission.r || permission.r == 1 || permission.r == '1')
            //   && (!permission.w || permission.w != 1 || permission.w != '1')
            //   && (!permission.d || permission.d != 1 || permission.d != '1')) { // Download Only
            //   console.log(permission);
            //   flag = false;
            //   break;
            // }
          } else {
            flag = false;

          }
        }
        return flag;
      }
    }
  }


  checkCondition(asset) {
    if(parseInt(asset.width) > parseInt(asset.height)){
      return true;
    }
  }

  getAllLatestAssets(filterType?) {
    let isUpdate = false;
    this.assetSearchLoading = true;
    if(filterType){
      this.listPage.filter = '';
    }
    this.assetLisItems = [];
    this.loading = true;

      let userID;
      userID = JSON.parse(this.getToken('userDetail')).userID;
      console.log("====???====???", this.categoryIDs);
      let data = {
        page: this.listPage.page,              // page number
        fetchSize: this.listPage.pageSize,    // page size
        order: this.listPage.sort,             // sort column name
        dir: this.listPage.dir,                // sort direction up/down
        filter: this.listPage.filter ? ('F_AssetType:' + this.listPage.filter) : '',
        search: this.listPage.search,
        catalogue: this.listPage.catalogue,
        fromDate: '',
        toDate: '',        // this.listPage.fromdate, this.listPage.todate,
        categoryIDs: this.categoryIDs,
        findDuplicate: this.listPage.findDuplicate,
        searchCurrent: this.listPage.searchCurrent,
        token: this.getToken('accessToken'),
        uid: userID
      };

      const categoriesParams = this.serialize(data)
      console.log("categoriesParams", categoriesParams);
      // let categoryParamsIds = this.ca
     this.categoryIDs = this.categoryIDs.map(res => Number(res));
      this.assetTilesService.getAllLatestAssets(categoriesParams).subscribe((categoryAndAssetListPage: any) => {
        let data = {
          categoryIDs: JSON.stringify(this.categoryIDs),

        };

        let categoryClients = {
          clientIDs : ','+ Number(this.catalogPermissions[0].key) + ',',
          token: this.getToken('accessToken')
        }
        const categoryClientParams = this.serialize(categoryClients)
        this.assetTilesService.getUpdatedCategoryPermission(this.listPage.catalogue,data,categoryClientParams).subscribe((categoryPermission: any) => {
          this.categoryPermission = categoryPermission;
          this.allItemsCategoryPermission = categoryPermission;
        });
        console.log("categoryAndAssetListPage===", categoryAndAssetListPage);
        categoryAndAssetListPage = categoryAndAssetListPage.instance;
        this.totalSize = Math.ceil(categoryAndAssetListPage.totalSize / categoryAndAssetListPage.pageSize);
        this.assetLisItems = categoryAndAssetListPage.rows;
        console.log(this.assetLisItems);
        // this.assetLisItems.map(res => {
        //   res.categories.map(res1 => {
        //     if(res1.categoryID === res)
        //   })
        // })
        // this.assetCategories = categoryAndAssetListPage.instance.rows;
        this.assetLisItems.forEach(res => {
          res.assetThumbnailPath = res.assetThumbnailPath + '?t=' + new Date().getTime();
        });
        this.loading = false;
      });

  }

  fnApplyFilter() {

  }

  fnClearFilter() {

  }

  closeFilter() {

  }

  createBreadcumbOnChangeOfCategory(children, categoryPath) {
    for (let j = 0; j < children.length; j++) {
      if (this.breadcumb.length === categoryPath.length) {
        break;
      } else {
        if (categoryPath.indexOf(children[j].title) !== -1) {
          for (let k = 0; k < this.breadcumb.length; k++) {
            if (this.breadcumb[k].title !== children[j].title) {
              const breadcumbObj = {
                catalogue: children[j].catalogue,
                categoryID: children[j].id,
                title: children[j].title
              };
              this.breadcumb.push(breadcumbObj);
              this.createBreadcumbOnChangeOfCategory(children[j].children, categoryPath);
              break;
            } else {
              break;
            }
          }
        }
        break;
      }
    }
  }

  find(source, id) {
    for (const key in source) {
      if (key) {
        const item = source[key];
        if (item.title === id) {
          return item;
        }
        // Item not returned yet. Search its children by recursive call.
        if (item.children) {
          const subresult = this.find(item.children, id);
          // If the item was found in the subchildren, return it.
          if (subresult) {
            return subresult;
          }
        }
      }
    }

    return null;
  }

  updateOrder(order) {
    this.order = (<HTMLInputElement>document.getElementById(order)).value;
    if (this.order === 'AssetName' || this.order === 'FileFormat') {
      this.filterData.fromdate = '';
      this.filterData.todate = '';
    }
  }

  openCategory(catalogue, categoryID, categoryName?, breadecrumStatus?) {
    this.assetTilesService.setSelectedCategory(categoryName);
    this.isAssetsItem = false;
    console.log('catalogue, categoryID, categoryName?===', catalogue, categoryID, categoryName);
    this.selectCategory = categoryID;
    this.listPage.catalogue = catalogue;
    this.listPage.categoryID = categoryID;
    window.scrollTo(0, 0);
    // required here otherwise next page loading in previous category interferes new listing

    let event = {
      event_id: this.constants.ASSET_CATEGORY.event_id,
      event_desc: this.constants.ASSET_CATEGORY.event_desc,
      attributes: categoryName ? categoryName : '',
      categoryId : categoryID ? categoryID : ''
    };
    this.logService.createLog(event);
    this.updateBreadcrumb(catalogue, categoryID, categoryName, breadecrumStatus);
    if(categoryID) {
      this.getUserPerrmissionsKey(categoryID);
    }
    this.refreshPage();
  }



// update path with new selection
  updateBreadcrumb(catalogue, categoryID, categoryName, breadecrumStatus?) {
    if (breadecrumStatus) {
      this.breadcumb = [];
    }
    // breadcrumb update
    const alreadyIn = this.breadcumb.find((entry) => {
      console.log('entry====', entry);
      return entry.categoryID === categoryID && entry.title === categoryName;
    });
    if (!alreadyIn) {
      this.breadcumb.push({
        catalogue: catalogue, categoryID: categoryID, title: categoryName
      });
    }
  }

  categoryTree(assetObject) {
    if (assetObject.categoryID === -1) {
      this.assetLisItems = [];
      this.categoryLisItems = [];
      // $rootScope.$emit("CallRootMethod", {});   //no need to init tree
      this.breadcumb = [];  //  assets selected
    }
    this.noMoreAssets = false;
    this.loadMoreCategoriesAndAssets(assetObject, true);
  }

  isZip(fileName) {
    if (fileName && fileName.indexOf('.') > 0 && fileName.split('.').pop().toLowerCase() === 'zip') {
      return true;
    }
    return false;
  }

  isIndd(fileName) {
    if (fileName && fileName.indexOf('.') > 0 && fileName.split('.').pop().toLowerCase() === 'indd') {
      return true;
    }
    return false;
  }

  openCategoryDetailModal(isEdit) {
    console.log('isEdit=====', isEdit);
    this.categoryInProcess = false;
    // this.$broadcast('clearFiles');
    this.fileMetaList = [];
    this.isEditCategory = isEdit;
    if (isEdit) {
      this.getFilestorCategoryDetails(isEdit);
    } else {
      this.category = {
        categoryID: -1,
        parentID: this.listPage.categoryID,
        catalogue: this.listPage.catalogue,
        name: null,
        categoryIconOn: null,
        categoryIconOff: null,
        categoryIconClick: '',
        description: null,
        hasChildren: 0,
        categoryExpireType: 1   // 1:day, 2:week, 3:month, 4:year
//                    connectID: null
      };
      this.edit = false;
      // $('#categoryDetail_modal').modal('show');
      this.assetTilesService.setCategoryData(this.category);
      this.assetTilesService.setCategoryEditData(this.edit);
      this.assetTilesService.setListPageData(this.listPage);
      this.router.navigate(['/assets-tiles/manage-category'])
      // this.convertComponentToDom(AddCategoryModalComponent);
    }
  }

  getFilestorCategoryDetails(category) {
    const categoryDup = JSON.parse(JSON.stringify(category));
    delete categoryDup['categoryName'];
    delete categoryDup['categoryPath'];
    categoryDup.token = this.getToken('accessToken');
    this.assetTilesService.getFilestorCategoryDetails(categoryDup).subscribe((response: any) => {
      this.category = JSON.parse(JSON.stringify(response));
      this.edit = true;
      if (this.assetDetails.metaList) {
        this.assetDetails.metaList.forEach((data: any) => {
          data.editingURL = data.fieldValue === null || data.fieldValue === '' || data.fieldValue === undefined;
        });
      }
      this.assetTilesService.setCategoryData(this.category);
      this.assetTilesService.setCategoryEditData(this.edit);
      this.assetTilesService.setListPageData(this.listPage);
      this.assetTilesService.setAssetDetailsData(this.assetDetails);
      this.router.navigate(['/assets-tiles/manage-category'])
      // this.convertComponentToDom(AddCategoryModalComponent);
      // $('#categoryDetail_modal').modal('show');
    });
  }

  openAddAssetModal() {
    this.fileMetaList = [];
    this.assetMetaData = [];
    let data = {
      catalogue: this.listPage.catalogue,
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getAssetMetaDataListWithoutValue(data).subscribe((assetmetaData: any) => {
        this.assetMetaData = assetmetaData;
        this.assetMetaData.forEach((data: any) => {
          data.editingURL = data.fieldValue === null || data.fieldValue === '' || data.fieldValue === undefined;
        });
        this.assetTilesService.setAssetMetaDataData(this.assetMetaData);
        this.assetTilesService.setListPageData(this.listPage);
        this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
        this.convertComponentToDom(AddAssetModalComponent);
      }
    );
  }

  openCategoryPermissionModal(catalogue, category) {
    this.assetTilesService.setTokenData(this.token);
    // this.broadcaster.broadcast('showPermissionModal', {catalogue:catalogue,category:category});
    this.assetTilesService.setPermissionData({catalogue: catalogue, category: category});


    this.router.navigate(['/assets-tiles/category-permission'])
    // this.convertComponentToDom(CategoryPermissionModalComponent);
    // $('#categoryPermission_modal').modal('show');
  }

  editAssetDetails(asset) {

    this.assetDetails = {};
    // var retAssetList = assetService.getAssetById(asset.assetID, asset.catalogue);
    let data = {
      assetID: parseInt(asset.assetID, 0),
      catalogue: asset.catalogue,
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getAsset(data).subscribe((assetDetails: any) => {
        // this.commonService.callApiRestV2('AssetService/asset/getAsset', this.attachToken({
        //
        // }, this.token), 'post').then(
        //   (assetDetails: any) => {
        if (assetDetails) {
          assetDetails.metaList.forEach((obj, index) => {
            if (obj.fieldDisplayType === 'multipleselect') {
              if (obj.fieldValue) {
                obj.fieldValue = obj.fieldValue.split(',');
              }
            } else if (obj.fieldDisplayType === 'date') {
              obj.fieldValue = this.utcToLocalDate(obj.fieldValue);
            }
          });
          this.assetDetails = assetDetails;

          // this.$broadcast('clearFiles'); // clear file list on fileUpload moduleÒ
          this.fileMetaList = [];
          // Service to get the Metadata fields
          // var retList = assetService.getAssetMetaDataListWithoutValue();
          let data = {
            catalogue: this.listPage.catalogue,
            token: this.getToken('accessToken')

          };
          this.assetTilesService.getAssetMetaDataListWithoutValue(data).subscribe((assetmetaData: any) => {
              // this.commonService.callApiRestV2('AssetService/asset/getAssetMetaDataListWithoutValue', {
              //
              //   },
              //   'post').then(
              //   (assetmetaData: any) => {
              this.assetMetaData = assetmetaData;
              this.assetTilesService.setAssetMetaDataData(this.assetMetaData);
              this.assetTilesService.setTokenData(this.token);
              this.assetTilesService.setListPageData(this.listPage);
              this.assetTilesService.setBreadcumb(this.breadcumb);
              this.assetTilesService.setAssetDetailsData(this.assetDetails);
              this.assetTilesService.setUserClientID(this.userClientID);
              // $('#assetDetailEdit_modal').modal('show');  // ensure to fetch fresh assetDetails

              this.convertComponentToDom(EditAssetModalComponent);
            }
          );


        }
      }
    );
  }

  downloadAsset(assetDetail) {
    if (this.accessID > 0) {
      this.translate.get('DownloadInProgress').subscribe((res: string) => {
        this.displayMessage = res;
      });
      this.translate.get('Error').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
    } else {
      this.currentProgress = 0;
      this.assetTilesService.setCurrentProgress(this.currentProgress);
      // $('#assetDownload_modal').modal('show');
      this.convertComponentToDom(DownloadAssetModalComponent);
      let data = {
        assetIDs: [parseInt(assetDetail.assetID, 0)],
        catalogue: assetDetail.catalogue,
        token: this.getToken('accessToken')
      };
      this.assetTilesService.prepAssetFileDownload(data).subscribe((restResponse: any) => {
          console.log('restResponse===selected=111=', restResponse);
          // To get the download progress
          this.accessID = restResponse.message;
          // window.open('../downloadService/download/asset?name=' + restResponse.key + '&access=' + restResponse.message);
          // const a = document.createElement('a');
          // a.id = 'assetDownld';
          // a.name = 'assetDownld';
          // a.href = this.imageUrl + '/downloadService/download/asset?name='
          //   + restResponse.key + '&access=' + restResponse.message;
          // a.click();
          // let data = {
          //   access: this.accessID
          // };
          this.assetTilesService.getProgress({access: this.accessID}).subscribe((progressDetails: any) => {
              console.log("progressDetails=====", progressDetails);
              this.currentProgress = 100;
              this.assetTilesService.setCurrentProgress(this.currentProgress);
              this.accessID = 0;
              this.translate.get('DownloadCompleted').subscribe((res: string) => {
                this.displayMessage = res;
              });
              this.translate.get('Success').subscribe((res: string) => {
                this.successMessage = res;
              });
              this.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
              $('#assetDownld').remove();
              // $('#assetDownload_modal').modal('hide');
              this.closeModel();
              // $('#assetDownload_modal').modal('hide');
            }
          );
        }
      );
    }

  }

  downloadSelectedAssets() {
    var assets = [];
    for (var i = 0; i < this.assetLisItems.length; i++) {
      var assetTemp = this.assetLisItems[i];
      if (assetTemp.checked) {
        assets.push(Number(assetTemp.assetID));
      }
    }
    if (assets && assets.length > 0) {
      this.convertComponentToDom(DownloadAssetModalComponent);
      // $('#assetDownload_modal').modal('show');
      // var retAssetsDown = assetService.prepAssetFileDownload(assets, assetTemp.catalogue);
      let data = {
        assetIDs: assets,
        catalogue: assetTemp.catalogue,
        token: this.getToken('accessToken')
      };
      this.assetTilesService.prepAssetFileDownload(data).subscribe((restResponse: any) => {
          // this.commonService.callApiRestV2('AssetService/asset/prepAssetFileDownload', {
          //
          //   token: this.token
          // }, 'post').then(
          //   (restResponse: any) => {
          console.log("restResponse===selected==", restResponse);

          // To get the download progress
          this.accessID = restResponse.message;

          // window.open('../downloadService/download/asset?name=' + restResponse.key + '&access=' + restResponse.message);
          // var a = document.createElement("a");
          // a.id = "assetDownld";
          // a.name = "assetDownld";
          // a.href = this.imageUrl + '/downloadService/download/asset?name=' + restResponse.key + '&access=' + restResponse.message;
          // a.click();
          // $interval.cancel(downloadInterval);//need to cancel anything existing one
          // downloadInterval = $interval( getProgressDetails, 1000);  // every 1 second

          this.assetTilesService.getProgress({access: this.accessID}).subscribe((progressDetails: any) => {
              console.log("progressDetails=====", progressDetails);
              this.currentProgress = 100;
              this.assetTilesService.setCurrentProgress(this.currentProgress);
              this.accessID = 0;
              this.translate.get('DownloadCompleted').subscribe((res: string) => {
                this.displayMessage = res;
              });
              this.translate.get('Success').subscribe((res: string) => {
                this.successMessage = res;
              });
              this.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
              $('#assetDownld').remove();
              this.closeModel();
              // $('#assetDownload_modal').modal('hide');

            }
          );
          // $('#assetDownload_modal').modal('hide');
        }
      );
    } else {
      this.translate.get('PleaseSelectAsset').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.displayToaster('error', [this.errorMessage]);
    }
  }


  showAssetDetails(asset, assetIndex) {
    console.log(asset)

    if (assetIndex && (assetIndex === 'forward' || assetIndex === 'backward')) {
      if (assetIndex === 'forward' && this.assetIndex < this.assetLisItems.length - 1) {
        this.assetIndex = (this.assetIndex + 1);
        asset = this.assetLisItems[this.assetIndex];
      } else if (assetIndex === 'backward' && this.assetIndex > 0) {
        this.assetIndex = (this.assetIndex - 1);
        asset = this.assetLisItems[this.assetIndex];
      }

    } else if (assetIndex >= 0) {
      this.assetIndex = assetIndex;
    }
    let data = {
      assetID: parseInt(asset.assetID, 0),
      catalogue: asset.catalogue,
      token: this.getToken('accessToken')
    };
    this.assetDetails = {};
    // var retAssetList = assetService.getAssetById(asset.assetID, asset.catalogue);
    this.assetTilesService.getAsset(data).subscribe((assetDetails: any) => {
        console.log(assetDetails);
        
        if (assetDetails) {
          let event = {
            event_id: this.constants.ASSET_VIEW.event_id,
            event_desc: this.constants.ASSET_VIEW.event_desc,
            attributes: assetDetails.assetID,
            categoryId : assetDetails.cid
          };
          this.logService.createLog(event);
          assetDetails.metaList.forEach((obj, index) => {
            if (obj.fieldDisplayType === 'multipleselect') {
              if (obj.fieldValue) {
                obj.fieldValue = obj.fieldValue.split(',');
              }
            } else if (obj.fieldDisplayType === 'date') {
              if (obj.fieldValue && obj.fieldValue != 'Invalid date') {
                obj.fieldValue = this.utcToLocalDate(obj.fieldValue);
              }
              if (obj.fieldValue === 'Invalid date') {
                obj.fieldValue = this.utcToLocalDate(new Date());
              }
            }
          });
          this.assetDetails = assetDetails;
          this.assetTilesService.setAssetDetailsData(this.assetDetails);
          this.assetTilesService.setTokenData(this.token);
          this.assetTilesService.setUserClientID(this.userClientID);
          this.assetTilesService.setListPageData(this.listPage);
          this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
          this.assetTilesService.setAssetIndexItems(this.assetIndex);
          this.assetTilesService.setCategoryPermission(this.categoryPermission);
          if (assetDetails.assetS3PreviewPath) {
            this.imageList = JSON.parse(assetDetails.assetS3PreviewPath);
            this.imageExtension = this.getFileExtension(this.imageList[0].s3Path);
            this.assetsImagePreview = this.imageList[0].s3Path;
          } else {
            this.assetsImagePreview = 'assets/images/default-228x228.jpg';
          }
          this.assetsImageDescription = this.assetDetails.recordName ? this.assetDetails.recordName : this.assetDetails.recordName;
          this.$('#assetsPreviewModal').modal('show')
        }
      }
    );
  }

  addAssetLogHistory(action) {
    console.log("action====", action);
    this.commonService.assetHistoryDetails = [];
    this.token = this.getToken('accessToken');
    let dataObj = {
      assetID: this.assetDetails.assetID,
      catalogue: this.assetDetails.catalogue,
      assetName: this.assetDetails.assetName,
      categoryID: this.assetDetails.cid,
      actionInt: action
    }

    this.assetTilesService.insertAssetLogHistory(dataObj, this.token).subscribe((logAsset: any) => {
      if (logAsset.statusCode === 200) {
        let data = {
          assetID: this.assetDetails.assetID,
          catalogue: this.assetDetails.catalogue
        }
        this.assetTilesService.getAssetLogHistory(data, this.token).subscribe((assetHistoryDetails: any) => {
            this.commonService.assetHistoryDetails = assetHistoryDetails;
          }
        );

      }
    })
    // });
  }

  openShareAssetFilesModal() {
    if (!!this.assetLisItems && this.assetLisItems.length > 0) {
      // make a copy of asset files for clarity
      this.assetShare.type = 'asset';
      this.assetShare.jobStageID = 0;
      this.assetShare.catalogue = this.listPage.catalogue;     // assume assets are all under the same catalogue
      this.assetShare.assetFiles = [];
      // only pick necessary info from asset list - assetID, catalogue, name
      this.assetLisItems.map((asset: any) => {
        this.assetShare.assetFiles.push({
          selected: true,  // select all files by default
          assetID: asset.assetID,
          assetName: asset.assetName
        });
      });
      this.assetShare.disabled = false;
      this.assetShare.emails = '';
      this.assetShare.message = '';
      this.assetShare.minDateRange = new Date(moment().add(-1, 'days').toDate()).getTime();
      this.assetShare.expireDate = new Date(moment().add(7, 'days').toDate()).setHours(17, 0, 0);    // +7 days at 5pm
      this.assetShare.expireDate = new Date(this.assetShare.expireDate);
      // $('#share-asset-files-modal').modal('show');
      this.assetShare.assetFiles = this.assetLisItems;
      this.assetTilesService.setTokenData(this.token);
      this.assetTilesService.setAssetShare(this.assetShare)
      this.convertComponentToDom(ShareAssetModalComponent);
    } else {
      this.displayToaster('warning', [this.getTranslateWord('Noassetsavailableinthiscategory')]);
    }
  }

  assetsDownload(assets) {
    console.log("assets", assets);
    const data = {
      token: this.getToken('accessToken'),
      catalouge: this.isCCEP(), // Remove Hard coded
      assetsIds: assets.assetID
    };

    let event = {
      event_id: this.constants.ASSET_DOWNLOAD.event_id,
      event_desc: this.constants.ASSET_DOWNLOAD.event_desc,
      attributes: assets.assetID,
      categoryId : assets.cid
    };
    this.logService.createLog(event);

    console.log(new Date().getTime().toString())
    this.url = this.env.apiUrl + 'AssetService/v1/asset/' + data.catalouge + '/download?token=' + data.token + '&fileName=&assetIDs=' + data.assetsIds+ '&timestamp=' + new Date().getTime().toString();
    window.open(this.url);
  }


  getFileExtension(file) {
    var regexp = /\.([0-9a-z]+)(?:[\?#]|$)/i;
    var extension = file.match(regexp);
    return extension && extension[1];
  }

  closePopup(imageExtension) {
    if (imageExtension === 'mp4') {
      this.video = document.getElementById('video');
      this.video.src = "";
    }
    this.$('#assetsPreviewModal').modal('hide');
  }

  allAssetsList() {
    this.isAssetsItem = true;
    this.selectCategory = '';
    this.filterType = true;
    this.getAllLatestAssets(this.filterType);
    this.getAssetsFilterFromServer("0");
    let event = {
      event_id: this.constants.ASSET_CATEGORY.event_id,
      event_desc: this.constants.ASSET_CATEGORY.event_desc,
      attributes: this.constants.LOG_ALL_ITEM,
      categoryId : 0
    };
    this.logService.createLog(event);
  }


  // =========end==========
}



