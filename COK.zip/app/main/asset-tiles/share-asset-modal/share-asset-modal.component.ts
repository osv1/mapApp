import {
  Component,
  OnInit,
  ChangeDetectorRef,
  Injector,
} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {AssetTilesService} from "../asset-tiles.service";

declare var $: any;
declare var moment: any;

@Component({
  selector: 'app-share-asset-modal',
  templateUrl: './share-asset-modal.component.html',
  styleUrls: ['./share-asset-modal.component.css'],
})
export class ShareAssetModalComponent extends BaseComponent implements OnInit {
  assetShare: any = {emails: '', disabled: false, message: ''};
  restUserCreateAsset: any = '';
  token: any;
  userDetail: any;

  constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService) {
    super(inj);
  }

  ngOnInit() {
    this.assetTilesService.tokenItems.subscribe((success: any) => {
      this.setTokenValue(success);
    });
    this.assetTilesService.assetShare.subscribe((success: any) => {
      this.setAssetShare(success);
    });
  }

  setTokenValue(data) {
    this.token = data;
  }

  setAssetShare(data) {
    this.assetShare = data;

    // share file selection flag is 'selected'
    this.assetShare.assetFiles.map((assetFile: any) => {
      assetFile.selected = !!assetFile.checked ? assetFile.checked : false;   // just in case checked is undefined
    });
  }

  // (un)tick a file, disable share button when none is selected
  selectAssetFile(assetFile) {
    assetFile.selected = !assetFile.selected;

    const selectedFiles = this.assetShare.assetFiles.filter((assetFileRes: any) => {
      return assetFileRes.selected;
    });

    if (selectedFiles && selectedFiles.length > 0) {
      this.assetShare.disabled = false;
    } else {
      this.assetShare.disabled = true;
    }
  }

  setDefaultDate(obj, dateType) {
    if (dateType === 'startDate' || dateType === 'newStartDate') {
      if (obj) {
        if (obj[dateType]) {
          // obj[dateType] = obj[dateType].replace('00:00', '09:00');
        }
      }
    } else {
      if (obj[dateType]) {
        // obj[dateType] = obj[dateType].replace('00:00', '17:00');
      }
    }
    // $scope.campaignCrud[dateType] = obj[dateType];
  }

  shareAssetFiles(ev) {
    const messages = [];

    const fileNames = [];
    const assetIDs = [];
    if (this.assetShare.assetFiles.length === null || this.assetShare.assetFiles.length === 0) {
      messages.push(this.getTranslateWord('Assetfilerequired'));
    } else {
      this.assetShare.assetFiles.map(function (file) {
        if (file.selected) {  // ticked asset files only
          assetIDs.push(+file.assetID);    // pass a list of ids only, ensure to make it number
          fileNames.push(file.assetName);
        }
      });
    }

    let emails = [];
    if (this.assetShare.emails === null || this.assetShare.emails.length === 0) {
      messages.push(this.getTranslateWord('Emailaddressrequired'));
    } else {
      // simple pattern checkup
      if (this.assetShare.emails.indexOf(',') !== -1) {
        emails = this.assetShare.emails.split(',');
      } else {
        emails.push(this.assetShare.emails);
        // one entry
      }

      const wrongEmails = emails.filter(function (email) {
        return !email.match(/@\w+\./g);     // simple check up to see if the email has a pattern of @abc.
      });

      if (wrongEmails && wrongEmails.length > 0) {
        messages.push(this.getTranslateWord('Validemailaddressrequired'));
      }
    }

    if (this.assetShare.expireDate === null || this.assetShare.expireDate === '') {
      messages.push(this.getTranslateWord('Expiredatemissing'));
    }

    if (messages.length > 0) {
      this.displayToaster('warning', [messages]);
      return;
    }

    // !!! NOTE UTC is not used on this expire value - simple string value
    const expireDateToSubmit = moment(this.assetShare.expireDate).format('YYYY-MM-DD HH:mm');
    const expireDateForComment = moment(this.assetShare.expireDate).format('Do MMMM YYYY');
    // 10th November 2018
    let contentText: any = '';
    this.translate.get('content').subscribe((res: string) => {
      contentText = res;
    });
    let okText: any = '';
    this.translate.get('ok').subscribe((res: string) => {
      okText = res;
      okText = res;
    });
    let cancelText: any = '';
    this.translate.get('ok').subscribe((res: string) => {
      cancelText = res;
    });
    this.swal({
      title: 'Are you sure you want to share selected files?',
      text: 'This action cannot be undone.',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      cancelButtonText: 'Cancel',
      confirmButtonText: 'Ok'
    }).then((result) => {
        if (result.value) {
          if (!this.restUserCreateAsset.token) {
            this.assetShare.disabled = true;
            let objData = {
              email: this.assetShare.emails,
              expiryDate: expireDateToSubmit,
              catalogue: this.assetShare.catalogue,
              assetIDs: assetIDs,
              type: this.assetShare.type,
              message: this.assetShare.message,
              expiryDateString: expireDateForComment
            }
            let token = this.getToken('accessToken')
            this.assetTilesService.share(objData, token).subscribe((response: any) => {
              if (response.statusCode === 200) {
                this.displayToaster('sucess', [this.getTranslateWord('Emailnotificationsentsuccessfully')]);
                this.closeModel();
                // $('#share-asset-files-modal').modal('hide');
              } else {
                this.displayToaster('error', [this.getTranslateWord('Failedtoshareassetfiles')]);
              }
              this.assetShare.disabled = false;

            });
            // }
            // });

          } else {
            this.restUserCreateAsset = '';
            this.displayToaster('error', [this.getTranslateWord('Failedtoregisterrestfulservice')]);
          }
        }
      }
    );
  }
}
