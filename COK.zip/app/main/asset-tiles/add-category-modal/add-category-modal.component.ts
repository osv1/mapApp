import {Component, OnInit, ChangeDetectorRef, Injector, ViewChild, ElementRef} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {FileUploader} from 'ng2-file-upload';
import {AssetTilesService} from '../asset-tiles.service';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';


declare var $: any;
declare var moment: any;

@Component({
  selector: 'app-add-category-modal',
  templateUrl: './add-category-modal.component.html',
  styleUrls: ['./add-category-modal.component.css'],
})
export class AddCategoryModalComponent extends BaseComponent implements OnInit {
  @ViewChild('fileInput') fileInput: ElementRef;
  public assetMetaData: any = [];
  addAssetAjax = false;
  displayMessage;
  token: any;
  isEditCategory;
  assetDetails: any = {};
  categoryInProcess = false;
  category: any;
  listPage: any = {
    rows: [],
    page: 1,
    pageSize: 100,
    totalSize: 0,
    sort: 'AssetName',
    dir: 'up',
    search: '',
    catalogue: this.isCCEP(),
    categoryID: 0,
    findDuplicate: false,
    searchCurrent: false
  };
  edit;
  errorMessage;
  successMessage;
  public assetsSyncedCategories = [];
  public categories : any = [];
  public newCategoryName;
  public categoryDetails: any = {};
  public categoryOrders;
  private subSelectedCategorieIds = [];
  categoryRequest: any = {
    catalogue: this.isCCEP(),
    categoryIDs: '',
    categoryID: ''
  };
  newCategoryId: any;
  categoryItem: any;
  categoryPrint:  any;


  constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService) {
    super(inj);
  }

  ngOnInit() {
    this.commonService.imageTypeFields = [''];

    this.getSyncedCategories();
  }

  getCategoriesList() {
    this.listPage.token = this.getToken('accessToken');
    this.listPage.uid = 0;
    this.listPage.fromDate = '';
    this.listPage.toDate = '';
    this.listPage.fetchSize = 100;
    this.listPage.order = 'AssetName';

    let data = this.listPage;
    const categoriesParams = this.serialize(data);
    this.assetTilesService.getAssetsCategoriesInRange(categoriesParams).subscribe((categoryAndAssetListPage: any) => {
      if (categoryAndAssetListPage.statusCode === 200) {
        this.categories = [];
        this.categories = categoryAndAssetListPage.instance.categories;
        this.categories.sort((a, b) => Number(a.rank) - Number(b.rank));
        console.log(this.categories);
        this.categoryPrint=  this.categories[0].categoryName;
        this.newCategoryId = this.categories[0].categoryID;
        this.categoryDetails.selectedCategory = categoryAndAssetListPage.instance.categories[0].categoryID;
        this.assetsSyncedCategories.forEach((obj, index) => {
          // console.log("obj", obj)
          if (obj.categoryID == this.newCategoryId) {
            console.log('categories list *******', obj);
            this.subSelectedCategorieIds.push(Number(obj.dmhCategoryID));
          }
        });
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, categoryAndAssetListPage.message);
      }
    });
  }

  getSyncedCategories() {
    this.assetTilesService.getSynced().subscribe((res: any) => {
      // this.commonService.displayToaster(this.constants.TOAST_SUCCESS,res.message);
      if (res.statusCode === 200) {
        this.assetsSyncedCategories = res.instance;
        // this.categoryRequest.categoryIDs = 75;
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
      }
      this.getCategoriesList();
    });
  }


  addCategory() {
    let data = {
      catalogue: this.isCCEP(),
      name: this.newCategoryName
    };
    if (this.newCategoryName) {
      this.assetTilesService.addNewCategory(data).subscribe((res: any) => {
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, res.message);
        if (res.statusCode === 200) {
          this.newCategoryName = undefined;
          this.getCategoriesList();
        } else {
          this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
        }
      });
    } else {
      this.commonService.displayToaster(this.constants.TOAST_ERROR, 'Please add category name.');
    }
  }


  openDeleteCategoryModal(){
    this.$('#deleteCategoryModal').modal('show');
  }

  hideDeleteCategoryModal(){
    this.$('#deleteCategoryModal').modal('hide');
  }

  deleteCategorgy() {
    let data = {
      catalogue: this.isCCEP(),
      categoryId: Number(this.categoryDetails.selectedCategory)
    };
    if (this.categoryDetails.selectedCategory) {

      this.assetTilesService.deleteCategory(data).subscribe((res: any) => {
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, res.message);
        if (res.statusCode === 200) {
          this.newCategoryName = undefined;
          this.getCategoriesList();
        } else {
          this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
        }
      });
    } else {
      this.commonService.displayToaster(this.constants.TOAST_ERROR, 'Please add category name.');
    }
  }

  setNewCategory(event) {
    this.subSelectedCategorieIds = [];
   console.log("event",event);
    this.categoryDetails.selectedCategory = event.target.value;
    // this.categoryItem = event.target.value.categoryName;
    this.newCategoryId = event.target.value;
    // this..filter(())
    this.categories.forEach((obj,index)=>{
     if(obj.categoryID === event.target.value) {
       this.categoryPrint = obj.categoryName;
     }
    });
    this.assetsSyncedCategories.forEach((obj, index) => {
      // console.log("obj", obj)
      if (obj.categoryID == this.newCategoryId) {
        console.log('categories list *******', obj);
        this.subSelectedCategorieIds.push(Number(obj.dmhCategoryID));
      }
    });
  }


  /* Drag n Drop - angular cdk */
  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex);
    }
    let data = event.container.data;
    data.map((res:any,index) => {
      console.log(res.categoryName,index)
      res.rank = index+1
    })
    console.log(data);
    this.categoryOrders = data.reduce(
      (data, item:any) => Object.assign(data, { [Number(item.rank)]: Number(item.categoryID) }), {});
    console.log(this.categoryOrders)
    this.saveCategoryOrder();
  }


  saveCategoryOrder(){
    let data = {
      categoriesWithOrder : this.categoryOrders
    };
    this.assetTilesService.saveCategoryOrder(data, this.isCCEP()).subscribe((res: any) => {
      if (res.statusCode = this.constants.SUCCESS_CODE) {
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, 'Category order successfully');
      }
    })
  }

  saveCategory(categoryData) {
    if (categoryData.categoryIDs || this.subSelectedCategorieIds.length) {
      this.categoryRequest = {
        catalogue: this.isCCEP(),
        categoryIDs: categoryData.categoryIDs.length ? categoryData.categoryIDs.toString() : this.subSelectedCategorieIds.toString(),
        categoryID: parseInt(this.categoryDetails.selectedCategory)
      };
      let token = this.getToken('accessToken');
      this.assetTilesService.saveCategory(this.categoryRequest, token).subscribe((res: any) => {
        console.log("assetTilesService=====>>>", res);
        if (res.statusCode = this.constants.SUCCESS_CODE) {
          this.commonService.displayToaster(this.constants.TOAST_SUCCESS, 'Category saved successfully');
          this.router.navigate(['assets-tiles']);
        }
      })
    } else {
      this.commonService.displayToaster(this.constants.TOAST_ERROR, 'Please select at least one category');
    }

  }
}
