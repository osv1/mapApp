import {
  Component,
  OnInit,
  AfterViewInit,
  ChangeDetectorRef,
  Injector,
  ViewChild,
  ElementRef
} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {AssetTilesService} from "../asset-tiles.service";

declare var $: any;
declare var moment: any;

@Component({
  selector: 'app-edit-asset-modal',
  templateUrl: './edit-asset-modal.component.html',
  styleUrls: ['./edit-asset-modal.component.css'],
})
export class EditAssetModalComponent extends BaseComponent implements OnInit {
  @ViewChild('fileInput') fileInput: ElementRef;
  public assetMetaData: any = [];
  assetDetails: any = {};
  breadcumb = [];
  assetLisItems = [];
  addAssetAjax = false;
  displayMessage;
  token: any;
  closeAssetUpload = false;
  listPage: any = {
    rows: [],
    page: 0,
    pageSize: 100,
    totalSize: 0,
    sort: 'AssetName',
    dir: 'up',
    search: '',
    catalogue: 'Assets',
    categoryID: -1,
    findDuplicate: false,
    searchCurrent: false
  };
  userClientID: any;
  errorMessage;
  successMessage;
  userDetails:any= {};

  constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService) {
    super(inj);
  }

  ngOnInit() {
    this.commonService.imageTypeFields = [''];
    this.fileUploaderService.ngOnInit();
    this.assetTilesService.assetMetaData.subscribe((success: any) => {
      this.setAssetMetaDataValue(success);
    });
    this.assetTilesService.listPageItems.subscribe((success: any) => {
      this.setListPageDataValue(success);
    });
    this.assetTilesService.assetListItems.subscribe((success: any) => {
      this.setAssetLisItemsValue(success);
    });
    this.assetTilesService.tokenItems.subscribe((success: any) => {
      this.setTokenValue(success);
    });
    this.assetTilesService.breadcumb.subscribe((success: any) => {
      this.setBreadcumbValue(success);
    });
    this.assetTilesService.assetDetailsItems.subscribe((success: any) => {
      this.setAssetDetailDataValue(success);
    });
    this.assetTilesService.userClientIDItems.subscribe((success: any) => {
      this.setUserClientID(success);
    });
  }

  setUserClientID(data) {
    this.userClientID = data;
  }

  setAssetDetailDataValue(data) {
    this.assetDetails = Object.assign({}, data);
  }

  setBreadcumbValue(data) {
    this.breadcumb = data;
  }

  setTokenValue(data) {
    this.token = data;
  }

  setAssetMetaDataValue(data) {
    this.assetMetaData = data;
  }

  setListPageDataValue(data) {
    this.listPage = data;
  }

  setAssetLisItemsValue(data) {
    this.assetLisItems = data;
  }

  openFileUpload() {
    this.fileInput.nativeElement.click();
  }

  closeAddAssetPopUp() {
    this.assetMetaData = [];
  }

  ///////////////////////////////////////////////////////////////////////////
  //                  Function to update  the assets                          //
  ///////////////////////////////////////////////////////////////////////////
  updateAssetDetailsFile(updatedAssetDetails) {
    this.addAssetAjax = false;
    if (this.fileUploaderService.fileMetaList.length === 0) {
      let PleaseSelectFileFirst;
      this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
        PleaseSelectFileFirst = res;
      });
      let FileUpload;
      this.translate.get('FileUpload').subscribe((res: string) => {
        FileUpload = res;
      });
      this.displayToaster('error', [PleaseSelectFileFirst], 5000, FileUpload);
      return;
    } else if (this.fileUploaderService.fileMetaList.length > 1) {
      let OnlyOneFileIsAllowed;
      this.translate.get('OnlyOneFileIsAllowed').subscribe((res: string) => {
        OnlyOneFileIsAllowed = res;
      });
      let FileUpload;
      this.translate.get('FileUpload').subscribe((res: string) => {
        FileUpload = res;
      });
      this.displayToaster('error', [OnlyOneFileIsAllowed], 5000, FileUpload);
      return;
    }
    if (this.fileUploaderService.fileMetaList) {
      // Service call to add the assets
      this.addAssetAjax = true;

      // pick up required details only and create a file list to submit
      const filesToAdd = [];
      this.fileUploaderService.fileMetaList.forEach((f, index) => {
        const fileMeta: any = {
          fileName: f.fileName,
          fileSize: '',
          fileType: f.fileType,
          realFileName: f.realFileName
        };
        filesToAdd.push(fileMeta);
      });
      // var retAssetList = assetService.getAssetById(updatedAssetDetails.assetID, updatedAssetDetails.catalogue);
      let objData = {
        assetID: parseInt(updatedAssetDetails.assetID, 0),
        catalogue: updatedAssetDetails.catalogue,
        token: this.getToken('accessToken')
      }
      this.assetTilesService.getAsset(objData).subscribe((assetDetails: any) => {
        if (assetDetails) {
          const returnAssetMetaDataList = this.prepMetadataForSubmission(assetDetails.metaList, undefined, undefined, true);
          this.userDetails = JSON.parse(this.getToken('userDetail'));
          console.log("this.userDetails",this.userDetails);
          // Puneet - matching the call
          // Call prepMetadataForSubmission function
          // TODO - MODIFY THIS METHOD TO ONLY ALLOW TO UPDATE FILE
          // var retAssetList = assetService.updateFilesForAsset(this.listPage.catalogue, this.listPage.categoryID,
          // returnAssetMetaDataList, filesToAdd, updatedAssetDetails.assetID);
          // http://54.206.16.72/rest_v2/RestService/asset/updateFilesForAsset
          let objData = {
            uid: this.userDetails.userID,
            assetID: parseInt(updatedAssetDetails.assetID, 0),
            categoryID: this.listPage.categoryID,
            catalogue: this.listPage.catalogue,
            metadata: returnAssetMetaDataList,
            fileMeta: filesToAdd,
            loginUserName: '',
            userClientID: parseInt(this.userClientID, 0),
            token: this.getToken('accessToken')
          }
          this.assetTilesService.updateFilesForAsset(objData).subscribe((restResponse: any) => {
              // this.commonService.callApiRestV2('RestService/asset/updateFilesForAsset', this.attachToken({
              //
              // }, this.token), 'post').then(
              //     (restResponse: any) => {
              if (restResponse.statusCode === 200) {
                if (restResponse.instance && restResponse.instance instanceof Array) {
                  for (let i = 0; i < restResponse.instance.length; i++) {
                    this.assetLisItems.push(restResponse.instance[i]);
                    // append asset list
                  }
                } else {
                  this.assetLisItems.push(restResponse.instance);
                  // append asset
                }
                this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
                // categoryTree(breadcumbobject)

                if (this.breadcumb && this.breadcumb.length > 0) {
                  // refresh new thumbnail
                  const assetObject = this.breadcumb[this.breadcumb.length - 1];
                  // this.categoryTree(assetObject);
                  this.broadcaster.broadcast('categoryTree', {assetObject: assetObject});
                }
                // $('#assetDetailEdit_modal').modal('hide');
                this.closeModel();
                this.fileUploaderService.fileMetaList = [];   // remove files in asset module
                // $rootScope.$broadcast('fileRemove');    // remove files in upload module
                let AssetFileHasBeenUpdatedSuccessfully;
                this.translate.get('AssetFileHasBeenUpdatedSuccessfully').subscribe((res: string) => {
                  AssetFileHasBeenUpdatedSuccessfully = res;
                });
                this.translate.get('Success').subscribe((res: string) => {
                  this.successMessage = res;
                });
                this.displayToaster('success', [AssetFileHasBeenUpdatedSuccessfully], 5000, this.successMessage);
              } else {
                let FailedToUpadateAsset;
                this.translate.get('FailedToUpadateAsset').subscribe((res: string) => {
                  FailedToUpadateAsset = res;
                });
                this.translate.get('Error').subscribe((res: string) => {
                  this.errorMessage = res;
                });
                this.displayToaster('error', [FailedToUpadateAsset], 5000, this.errorMessage);
              }
              this.addAssetAjax = false;

            }
          );
        } else {
          let PleaseUploadFileAtleastToAddTheAsset;
          this.translate.get('PleaseUploadFileAtleastToAddTheAsset').subscribe((res: string) => {
            PleaseUploadFileAtleastToAddTheAsset = res;
          });
          let MissingFileUpload;
          this.translate.get('MissingFileUpload').subscribe((res: string) => {
            MissingFileUpload = res;
          });
          this.displayToaster('error', [PleaseUploadFileAtleastToAddTheAsset], 5000, MissingFileUpload);
        }
      });
    }

  }

  ///////////////////////////////////////////////////////////////////////////
  //                  Function to replace thumbnail                        //
  ///////////////////////////////////////////////////////////////////////////
  replaceAssetThumbnail(updatedAssetDetails) {
    this.addAssetAjax = false;
    let FileUpload;
    this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
      FileUpload = res;
    });
    if (this.fileUploaderService.fileMetaList.length === 0) {
      let PleaseSelectFileFirst;
      this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
        PleaseSelectFileFirst = res;
      });
      this.displayToaster('error', [PleaseSelectFileFirst], 5000, FileUpload);
      return;
    } else if (this.fileUploaderService.fileMetaList.length > 1) {
      let OnlyOneFileIsAllowed;
      this.translate.get('OnlyOneFileIsAllowed').subscribe((res: string) => {
        OnlyOneFileIsAllowed = res;
      });
      this.displayToaster('error', [OnlyOneFileIsAllowed], 5000, FileUpload);
      return;
    }


    if (this.fileUploaderService.fileMetaList) {
      // Service call to add the assets
      this.addAssetAjax = true;

      // pick up required details only and create a file list to submit
      const filesToAdd = [];
      this.fileUploaderService.fileMetaList.forEach((f, index) => {
        const fileMeta = {
          fileName: f.fileName,
          fileSize: '',
          fileType: f.fileType,
          realFileName: f.realFileName
        };
        filesToAdd.push(fileMeta);
      });

      // var retAssetList = assetService.getAssetById(updatedAssetDetails.assetID, updatedAssetDetails.catalogue);
      let objData = {
        assetID: parseInt(updatedAssetDetails.assetID, 0),
        catalogue: updatedAssetDetails.catalogue,
        token: this.getToken('accessToken')
      }
      this.assetTilesService.getAsset(objData).subscribe((assetDetails: any) => {
      // this.commonService.callApiRestV2('AssetService/asset/getAsset', this.attachToken({
      //   assetID: parseInt(updatedAssetDetails.assetID, 0),
      //   catalogue: updatedAssetDetails.catalogue
      // }, this.token), 'post').then(
      //   (assetDetails: any) => {
          if (assetDetails) {
            // Call prepMetadataForSubmission function
            const returnAssetMetaDataList = this.prepMetadataForSubmission(assetDetails.metaList, undefined, undefined, true);
            // Puneet - matching the call


            // var retAssetList = assetService.replaceAssetThumbnail($scope.listPage.catalogue, $scope.listPage.categoryID
            // , returnAssetMetaDataList, filesToAdd, updatedAssetDetails.assetID);
            let objData = {
              assetID: parseInt(updatedAssetDetails.assetID, 0),
              categoryID: this.listPage.categoryID,
              catalogue: this.listPage.catalogue,
              metadata: returnAssetMetaDataList,
              fileMeta: filesToAdd,
              loginUserName: '',
              userClientID: parseInt(this.userClientID, 0),
              token: this.getToken('accessToken')
            }
            this.assetTilesService.replaceAssetThumbnail(objData).subscribe((restResponse: any) => {
                if (restResponse.statusCode === 200) {
                  if (restResponse.instance && restResponse.instance instanceof Array) {
                    for (let i = 0; i < restResponse.instance.length; i++) {
                      this.assetLisItems.push(restResponse.instance[i]);
                      // append asset list
                    }
                  } else {
                    this.assetLisItems.push(restResponse.instance);
                    // append asset
                  }
                  this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
                  // categoryTree(breadcumbobject)

                  if (this.breadcumb && this.breadcumb.length > 0) {
                    // refresh new thumbnail
                    const assetObject = this.breadcumb[this.breadcumb.length - 1];
                    // this.categoryTree(assetObject);
                    this.broadcaster.broadcast('categoryTree', {assetObject: assetObject});
                  }
                  // $('#assetDetailEdit_modal').modal('hide');
                  this.closeModel();
                  this.fileUploaderService.fileMetaList = [];   // remove files in asset module
                  // $rootScope.$broadcast('fileRemove');    // remove files in upload module
                  let AssetFileHasBeenUpdatedSuccessfully;
                  this.translate.get('AssetFileHasBeenUpdatedSuccessfully').subscribe((res: string) => {
                    AssetFileHasBeenUpdatedSuccessfully = res;
                  });
                  this.translate.get('Success').subscribe((res: string) => {
                    this.successMessage = res;
                  });
                  this.displayToaster('success', [AssetFileHasBeenUpdatedSuccessfully], 5000, this.successMessage);
                } else {
                  let FailedToUpadateAsset;
                  this.translate.get('FailedToUpadateAsset').subscribe((res: string) => {
                    FailedToUpadateAsset = res;
                  });
                  this.translate.get('Error').subscribe((res: string) => {
                    this.errorMessage = res;
                  });
                  this.displayToaster('error', [FailedToUpadateAsset], 5000, this.errorMessage);
                }
                this.addAssetAjax = false;

              }
            );
          } else {
            let PleaseUploadFileAtleastToAddTheAsset;
            this.translate.get('PleaseUploadFileAtleastToAddTheAsset').subscribe((res: string) => {
              PleaseUploadFileAtleastToAddTheAsset = res;
            });
            let MissingFileUpload;
            this.translate.get('MissingFileUpload').subscribe((res: string) => {
              MissingFileUpload = res;
            });
            this.displayToaster('error', [PleaseUploadFileAtleastToAddTheAsset], 5000, MissingFileUpload);
          }
        });
    }

  }

  prepMetadataForSubmission(metaList, id, isPressJob, isAddAsset, isTaskCopy?, isProcurement?, addNooshProjectId?) {
    // isPressJob used to allow noneditable fields to get values
    // create a array of string 'fieldID|,|fieldValue' pairs  TODO may just pass changed values by keeping a copy of original
    const metaIdValuePairs = [];
    // angular.forEach(metaList, function (meta, index) {
    if (metaList !== null || metaList !== undefined) {
      for (let index = 0; index < metaList.length; index++) {     // use for loop to break out of looping
        const meta = metaList[index];
        // extra care for date and other spcial display types
        if (typeof meta.fieldDisplayType === 'string') {
          if (meta.fieldDisplayType.toLowerCase().indexOf('noneditable') === -1 || isPressJob || (addNooshProjectId
            && addNooshProjectId === true && meta.fieldName === 'NooshProjectID') || (meta.fieldName === 'Project_Name')) {
            // Press job needs to allow noneditable fields to be updated

            if (meta.fieldDisplayType === 'date') { // update date format to make the field eligible for database insert
              if (meta.fieldValue !== '') {
                meta.fieldValue = this.localToUtcWithInputFormat(meta.fieldValue);
              }
              // jquery plugin version
              /*meta.fieldValue = $('#date-' + id + '-' + meta.fieldID).val();
               if ( meta.fieldValue == undefined ) {
               meta.fieldValue = '';
               }*/
            } else if (meta.fieldDisplayType === 'multipleselect') {
              if (isAddAsset) {
                if (meta.fieldValue) {
                  meta.fieldValue = meta.fieldValue.toString();
                }
              } else {
                let checked = '';
                meta.multiValues.forEach((selectOpt, metaIndex) => {
                  if (selectOpt.selected !== '') {
                    checked = checked + ',' + selectOpt.selected;
                  }
                });
                meta.fieldValue = checked.substring(1);
              }
            }

            // mandatory field checkup
            if (meta.mandatory && (meta.fieldValue === '' || meta.fieldValue == null ||
              (meta.fieldDisplayType === 'file' && meta.fieldValue === 0))) {
              // updated to use fieldName
              if (typeof meta.fieldName === 'string') {
                if (isProcurement && meta.fieldName.toLowerCase() === 'contact' /*meta.fieldID=='62'*/) {
                  // skip checking ergo contact ID if procurement channel is added after import
                } else {
                  return null;
                }
              } else {
                return null;
              }

            }

            // metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);

            if (isTaskCopy) {
              metaIdValuePairs.push(meta.fieldID + '_' + meta.jobMetaDataID /*taskCopyUD*/ + '|-|' + meta.fieldValue + '|,|');

            } else {

              if (meta.fieldID === undefined) {  // Filestor 3.7 metadata
                metaIdValuePairs.push(meta.fieldName + '|=|' + meta.fieldValue);
              } else {                            // JAS metadata
                if (meta.fieldValue.id === undefined) {
                  metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);
                } else {  // in case of id is used for value
                  metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue.id);
                }
              }
            }
          }
        } else {
          return null;
        }
      }
    }
    // });
    return metaIdValuePairs;
  }

  localToUtcWithInputFormat(strLocalDateTime, inputFormat?) {
    // when input format is not set use default
    if (!inputFormat) {
      inputFormat = this.defultInputFormat; // 'DD/MM/YYYY HH:mm';
    }

    // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
    const momentTime = moment(strLocalDateTime).subtract(moment(strLocalDateTime).utcOffset(), 'm');
    const formattedUtcDateTime = momentTime;
    return formattedUtcDateTime.format(this.defaultFormat);
  }
}
