import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssetsDownloadsComponent } from './assets-downloads.component';

describe('AssetsDownloadsComponent', () => {
  let component: AssetsDownloadsComponent;
  let fixture: ComponentFixture<AssetsDownloadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssetsDownloadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssetsDownloadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
