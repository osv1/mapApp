import {
  Component,
  OnInit,
  Injector,
} from '@angular/core';
import {AssetTilesService} from '../asset-tiles.service';
import {BaseComponent} from '../../../common/commonComponent';

@Component({
  selector: 'app-assets-downloads',
  templateUrl: './assets-downloads.component.html',
  styleUrls: ['./assets-downloads.component.css']
})
export class AssetsDownloadsComponent extends BaseComponent implements OnInit {
  downloadDeatils: any = [];
  public pagination: any = {
    page: 1,
    fetchSize: '12',
    order: 'Time',
    dir: 'down'
  };
  totalCount: number;
  userDateFormat = 'dd/MM/yy';
  userTimeFormat = 'HH:mm';
  sortName;
  shortByValue;
  pageValue;
  fetchSize = this.constants.pageValue[0];
  constructor(inj: Injector, public assetTilesService: AssetTilesService) {
    super(inj);
  }

  ngOnInit() {
    this.shortByValue = this.constants.shortByValueAllDownload;
    this.sortName = this.constants.shortByValueAllDownload[0];
    this.pageValue = this.constants.pageValue;
    // this.listPage.dir = this.constants.shortByValueAssetsTiles[0].dir;
    // this.listPage.pageSize = this.constants.pageValue[0].size;
    this.getAllAssetsDownloads();
  }

  next() {
    this.pagination.page = this.pagination.page + 1
    this.getAllAssetsDownloads();
  }

  prev() {
    this.pagination.page = this.pagination.page - 1;
    this.getAllAssetsDownloads();
  }


  getAllAssetsDownloads() {
    let objData = {
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getAllAssetsDownloads(this.pagination,objData).subscribe((restResponse: any) => {
      console.log('restResponse', restResponse);
      this.downloadDeatils = restResponse.instance;
      restResponse.key = parseInt(restResponse.key);
      this.totalCount = Math.ceil(parseInt(restResponse.key) / this.pagination.fetchSize);
    });
  }

  sortBy(data, key) {
    console.log('data', data);
    if (key == 'sortby') {
      this.pagination.dir = data.dir;
      this.pagination.order = data.order;
    }
    if (key == 'show') {
      this.pagination.fetchSize = data.size;
    }
    setTimeout(() => {
        this.getAllAssetsDownloads();
    }, 300);

  }
}
