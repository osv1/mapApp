import {
    Component,
    OnInit,
    AfterViewInit,
    ChangeDetectorRef,
    Injector,
    ViewChild,
    ElementRef
} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {FileUploader} from 'ng2-file-upload';
import {AssetTilesService} from "../asset-tiles.service";
declare var $: any;
declare var moment: any;

@Component({
    selector: 'app-add-asset-modal',
    templateUrl: './download-asset-modal.component.html',
    styleUrls: ['./download-asset-modal.component.css'],
})
export class DownloadAssetModalComponent extends BaseComponent implements OnInit {
    currentProgress;
    constructor(inj: Injector,public changeDetector: ChangeDetectorRef,public assetTilesService:AssetTilesService) {
        super(inj);
    }
    ngOnInit() {
        this.assetTilesService.currentProgress.subscribe((success: any) => {
            this.setCurrentProgressValue(success);
        });
    }
    setCurrentProgressValue(data){
        this.currentProgress = data;
    }
}
