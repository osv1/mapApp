import {
  Component,
  OnInit,
  AfterViewInit,
  ChangeDetectorRef,
  Injector,
  ViewChild,
  ElementRef
} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {FileUploader} from 'ng2-file-upload';
import {AssetTilesService} from '../asset-tiles.service';
import {LoadingBarService} from '@ngx-loading-bar/core';
import {log} from "util";
import {forEach} from "@angular/router/src/utils/collection";

declare var $: any;
declare var moment: any;

@Component({
  selector: 'app-add-asset-modal',
  templateUrl: './add-asset-modal.component.html',
  styleUrls: ['./add-asset-modal.component.css'],
})
export class AddAssetModalComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild('fileInput') fileInput: ElementRef;
  public assetMetaData: any = [];
  assetLisItems = [];
  addAssetAjax = false;
  displayMessage;
  token: any;
  closeAssetUpload = false;
  listPage: any = {
    rows: [],
    page: 0,
    pageSize: 100,
    totalSize: 0,
    sort: 'AssetName',
    dir: 'up',
    search: '',
    catalogue: this.isCCEP(),
    categoryID: 0,
    findDuplicate: false,
    searchCurrent: false
  };
  errorMessage;
  successMessage;
  categoryAndAssetListPage: any = [];
  assetsId: any;
  assetMetaFields: any = []
  paramsCatalogue: any;
  categorySelected: any;
  public fileUploadBar: Boolean = false;
  updateObjData: any = {};


  constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService, private  loadingService: LoadingBarService) {
    super(inj);
  }

  ngOnInit() {

    this.fileUploaderService.ngOnInit();
    this.commonService.imageTypeFields = [''];
    this.getCategoryDetails();
    this.assetMetaData = [];
    let data = {
      catalogue: this.listPage.catalogue,
      token: this.getToken('accessToken')
    };
    this.assetTilesService.getAssetMetaDataListWithoutValue(data).subscribe((assetmetaData: any) => {
      this.fileUploadBar = true;
      this.assetMetaData = assetmetaData.instance;
      this.assetMetaData.forEach((obj, index) => {
        if (obj.fieldName === "F_AssetType") {
          if (obj.optionList) {
            obj.fieldValue = obj.optionList[0];
          }
        }
      })
      console.log('success', this.assetMetaData);
      this.setAssetMetaDataValue(this.assetMetaData);
    });
    this.assetTilesService.listPageItems.subscribe((success: any) => {
      this.setListPageDataValue(success);
    });
    this.assetTilesService.assetListItems.subscribe((success: any) => {
      this.setAssetLisItemsValue(success);
    });
    this.assetsId = this.activatedRoute.snapshot.params['id'];
    this.paramsCatalogue = this.activatedRoute.snapshot.params['catalogue'];
    if (this.assetsId) {
      this.getAssetsDetails(this.assetsId);
    }

  }


  getCategoryDetails() {
    let data = {
      page: this.listPage.page + 1,              // page number
      fetchSize: this.listPage.pageSize,    // page size
      order: this.listPage.sort,             // sort column name
      dir: this.listPage.dir,                // sort direction up/down
      filter: this.listPage.filter ? ('F_AssetType:' + this.listPage.filter) : '',
      search: this.listPage.search,
      catalogue: this.listPage.catalogue,
      fromDate: '',
      toDate: '',        // this.listPage.fromdate, this.listPage.todate,
      categoryID: parseInt(this.listPage.categoryID, 0),
      findDuplicate: this.listPage.findDuplicate,
      searchCurrent: this.listPage.searchCurrent,
      token: this.getToken('accessToken'),
      uid: 0
    };

    const categoriesParams = this.serialize(data)
    this.assetTilesService.getAssetsCategoriesInRange(categoriesParams).subscribe((categoryAndAssetListPage: any) => {
      this.categoryAndAssetListPage = categoryAndAssetListPage.instance.categories;
    })
  }

  setAssetMetaDataValue(data) {
    this.assetMetaData = data;
    this.assetMetaData.forEach((obj) => {
      if (obj.fieldDisplayType === 'date') {
        obj.fieldValue = '';
      }
    });
  }

  setListPageDataValue(data) {
    this.listPage = data;
  }

  setAssetLisItemsValue(data) {
    this.assetLisItems = data;
  }

  ngAfterViewInit() {

  }

  openFileUpload() {
    this.fileInput.nativeElement.click();
  }

  closeAddAssetPopUp() {
    this.assetMetaData = [];
  }

  getImageTypes(clientID?) {
    const clientid = clientID ? clientID : 0;
    this.commonService.callApi(this.setSecurePath() + '/element/getClientStyleFieldOptions' +
      '', this.attachToken({
      clientID: clientid,
      typeID: 2,
      uid: 0
    }), 'post').then((fieldOptions: any) => {
      this.commonService.imageTypeFields = fieldOptions;
      let match = this.commonService.imageTypeFields.find((type) => {
        return this.constants.STYLE_FIELD_TYPE_IMAGE == type.displayName.toLowerCase();
      });
      this.commonService.artworkFieldName = !!match ? match.key : ''; // set default value
    });
  }


  ///////////////////////////////////////////////////////////////////////////
  //                  Function to add  the assets                          //
  ///////////////////////////////////////////////////////////////////////////
  addAssetDetails(assetData) {
    if (this.assetsId) {
      let tempData = Object.assign([], assetData);
      this.updateAssetDetails(tempData);
    } else {
      // Call prepMetadataForSubmission function
      const returnAssetMetaDataList: any = this.prepMetadataForSubmission(assetData, undefined, undefined, true);
      // Puneet - matching the call

      if (returnAssetMetaDataList === null) {
        this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('MissingFields').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        return;
      }
      this.assetMetaData.forEach(key => {
        if (key.fieldDisplayType.toLowerCase() === 'date') {
          if (key.fieldValue) {
            key.fieldValue = new Date(key.fieldValue);
          }
        }
      });

      if (this.listPage.catalogue === '') {
        this.translate.get('PleaseSelectValidCatalogue').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('Catalogue').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        return;
      }
      if (this.fileUploaderService.fileMetaList.length === 0) {
        this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('FileUpload').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        return;
      }

      if (this.assetMetaData[1].categoryID === undefined || this.assetMetaData[1].categoryID.length === 0) {
        this.translate.get('PleaseSelectAtLeastOneCategory').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('Category').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        return;
      }


      // now allow multiple files
      /*if ( this.fileMetaList != null && this.fileMetaList.length > 1 ) {
          sharedService.displayToaster('error', [$translate('MultiFilesAreNOTSupported')], 5000, $translate('MultipleFiles'));
          return;
      }*/

      if (this.fileUploaderService.fileMetaList) {
        this.closeAssetUpload = true;
        // allowed to close the modal without confirmation

        // Service call to add the assets
        this.addAssetAjax = true;

        // pick up required details only and create a file list to submit
        var filesToAdd: any = [];
        for (let index = 0; index < this.fileUploaderService.fileMetaList.length; index++) {
          filesToAdd.push({
            fileName: this.fileUploaderService.fileMetaList[index].fileName,
            fileSize: '',
            fileType: this.fileUploaderService.fileMetaList[index].fileType,
            realFileName: this.fileUploaderService.fileMetaList[index].realFileName
          });
        }

        let data = {
          // HNK Records ===>>
          loginUserName: JSON.parse(this.getToken('userDetail')).userName,
          userClientID: JSON.parse(this.getToken('userDetail')).defaultClientID,
          uid: JSON.parse(this.getToken('userDetail')).userID,
          categoryIDs: ',' + this.assetMetaData[1].categoryID.toString() + ',',
          catalogue: this.isCCEP(),
          metadata: returnAssetMetaDataList,
          fileMeta: filesToAdd,
          categoryID: 0
        };

        let token = this.getToken('accessToken');

        this.assetTilesService.addFilestorAsset(data, token).subscribe((restResponse: any) => {
            if (restResponse.statusCode === this.constants.SUCCESS_CODE) {
              if (restResponse.instanceList && restResponse.instanceList instanceof Array) {
                this.translate.get('NewAssetHasBeenAddedSuccessfully').subscribe((res: string) => {
                  this.displayMessage = res;
                });
                this.translate.get('Success').subscribe((res: string) => {
                  this.successMessage = res;
                });
                this.commonService.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
                this.router.navigate(['assets-tiles']);
                for (let i = 0; i < restResponse.instance.length; i++) {
                  this.assetLisItems.push(restResponse.instance[i]);
                  // append asset list
                }

              } else {
                if (restResponse.instanceList) {
                  this.assetLisItems.push(restResponse.instanceList);
                }
                // append asset
              }
              this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
              this.closeModel();
              this.fileUploaderService.fileMetaList = [];   // remove files in asset module
            } else {
              this.translate.get('FailedToAddNewAsset').subscribe((res: string) => {
                this.displayMessage = res;
              });
              this.translate.get('Error').subscribe((res: string) => {
                this.errorMessage = res;
              });
              this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            }
            this.addAssetAjax = false;

          }
        );
      } else {
        this.translate.get('PleaseUploadFileAtleastToAddTheAsset').subscribe((res: string) => {
          this.displayMessage = res;
        });
        this.translate.get('MissingFileUpload').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
      }
    }
  }

  prepMetadataForSubmission(metaList, id, isPressJob, isAddAsset, isTaskCopy?, isProcurement?, addNooshProjectId?) {
    console.log("metaList===??", metaList);
    // isPressJob used to allow noneditable fields to get values
    // create a array of string 'fieldID|,|fieldValue' pairs  TODO may just pass changed values by keeping a copy of original

    const metaIdValuePairs = [];
    // angular.forEach(metaList, function (meta, index) {
    if (metaList !== null || metaList !== undefined) {
      for (let index = 0; index < metaList.length; index++) {     // use for loop to break out of looping
        const meta = metaList[index];
        // extra care for date and other spcial display types
        if (typeof meta.fieldDisplayType === 'string') {
          if (meta.fieldDisplayType.toLowerCase().indexOf('noneditable') === -1 || isPressJob || (addNooshProjectId
            && addNooshProjectId === true && meta.fieldName === 'NooshProjectID') || (meta.fieldName === 'Project_Name')) {
            // Press job needs to allow noneditable fields to be updated

            if (meta.fieldDisplayType === 'date') {

              // update date format to make the field eligible for database insert

              if (meta.fieldValue !== '') {
                if (this.assetsId) {

                  meta.fieldValue = this.localToUtcWithInputFormatUpdate(meta.fieldValue);

                } else {
                  meta.fieldValue = this.localToUtcWithInputFormat(meta.fieldValue);

                }
              }
              // jquery plugin version
              /*meta.fieldValue = $('#date-' + id + '-' + meta.fieldID).val();
               if ( meta.fieldValue == undefined ) {
               meta.fieldValue = '';
               }*/
            } else if (meta.fieldDisplayType === 'multipleselect') {
              if (isAddAsset) {
                if (meta.fieldValue) {
                  meta.fieldValue = meta.fieldValue.toString();
                }
              } else {
                let checked = '';
                meta.multiValues.forEach((selectOpt, metaIndex) => {
                  if (selectOpt.selected !== '') {
                    checked = checked + ',' + selectOpt.selected;
                  }
                });
                meta.fieldValue = checked.substring(1);
              }
            }

            // mandatory field checkup
            if (meta.mandatory && (meta.fieldValue === '' || meta.fieldValue == null ||
              (meta.fieldDisplayType === 'file' && meta.fieldValue === 0))) {
              // updated to use fieldName
              if (typeof meta.fieldName === 'string') {
                if (isProcurement && meta.fieldName.toLowerCase() === 'contact' /*meta.fieldID=='62'*/) {
                  // skip checking ergo contact ID if procurement channel is added after import
                } else {
                  return null;
                }
              } else {
                return null;
              }

            }

            // metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);

            if (isTaskCopy) {
              metaIdValuePairs.push(meta.fieldID + '_' + meta.jobMetaDataID /*taskCopyUD*/ + '|-|' + meta.fieldValue + '|,|');

            } else {

              if (meta.fieldID === undefined) {  // Filestor 3.7 metadata
                metaIdValuePairs.push(meta.fieldName + '|=|' + meta.fieldValue);
              } else {                            // JAS metadata
                if (meta.fieldValue.id === undefined) {
                  metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);
                } else {  // in case of id is used for value
                  metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue.id);
                }
              }
            }
          }
        } else {
          return null;
        }
      }
    }
    // });
    return metaIdValuePairs;
  }

  localToUtcWithInputFormat(strLocalDateTime, inputFormat?) {
    // when input format is not set use default
    if (!inputFormat) {
      inputFormat = this.defultInputFormat; // 'DD/MM/YYYY HH:mm';
    }

    // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
    const momentTime = moment(strLocalDateTime).subtract(moment(strLocalDateTime).utcOffset(), 'm');
    const formattedUtcDateTime = momentTime;
    return formattedUtcDateTime.format(this.defaultFormat);
  }

  localToUtcWithInputFormatUpdate(strLocalDateTime, inputFormat?) {
    // when input format is not set use default
    if (!inputFormat) {
      inputFormat = this.defultInputFormat; // 'DD/MM/YYYY HH:mm';
    }

    // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
    const momentTime = moment(strLocalDateTime).add(moment(strLocalDateTime).utcOffset(), 'm');
    const formattedUtcDateTime = momentTime;
    return formattedUtcDateTime.format(this.defaultFormat);
  }

  public loded: any;

  getAssetsDetails(assetId) {
    let data = {
      assetID: parseInt(assetId, 0),
      catalogue: this.paramsCatalogue,  // need to remove
      token: this.getToken('accessToken'),
      categoryID: 0,
      uid: JSON.parse(this.getToken('userDetail')).userID
    };
    this.assetTilesService.getSingleAsset(data).subscribe((assetDetails: any) => {
      console.log(assetDetails);
      let categoryIDs = [];
      this.categorySelected = assetDetails.instance.categories;
      this.assetMetaData.categoryID = [];
      this.categorySelected.forEach((obj, index) => {
        console.log("obj", obj);
        // this.assetMetaData.categoryID.push(obj.cid);

        categoryIDs.push(obj.cid.toString());
        // 33536

      })

      this.loded = categoryIDs;
      // this.assetMetaData.categoryID = this.loded;
      this.assetMetaFields = assetDetails.instance.metaList;
      this.assetMetaData = this.assetMetaFields.filter(data => (data.fieldName === 'F_RecordName' || data.fieldName === 'ExpiryDate' || data.fieldName === 'F_AssetType'));

      if (assetDetails) {
        this.assetMetaData.forEach((obj, index) => {
          if (obj.fieldName == 'ExpiryDate') {
            if (obj.fieldValue == 'Invalid date' || obj.fieldValue == '') {
              obj.fieldValue = '';
            }
            if (obj.fieldValue != '' && obj.fieldValue != 'Invalid date') {
              obj.fieldValue = new Date(obj.fieldValue.split(' ')[0]);
            }
          }
          if (index === 1) {
            obj.categoryID = this.loded;
          }
        });
      }
    })
  }

  updateAssetDetails(updatedAssetDetails) {
    console.log("updatedAssetDetails", updatedAssetDetails);
    // console.log(this.assetMetaData[1])
    // updatedAssetDetails = this.assetMetaData;
    if (this.assetMetaData[1].categoryID === undefined || this.assetMetaData[1].categoryID.length === 0) {
      this.translate.get('PleaseSelectAtLeastOneCategory').subscribe((res: string) => {
        this.displayMessage = res;
      });
      this.translate.get('Category').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
      return;
    }
    // Call prepMetadataForSubmission function
    const returnAssetMetaDataUpdateList = this.prepMetadataForSubmission(updatedAssetDetails, undefined, undefined, true);
    console.log(returnAssetMetaDataUpdateList);
    if (returnAssetMetaDataUpdateList == null) {
      let PleaseKeyInMandatoryField;
      this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
        PleaseKeyInMandatoryField = res;
      });
      let MissingFields;
      this.translate.get('MissingFields').subscribe((res: string) => {
        MissingFields = res;
      });
      this.commonService.displayToaster('error', [PleaseKeyInMandatoryField], 5000, MissingFields);
      return;
    }
    // updateObjData = {
    this.updateObjData.assetID = parseInt(this.assetsId, 0);
    this.updateObjData.catalogue = this.isCCEP();
    this.updateObjData.metadata = returnAssetMetaDataUpdateList;
    this.updateObjData.token = this.getToken('accessToken');
    this.updateObjData.categoryIDs = ',' + this.assetMetaData[1].categoryID.toString() + ','
    // }
// ========= file upload
    if (this.fileUploaderService.fileMetaList) {
      this.closeAssetUpload = true;
      // allowed to close the modal without confirmation

      // Service call to add the assets
      this.addAssetAjax = true;

      // pick up required details only and create a file list to submit
      var filesToAdd: any = [];
      for (let index = 0; index < this.fileUploaderService.fileMetaList.length; index++) {
        filesToAdd.push({
          fileName: this.fileUploaderService.fileMetaList[index].fileName,
          fileSize: '',
          fileType: this.fileUploaderService.fileMetaList[index].fileType,
          realFileName: this.fileUploaderService.fileMetaList[index].realFileName
        });
      }
      if (filesToAdd.length != 0) {
        this.updateObjData.fileMeta = filesToAdd;
      }
    }
    // =======
    // Service call to update the assets

    console.log(this.assetMetaData)
    this.assetMetaData.forEach(key => {
      if (key.fieldDisplayType.toLowerCase() === 'date') {
        if (key.fieldValue) {
          key.fieldValue = new Date(key.fieldValue);
        }
      }
    });
    console.log("this.updateObjData", this.updateObjData);
    this.assetTilesService.updateAssetValue(this.updateObjData).subscribe((restResponse: any) => {
        if (restResponse.statusCode === this.constants.SUCCESS_CODE) {
          this.router.navigate(['assets-tiles']);
          let NewAssetHasBeenUpdatedSuccessfully;
          this.translate.get('NewAssetHasBeenUpdatedSuccessfully').subscribe((res: string) => {
            NewAssetHasBeenUpdatedSuccessfully = res;
          });
          this.translate.get('Success').subscribe((res: string) => {
            this.successMessage = res;
          });
          this.commonService.displayToaster('success', [NewAssetHasBeenUpdatedSuccessfully], 5000, this.successMessage);
          this.broadcaster.broadcast('openCategory', {
            catalogue: this.listPage.catalogue,
            categoryID: this.listPage.categoryID
          });
        } else {
          let FailedToUpdateTheAsset;
          this.translate.get('FailedToUpdateTheAsset').subscribe((res: string) => {
            FailedToUpdateTheAsset = res;
          });
          this.translate.get('Error').subscribe((res: string) => {
            this.errorMessage = res;
          });
          this.commonService.displayToaster('error', [FailedToUpdateTheAsset], 5000, this.errorMessage);
        }

      }
    );
  }

  setAssetsType(event) {
    console.log(event.target.value);
  }

  deleteAssetsMeta() {
    let objData = {
      token: this.getToken('accessToken'),
      catalog: this.isCCEP(),
      assetsId: parseInt(this.assetsId, 0)
    }
    this.assetTilesService.deleteAssetsDetail(objData).subscribe((res: any) => {
      this.commonService.displayToaster(this.constants.TOAST_SUCCESS, res.message);
      if (res.statusCode === this.constants.SUCCESS_CODE) {
        this.router.navigate(['assets-tiles']);
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
      }
    })
  }


  openDeleteAssetsModal() {
    this.$('#deleteAssetsModal').modal('show');
  }

  hideDeleteAssetsModal() {
    this.$('#deleteAssetsModal').modal('hide');
  }

}

