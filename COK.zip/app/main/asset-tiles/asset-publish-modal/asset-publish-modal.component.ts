import {
  Component,
  OnInit,
  ChangeDetectorRef,
  Injector
} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {FileUploader} from 'ng2-file-upload';
import {AssetTilesService} from "../asset-tiles.service";

declare var $: any;
declare var moment: any;

@Component({
  selector: 'app-asset-publish-modal',
  templateUrl: './asset-publish-modal.component.html',
  styleUrls: ['./asset-publish-modal.component.css'],
})
export class AssetPublishModalComponent extends BaseComponent implements OnInit {
  publishAsset = null;
  assetLisItems = [];
  publishCategoryPointName = '';
  userClientID: any;
  successMessage: any;
  publishAssetIdx = -1;
  publishCategoryPoints;
  publishMessages = [];
  token: any;
  errorMessage;
  publishAjax = false;
  listPage: any = {
    rows: [],
    page: 0,
    pageSize: 100,
    totalSize: 0,
    sort: 'AssetName',
    dir: 'up',
    search: '',
    catalogue: 'Assets',
    categoryID: -1,
    findDuplicate: false,
    searchCurrent: false
  };

  constructor(inj: Injector, public changeDetector: ChangeDetectorRef, public assetTilesService: AssetTilesService) {
    super(inj);
  }

  ngOnInit() {
    this.assetTilesService.tokenItems.subscribe((success: any) => {
      this.setTokenValue(success);
    });
    this.assetTilesService.listPageItems.subscribe((success: any) => {
      this.setListPageDataValue(success);
    });
    this.assetTilesService.assetListItems.subscribe((success: any) => {
      this.setAssetLisItemsValue(success);
    });
    this.assetTilesService.publishCategoryPoints.subscribe((success: any) => {
      this.setpublishCategoryPoints(success);
    });
    this.assetTilesService.publishAsset.subscribe((success: any) => {
      this.setPublishAsset(success);
    });
    this.assetTilesService.publishAssetIdx.subscribe((success: any) => {
      this.setpublishAssetIdx(success);
    });
    this.assetTilesService.userClientIDItems.subscribe((success: any) => {
      this.setUserClientID(success);
    });
  }

  setUserClientID(data) {
    this.userClientID = data;
  }

  setPublishAsset(data) {
    this.publishAsset = data;
  }

  setpublishAssetIdx(data) {
    this.publishAssetIdx = data;
  }

  setListPageDataValue(data) {
    this.listPage = data;
  }

  setTokenValue(data) {
    this.token = data;
  }

  setAssetLisItemsValue(data) {
    this.assetLisItems = data;
  }

  setpublishCategoryPoints(data) {
    this.publishCategoryPoints = data;
  }

  publishFilestorAsset(publishAsset, categoryPoint) {
    this.publishMessages = [];
    this.publishAjax = true;
    const publishSelectedAssets = [];     // array of selected assets for publish - initially only SINGLE asset will be considered
    publishSelectedAssets.push(
      {
        assetID: publishAsset.assetID,
        catalogue: publishAsset.catalogue,
        categoryID: publishAsset.cid,
        type: publishAsset.assetType,
        assetName: publishAsset.assetName
      }
    );

    // Service call to publish the assets
    // var retAssetUpdate = assetService.publishFilestorAsset(publishAsset.assetID,
    // $scope.listPage.catalogue, categoryPoint, publishSelectedAssets);
    let objData = {
      assetID: publishAsset.assetID,
      catalogue: this.listPage.catalogue,
      categoryPointName: categoryPoint,
      userClientID: parseInt(this.userClientID, 0),
      selectedAssets: publishSelectedAssets,
      token: this.getToken('accessToken')
    }

    this.assetTilesService.publishAssets(objData).subscribe((restResponse: any) => {
        if (restResponse.statusCode === 200) {
          this.assetLisItems.splice(this.publishAssetIdx, 1);   // remove the asset from list
          // $('#assetPublish_modal').modal('hide');
          this.assetTilesService.setAssetLisItemsData(this.assetLisItems);
          this.closeModel();
          let AssetHasBeenPublishedSuccessfully;
          this.translate.get('AssetHasBeenPublishedSuccessfully').subscribe((res: string) => {
            AssetHasBeenPublishedSuccessfully = res;
          });
          this.translate.get('Success').subscribe((res: string) => {
            this.successMessage = res;
          });
          this.displayToaster('success', [AssetHasBeenPublishedSuccessfully], 5000, this.successMessage);
        } else {
          if (restResponse.instance != null) {
            this.publishMessages = restResponse.instance;
            let FailedToPublishTheAsset;
            this.translate.get('FailedToPublishTheAsset').subscribe((res: string) => {
              FailedToPublishTheAsset = res;
            });
            this.translate.get('Error').subscribe((res: string) => {
              this.errorMessage = res;
            });
            this.displayToaster('error', [FailedToPublishTheAsset], 5000, this.errorMessage);
          }
        }
        this.publishAjax = false;
      }
    );
  }

  // category point change needs to set messages clear
  clearPublishMessages() {
    this.publishMessages = [];
  }

  // validate to see if selected asset is eligible to be published to the selected category point without actual publish
  validateCategoryPoint(publishAsset, categoryPoint) {
    this.publishMessages = [];
    this.publishAjax = true;
    const publishSelectedAssets = [];     // array of selected assets for publish - initially only SINGLE asset will be considered
    publishSelectedAssets.push(
      {
        assetID: publishAsset.assetID,
        catalogue: publishAsset.catalogue,
        categoryID: parseInt(publishAsset.cid, 0),
        type: publishAsset.assetType,
        assetName: publishAsset.assetName
      }
    );

    // Service call to validate the assets
    // categoryPoint, publishSelectedAssets);
    let objData = {
      assetID: publishAsset.assetID,
      catalogue: this.listPage.catalogue,
      userClientID: parseInt(this.userClientID, 0),
      categoryPointName: categoryPoint,
      selectedAssets: publishSelectedAssets,
      token: this.getToken('accessToken')
    }
    this.assetTilesService.validateCategoryPoint(objData).subscribe((results: any) => {
        this.publishMessages = results;
        this.publishAjax = false;
      }
    );
  }
}
