import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmhHompageComponent } from './dmh-hompage.component';

describe('DmhHompageComponent', () => {
  let component: DmhHompageComponent;
  let fixture: ComponentFixture<DmhHompageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmhHompageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmhHompageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
