import {Component, OnInit, Injector} from '@angular/core';
import {BaseComponent} from "../../common/commonComponent";
import {LoginService} from '../../public/login/login.service';
import {environment} from "../../../environments/environment";
import {PublicationService} from "../publications/publication.service";
import {OnlineOrderingService} from "../online-ordering/online-ordering-select/online-ordering.service";


declare var $: any;

@Component({
  selector: 'app-dmh-hompage',
  templateUrl: './dmh-hompage.component.html',
  styleUrls: ['./dmh-hompage.component.css']
})
export class DmhHompageComponent extends BaseComponent implements OnInit {

  public userDetails: any = {};
  public timeout: any;
  hnkStaticValue: boolean;
  catalog: any;
  assetCategories: any = [];
  public isLoading;
  categoryIDs = ["0"];
  public config = (<any>environment);
  categoriesList: any = [];

  constructor(inj: Injector, private loginService: LoginService,private publicationService: PublicationService,public onlineOrderingService: OnlineOrderingService) {
    super(inj);
  }

  ngOnInit() {
    if (environment.envnName === this.constants.enviromentValues.heineken) {
      this.hnkStaticValue = true;

    }
    // if (environment.envnName === this.constants.enviromentValues.cokeMain) {
      this.getAllCategoriesForCoke();
    // }

    this.loginService.getUserName().subscribe(res => {
      this.userDetails = JSON.parse(this.getToken('userDetail'));
    })
    this.userDetails = JSON.parse(this.getToken('userDetail'))

    let catalogue = {
      id: 0,
      catalogue : this.constants.HK_CATALOUGE
    }
    this.selectedTreeMenuForAssets1(catalogue)

  }

  selectedTreeMenuForAssets1(catalogues) {
    let data = {
      catalogue: this.constants.HK_CATALOUGE,
      parentID: catalogues.id,
      token: this.getToken('accessToken'),
      // uid: JSON.parse(this.getToken('userDetail')).userID,
      uid:1,
      categoryID: 0
    }

    this.publicationService.getCategotyItems(data).subscribe((res: any) => {
      if (res.statusCode === 200) {
        res.instance.map(category => {
          if(category.id) {
            this.categoryIDs.push(category.id.toString())
          }
        })
        this.getAllLatestCatalouge();
      }
    })
  }

  getAllLatestCatalouge() {
    this.isLoading = true;
    this.catalog = {
      "catalogue": this.constants.HK_CATALOUGE,
      "categoryIDs": this.categoryIDs,
      "dir": "downk",
      "fetchSize": this.constants.LATEST_HK_CATALOUGE_PAGESIZE,
      "findDuplicate": false,
      // "uid": JSON.parse(this.getToken('userDetail')).userID,
      "uid":1,
      "order": this.constants.F_ASSETS_MODIFIED,
      "page": 1,
      "search": "",
      "searchCurrent":false,
      "token": this.getToken('accessToken')
    }
    let parmasData = this.serialize(this.catalog);
    this.publicationService.getAllLatestCatalouge(parmasData).subscribe((categoryAndAssetListPage: any) => {
      this.assetCategories = categoryAndAssetListPage.instance.rows;
      this.isLoading = false;
    })
  }

  learnMoreAutoScroll(id) {
    const hash = id;
    $('html, body').animate({
      scrollTop: $(hash).offset().top
    }, 1500, function () {
    });
  }
   viewArticle(assetThumbnailPath){

     let data = {
       assetID: assetThumbnailPath.assetID,
       catalogue: assetThumbnailPath.catalogue,
       token: this.getToken('accessToken'),
       fileName: assetThumbnailPath.recordName
     };

     let event = {
       event_id: this.constants.ASSET_LATEST_NEWS.event_id,
       event_desc: this.constants.ASSET_LATEST_NEWS.event_desc,
       attributes: assetThumbnailPath.assetID,
       categoryId : assetThumbnailPath.cid
     };
     this.logService.createLog(event);
     let downloadURL = this.config.apiUrl + 'AssetService/v1/asset/' + data.catalogue + '/' + data.assetID + '/download/' + '?token=' + data.token + '&fileName=' + data.fileName;
     window.open(downloadURL);
   }

   getAllCategoriesForCoke(){
     this.onlineOrderingService.getAllCategories().subscribe((categoryList: any) => {
       this.categoriesList = categoryList;
     })
   }
}
