import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-legal-policy',
  templateUrl: './legal-policy.component.html',
  styleUrls: ['./legal-policy.component.css']
})
export class LegalPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
