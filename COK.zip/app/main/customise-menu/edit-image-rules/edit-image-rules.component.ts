import {Component, Injector, OnInit} from '@angular/core';
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";
import {CustomiseMenuService} from "../customise-menu.service";
import {BaseComponent} from "../../../common/commonComponent";
import {EditRules} from '../../../common/models/EditRules';

@Component({
    selector: 'app-edit-image-rules',
    templateUrl: './edit-image-rules.component.html',
    styleUrls: ['./edit-image-rules.component.css']
})
export class EditImageRulesComponent extends BaseComponent implements OnInit {
    thumbnailURL: any;
    editRules: EditRules;
    editable: any;
    deletable: any;
    movable: any;
    resizable: any;

    constructor(public inj: Injector, public customiseMenuPropertyService: CustomiseMenuPropertyService, private customiseMenuService: CustomiseMenuService) {
        super(inj);
    }

    ngOnInit(): void {
        const editRules = this.customiseMenuPropertyService.editImageRules;
        this.thumbnailURL = editRules.originalURL;
        const updatedEditRules = editRules.ccImage && editRules.ccImage.editRules;

        this.editable = updatedEditRules && updatedEditRules.length && updatedEditRules[0].editable === '0' ? false : true;
        this.movable = updatedEditRules && updatedEditRules.length && updatedEditRules[0].movable === '0' ? false : true;
        this.deletable = updatedEditRules && updatedEditRules.length && updatedEditRules[0].deletable === '0' ? false : true;
        this.resizable = updatedEditRules && updatedEditRules.length && updatedEditRules[0].resizable === '0' ? false : true;
    }

    ngAfterViewInit() {
    }

    /** Save image rules handler */
    saveImageRules(): void {
        let _this = this,
            rules = new EditRules();

        rules.editable = _this.editable ? '1' : '0';
        rules.deletable =  _this.deletable ? '1' : '0';
        rules.movable = _this.movable ? '1' : '0';
        rules.resizable = _this.resizable ? '1' : '0';
        this.broadcaster.broadcast('imageEditRules', rules);
        this.closeModel();
    }
}
