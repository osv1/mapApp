import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditDesignsRuleComponent } from './edit-designs-rule.component';

describe('EditDesignsRuleComponent', () => {
  let component: EditDesignsRuleComponent;
  let fixture: ComponentFixture<EditDesignsRuleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditDesignsRuleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDesignsRuleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
