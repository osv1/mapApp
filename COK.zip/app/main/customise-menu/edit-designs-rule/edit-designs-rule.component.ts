import {Component, Injector, OnInit} from '@angular/core';
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";
import {BaseComponent} from "../../../common/commonComponent";
import {CustomiseMenuService} from "../customise-menu.service";
import {RestResponse} from "../../../common/models/RestResponse";
import {TemplateStyleRule} from "../../../common/models/TemplateStyleRule";

/** admin mode only, when pencil is clicked from an thumbnail item under Designs tab */
@Component({
    selector: 'app-edit-designs-rule',
    templateUrl: './edit-designs-rule.component.html',
    styleUrls: ['./edit-designs-rule.component.css']
})
export class EditDesignsRuleComponent extends BaseComponent implements OnInit {
    uploadAllowed: boolean;
    imageRegionsOnly: boolean;
    thumbnailURL: any;
    templateRule: TemplateStyleRule;

    constructor(public inj: Injector, private customiseMenuPropertyService: CustomiseMenuPropertyService, private customiseMenuService: CustomiseMenuService) {
        super(inj);
    }

    ngOnInit() {
        this.thumbnailURL = this.customiseMenuPropertyService.editDesign.value;
        // load selected template's style rules for editing
        this.customiseMenuService.getTemplateStyleRuleByTemplateId( +this.customiseMenuPropertyService.editDesign.name, 1, this.customiseMenuPropertyService.apiToken)
            .subscribe((res: RestResponse) => {
                if (res.statusCode === 200) {
                    // when there is no existing template rule, returned TemplateStyleRule will have 0 on TemplateStyleRuleID
                    this.templateRule = res.instance as TemplateStyleRule;
                    this.templateRule.templateID = +this.customiseMenuPropertyService.editDesign.name;  // ensure templateID is set
                    this.uploadAllowed = this.templateRule.templateEditRule.uploadAllowed === '1' ? true : false;
                    this.imageRegionsOnly = this.templateRule.templateEditRule.imageRegionsOnly === '1' ? true : false;
                } else {
                    console.error('Failed to get TemplateRule!')
                }
            });
    }

    /** Save Design Rules to backend */
    saveDesignRules(): void {
        this.templateRule.templateEditRule.imageRegionsOnly = this.imageRegionsOnly ? '1' : '0';
        this.templateRule.templateEditRule.uploadAllowed = this.uploadAllowed ? '1' : '0';
        // inset or update new TemplateStyleRule
        if ( this.templateRule.templateStyleRuleID > 0 ) {  //update
            this.customiseMenuService.updateTemplateStyleRule(this.templateRule.templateID, this.templateRule, this.customiseMenuPropertyService.apiToken)
                .subscribe((res: RestResponse) => {
                    if (res.statusCode !== 200) {
                        console.error('Failed to update templateRule!')
                    }
                });
        } else {    // insert
            this.customiseMenuService.insetTemplateStyleRule(this.templateRule.templateID, this.templateRule, this.customiseMenuPropertyService.apiToken)
                .subscribe((res: RestResponse) => {
                    if (res.statusCode !== 200) {
                        console.error('Failed to insert templateRule!')
                    }
                });
        }
        this.closeModel();
    }

}
