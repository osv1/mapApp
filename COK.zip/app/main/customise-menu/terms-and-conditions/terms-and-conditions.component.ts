import {Component, OnInit, Injector} from '@angular/core';
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";
import {BaseComponent} from '../../../common/commonComponent';

@Component({
  selector: 'app-terms-and-conditions',
  templateUrl: './terms-and-conditions.component.html',
  styleUrls: ['./terms-and-conditions.component.css']
})
export class TermsAndConditionsComponent extends BaseComponent implements OnInit {
  submitted = false;

  constructor(inj: Injector, public customiseMenuPropertyService: CustomiseMenuPropertyService) {
    super(inj)
  }

  ngOnInit() {

  }

  updateField(form) {
    this.submitted = true;
    if (form.valid) {
      this.broadcaster.broadcast('updateTermsandCondition');
      this.closeModel();
    }
  }
}
