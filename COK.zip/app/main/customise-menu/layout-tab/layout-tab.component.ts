import {Component, OnInit, Input, Output, EventEmitter, OnChanges} from '@angular/core';
import {CustomiseMenuService} from "../customise-menu.service";
import {RestResponse} from "../../../common/models/RestResponse";

@Component({
  selector: 'app-layout-tab',
  templateUrl: './layout-tab.component.html',
  styleUrls: ['./layout-tab.component.css']
})
// selection from here will change a single grid/page in most cases
export class LayoutTabComponent implements OnInit, OnChanges {
  @Input() baseTemplateId: number;
  @Input() token: string;
  @Output() passSelected = new EventEmitter();

  baseThumbnailUrls = [];   // will hold pageNo & s3Path pairs

  constructor(private customiseMenuService: CustomiseMenuService) { }

  // respond data-bound input properties (re)sets - baseTemplateId, token
  ngOnChanges() {
      // let's get fresh thumbnail images for base template - pass 0 to regenerate when images are not there yet
      this.customiseMenuService.getTemplateThumbnailUrls(this.baseTemplateId, 0, this.token)
          .subscribe((res: RestResponse) => {
              if (res.statusCode === 200) {
                  this.baseThumbnailUrls = res.instance;
              } else {
                  console.error('Failed to retrieve template thumbnail urls!')
              }
          })
  }

  // called every time this tab displays
  ngOnInit() {

  }
}
