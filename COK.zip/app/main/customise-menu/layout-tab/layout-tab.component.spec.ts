import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutTabComponent } from './layout-tab.component';
import {Test} from "tslint";
import {HttpClientTestingModule, HttpTestingController} from "@angular/common/http/testing";
import {CustomiseMenuService} from "../customise-menu.service";
import {RestResponse} from "../../../common/models/RestResponse";
import {RouterModule, Routes} from "@angular/router";
import {CustomiseMenuComponent} from "../customise-menu.component";
import {DesignsTabComponent} from "../designs-tab/designs-tab.component";
import {BackgroundTabComponent} from "../background-tab/background-tab.component";
import {ImagesTabComponent} from "../images-tab/images-tab.component";
import {ApprovalsTabComponent} from "../approvals-tab/approvals-tab.component";
import {ConfigEditorComponent} from "../config-editor/config-editor.component";
import {NO_ERRORS_SCHEMA} from "@angular/core";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {BrowserModule} from "@angular/platform-browser";
import {
  MatAutocompleteModule,
  MatButtonToggleModule,
  MatFormFieldModule,
  MatInputModule,
  MatSelectModule
} from "@angular/material";
import {Broadcaster} from "../../../common/BroadCaster";
import {CommonService} from "../../../common/common.service";
import {config} from '../../../../assets/config/configs';

describe('LayoutTabComponent', () => {
  let component: LayoutTabComponent;
  let fixture: ComponentFixture<LayoutTabComponent>;
  let commonService: CommonService;
  let customiseMenuService: CustomiseMenuService;
  let httpTestingController:  HttpTestingController;

  const appRoutes: Routes = [
    {path: 'customiseMenu', component: CustomiseMenuComponent}
  ];

  /*beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LayoutTabComponent ]
    })
    .compileComponents();
  }));*/

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        CustomiseMenuComponent,
        DesignsTabComponent,
        LayoutTabComponent,
        BackgroundTabComponent,
        ImagesTabComponent,
        ApprovalsTabComponent,
        ConfigEditorComponent
      ],
      schemas: [NO_ERRORS_SCHEMA ],
      imports: [  HttpClientTestingModule,
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        MatAutocompleteModule,
        MatButtonToggleModule,
        MatInputModule,
        MatFormFieldModule,
        MatSelectModule,
        RouterModule.forRoot(appRoutes)
      ],
      providers: [ Broadcaster, CommonService, CustomiseMenuService ]
    });
    customiseMenuService = TestBed.get(CustomiseMenuService);
    httpTestingController = TestBed.get(HttpTestingController);

    fixture = TestBed.createComponent(LayoutTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('http - should have 1 item', () => {
    customiseMenuService.getTemplateThumbnailUrls(1331, 0, 'test')
        .subscribe( (res: RestResponse) => {
          // get 1 mock up object
          expect(res.instance.length).toBe(1);
        })

    // single request expected
    let req = httpTestingController.expectOne(config.restv2api +'TemplateService/v1/template/1331/thumbnails?refresh=0&token=test');
    // return mock up to above sbscribe return value
    req.flush(<RestResponse>{
      statusCode: 200,
      statusText: 'OK',
      message: 'Successful operation!',
      key: '',
      instance: [
        {
          "pageNo": "1",
          "s3Path": "https://s3-ap-southeast-2.amazonaws.com/dev-adworks-storage/Templates/1331/thumbnails/thumbnail_20343.png"
        }
      ]
    });

    httpTestingController.verify();

    //const fixture = TestBed.createComponent(LayoutTabComponent);
    //fixture.detectChanges();
    //const compiled = fixture.debugElement.nativeElement;
    //expect(compiled.querySelector('span .item-name').textContent).toContain('3');
  })
});
