import {Injectable} from '@angular/core';
import {TemplateTextStyleSvg} from "../../common/models/TemplateTextStyleSvg";
import {TemplateStyleRule} from "../../common/models/TemplateStyleRule";

/** service to share common property across related customise menu components */
@Injectable({
  providedIn: 'root'
})
export class CustomiseMenuPropertyService {
  baseTemplateId: number;
  jTemplateId: number;
  apiToken: string;
  isAdmin = false;
  editTextArea: any = {};
  editImageRules: any;
  selectedImage: any = {};
  activeIndex: number;
  templateTextStyleSvg: TemplateTextStyleSvg | null;
  templateStyleRule: TemplateStyleRule | null;    // current working job template's base template style rule (different from text/image editRules)
  editDesign: any = {};                           // selected design for rule editing from Designs tab
  locked: any = null;
  dynamicTextTitle: string;
  dynamicTextFields: any;

  constructor() {
  }
}
