import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ImagesOverlayComponent} from './images-overlay.component';

describe('ImagesOverlayComponent', () => {
    let component: ImagesOverlayComponent;
    let fixture: ComponentFixture<ImagesOverlayComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [ImagesOverlayComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ImagesOverlayComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });
});
