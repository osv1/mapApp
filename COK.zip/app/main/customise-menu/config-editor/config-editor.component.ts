import {Component, Injector, EventEmitter, OnInit, Output, Input, SimpleChanges, ViewChild} from '@angular/core';
import {Observable, Subject, merge} from 'rxjs';
import {map, debounceTime, distinctUntilChanged, filter} from 'rxjs/operators';
import {fontStyle, fontSizes} from './fonts';
import {NgbTypeahead} from '@ng-bootstrap/ng-bootstrap';

declare const $: any;
import {CustomiseMenuService} from '../customise-menu.service';
import {BaseComponent} from "../../../common/commonComponent";
import {EditTextRulesComponent} from "../edit-text-rules/edit-text-rules.component";
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";

@Component({
    selector: 'app-config-editor',
    templateUrl: './config-editor.component.html',
    styleUrls: ['./config-editor.component.css']
})
export class ConfigEditorComponent extends BaseComponent implements OnInit {
    @Output() fontChanges = new EventEmitter<Object>();
    @Output() removeObject = new EventEmitter();
    @Input() fontStyles: Array<fontStyle>;
    @Input() selectedObjFontsStyles: object;
    @Input() showDelete: any;
    @Output() rotate = new EventEmitter();    // done or cancel
    color: string;
    fontSizes: Array<number> = fontSizes;
    fontSizesOriginal: Array<number> = fontSizes;
    fontSize: any = 10;
    fontStyleName = 'ARIALUNI.TTF';
    fontWeightVal: string = '';
    fontStyleVal: string = '';
    fontUnderlineVal: boolean = false;
    fontCapsVal: boolean = false;
    textAlign: string = '';
    fontTitleVal = false;
    isTextNonEditable = false;
    isTextNonDeletable = false;
    // @ViewChild('instance') instance: NgbTypeahead;
    @ViewChild('fontsinstance') fontsinstance: NgbTypeahead;
    focus$ = new Subject<string>();
    click$ = new Subject<string>();
    currentFontType: string;
    fontfocus$ = new Subject<number>();
    fontclick$ = new Subject<number>();
    // isDesignLocked: boolean = null;
    // search = (text$: Observable<string>) => {
    //     const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    //     const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
    //     const inputFocus$ = this.focus$;
    //
    //     return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
    //         map(term => (term === '' ? this.fontSizesOriginal
    //             : this.fontStyles.filter((v: any) => v.name.toLowerCase().indexOf(term.toLowerCase()) > -1)))
    //     );
    // };
    // this.fontStyles.push({
    //                          name: "ARIALUNI.ttf",
    //                          type: "",
    //                          value: "https://s3-ap-southeast-2.amazonaws.com/dev-adworks-storage/Fonts/png/ArialMT_ttf.png"
    //                      });
    formatter = (x: { name: string }) => x.name;

    fontsearch = (text$: Observable<number>) => {
        const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
        const clicksWithClosedPopup$ = this.fontclick$.pipe(filter(() => !this.fontsinstance.isPopupOpen()));
        const inputFocus$ = this.fontfocus$;
        return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
            map(term1 => this.fontSizes));
    };

    constructor(inj: Injector, public customiseMenuService: CustomiseMenuService, public customiseMenuPropertyService: CustomiseMenuPropertyService) {
        super(inj);
    }

    ngOnInit(): void {

        // this.myControl.setValue(this.fontStyle.name);
        // this.filteredFontSyles = this.myControl.valueChanges
        // 	.pipe(
        // 		startWith(''),
        // 		map(value => value && value.length >= 1 ? this._filter(value) : [])
        // 	);

    }

    ngOnChanges(selectedObjFontsStyles: SimpleChanges) {
        for (let propName in selectedObjFontsStyles) {
            if (propName === 'selectedObjFontsStyles') {
                let change = selectedObjFontsStyles[propName];
                for (let val in change.currentValue) {
                    if (val === 'fontFamily') {
                        this.fontStyleName = change.currentValue[val];
                    } else if (val === 'fontWeight') {
                        this.fontWeightVal = change.currentValue[val];
                    } else if (val === 'fontStyle') {
                        this.fontStyleVal = change.currentValue[val];
                    } else if (val === 'underline') {
                        this.fontUnderlineVal = change.currentValue[val];
                    } else if (val === 'fontAlign') {
                        this.textAlign = change.currentValue[val];
                    } else if (val === 'fontSize') {
                        this.fontSize = parseFloat(change.currentValue[val]);
                    } else if (val === 'caps') {
                        this.fontCapsVal = change.currentValue[val];
                        if (this.fontCapsVal) {
                            this.currentFontType = 'C';
                        }
                    } else if (val === 'Title') {
                        this.fontTitleVal = change.currentValue[val];
                        if (this.fontTitleVal) {
                            this.currentFontType = 'T';
                        }
                    } else {
                        this[val] = change.currentValue[val];
                    }
                }
                if (change.currentValue && !change.currentValue.caps && !change.currentValue.Title) {
                    this.fontCapsVal = false;
                    this.fontTitleVal = false;
                    this.currentFontType = 'N';
                }
            }
        }
        if (this.customiseMenuPropertyService.editTextArea
            && this.customiseMenuPropertyService.editTextArea.editRules
            && this.customiseMenuPropertyService.editTextArea.editRules.length) {
            if ( this.customiseMenuPropertyService.editTextArea.editRules[0].editable === '0' ) {
                this.isTextNonEditable = true;
            } else {
                this.isTextNonEditable = false;
            }

            if ( this.customiseMenuPropertyService.editTextArea.editRules[0].deletable === '0' ) {
                this.isTextNonDeletable = true;
            } else {
                this.isTextNonDeletable = false;
            }
        }
        this.fontSizesOriginal = Object.assign([], this.fontStyles);
        /* Display name of font */
        this.fontSizesOriginal.forEach((data: any) => {
            data.displayName = data.name.split('.')[0];
        });

        // if(this.customiseMenuPropertyService.locked) {
        //   this.isDesignLocked = true;
        // } else {
        //   this.isDesignLocked = null;
        // }
    }

    /** Set font styles*/
    setFontStyle(fontStyleVal: any): void {
        if (fontStyleVal) {
            fontStyleVal = fontStyleVal.split('.')[0];
            this.fontStyleName = fontStyleVal;
            this.fontChanges.emit({
                fontStyle: fontStyleVal
            });
        }
    }

    enterFontSize(el: any) {
        let fontSize = el.target.value;
        // if (fontSize <= 0) fontSize = 1;
        if (fontSize > 300) fontSize = 300;
        this.fontSize = !!el.target.value ? parseFloat(fontSize) : '';
    }

    /** Set font size*/
    setFontSize(fontSize: any): void {
        if (fontSize > 300) fontSize = 300;
        this.fontSize = parseFloat(fontSize);
        this.fontChanges.emit({
            fontSize: fontSize
        });
    }

    /** Set font color*/
    changeTextsColor(color: string): void {
        this.fontChanges.emit({
            fontColor: color
        });
    }

    /** set font weight, style, decoration*/
    fontWeightChange(fontWeight: string): void {
        switch (fontWeight) {
            case 'bold':
                if (this.fontWeightVal === fontWeight) {
                    fontWeight = 'non-' + fontWeight;
                }

                this.fontWeightVal = fontWeight;
                break;
            case 'italic':
                if (this.fontStyleVal === fontWeight) {
                    fontWeight = 'non-' + fontWeight;
                }

                this.fontStyleVal = fontWeight;
                break;
            case 'underline':
                if (this.fontUnderlineVal) {
                    fontWeight = 'non-' + fontWeight;
                }

                this.fontUnderlineVal = fontWeight === 'underline' ? true : false;
                break;
            case 'Caps':
                this.fontCapsVal = fontWeight === 'Caps' ? true : false;
                this.fontTitleVal = false;
                this.currentFontType = 'C';
                break;
            case 'Title':
                this.fontTitleVal = fontWeight === 'Title' ? true : false;
                this.fontCapsVal = false;
                this.currentFontType = 'T';
                break;
            case 'Normal':
                this.fontTitleVal = false;
                this.fontCapsVal = false;
                this.currentFontType = 'N';
                break;
        }
        this.fontChanges.emit({
            fontWeight: fontWeight
        });
    }

    /** set font position */
    fontAlignChange(align: string): void {
        this.textAlign = align;
        this.fontChanges.emit({
            fontAlign: align
        });
    }

    /** Handler while opening popup of font size list*/
    openPopup(): void {
        // this.fontclick$.next(event.target.value);
        setTimeout(() => {
            const counts = this.fontSizes;
            const goal = this.fontSize;
            const output = counts.reduce((prev, curr) => Math.abs(curr - goal) < Math.abs(prev - goal) ? curr : prev);
            const fSize = this.fontSize > 72 ? 72 : output;
            if (this.fontsinstance.isPopupOpen() && $("#font-" + Math.floor(fSize)).position().top !== 0) {
                $('.dropdown-menu.show').scrollTop($("#font-" + Math.floor(fSize)).position().top);
            }
        }, 300);

    }

    /** Remove selected object*/
    removeTexts() {
        this.removeObject.emit();
    }

    openEditRules() {
        this.convertComponentToDom(EditTextRulesComponent);
    }
}
