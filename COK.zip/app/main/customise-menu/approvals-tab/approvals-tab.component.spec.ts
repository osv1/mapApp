import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalsTabComponent } from './approvals-tab.component';

describe('ApprovalsTabComponent', () => {
  let component: ApprovalsTabComponent;
  let fixture: ComponentFixture<ApprovalsTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApprovalsTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovalsTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
