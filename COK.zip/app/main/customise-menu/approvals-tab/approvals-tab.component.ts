import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-approvals-tab',
  templateUrl: './approvals-tab.component.html',
  styleUrls: ['./approvals-tab.component.css']
})
export class ApprovalsTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
