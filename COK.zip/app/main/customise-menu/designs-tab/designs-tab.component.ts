import {Component, EventEmitter, Injector, Input, OnInit, Output} from '@angular/core';
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";
import {EditDesignsRuleComponent} from "../edit-designs-rule/edit-designs-rule.component";
import {BaseComponent} from "../../../common/commonComponent";

@Component({
    selector: 'app-designs-tab',
    templateUrl: './designs-tab.component.html',
    styleUrls: ['./designs-tab.component.css']
})
// selection from here will change the whole template where a user is working on
export class DesignsTabComponent extends BaseComponent implements OnInit {
    @Input() categoryId: number;    // parent category id where base templates exist
    @Input() token: string;
    @Input() designLoading: boolean;
    @Input() baseTemplateId: string;
    @Output() selectDesign = new EventEmitter();

    @Input() designThumbnailUrls = [];   // will hold pageNo & s3Path pairs

    constructor(inj: Injector, public customiseMenuPropertyService: CustomiseMenuPropertyService) {
        super(inj);
    }

    // respond data-bound input properties (re)sets - categoryId, token
    ngOnChanges(changes) {
        // let's get fresh thumbnail images for base templates under a category
        if (changes.designThumbnailUrls) {

        }
    }

    // called every time this tab displays
    ngOnInit() {

    }

    /** Select design template from list */
    onSelectDesign(thumb: any, event: any): void {
        if(event.target.classList.contains('fa-pencil-alt')) {
            return;
        }
        this.selectDesign.emit(thumb);
    }

    /** Open edit rules overlay */
    openEditRules(thumb: any): void {
        this.customiseMenuPropertyService.editDesign = thumb;
        this.convertComponentToDom(EditDesignsRuleComponent);
    }
}
