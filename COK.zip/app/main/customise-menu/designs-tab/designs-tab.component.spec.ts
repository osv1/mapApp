import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DesignsTabComponent } from './designs-tab.component';

describe('DesignsTabComponent', () => {
  let component: DesignsTabComponent;
  let fixture: ComponentFixture<DesignsTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DesignsTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DesignsTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
