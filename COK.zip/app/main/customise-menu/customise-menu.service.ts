import {Injectable, Input} from '@angular/core';
import {from, Observable, of} from 'rxjs';
import {catchError, map} from 'rxjs/operators';
import {CommonService} from '../../common/common.service';
import {RestLoginFields} from '../../common/models/RestLoginFields';
import {config} from '../../../assets/config/configs';
import {RenderText} from '../../common/models/RenderText';
import {GridField} from '../../common/models/GridField';
import {HttpClient} from '@angular/common/http';
import {TextRegion} from '../../common/models/TextRegion';
import {XmlImage} from '../../common/models/XmlImage';
import {JobTemplateSaveRequest} from '../../common/models/JobTemplateSaveRequest';
import {TemplateTextStyleSvg} from "../../common/models/TemplateTextStyleSvg";
import {TemplateStyleRule} from "../../common/models/TemplateStyleRule";
import {CreateBaseTemplateRequest} from "../../common/models/CreateBaseTemplateRequest";
import {TemplateColourPalette} from '../../common/models/TemplateColourPalette';
import 'rxjs/add/operator/retryWhen';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/take';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

export interface CacheEntry {
    url: string;
    response: any;
    entryTime: number;
}

declare const $: any;

export const MAX_CACHE_AGE = 86400000; // in milliseconds - 1440min = 24hours

@Injectable({
    providedIn: 'root'
})
export class CustomiseMenuService {
    template_svc: string = 'TemplateService/v1/';    //TODO may move to constant list
    asset_svc: string = 'AssetService/v1/';    //TODO may move to constant list
    private cacheMap = new Map<string, CacheEntry>();
    public editorFocus = false;
    imageEditorConfigs: any = {};
    security_token: any;    //TODO use customiseMenuPropertyService.apiToken instead
    cropSpinner = false;
    // isAdmin = false;
    // editTextArea: any = {};
    // editImageRules: any;

    constructor(private commonService: CommonService, private _http: HttpClient) {
    }

    // TODO get a list of backgrounds

    // TODO Kush - please create 2 more calls to reflect API calls below:
    // /TemplateService/v1/jobTemplate/{jTemplateID}/grid/{jTemplateGridID}/textRegions
    // /TemplateService/v1/jobTemplate/{jTemplateID}/grid/{jTemplateGridID}/images

    /** register user and create one if the username does not eixist */ //TODO this might needs to be moved to common service
    registerRestV2(loginFields: RestLoginFields): Observable<any> {
        const userFields = [];    // pass name & value pasirs as array
        for (const prop in loginFields) {
            if (loginFields.hasOwnProperty(prop)) {
                userFields.push({name: '' + prop, value: loginFields[prop]});
            }
        }

        const observable = from(this.commonService.callApiRestV2('RegisterService/register_create', {
            username: 'adilkhan',
            // fields: userFields,
            // clientID: config.CLIENT_ID,
            // groupID: config.GROUP_ID,
            // moduleID: config.MODULE_ID,
            // portalUserID: config.PORTAL_USER_ID,
        }, 'post'));
        return observable;
    }

    /******************************************************************************/
    /**                         Job Template API Calls                            */

    /******************************************************************************/
    /** get Job template details */
    getJobTemplate(jTemplateId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}?token=${token}`, {}, 'get');
        return observable;
    }

    /** get Job template grid details */
    getJobTemplateGrid(jTemplateId, gridName, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridName}?token=${token}`, {}, 'get');
        return observable;
    }

    /** get Job Template Text Region details */
    getJobTextRegions(jTemplateId, gridId, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegions?token=${token}`, {}, 'get');
        return observable;
    }

    /** Delete Job Template Text Region details */
    deleteJobTextRegion(jTemplateId: number, gridId: number, textRegionId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegion/${textRegionId}?token=${token}`, {}, 'delete');
        return observable;
    }

    /** Add Job Template Text Region details */
    insertTextRegionInJob(jTemplateId: number, gridId: number, data: TextRegion, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegion/new?token=${token}`, data, 'post');
        return observable;
    }

    /** Update Job Template Text Region details */
    updateTextRegionInJob(jTemplateId: number, gridId: number, data: TextRegion, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegion?token=${token}`, data, 'put');
        return observable;
    }

    /** Delete Job Template Text Region details in bulk */
    deleteBulkJobTextRegion(jTemplateId: number, gridId: number, textRegionId: number[], token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegion/bulk?token=${token}&textRegionIDs=${textRegionId}`, {}, 'delete');
        return observable;
    }

    /** Add Job Template Text Region details in bulk */
    insertBulkTextRegionInJob(jTemplateId: number, gridId: number, data: TextRegion[], token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegion/newbulk?token=${token}`, data, 'post');
        return observable;
    }

    /** Update Job Template Text Region details in bulk */
    updateBulkTextRegionInJob(jTemplateId: number, gridId: number, data: TextRegion[], token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/textRegion/bulk?token=${token}`, data, 'put');

        return observable;
    }

    /** get Job Template Image details */
    getJobImages(jTemplateId, gridId, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/images?token=${token}`, {}, 'get');
        return observable;
    }

    /** get JOB template grid field details - GridFieldTDO reflected in GridField */
    getJobTemplateGridFields(jobTemplateId: number, jobTemplateGridId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jobTemplateId}/grid/${jobTemplateGridId}/fields?token=${token}`, {}, 'get');
        return observable;
    }

    createNewJTemplate(templateId: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate?token=${token}`, {templateID: parseInt(templateId)}, 'post');
        return observable;
    }

    /** get job template image attribute details */
    getTemplateImageAttributes(jobTemplateId: number, gridField: GridField, token: string): Observable<any> {

        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jobTemplateId}/grid/${gridField.gridID}/field/${gridField.fieldName}/imageAttr?elementIndex=${gridField.elementIndex}&token=${token}`, {}, 'get');
        return observable;
    }

    /** generate background image for template grid based on base template grid id or simple rgb colour - jTemplateGridID added to allow job grid specific background */
    getJobTemplateGridBackground(templateId: number, baseTemplateGridID: string, jTemplateGridID: string, token: string): Observable<any> {
        let apiCount = 1;
        return this._http.get(
            `${this.commonService._restv2api}${this.template_svc}template/${templateId}/grid/${baseTemplateGridID}/background/id?jTemplateGridID=${jTemplateGridID}&token=${token}`,
            {responseType: 'text'}
        ).pipe(map((res: any) => res),
            catchError((e: any) => {
                //do your processing here
                if (e.status !== 400) {
                    this.commonService.showServerError(e)
                }
                if (apiCount === 3) {
                    this.commonService.showServerError(e)
                }
                return Observable.throw(e);
            })
        ).retryWhen((errors) => {
            return errors
                .mergeMap((error) => {
                    apiCount++;
                    if (error && error.status === 400) {
                        return Observable.of(error)
                    } else {
                        return Observable.throw(error)
                    }
                })
                .delay(1000)
                .take(3);
        });
    }

    /** Save Job Template Service */
    saveJobTemplate(jobTemplateId: number, data: JobTemplateSaveRequest, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jobTemplateId}/save?token=${token}`, data, 'post');
        return observable;
    }

    /******************************************************************************/
    /**                         Base Template API Calls                           */

    /******************************************************************************/
    /** get base template details */
    getTemplate(templateId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${templateId}?token=${token}`, {}, 'get');
        return observable;
    }

    /** get template grid details */
    getTemplateGrid(templateId: number, gridName: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${templateId}/grid/${gridName}?token=${token}`, {}, 'get');
        return observable;
    }

    /** generate background image for template grid */
    getTemplateGridBackground(templateId: number, gridName: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${templateId}/grid/${gridName}/background?token=${token}`, {}, 'get');
        return observable;
    }

    /** render text as png image and return url */
    renderText(text: RenderText, token: string): Observable<any> {
        return this._http.get(
            `${this.commonService._restv2api}${this.template_svc}template/${text.templateId}/grid/${text.gridName}/text?text=${encodeURIComponent(text.text)}&font=${text.font}&fontSize=${text.fontSize}&fontColour=${text.fontColour}&width=${text.width}&height=${text.height}&token=${token}`,
            {responseType: 'blob'}
        )
            .pipe(map((res: any) => URL.createObjectURL(res)));
    }

    /** get S3 thumbnail urls for base template - use refresh flag 1 to regenerate */
    getTemplateThumbnailUrls(templateId: number, refreshFlag: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${templateId}/thumbnails?refresh=${refreshFlag}&token=${token}`, {}, 'get');
        return observable;
    }

    /** get S3 thumbnail urls for 1st pages of base templates under category - will populated design tab images */
    getDesignTemplateThumbnailUrls(categoryId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}category/${categoryId}/thumbnails?token=${token}`, {}, 'get');
        return observable;
    }


    /******************************************************************************/
    /**                 Job Template Grid CRUD operations                         */

    /******************************************************************************/
    insertGridPage(jTemplateId: number, data: any, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/new?token=${token}`, data, 'post');
        return observable;
    }

    /** revert changes on job template grid to original base template grid - original templateID & page index as data */
    resetGridPage(jTemplateId: number, jTemplateGridID: number, data: any, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${jTemplateGridID}?token=${token}`, data, 'put');
        return observable;
    }

    deleteGridPage(jTemplateID, jTemplateGridID, index, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateID}/grid/${jTemplateGridID}/${index}?token=${token}`, {}, 'delete');
        return observable;
    }


    /******************************************************************************/
    /**                       Image Asset API Calls                               */
    /******************************************************************************/

    // actual image to be used for image manipulation - cropping, moving, resizing... e.g. http://54.206.16.72:8033/adworks_rest_v2/PreviewService/get/getImage?catalogue=&assetID=129&token=69dcd568-1758-4413-a601-8b7da4b6dab7
    getTemplateImage(catalogue: string, assetId: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`PreviewService/get/getImage?catalogue=${catalogue}&assetID=${assetId}&token=${token}`, {responseType: 'blob'}, 'get');
        return observable;
    }

    /** get a list of image assets from search */
    searchImageAssets(page: number, fetchSize: number, search: string, token: string, filter?: string): Observable<any> {
        if (!filter) {
            filter = '';
        }
        const observable = this.commonService.callApiObservable(`${this.template_svc}assets?page=${page}&fetchSize=${fetchSize}&search=${search}&filter=${filter}&token=${token}`, {}, 'get');
        return observable;
    }

    /** get a list of assets for background */
    getBackgroundAssets(page: number, fetchSize: number, baseTemplateID: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}assets?background=1&page=${page}&fetchSize=${fetchSize}&search=${baseTemplateID}&token=${token}`, {}, 'get');
        return observable;
    }

    /** Insert image region in grid */
    insertImageInGrid(jTemplateId: number, gridId: number, data: XmlImage[], token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/images/new?token=${token}`, data, 'post');
        return observable;
    }

    /** Delete Job Template Text Region details in bulk */
    deleteImageInGrid(jTemplateId: number, gridId: number, xmlImageIDs: number[], token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/images?token=${token}&xmlImageIDs=${xmlImageIDs}`, {}, 'delete');
        return observable;
    }

    /** Update Job Template Text Region details in bulk */
    updateImageInGrid(jTemplateId: number, gridId: number, data: XmlImage[], token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/images?token=${token}`, data, 'put');
        return observable;
    }

    /** ADD ASSET IMAGE */
    addAssetImage(data: any, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.asset_svc}asset?token=${token}`, data, 'post');
        return observable;
    }

    /** Load images for replace image overlay */
    getSimilarAssetsForReplacement(assetID: string, page: number, catalogue: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.asset_svc}assets/similar?token=${token}`, {
            page: page,
            dir: 'up',
            order: 'F_AssetName',
            fetchSize: 10,
            matchFields: 'F_Keywords',
            categoryID: -1,
            catalogue: '',
            assetID: assetID
        }, 'get');
        return observable;
    }

    /** get a list of available assetTypes */
    getAssetFilters(catalogue: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.asset_svc}assets/filters?token=${token}`, {
            catalogue: catalogue,
            fieldName: 'F_AssetType'
        }, 'get');
        return observable;
    }

    /******************************************************************************/
    /**                           Fonts API Calls                                 */

    /******************************************************************************/
    /** get font file from the backend - fontFileName & s3 path pairs */   //TODO may use front end side caching since font files barely change
    getFont(fontFileName: string, token: string): Promise<any> {
        const url = `${this.commonService._restv2api}${this.template_svc}font?name=${fontFileName}&token=${token}`;

        // this is temporary measure to apply fonts on texts tab menu items
        const a = '<style> @font-face {\n' +
            '    font-family: ' + fontFileName + ';\n' +
            '    src: url(' + url + ') format("opentype");\n' +
            '}</style>';
        $('head').append(a);

        const entry = this.cacheMap.get(url);

        const isExpired = entry ? (Date.now() - entry.entryTime) > MAX_CACHE_AGE : true;

        if (!isExpired) {
            return new Promise((resolve) => {
                resolve(entry.response);
            });
        } else {
            return new Promise((resolve) => {
                this._http.get(
                    url,
                    {responseType: 'blob'}
                ).subscribe((res: any) => {
                    const entry: CacheEntry = {url: url, response: URL.createObjectURL(res), entryTime: Date.now()};
                    this.cacheMap.set(url, entry);
                    this.deleteExpiredCache();
                    resolve(URL.createObjectURL(res));
                }, () => {
                    resolve('failed');
                });
            });
        }
    }

    /** get a list of font png options - used for font option list, base templateID will be used to limit the return later */
    getFontPngOptions(templateID: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}font/list?templateID=${templateID}&token=${token}`, {}, 'get');
        return observable;
    }

    /**
     * Delete cache file of fonts once it expire
     */
    private deleteExpiredCache() {
        this.cacheMap.forEach(entry => {
            if ((Date.now() - entry.entryTime) > MAX_CACHE_AGE) {
                this.cacheMap.delete(entry.url);
            }
        });
    }

    /**
     * Get blob of image
     * @param imageUrl
     */
    getImage(imageUrl: string): Observable<File> {
        return this._http
            .get(imageUrl, {responseType: 'blob'})
            .map((res: any) => res);
    }

    /******************************************************************************/
    /**                 Get Template size                       */

    /******************************************************************************/
    getTemplateSizes(jTemplateId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/sizes?token=${token}`, {}, 'get');
        return observable;
    }

    /******************************************************************************/
    /**                 Get Swap Job Grid Backgrond                          */

    /******************************************************************************/
    swapJobGridBackgrond(jTemplateId: number, gridId: number, assetID: number, catalogue: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/background/swap?assetID=${assetID}&catalogue=${catalogue}&token=${token}`, {}, 'get');
        return observable;
    }

    /******************************************************************************/
    /**                 Get Image Edit Rules                 */

    /******************************************************************************/
    applyJobGridBackgroundColour(jTemplateId, gridId, rgbColour: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/grid/${gridId}/background/colour`, {
            rgbColour: rgbColour,
            token: token
        }, 'get');
        return observable;
    }

    /******************************************************************************/

    /* Resize API for job template /

    /******************************************************************************/
    resizeJobTemplate(jTemplateId, data, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateId}/resize?token=${token}`, data, 'put');
        return observable;
    }

    /******************************************************************************/
    /**                Template Text Styles with SVG CRUD                         */

    /******************************************************************************/
    /** get a list of text styles with svg */
    getTemplateStyleSvgByTemplateId(baseTemplateId: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${baseTemplateId}/svg?token=${token}`, {}, 'get');
        return observable;
    }

    /** insert new text style processed from base template's text-styles - admin/clientAdmin only */
    insetTemplateTextStyleSvg(baseTemplateId: number, textStyleSvg: TemplateTextStyleSvg, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${baseTemplateId}/svg/new?token=${token}`, textStyleSvg, 'post');
        return observable;
    }

    /** update existing text style with svg - templateId & styleName will be used to find the matching item at the backend - admin/clientAdmin only */
    updateTemplateTextStyleSvg(baseTemplateId: number, textStyleSvg: TemplateTextStyleSvg, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${baseTemplateId}/svg/update?token=${token}`, textStyleSvg, 'put');
        return observable;
    }

    /******************************************************************************/
    /**                         Template Style Rules CRUD                         */

    /******************************************************************************/
    /** get Template style rule - NOTE it always returns full permissions for admin/clientAdmin when isEdit is 0 */
    getTemplateStyleRuleByTemplateId(baseTemplateId: number, isEdit: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${baseTemplateId}/rules?edit=${isEdit}&token=${token}`, {}, 'get');
        return observable;
    }

    /** insert new Template style rule - admin/clientAdmin only */
    insetTemplateStyleRule(baseTemplateId: number, templateStyleRule: TemplateStyleRule, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${baseTemplateId}/rules/new?token=${token}`, templateStyleRule, 'post');
        return observable;
    }

    /** update existing Template style rule - templateId will be used to find the matching item at the backend, admin/clientAdmin only */
    updateTemplateStyleRule(baseTemplateId: number, templateStyleRule: TemplateStyleRule, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/${baseTemplateId}/rules/update?token=${token}`, templateStyleRule, 'put');
        return observable;
    }

    getUsers(friendUser?: any) {
        var userID = 0;
        if (friendUser) userID = friendUser.userID;
        let data = {
            userID: userID, moduleID: 0
        }
        const observable = from(this.commonService.callApiRestV2('UserService/v1/user/?token=' + friendUser, '', 'get'));
        return observable;
    }

    /******************************************************************************/
    /**                         JobBag Services                                   */

    /******************************************************************************/

    /* Get current jobbag for a user */
    getJobBag(jobBagId: number) {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag/' + jobBagId, '', 'get');
        return observable;
    }

    /* add new job bag - used to construct a job bag container to hold line items */
    createNewJobBag() {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag', '', 'post', false, true);
        return observable;
    }

    checkJobBag() {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag', '', 'get', false, true);
        return observable;
    }


    getPreviousOrderDetails(pagination, filters) {
        const observable = this.commonService.callApiObservable('jobbagService/v1/reorder/jobbags?page=' + pagination.page + '&fetchSize=' + pagination.fetchSize + '&filters=' + filters, '', 'get');
        return observable;
    }

    reOrdersDetails(jobBagId: number) {
        const observable = this.commonService.callApiObservable('jobbagService/v1/reorder/jobbag/' + jobBagId, '', 'post');
        return observable;
    }

    getJobCartDetails() {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag', '', 'get');
        return observable;
    }

    removeCartItem(uid: number, clientId: number, jobBagID: number, itemID: number): Observable<any> {
        let data = {
            uid,
            clientId
        }
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag/item/' + jobBagID + '/ecommerce' + '/' + itemID, data, 'delete');
        return observable;
    }

    updateJobBag(jobBagID: number, cartJobBag) {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag/' + jobBagID, cartJobBag, 'put');
        return observable;
    }


    checkout(data, jobbagId: number) {
        const observable = this.commonService.callApiObservable('commerceService/v1/checkout/' + jobbagId, data, 'post');
        return observable;
    }

    getCartSummaryDetails() {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag', '', 'get');
        return observable;
    }

    removeDataFromCart(jobBagId: number) {
        const observable = this.commonService.callApiObservable('jobbagService/v1/jobbag/clear/' + jobBagId, '', 'post');
        return observable;
    }

    /******************************************************************************/
    /**                         Share Job Services                                */

    /******************************************************************************/

    /* Share Job Template */
    shareJobTemplate(jTemplateID: number, data, token: string) {
        const observable = this.commonService.callApiObservable(`${this.template_svc}jobTemplate/${jTemplateID}/pdf/email?token=${token}`, data, 'post');
        return observable;
    }

    /******************************************************************************/
    /**                        Base Template Services                             */

    /******************************************************************************/

    /* Create new base template under specified categoryID with given name */
    createBaseTemplate(data: CreateBaseTemplateRequest, token: string) {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/new?token=${token}`, data, 'post');
        return observable;
    }

    /** Template lock service */
    lockJTemplate(jTemplateID: number, token: string) {
        const observable = this.commonService.callApiObservable(`TemplateService/v1/jobTemplate/${jTemplateID}/lock?token=` + token, '', 'get');
        return observable;
    }

    /** Product description service */
    getProductDetails(productID: number): Observable<any> {
        const observable = from(this.commonService.callApiObservable('commerceService/v1/products/' + productID + '/', '', 'get', true));
        return observable;
    }

    /** Add item to job bag service */
    addItemToJobBag(jobBagId: number, defaultClientID: number, jobBagItem: object, token: string) {
        const observable = from(this.commonService.callApiObservable('jobbagService/v1/jobbag/item/' + jobBagId + '?clientId=' + defaultClientID + '&token=' + token, jobBagItem, 'post', false));
        return observable;
    }

    /* Read the uploaded xml and identify background pdf required and see if any new fonts are required - will return missing fonts that need to be uploaded and background pdf name */
    readUploadedXml(xmlFileName: string, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`${this.template_svc}template/xml/identify?token=${token}&xmlFileName=${xmlFileName}`, {}, 'get');
        return observable;
    }

    /** fetch category list of templates */
    getTemplateAndCategoryList(page: number, fetchSize: number, search: string = '', categoryID: number = 0, clientID: number = 0, token: string) {
        const observable = from(this.commonService.callApiObservable('TemplateService/v1/template/list?page=' + page + '&fetchSize=' + fetchSize + '&search=' + search + '&categoryID=' + categoryID + '&clientID=' + clientID + '&token=' + token, '', 'get', false));
        return observable;
    }

    /** Function to publish the base template */
    publishBaseTemplate(templateID: number, token: string): Observable<any> {
        const observable = this.commonService.callApiObservable(`/TemplateService/v1/template/${templateID}/publish?token=${token}`, {}, 'put');
        return observable;
    }

    /******************************************************************************/
    /**                         Template palettes Services                        */

    /******************************************************************************/

    /** Function to get colour palettes */
    getColourPalettes(templateID: number, clientID: number, token: string) {
        const observable = this.commonService.callApiObservable(`/TemplateService/v1/template/${templateID}/colourPalette/list?clientID=${clientID}&token=${token}`, {}, 'get');
        return observable;
    }

    /** Function to get colour palettes */
    createColourPalette(templateColourPalette: TemplateColourPalette, token: string) {
        const observable = this.commonService.callApiObservable(`/TemplateService/v1/template/colourPalette/new?token=${token}`, templateColourPalette, 'post');
        return observable;
    }

    /** Function to get colour palettes */
    updateColourPalette(templateColourPalette: TemplateColourPalette, token: string) {
        const observable = this.commonService.callApiObservable(`/TemplateService/v1/template/colourPalette/update?token=${token}`, templateColourPalette, 'put');
        return observable;
    }
}
