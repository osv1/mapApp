import {Component, Injector, OnInit, OnDestroy, HostListener} from '@angular/core';
import {BaseComponent} from '../../common/commonComponent';
import {CustomiseMenuService} from './customise-menu.service';
import {XmlImage} from '../../common/models/XmlImage';
import {vfield} from '../../common/models/vfield';
import {TextRegion} from '../../common/models/TextRegion';
import {GridField} from '../../common/models/GridField';
import {Location} from '@angular/common';
import {RestLoginFields} from '../../common/models/RestLoginFields';
import {RestResponse} from '../../common/models/RestResponse';
import {FieldRule} from '../../common/models/FieldRule';
import {queueScheduler} from 'rxjs';
import set = Reflect.set;
import {XmlId} from '../../common/models/XmlId';
import {XmlTMatrix} from '../../common/models/XmlTMatrix';
import {XmlClip} from '../../common/models/XmlClip';
import {XmlImageBounds} from '../../common/models/XmlImageBounds';
import {Page} from '../../common/models/Page';
import {Asset} from '../../common/models/Asset';
import {config} from '../../../assets/config/configs';
import {CustomiseMenuPropertyService} from './customise-menu-property.service';
import {CustomiseMenuSharedService} from './customise-menu-shared.service';
import {EditRules} from '../../common/models/EditRules';
import {TemplateTextStyleSvg} from '../../common/models/TemplateTextStyleSvg';
import {SizeOption} from '../../common/models/SizeOption';
import {ImageUploadComponent} from './image-upload/image-upload.component';
import * as _ from 'lodash';
import {TermsAndConditionsComponent} from './terms-and-conditions/terms-and-conditions.component';

declare const opentype: any;
declare let fontsArr: any;  // added to fabricCurvesText.js;

declare const fabric: any;
declare const $: any;

interface fontsStyles {
    fontFamily?: object;
    fontSize?: number;
    fontAlign?: string;
    fontWeight?: string;
    fontStyle?: string;
    underline?: boolean;
    caps?: boolean;
    color?: string;
    Title?: boolean;
}

@Component({
    selector: 'app-customise-menu',
    templateUrl: './customise-menu.component.html',
    styleUrls: ['./customise-menu.component.css']
})
export class CustomiseMenuComponent extends BaseComponent implements OnInit, OnDestroy {
    objectNotSelected = true;
    showDelete = false;
    activeTextRegionHover: any;
    activeImageRegionHover: any;
    currentView = '';
    currentState: any;
    grids: any [];
    canvas = [];
    textStylesRaw: any;     // used to pass text-styles to TextEditorComponent for formatting
    baseTemplateId: number; // 1331;    //TODO replace with CustomiseMenuPropertyService.baseTemplateId
    groupTextRegions = new Map<string, TextRegion[]>(); // key: index, value: text regions
    maxWidth: string;      // used to pass grid width to TextEditorComponent to set max text width
    //emptyRegionWidth: string;   // keep the 1st empty textregion width
    scaleFactor: number = 0;
    selectedScale: any = "Fit";
    textStyleSvgs: TemplateTextStyleSvg[] = [];
    scales = [25, 50, 75, 100, 125, 150, 175, 200, 225, 250, 275, 300, 'Fit'];
    loginFields: RestLoginFields;
    security_token: string; //TODO replace with CustomiseMenuPropertyService.apiToken
    jTemplateId: number; // 21122;
    gridTextRegionsByGrid = [];  // array of textregions for input elements display
    gridImageRegionsByGrid = [];
    gridFieldsByGrid = [];  // input grid fields on left hand side
    //vfieldsInput: VFieldDisplay[]; //NOT used
    jTemplateGridIds = []; // [76484, 76485];// create text details to submit to fetch png images for convenience
    activeCanvasIndex = 0;
    originalJTemplateGridIds = [];
    categoryId: number;
    classList: any;
    fontPngs: any;
    selectedObjFontsStyles: fontsStyles;
    imageEditorConfigs: any = {};
    activeGroup: any;
    activeTextObject: any;
    activeLastIndex: number;
    lastSelectedObject: any;
    lastSelectedopacity: number;
    lastImageObjectSelected = false;
    templateFieldRules: FieldRule[] = [];   // constraints, default value, datasource... by field id (eg. 908:25)
    groupText = [];
    mods = 0;
    state = [];
    imageCatalogue: string = '';
    textEditorCursorStyle: string = 'pointer';  //while text menu is added, cursor needs to be changed to 'wait'
    imageEditorCursorStyle: string = 'pointer';  // while image is added, cursor needs to be changed to 'wait'
    spinner = false;
    jobTemplateName: string;
    designThumbnailUrls = [];
    designLoading = false;
    isCanvasChanged = false;
    updatedOnAnotherEvent = false;    // flag to prevent duplicate api call from :modified event
    breadcumbs = [];
    selectedBaseTempId;
    showSaveSpinner = false;
    //imgCalls = [];
    username: string;
    imageRegions = [];
    isCropMode = false;     // when crop mode is on, other functions may may need to be disabled
    textRegionsToUpdate: TextRegion[] = [];     //will keep text region that needs to be updated
    public scalingProperties = {};
    public activeObject; // When any object is selected it will needs to updated.
    public imageZIndex = 0;
    currentTextRegion: any;
    templateSizes = [];
    selectedSize: SizeOption;
    originalSize: SizeOption;      // original size from base template
    backGroundImages: any = [];
    scaleIsNotSet = false;
    isUploadImagesEnable: boolean;
    // TODO extra padding space is required to allow negative positions for objects in the actual working area
    // TODO search for canvasMargin to see how it's been applied on canvas, background and empty image region
    //canvasMargin: number = 40; // canvasMargin * 2 will be added to both width & height - need extra padding to display elements with negative x,y values
    lastEmptyTextRegion: any;

    // isDesignLocked: any = null;
    constructor(inj: Injector, private customiseMenuService: CustomiseMenuService, private locationService: Location, public customiseMenuPropertyService: CustomiseMenuPropertyService, public customiseMenuSharedService: CustomiseMenuSharedService) {
        super(inj);
        this.broadcaster.on('setTextRules').subscribe((success: any) => {
            this.setEditTextRules(success);
        });
        this.broadcaster.on('updateTermsandCondition').subscribe((success: any) => {
            this.updateTermsandCondition();
        });
    }

    /** get query param value from url using query name */
    static getParamValue(name: string, url: string) {
        url = '&' + url;
        name = name.replace(/[\[]/, '\\\[').replace(/[\]]/, '\\\]');
        const regexS = '[\\?|&]' + name + '=([^&#]*)';
        const regex = new RegExp(regexS);
        const results = regex.exec(url);
        return results == null ? '' : results[1];
    }

    ngOnDestroy() {
        window.removeEventListener('scroll', this.onMouseWheel, true);
    }

    /** Load resources and data initially */
    ngOnInit() {
        document.addEventListener('contextmenu', event => event.preventDefault());
        this.spinner = true;
        this.objectNotSelected = true;
        this.isCropMode = false;
        const fontName = 'ARIALUNI';
        opentype.load('assets/fonts/ARIALUNI.TTF', (err, fontRes) => {
            if (err) {
                console.error('Error loading font ', err);
                return;
            }
            fontsArr[fontName] = {
                obj: fontRes,
                name: fontName
            };
        });

        // on apply button from crop window     //TODO remove
        this.broadcaster.on('imageCropped').subscribe(data => {
            this.cropEventHandler(data);
        });

        this.broadcaster.on('replaceimage').subscribe((data: any) => {
            data.asset = {
                width: data.width,
                height: data.height
            };
            data.asset = JSON.stringify(data.asset);
            this.replaceCurrentImage(data);
        });
        this.broadcaster.on('imageEditRules').subscribe((rules: any) => {
            this.submitImageEditRules(rules);
        });

        // check url for clickthru param
        if (this.locationService.path().indexOf('commerceParameters=') != -1) {
            // populate fields based on query parameters
            this.buildLoginFieldsFromQueryParmas();
        } else {
            this.loginFields = undefined;
        }
        window.addEventListener('scroll', this.onMouseWheel.bind(this), true);
    }

    /** Load resources and data after initialization of component */
    ngAfterViewInit() {
        this.activatedRoute.queryParams.subscribe(params => {
            if (params['baseTemplateId']) {
                setTimeout(()=> {
                    this.customiseMenuPropertyService.apiToken = this.getToken('accessToken');
                    this.baseTemplateId = params['baseTemplateId'];
                    this.jTemplateId = params['jTemplateId'];
                    this.security_token = this.getToken('accessToken');
                    this.customiseMenuPropertyService.isAdmin = true;
                    this.categoryId = 254;
                    this.loginFields = new RestLoginFields();
                    this.loginFields.templateID = params['baseTemplateId'];
                    this.loginFields.jTemplateID = params['jTemplateId'];
                    this.spinner = true;
                    if (!this.jTemplateId || this.jTemplateId === 0) {
                        this.createNewJobTemplate(true);
                    } else {
                        this.loadFontsPng(false, true);
                    }
                }, 200);
            } else {
                if (!this.loginFields) {
                    // TODO - This register service call will be replace just one common fuction in future when all the components are converted in Angular 7
                    this.customiseMenuService.registerRestV2(this.loginFields).subscribe((res: any) => {
                        if (res.statusCode === 200) {
                            this.security_token = res.key;
                            this.customiseMenuPropertyService.apiToken = res.key;
                            // this.commonService._restv2api = res.instance.baseUrl + '/';
                            this.commonService.restUser.restUploadUrl = res.instance.baseUrl + '/AssetService/upload/' + res.key;
                            this.customiseMenuService.getUsers(this.security_token).subscribe((userResponse: any) => {

                                if (userResponse) {
                                    userResponse = userResponse.instance;
                                    //   this.categoryId = 254;
                                    //   this.username = userResponse.userName;
                                    //   this.getDesignImages();
                                    //   this.currentView = 'designs';
                                    // }
                                    // window.location.href = this.CM_Url;
                                    if (userResponse.moduleRoles && userResponse.moduleRoles[3] === '1') {
                                        this.customiseMenuPropertyService.isAdmin = true;
                                        this.designLoading = true;
                                        this.showSaveSpinner = true;
                                        this.categoryId = 254;
                                        // this.username = userResponse.userName;
                                        this.getDesignImages();
                                        this.currentView = 'designs';
                                        this.spinner = false;
                                    } else {
                                        // window.location.href = this.CM_Url;
                                    }
                                    // }
                                }
                            });
                            // this.loadFontsPng();
                        }
                    });
                } else {
                    // login to rest_v2 to get a token using details from clickthru
                    this.customiseMenuService.registerRestV2(this.loginFields).subscribe((res: RestResponse) => {
                        if (res.statusCode === 200) {
                            this.security_token = res.key;
                            this.baseTemplateId = +this.loginFields.templateID;
                            this.customiseMenuPropertyService.baseTemplateId = +this.loginFields.templateID;     //use property service one
                            this.customiseMenuPropertyService.apiToken = res.key;
                            this.commonService.restUser.restUploadUrl = this.commonService._restv2api + +'/AssetService/v1/asset/upload?token=' + this.security_token;
                            this.selectedBaseTempId = this.baseTemplateId.toString();
                            if (!!this.loginFields.jTemplateID && this.loginFields.jTemplateID.length > 0) {
                                this.jTemplateId = +this.loginFields.jTemplateID;
                                this.baseTemplateId = +this.loginFields.templateID;
                                this.loadFontsPng();
                                this.customiseMenuPropertyService.baseTemplateId = +this.loginFields.templateID;     // use property serivce
                                this.selectedBaseTempId = this.baseTemplateId.toString();
                                // this.jTemplateGridIds = [];
                                // this.originalJTemplateGridIds = [];
                                // this.activeCanvasIndex = 0;
                                // templateRes.templateGrids.forEach((data) => {
                                //     if (data.templateGridID) {
                                //         this.jTemplateGridIds.push(data.templateGridID);
                                //     }
                                //     if (data.originalTemplateGridID) {
                                //         this.originalJTemplateGridIds.push(data.originalTemplateGridID);
                                //     }
                                // });
                                this.loadFontsPng(false, true);
                            } else {
                                // create new job template
                                this.createNewJobTemplate(true);
                            }

                        } else {
                            // console.log('failed to login to rest_v2');
                        }
                    });
                }
            }
        });

    }

    /* Show / Hide Toolbar Action Menu for responsive. */
    showActionBtns() {
        if ($(".right-action-btns").css('display') == "none") {
            $(".right-action-btns").slideDown('fast');
        } else {
            $(".right-action-btns").slideUp('fast');
        }
    }


    /** on initial loading or design change needs to create new job template from selected base template */
    createNewJobTemplate(loadFonts) {

        this.selectedScale = "Fit";   // reset to 100% when it's chnaged to new design
        this.scaleIsNotSet = true;
        this.textEditorCursorStyle = 'pointer'; //reset just in case
        this.customiseMenuService.createNewJTemplate(this.loginFields.templateID, this.security_token).subscribe((templateRes: any) => {
            this.baseTemplateId = templateRes.templateID;
            this.customiseMenuPropertyService.baseTemplateId = templateRes.templateID;     // use property serivce
            this.selectedBaseTempId = this.baseTemplateId.toString();
            this.jTemplateId = templateRes.jtemplateID;
            this.jTemplateGridIds = [];
            this.originalJTemplateGridIds = [];
            this.activeCanvasIndex = 0;
            templateRes.templateGrids.forEach((data) => {
                if (data.templateGridID) {
                    this.jTemplateGridIds.push(data.templateGridID);
                }
                if (data.originalTemplateGridID) {
                    this.originalJTemplateGridIds.push(data.originalTemplateGridID);
                }
            });

            this.loadFontsPng(!loadFonts ? true : false, true);
            // if (!loadFonts) {
            //     this.setBaseTamplateAndBackground(undefined, true);
            // }
        });
    }

    /** formatted text regions by text menu index */
    getGroupTextRegionsAsMap(mapGroupTextRegions: Map<string, TextRegion[]>) {
        this.groupTextRegions = mapGroupTextRegions;
    }

    /** get base template and its grid and also set background for template on canvas */
    setBaseTamplateAndBackground(gridIndex?: number, isDesign?: boolean, isSizes?: boolean, isRefreshTab?: boolean) {  //when 0 based gridIndex is passed, that certain grid needs to be updated only

        if (!gridIndex) { // to be called only on full refresh
            this.customiseMenuService.getTemplate(this.baseTemplateId, this.security_token).subscribe(res => {
                if (res.template['text-styles']) {
                    // this.textStyles = this.formateTextStyles(res.template['text-styles']['text-style']);
                    // this.textStyles = this.customiseMenuService.formatTextStyles(res.template['text-styles']['text-style']);
                    // this.textStylesRaw = res.template['text-styles']['text-style'];

                    let firstGrid;
                    let singlePage = false;
                    if (Array.isArray(res.template.grids.grid)) {
                        firstGrid = res.template.grids.grid[0];
                        if (res.template.grids.grid.length === 1) {
                            singlePage = true;
                        }
                    } else {
                        firstGrid = res.template.grids.grid;
                        singlePage = true;
                    }
                    //const firstGrid = Array.isArray(res.template.grids.grid) ? res.template.grids.grid[0] : res.template.grids.grid;
                    // use the 1st grid width as max text obj width
                    this.maxWidth = firstGrid.width; //Array.isArray(res.template.grids.grid) ? res.template.grids.grid[0].width : res.template.grids.grid.width;

                    // pass the 1st empty region on the 1st page to be used to set text style when it's present
                    if (singlePage) {
                        let textFlowRegion;
                        if (Array.isArray(firstGrid.region.style[1].textregion)) {    // textregion might be array or sinlge object
                            textFlowRegion = firstGrid.region.style[1].textregion.find(region => {
                                return !region.textblock;
                            });
                        } else {
                            textFlowRegion = !firstGrid.region.style[1].textregion.textblock ? firstGrid.region.style[1].textregion : undefined;
                        }
                        this.maxWidth = !!textFlowRegion ? textFlowRegion.width : this.maxWidth;
                    }
                    // // console.log('maxWidth: ' + this.maxWidth);
                }
            });
        }
        if (isSizes) {
            this.customiseMenuService.getTemplateSizes(this.jTemplateId, this.security_token).subscribe(res => {
                this.templateSizes = res;
                this.selectedSize = res.filter(data => data.selected === 'selected')[0] || res[0];

                // will keep a copy of original size for comparison
                this.originalSize = JSON.parse(JSON.stringify(this.selectedSize)) as SizeOption;
                // console.log('this.originalSize: ' + this.originalSize.name);
            })
        }
        this.customiseMenuService.getJobTemplate(this.jTemplateId, this.security_token).subscribe(res => {

            this.customiseMenuPropertyService.locked = (res.locked === 0) ? null : true; // Maintain locked state of template
            if (!gridIndex) { // to be called only on full refresh
                this.templateFieldRules = res.fieldRules;
            }
            this.categoryId = res.categoryID;

            if (!gridIndex && !isDesign) {    // fetch on full refresh only
                // console.log('design fetch!');
                this.getDesignImages();
            }

            if ((!gridIndex && !isRefreshTab) || (isDesign && !isRefreshTab)) {     // fetch on full refresh or design change
                this.backGroundImages = [];
                // console.log('bg fetch!');
                this.getBackgroundImages();
            }
            if (!isRefreshTab) {
                this.getTextTabData();
            }

            if (res.templateGrids) {
                if (res.templateGrids.length) {
                    if (!this.jTemplateGridIds || !this.jTemplateGridIds.length) {
                        // this.jobTemplateName = res.name;
                        this.jTemplateGridIds = [];
                        this.originalJTemplateGridIds = [];
                        this.activeCanvasIndex = 0;
                        res.templateGrids.forEach((data) => {
                            if (data.templateGridID) {
                                this.jTemplateGridIds.push(data.templateGridID);
                            }
                            if (data.originalTemplateGridID) {
                                this.originalJTemplateGridIds.push(data.originalTemplateGridID);
                            }
                        });
                    }
                    if (!!gridIndex) {  // !!! add new one only, otherwise will lose existing canvas grids
                        const gridInserted = res.templateGrids.find(grid => {
                            return +grid.gridName === gridIndex + 1;
                        });
                        if (!!gridInserted) {
                            gridInserted.id = gridInserted.gridName;
                            this.grids.push(gridInserted);
                        }

                    } else {    //full refresh
                        const gridsObj: any = [];
                        //const vfieldObj: any = [];
                        res.templateGrids.forEach((templateGridsData: any, index) => {
                            templateGridsData.id = templateGridsData.gridName;
                            gridsObj.push(templateGridsData);
                        });
                        //this.vfieldsInput = vfieldObj;
                        this.grids = gridsObj;
                    }

                    let obj = 0;
                    for (let index = 0; index < this.grids.length; index++) {

                        //when 0 based gridIndex is passed, that certain grid needs to be updated only after Insert Page operation
                        if (!!gridIndex && gridIndex !== index) {
                            continue;
                        }
                        // TODO why existing canvas pages are not being displayed ???
                        const grid = this.grids[index];
                        this.customiseMenuService.getJobTemplateGrid(this.jTemplateId, this.jTemplateGridIds[index], this.security_token).subscribe((resGrid: any) => {
                            const gridObj: any = resGrid;
                            gridObj.id = index + 1;
                            let imageObject: any = {vfield: {index: index}};
                            this.gridImageRegionsByGrid[index] = imageObject;
                            this.customiseMenuService.getJobTextRegions(this.jTemplateId, this.jTemplateGridIds[index], this.security_token).subscribe(
                                (resGrid: any) => {
                                    const textRegions: TextRegion[] = resGrid.instance[this.jTemplateGridIds[index]];
                                    this.gridTextRegionsByGrid[index] = textRegions;

                                    if (this.gridTextRegionsByGrid[index]) {
                                        this.customiseMenuService.getJobTemplateGridBackground(this.baseTemplateId, grid.originalTemplateGridID, grid.templateGridID, this.security_token).subscribe((backgroundValue: string) => {
                                            resGrid.grid = gridObj;

                                            // need to consider bgColour
                                            if (backgroundValue.toLowerCase().startsWith('rgb')) {
                                                resGrid.grid.bgColour = backgroundValue;
                                            } else {
                                                resGrid.grid.s3Background = backgroundValue;
                                            }

                                            if (resGrid && (resGrid.grid.s3Background || resGrid.grid.bgColour)) {
                                                this.initCanvas(resGrid, index);
                                            }
                                            obj = obj + 1;
                                            if (obj === this.grids.length) {
                                                this.spinner = false;
                                            }
                                        });
                                    }
                                });

                        });

                    }
                    /*this.grids.forEach((grid: any, index) => {
                        this.customiseMenuService.getJobTemplateGrid(this.jTemplateId, this.jTemplateGridIds[index], this.security_token).subscribe((resGrid: any) => {
                            const gridObj: any = resGrid;
                            gridObj.id = index + 1;
                            let imageObject: any = {vfield: {index: index}};
                            this.gridImageRegionsByGrid[index] = imageObject;
                            this.customiseMenuService.getJobTextRegions(this.jTemplateId, this.jTemplateGridIds[index], this.security_token).subscribe(
                                (resGrid: any) => {
                                    const textRegion: TextRegion = resGrid.instance[this.jTemplateGridIds[index]];
                                    this.gridTextRegionsByGrid[index] = textRegion;

                                    if (this.gridTextRegionsByGrid[index]) {
                                        this.customiseMenuService.getJobTemplateGridBackground(this.baseTemplateId, grid.originalTemplateGridID, this.security_token).subscribe((s3Path: any) => {
                                            resGrid.grid = gridObj;
                                            resGrid.grid.s3Background = s3Path;
                                            if (resGrid) {
                                                this.initCanvas(resGrid, index);
                                            }
                                            obj = obj + 1;
                                            if (obj === this.grids.length) {
                                                this.spinner = false;
                                            }
                                        });
                                    }
                                });

                        });
                    });*/

                    /*if (!gridIndex) {
                        this.getJobTemplateInputFiels();    //not used
                    }*/
                }
            }
        });
    }

    /** populate left input fields for all jTemplateGrids - job template version has extra details like optionList for select */
    getJobTemplateInputFiels() {
        this.jTemplateGridIds.forEach((jTemplateGridId, index) => {
            this.customiseMenuService.getJobTemplateGridFields(this.jTemplateId, jTemplateGridId, this.security_token).subscribe((gridFields: GridField[]) => {
                this.gridFieldsByGrid[index] = gridFields;   // map of key: grid index & value: grid fields
                // // console.log(this.gridFieldsByGrid[index].length);
            });

        });
    }

    // TODO image is added twice on pdf generation?  cropped image needs to be applied
    /** need to display existing images from template response - NO need to re-submit to backend */
    loadImages(imgInstance: any, index: number): void {
        const imgFn = (assetId, xmlImage) => {  //find matching asset to display
            this.customiseMenuService.searchImageAssets(1, 20, assetId, this.security_token)
                .subscribe((page: Page<Asset>) => {
                    if (!!page.rows && page.rows.length > 0) {
                        // when more than 1 assets returned, need to find matching asset with the same id
                        let asset: Asset;
                        if (page.rows.length === 1) {
                            asset = page.rows[0];
                        } else {
                            asset = page.rows.find((asset: any) => {
                                return +asset.assetID === +assetId;
                            });
                        }

                        //const imgURL = `https://api-dev.ergoasia.com/rest_v2/AssetService/v1/get/asset/preview?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.security_token}`;//config.restv2api + config.thumbPath + `?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.security_token}`;
                        const imgURL = config.restv2api + `AssetService/v1/get/asset/preview?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.security_token}`;//config.restv2api + config.thumbPath + `?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.security_token}`;
                        this.fabricImgCmp({
                            src: imgURL,
                            activeCanvasIndex: index,
                            left: xmlImage.x,
                            top: xmlImage.y,
                            originalURL: imgURL,
                            assetId: asset.assetID,
                            asset: {
                                width: asset.width,
                                height: asset.height
                            },
                            // zoomScale: this.scaleFactor,
                            zoomScale: xmlImage.vfield[0].tmatrix.a * this.scaleFactor,
                            // angle value from fabric image is clock wise unlike backend pdf creator
                            angle: +xmlImage.angle > 0 ? -xmlImage.angle + 360 : 0,

                            // already saved images need to set ccImage - no need to re-submit to backend
                            ccImage: xmlImage,
                            ccImageId: xmlImage.id,
                            noNeedToSubmit: true        // flag not to add this image to backend on object:added event

                        }, (img) => {
                            // console.log('existing image loaded: ' + img.ccImageId);
                        });
                    }
                });
        };

        // call imgFn() for valid asset image
        Object.keys(imgInstance).forEach((key) => {
            const xmlImages = imgInstance[key] as XmlImage[];  // get xmlImage instance
            if (!xmlImages.length /*|| !(xmlImages[0].vfield[0] && xmlImages[0].vfield[0].xmlId)*/) {
                return;
            }
            xmlImages.forEach(xmlImage => {
                if (xmlImage.vfield[0] && xmlImage.vfield[0].xmlId) { //only those ones with asset images
                    const assetId = xmlImage.vfield[0].xmlId.value;
                    imgFn(assetId, xmlImage);
                }
            });
        });
    }

    /** common function place image onto canvas */
    fabricImgCmp(imgObj: any, callback?: any): void {
        let activeCanvas = this.canvas[imgObj.activeCanvasIndex];
        fabric.Image.fromURL(imgObj.src, (img: any) => {
            // when zoomScale is not available, get scale based on width
            //img._originalElement.width =  +imgObj.asset.width;
            //img._originalElement.height =  +imgObj.asset.height;
            /*let imageScale;
            if ( !!imgObj.zoomScale ) {
                imageScale = +imgObj.zoomScale;
            } else {
                imageScale = 0.5;   // use 50% by default - naturalWidth does not seem to be resized with right ratio (always 800)
            }*/

            let imageScale;
            if (+imgObj.asset.width === 0 && imgObj.asset.height === 0) {
                imgObj.asset.width = +img._originalElement.naturalWidth;
                imgObj.asset.height = +img._originalElement.naturalHeight;
            }
            if (this.activeImageRegionHover) {
                const canvasAspect = Number(this.activeImageRegionHover.width) / Number(this.activeImageRegionHover.height);
                const imgAspect = Number(+img._originalElement.naturalWidth) / Number(+img._originalElement.naturalHeight);
                let scaleFactor;
                if (canvasAspect < imgAspect) {
                    scaleFactor = Number(this.activeImageRegionHover.width) / Number(+imgObj.asset.width);
                } else {
                    scaleFactor = Number(this.activeImageRegionHover.height) / Number(+imgObj.asset.height);
                }

                let calcNewLeft = (Number(this.activeImageRegionHover.width) - Number(+imgObj.asset.width * scaleFactor)) / 2;
                let calcNewTop = (Number(this.activeImageRegionHover.height) - Number(+imgObj.asset.height * scaleFactor)) / 2;
                calcNewLeft = calcNewLeft < 0 ? 0 : calcNewLeft;
                calcNewTop = calcNewTop < 0 ? 0 : calcNewTop;
                imgObj.left = Number(this.activeImageRegionHover.x) + calcNewLeft;
                imgObj.top = Number(this.activeImageRegionHover.y) + calcNewTop;
                imageScale = scaleFactor;
            } else {
                let width = Number(img._originalElement.naturalWidth || imgObj.asset.width);
                if (width >= activeCanvas.width) {
                    width = +activeCanvas.width - (+activeCanvas.width * 20) / 100;
                }
                imageScale = !!imgObj.zoomScale ? +imgObj.zoomScale : width / (+imgObj.asset.width);
            }

            if (!imgObj.noNeedToSubmit) {    // should be applied to new images that's being dragged onto canvas
                // Check whether Image Both Height and width greater than canvas height and width respectively. If yes then adjust zoom scale.
                if ((+imgObj.left + +imgObj.asset.width) >= activeCanvas.originalCanvasWidth && (+imgObj.top + +imgObj.asset.height) >= activeCanvas.originalCanvasHeight && !this.activeImageRegionHover) {
                    let heightDiff = (+imgObj.top + +imgObj.asset.height) - activeCanvas.originalCanvasHeight;
                    let widthDiff = (+imgObj.left + +imgObj.asset.width) - activeCanvas.originalCanvasWidth;
                    const scaleX = (+imgObj.asset.width - widthDiff) / +imgObj.asset.width;
                    const scaleY = (+imgObj.asset.height - heightDiff) / +imgObj.asset.height;
                    if (scaleX < scaleY) {
                        imageScale = scaleX;
                    } else {
                        imageScale = scaleY;
                    }
                } else if ((+imgObj.left + +imgObj.asset.width) >= activeCanvas.originalCanvasWidth && !this.activeImageRegionHover) {
                    // Check whether Image width greater than canvas width. If yes then adjust zoom scale based on width.
                    let diff = (+imgObj.left + +imgObj.asset.width) - activeCanvas.originalCanvasWidth;
                    imageScale = (+imgObj.asset.width - diff) / +imgObj.asset.width;
                } else if ((+imgObj.top + +imgObj.asset.height) >= activeCanvas.originalCanvasHeight && !this.activeImageRegionHover) {
                    // Check whether Image height greater than canvas height. If yes then adjust zoom scale based on height.
                    let diff = (+imgObj.top + +imgObj.asset.height) - activeCanvas.originalCanvasHeight;
                    imageScale = (+imgObj.asset.height - diff) / +imgObj.asset.height;
                }
            }

            img.set({
                type: 'image',
                crossOrigin: 'annonymous',
                lockScalingFlip: true,
                activeCanvasIndex: imgObj.activeCanvasIndex,
                width: Number(+imgObj.asset.width),     // use original size and apply scaling for whole image
                height: Number(+imgObj.asset.height),
                left: Number(imgObj.left),
                top: Number(imgObj.top),
                angle: !!imgObj.angle ? +imgObj.angle : 0,
                noNeedToSubmit: !!imgObj.noNeedToSubmit     // flag not to add this image to backend on object:added event
            });
            img.setControlsVisibility({     // keep resize handles on 4 corners only to keep ratio
                mb: false, ml: false, mr: false, mt: false
            });

            if (!!imgObj.ccImage) {   // existing image needs to set ccImage details
                img.ccImage = imgObj.ccImage;
                img.ccImageId = imgObj.ccImage.id;
            }

            img.originalURL = imgObj.originalURL;
            img.cropperPosition = imgObj.cropperPosition;
            img.oldZoomScale = imageScale;
            img.zoomScale = imageScale;     // this should be applied on crop window
            img.assetId = imgObj.assetId;
            img.asset = imgObj.asset; //centeredScaling :Boolean _needsResize() getOriginalSize() → {Object}
            img.scale(imageScale);  // scales an image (equally by x and y)
            this.imageZIndex = this.imageZIndex + 1;
            img.set({
                opacity: this.imageZIndex
            });
            activeCanvas.add(img);
            if (this.activeImageRegionHover) {
                img.set({
                    left: Number(imgObj.left),
                    top: Number(imgObj.top)
                });
            }
            // activeCanvas.bringForward(img);
            // activeCanvas.bringToFront(img);
            activeCanvas.setActiveObject(img);
            // img.scale(imageScale);
            activeCanvas.renderAll();

            callback && callback(img);
        }, {
            crossOrigin: 'annonymous'
        });
    }

    typingTimer;

    /** apply background from s3 image and place text blocks */
    initCanvas(resGrid: any, index: number, isScaling?: boolean) {

        this.scaleFactor = 0;

        // #6657 & #6659
        if (this.selectedScale !== 'Fit') {
            this.scaleFactor = this.selectedScale / 100;
        } else {
            this.scaleFactor = ((window.innerHeight - 200) * 100 / +resGrid.grid.height) / 100;
        }

        this.canvas[index] = new fabric.Canvas(`playground_${resGrid.grid.id}`, {
            // backgroundColor: 'rgb(100,100,200)'
            // backgroundImage: '../assets/images/Lighthouse.png'  //this gives rendering exception
            width: +resGrid.grid.width,
            height: +resGrid.grid.height,
            //width: (+resGrid.grid.width + (this.canvasMargin * 2)) * scaleFactor,
            //height: (+resGrid.grid.height + (this.canvasMargin * 2)) * scaleFactor,
            stateful: true,
            crossOrigin: 'anonymous'
        });
        // this.canvas[index].setDimensions({
        //     width: Number(this.canvas[index].originalCanvasWidth * this.scaleFactor),
        //     height: Number(this.canvas[index].originalCanvasHeight * this.scaleFactor)
        // });
        this.canvas[index].setZoom(this.scaleFactor);

        if (!!resGrid.grid.s3Background) {
            // get background image and sclale it to be fit within template's width & height
            fabric.Image.fromURL(resGrid.grid.s3Background, img => {
                img.set({
                    activeCanvasIndex: index
                    //,left: this.canvasMargin,
                    //top: this.canvasMargin
                });
                const background = img.scaleToWidth(+this.canvas[index].width, false);
                //const background = img.scaleToWidth(+this.canvas[index].width - (this.canvasMargin * 2), false);

                // digital templates need to use left bottom corner in order to be compatible with pdf output on RESIZE - background pdf is big enough to cover different types
                if (this.customiseMenuSharedService.isDigital(+resGrid.grid.width, +resGrid.grid.height)) {
                    //!!! top value must be adjusted to grid height
                    background.set({originX: 'left', originY: 'bottom', top: +resGrid.grid.height});
                }

                this.canvas[index].setBackgroundImage(background, el => {
                    //el.set( {originX: 'left', originY: 'bottom'} );
                    this.canvas[index].renderAll();  //canvas.requestRenderAll();
                });

                // extra attributes to keep the original size since scaled values causes unexpected issues - especially when FIT is applied
                this.canvas[index].originalBackgroundImageWidth = background.width;
                this.canvas[index].originalBackgroundImageHeight = background.height;

                this.prepCanvas(index);
            });

        } else if (!!resGrid.grid.bgColour) {
            this.canvas[index].backgroundImage = false;
            this.canvas[index].setBackgroundColor(resGrid.grid.bgColour, () => {
                this.canvas[index].renderAll();
            });

            this.prepCanvas(index);
        }

        // if(this.customiseMenuPropertyService.locked) {
        //   this.isDesignLocked = true;
        // } else {
        //   this.isDesignLocked = false;
        // }

        /*// get background image and sclale it to be fit within template's width & height
        fabric.Image.fromURL(resGrid.grid.s3Background, img => {
            img.set({
                activeCanvasIndex: index
                //,left: this.canvasMargin,
                //top: this.canvasMargin
            });
            const background = img.scaleToWidth(+this.canvas[index].width, false);
            //const background = img.scaleToWidth(+this.canvas[index].width - (this.canvasMargin * 2), false);

            // digital templates need to use left bottom corner in order to be compatible with pdf output on RESIZE - background pdf is big enough to cover different types
            if (this.customiseMenuSharedService.isDigital(+resGrid.grid.width, +resGrid.grid.height)) {
                //!!! top value must be adjusted to grid height
                background.set({originX: 'left', originY: 'bottom', top: +resGrid.grid.height});
            }

            this.canvas[index].setBackgroundImage(background, el => {
                //el.set( {originX: 'left', originY: 'bottom'} );
                this.canvas[index].renderAll();  //canvas.requestRenderAll();
            });

            // get this grid's textregions
            this.loadExistingTextRegions(index);

            // Load images of pre-designed
            this.customiseMenuService.getJobImages(this.jTemplateId, this.jTemplateGridIds[index], this.security_token).subscribe((resImage) => {
                this.imageRegions.push({
                    index: index,
                    res: resImage.instance
                });
                this.loadImages(resImage.instance, index);
            });

            this.canvas[index].originalCanvasWidth = this.canvas[index].width;
            this.canvas[index].originalCanvasHeight = this.canvas[index].height;

            let isRendering = false;
            const render = this.canvas[index].renderAll.bind(this.canvas[index]);

            this.canvas[index].renderAll = () => {
                if (!isRendering) {
                    isRendering = true;
                    requestAnimationFrame(() => {
                        render();
                        isRendering = false;
                    });
                }
            };

            //this.canvas[index].originalBackgroundImageWidth = background.width;
            //this.canvas[index].originalBackgroundImageHeight = background.height;

            // Bind canvas events
            this.bindCanvasEvents(this.canvas[index], index);
            //this.canvas[index].originalBackgroundImageWidth = background.width;
            //this.canvas[index].originalBackgroundImageHeight = background.height;
            this.canvas[index].setDimensions({
                width: Number(this.canvas[index].originalCanvasWidth * this.scaleFactor),
                height: Number(this.canvas[index].originalCanvasHeight * this.scaleFactor)
            });
            if (this.currentView && this.currentView !== 'background') {
                setTimeout(() => {
                    if (!!this.currentView) {
                        this.draggableBg(this.currentView, !!this.currentView);
                    }
                }, 100, this);
            }
        });*/

        fabric.util.addListener(document.body, 'keydown', (options) => {

            const key = options.which || options.keyCode; // key detection
            let isShift = options.shiftKey;
            if ((key === 8 || key === 46) && options.target.tagName === 'BODY') {
                this.removeObject();
            } else if ((key === 37 || (key === 52 && isShift) || key === 38 || (key === 56 && isShift) || key === 39 || (key === 54 && isShift) || key === 40 || (key === 50 && isShift)) && options.target.tagName === 'BODY' && this.activeObject) {
                options.preventDefault();
                clearTimeout(this.typingTimer);
                this.moveObject(key)
            }
        });
        fabric.util.addListener(document.body, 'keyup', (options) => {
            if (options.repeat) {
                return;
            }
            const key = options.which || options.keyCode; // key detection
            let isShift = options.shiftKey;
            if ((key === 37 || (key === 52 && isShift) || key === 38 || (key === 56 && isShift) || key === 39 || (key === 54 && isShift) || key === 40 || (key === 50 && isShift)) && options.target.tagName === 'BODY' && this.activeObject) {
                options.preventDefault();
                clearTimeout(this.typingTimer);
                this.typingTimer = setTimeout(() => {
                    if (this.activeObject.type === 'image') {
                        this.imageDataOps(this.activeObject, 'update', true);
                    } else {
                        this.updateActiveTextRegion(true);
                    }
                }, 500);
            }
        });
    }

    /* Add water Mark */
    addWaterMark(index) {
        const text = new fabric.Text('PROOF', {
            fontFamily: 'ARIALUNI',
            left: 10,
            top: 10,
            height: 80,
            stroke: '#000000',
            fill: '#ffffff',
            transparentCorners: false,
            lineHeight: 1,
            lockMovementX: true,  // prevent it from moving by itself
            lockMovementY: true,  // prevent it from moving by itself
            cornerStyle: 'circle',
            lockScalingFlip: true,
            lockScalingX: true,
            lockScalingY: true,
            selectable: false,
            editable: false,
            isWaterMark: true,
            hoverCursor: 'default'
        });
        text.set({opacity: this.imageZIndex + 1});
        this.canvas[index].add(text);
        this.canvas[index].renderAll();
    }

    /** common operations for both s3 background and simple colour value */
    prepCanvas(index: number): void {
        // get this grid's textregions
        this.loadExistingTextRegions(index);

        // Load images of pre-designed
        this.customiseMenuService.getJobImages(this.jTemplateId, this.jTemplateGridIds[index], this.security_token).subscribe((resImage) => {
            this.imageRegions.push({
                index: index,
                res: resImage.instance
            });
            this.loadImages(resImage.instance, index);
        });

        // extra attributes to keep the original size since scaled values causes unexpected issues - especially when FIT is applied
        this.canvas[index].originalCanvasWidth = this.canvas[index].width;
        this.canvas[index].originalCanvasHeight = this.canvas[index].height;

        let isRendering = false;
        const render = this.canvas[index].renderAll.bind(this.canvas[index]);

        this.canvas[index].renderAll = () => {
            if (!isRendering) {
                isRendering = true;
                requestAnimationFrame(() => {
                    render();
                    isRendering = false;
                });
            }
        };
        this.addWaterMark(index);

        //this.canvas[index].originalBackgroundImageWidth = background.width;
        //this.canvas[index].originalBackgroundImageHeight = background.height;

        // Bind canvas events
        this.bindCanvasEvents(this.canvas[index], index);
        //this.canvas[index].originalBackgroundImageWidth = background.width;
        //this.canvas[index].originalBackgroundImageHeight = background.height;
        this.canvas[index].setDimensions({
            width: Number(this.canvas[index].originalCanvasWidth * this.scaleFactor),
            height: Number(this.canvas[index].originalCanvasHeight * this.scaleFactor)
        });
        if (this.currentView /*&& this.currentView !== 'background'*/) {    // background also needs to bind dragging event
            setTimeout(() => {
                if (!!this.currentView) {
                    this.draggableBg(this.currentView, !!this.currentView);
                }
            }, 100, this);
        }
    }

    /** existing textregions with group rectangle need to be displayed on load */
    loadExistingTextRegions(index: number): void {
        // get this grid's textregions

        const gridTextRegions = this.gridTextRegionsByGrid[index];
        // console.log(gridTextRegions, 'gridTextRegions');
        if (!gridTextRegions) { // no text regions - no need to proceed
            return;
        }

        // display existing textRegions
        const styleTextRegionsOnLoad = new Map<string, any[]>(); // key: parent value, value: fabric texts under the same parent
        const singleTextRegionsOnLoad: any[] = []; // key: parent value, value: fabric texts under the same parent
        gridTextRegions.forEach((textRegion: TextRegion) => {
            if (!!textRegion.textBlocks) {
                if (!(textRegion.x === '-0.0' || textRegion.y === '-0.0')) {

                    // when there is new line(s) but number of rows are not reflecting that for pre-defined text, re-assign height
                    const xmlText = textRegion.textBlocks[0].xmlText[0];
                    if (!!xmlText.vfield[0].value.match(/\r/g) && xmlText.vfield[0].editRowHeight === '1') {
                        textRegion.height = '' + (+xmlText.pointsize * (xmlText.vfield[0].value.match(/\r/g).length + 1));
                    }

                    /*  If index is passed initially all the task will perform on index not in activeIndex */
                    const fabricText = this.addFabricTextWithTextRegion(textRegion, false, textRegion.parent ? textRegion.parent : '-1', undefined, undefined, undefined, index);
                    fabricText.isPreloaded = true;      //preloaded items needs to be excluded from shift down
                    // don't forget to set ids
                    if (!!textRegion.id && +textRegion.id > 0) {
                        fabricText.id = textRegion.id;
                    }
                    // need to group those textRegions with the same parent value
                    if (!!textRegion.parent && +textRegion.parent > 0) {
                        // map entry already exist - just add up, otherwise create new array
                        if (!!styleTextRegionsOnLoad.get(textRegion.parent)) {
                            styleTextRegionsOnLoad.get(textRegion.parent).push(fabricText)
                        } else {
                            styleTextRegionsOnLoad.set(textRegion.parent, [fabricText]);
                        }
                    } else {    //single item that does not need group rectangle but still has valid snap in area
                        if (!!textRegion.snapTextRegionId && +textRegion.snapTextRegionId > 0) {
                            singleTextRegionsOnLoad.push(fabricText);
                        }
                    }
                }

            }
        });

        /** group menu items need to be placed with parent rectangle */
        styleTextRegionsOnLoad.forEach((fabricTexts: any[], parent: string) => {
            // find dedicated empty region if any
            const emptyTextRegion = gridTextRegions.find((textRegion: TextRegion) => {
                return textRegion.id === fabricTexts[0].ccTextRegion.snapTextRegionId;
            });
            let snapInRegion;
            if (!!emptyTextRegion) {
                snapInRegion = {
                    x: +emptyTextRegion.x,
                    y: +emptyTextRegion.y,
                    width: +emptyTextRegion.width,
                    height: +emptyTextRegion.height
                };
            }

            fabricTexts.forEach((text) => {
                text.rectId = emptyTextRegion.id;
            });
            // !!! add group rectangle - use already added fabric text instances
            this.addTextsBeforeSubmit([], true, parent, emptyTextRegion, snapInRegion, fabricTexts, false, index);
        });

        // single items that only has snap in area withtou group rectangle
        singleTextRegionsOnLoad.forEach((fabricText: any) => {
            // find dedicated empty region if any
            const emptyTextRegion = gridTextRegions.find((textRegion: TextRegion) => {
                return textRegion.id === fabricText.ccTextRegion.snapTextRegionId;
            });
            let snapInRegion;
            if (!!emptyTextRegion) {
                snapInRegion = {
                    x: +emptyTextRegion.x,
                    y: +emptyTextRegion.y,
                    width: +emptyTextRegion.width,
                    height: +emptyTextRegion.height
                };

                fabricText.snapInRegion = snapInRegion; //just attach  snap in region
            }
        })
    }

    /** Load fonts and font blob files initially */
    loadFontsPng(setbackround?, isSizes?: boolean, isRefreshTab?: boolean): void {
        // retrieve rules from base template and apply them
        this.customiseMenuService.getTemplateStyleRuleByTemplateId(this.baseTemplateId, 0, this.security_token).subscribe((res: RestResponse) => {
            if (res.statusCode === 200) {
                this.customiseMenuPropertyService.templateStyleRule = res.instance;
                if (this.customiseMenuPropertyService.templateStyleRule) {
                    if (this.customiseMenuPropertyService.templateStyleRule.templateEditRule.uploadAllowed === '1') {
                        this.isUploadImagesEnable = true;
                    } else {
                        this.isUploadImagesEnable = false;
                    }
                }
            } else {
                console.log('Failed to retrieve template rules!');
            }
        });

        this.customiseMenuService.getFontPngOptions(this.baseTemplateId, this.security_token).subscribe((pngFonts) => {
            this.fontPngs = pngFonts.instance;
            /* Taken a letiable (obj) to incremented as per forloop executed and compare with fontPngs length to check all the data are loaded. */
            // TODO Ask shaun if there is no fonts file uploaded for that template can we make default font file ARIALUNI_ttf
            if (!this.fontPngs.length) {
                this.fontPngs.push({
                    name: "ARIALUNI.ttf",
                    value: "assets/fonts/ARIALUNI_ttf.png",
                    type: ""
                })
            }
            let obj = 1;
            this.fontPngs.forEach((font) => {
                const fontName = font.name.split('.')[0];
                this.customiseMenuService.getFont(`${fontName}`, this.security_token).then((res) => {
                    res = res === 'failed' ? 'assets/fonts/ARIALUNI.TTF' : res;
                    if (opentype) {
                        opentype.load(res, (err, fontRes) => {
                            if (err) {
                                console.error('Error loading font ', err);
                                return;
                            }
                            fontsArr[fontName] = {
                                obj: fontRes,
                                name: fontName
                            };
                        });
                        obj = obj + 1;
                        if (obj > this.fontPngs.length) {
                            this.loadArialUniFont();
                            if (setbackround) {
                                this.setBaseTamplateAndBackground(undefined, true, isSizes, isRefreshTab);
                            } else {
                                this.setBaseTamplateAndBackground(0, false, isSizes);
                            }
                        }
                    }
                });
            });

        });
        this.customiseMenuService.security_token = this.security_token;
    }

    /** Load default ARIALUNI font initially */
    loadArialUniFont() {
        this.fontPngs.push({
            'name': 'ARIALUNI.ttf',
            'value': 'assets/fonts/ARIALUNI_ttf.png',
            'type': ''
        });
    }

    /** Update modification of image */
    // updateModifications(savehistory, object) {
    //     if (savehistory === true && this.state.length <= 3) {
    //         const newObject = {
    //             src: object.getSrc(),
    //             left: object.left,
    //             top: object.top,
    //             originalURL: object.originalURL,
    //             cropperPosition: object.cropperPosition
    //         };
    //         if (JSON.stringify(newObject) !== JSON.stringify(this.state[this.state.length - 1])) {
    //             this.state.push(newObject);
    //         }
    //     }
    // }

    /** Undo feature of image */
    undo() {
        // const activeCanvasIndex = this.activeCanvasIndex;
        // const activeCanvas = this.canvas[activeCanvasIndex];
        // if (this.mods < this.state.length) {
        //     const state = this.state[this.state.length - 1 - this.mods - 1];
        //     if (!state) {
        //         return;
        //     }
        //     activeCanvas.remove(activeCanvas.getActiveObject());
        //     fabric.Image.fromURL(state.src, (img) => {
        //         img.set({
        //             type: 'image',
        //             scaleX: .25,
        //             scaleY: .25,
        //             crossOrigin: 'annonymous',
        //             lockScalingFlip: true,
        //             activeCanvasIndex: activeCanvasIndex,
        //             width: img._originalElement.naturalWidth,
        //             height: img._originalElement.naturalHeight,
        //             left: state.left,
        //             top: state.top
        //         });
        //         img.originalURL = state.originalURL;
        //         img.cropperPosition = state.cropperPosition;
        //         img.zoomScale = state.zoomScale;
        //         activeCanvas.add(img);
        //         activeCanvas.setActiveObject(img);
        //         activeCanvas.renderAll();
        //     }, {
        //         crossOrigin: 'annonymous'
        //     });
        //     this.state.splice(this.state.length - 1 - this.mods - 1, 1);
        //     this.mods += 1;
        // }
    }

    /** Redo feature of image */
    redo() {
        // const activeCanvasIndex = this.activeCanvasIndex;
        // const activeCanvas = this.canvas[activeCanvasIndex];
        // if (this.mods > 0) {
        //     const state = this.state[this.state.length - 1 - this.mods + 1];
        //     if (!state) {
        //         return;
        //     }
        //     activeCanvas.remove(activeCanvas.getActiveObject());
        //     fabric.Image.fromURL(state.src, (img) => {
        //         img.set({
        //             type: 'image',
        //             scaleX: .25,
        //             scaleY: .25,
        //             crossOrigin: 'annonymous',
        //             lockScalingFlip: true,
        //             activeCanvasIndex: activeCanvasIndex,
        //             width: img._originalElement.naturalWidth,
        //             height: img._originalElement.naturalHeight,
        //             left: state.left,
        //             top: state.top
        //         });
        //         img.originalURL = state.originalURL;
        //         img.cropperPosition = state.cropperPosition;
        //         img.zoomScale = state.zoomScale;
        //         activeCanvas.add(img);
        //         activeCanvas.setActiveObject(img);
        //         activeCanvas.renderAll();
        //     }, {
        //         crossOrigin: 'annonymous'
        //     });
        //     this.state.splice(this.state.length - 1 - this.mods + 1, 1);
        //     this.mods -= 1;
        // }
    }

    /** check intersecting of two text object */
    checkIntersectingObject(event, index: number, showRecTCross = true) {
        if (event && event.target) {
            event.target.setCoords();
            this.canvas[index].forEachObject((obj) => {
                let object = this.canvas[index].getActiveObject();
                if (!!object && !object.isCropBox) {   // this gives null in a few cases
                    if (obj === event.target) return;
                    if (obj.id && obj.id.includes('draggable-dots-') && showRecTCross) {
                        if (object.intersectsWithObject(obj)) {
                            this.showCrossInRect(obj.rectIndex, index, obj);
                        } else {
                            this.hideCrossLine(obj.rectIndex, index);
                        }
                    } else if (obj.id && obj.id.includes('draggable-imgdots-')) {
                        if (object.intersectsWithObject(obj)) {
                            // console.log('Intersect');
                        } else {

                        }
                    } else if (obj.text) {
                        if (object.intersectsWithObject(obj)) {
                            object.set('borderColor', 'red');
                            // this.displayToaster('warning', ['Objects are overlapping']);
                            setTimeout(() => {
                                object.set('borderColor', '#023cf7');
                            }, 300)
                        }
                    }
                }
            });
        }
    }

    checkIntersectingWaterMark(event, index: number) {
        if (event && event.target) {
            event.target.setCoords();
            this.canvas[index].forEachObject((obj) => {
                let object = this.canvas[index].getActiveObject();
                if (!!object && !object.isCropBox) {   // this gives null in a few cases
                    if (obj === event.target) return;
                    if (obj.isWaterMark) {
                        if (object.intersectsWithObject(obj)) {
                            const element = this.canvas[index].getActiveObject();
                            this.canvas[index].discardActiveObject();
                            element.setCoords();
                            this.canvas[index].calcOffset();
                            this.canvas[index].renderAll();
                            this.objectNotSelected = true;
                        }
                    }
                }
            });
        }
    }

    /** need to push away other elements to place target instance */
    prepShuffling(event: any, index: number) {
        event.target.setCoords();   //need to update coords
        // only consider relevant snapInRegion where this moving obj belongs to
        const snapInRegion = event.target.snapInRegion;
        if (!snapInRegion) {  // if there is no designated area, no need to worry
            return;
        }
        this.canvas[index].forEachObject((obj) => {
            if (obj !== event.target && (!obj.movedByShuffle /*|| obj.movedByShuffle !== direction*/)
                && !!obj.snapInRegion && obj.snapInRegion.x === snapInRegion.x && obj.snapInRegion.y === snapInRegion.y
                && (obj.isParent || obj.parent === '-1')/*no need to consider child text as passing obj*/
                && !!obj.id && obj.id.indexOf('draggable') === -1) {
                //obj.set('opacity', target.intersectsWithObject(obj) ? 0.1 : 0);
                // if it's moving upward top + height or else top - height

                if (event.target.intersectsWithObject(obj)) {
                    if (obj.aCoords.bl.y > event.target.aCoords.bl.y
                        && obj.aCoords.tl.y > event.target.aCoords.tl.y
                        && event.transform.ey/*event.transform.lastY*/ > event.pointer.y) { // moving upwards - moving obj top/bottom line is above passing opj & past y pointer is larger

                        // check if obj.top + event.target.height is overlap with any other object
                        const overlap = this.findOverlappingObjectOnNewPosition(obj, event.target, index, snapInRegion, 'up');
                        if (!overlap) {
                            obj.top = obj.top + event.target.height;
                            obj.movedByShuffle = true;//'up';

                            // also need to consider child instances if this obj is rectangle with child texts
                            this.setChildTextInRect(obj, 'up', event.target.height);
                            obj.setCoords();
                        }
                        this.canvas[index].requestRenderAll();

                    } else if (obj.aCoords.tl.y < event.target.aCoords.tl.y
                        && obj.aCoords.bl.y < event.target.aCoords.bl.y
                        && event.transform.ey/*event.transform.lastY*/ < event.pointer.y) { // moving downwards - moving obj top/bottom line is below passing opj & past y pointer is smaller

                        // check if obj.top - event.target.height is overlap with any other object
                        const overlap = this.findOverlappingObjectOnNewPosition(obj, event.target, index, snapInRegion, 'down');
                        if (!overlap) {
                            obj.top = obj.top - event.target.height;
                            obj.movedByShuffle = true;//'down';

                            // also need to consider child instances if this obj is rectangle with child texts
                            this.setChildTextInRect(obj, 'down', event.target.height);
                            obj.setCoords();
                        }
                        this.canvas[index].requestRenderAll();

                    } else {
                        obj.movedByShuffle = false; //'none';
                    }
                }
            }
        });
    }

    /** need to push away other elements to place target instance */
    rearrangeOverlappingObject(event: any, index: number) {
        event.target.setCoords();   //need to update coords
        // only consider relevant snapInRegion where this moving obj belongs to
        const snapInRegion = event.target.snapInRegion;
        if (!snapInRegion) {  // if there is no designated area, no need to worry
            return;
        }
        let justMovedObj = {newBottomLineY: -1, increase: 0, newTopLineY: -1};
        const eligibleObjects = [];
        this.canvas[index].forEachObject((obj) => {
            if (!!obj.id && obj.id !== event.target.id /*&& (!obj.movedByShuffle)*/
                && !!obj.snapInRegion && obj.snapInRegion.x === snapInRegion.x && obj.snapInRegion.y === snapInRegion.y
                && (obj.isParent || obj.parent === '-1')/*no need to consider child text as passing obj*/
                && obj.left >= 0 && obj.top >= 0 /* within canvas & exclude moving obj */
                && obj.id.indexOf('draggable') === -1) {

                //eligibleObjects.push(obj);  // get filtered items only for quick process

                let movement = 0;
                //!!! intersectsWithObject() might be called more than once when 1+ overlapping items exist
                if (event.target.intersectsWithObject(obj) /*&& justMovedObj.increase === 0*/) {
                    if (event.target.aCoords.tl.y <= obj.aCoords.tl.y && (event.target.aCoords.br.y >= obj.aCoords.tr.y && event.target.aCoords.br.y <= obj.aCoords.br.y)) { //bottom line inside another object
                        movement = event.target.aCoords.br.y - obj.aCoords.tr.y + 5;    // only overlapping height matters
                        if (justMovedObj.increase > movement) {
                            movement = justMovedObj.increase;
                            //justMovedObj.increase = justMovedObj.increase > movement ? justMovedObj.increase : movement;
                        } else {
                            justMovedObj.increase = movement;
                        }
                        //justMovedObj.increase = movement;

                    } else if (event.target.aCoords.br.y >= obj.aCoords.br.y && (event.target.aCoords.tl.y >= obj.aCoords.tl.y && event.target.aCoords.tl.y <= obj.aCoords.bl.y)) { //top line inside another object
                        movement = event.target.aCoords.br.y - obj.aCoords.tr.y + 5;
                        if (justMovedObj.increase > movement) {
                            movement = justMovedObj.increase;
                            //justMovedObj.increase = justMovedObj.increase > movement ? justMovedObj.increase : movement;
                        } else {
                            justMovedObj.increase = movement;
                        }
                        //justMovedObj.increase = movement; //obj.height;

                    } else if ((event.target.aCoords.tl.y >= obj.aCoords.tl.y && event.target.aCoords.tl.y <= obj.aCoords.bl.y)
                        && (event.target.aCoords.br.y >= obj.aCoords.tr.y && event.target.aCoords.br.y <= obj.aCoords.br.y)) {    // smaller than another object - inside another object
                        movement = event.target.aCoords.br.y - obj.aCoords.tl.y; //obj.aCoords.br.y - event.target.aCoords.tl.y + 5;
                        //justMovedObj.increase = justMovedObj.increase > movement ? justMovedObj.increase : movement;
                        justMovedObj.increase = movement;

                    } else if ((obj.aCoords.tl.y >= event.target.aCoords.tl.y && obj.aCoords.tl.y <= event.target.aCoords.bl.y)
                        && (obj.aCoords.br.y >= event.target.aCoords.tr.y && obj.aCoords.br.y <= event.target.aCoords.br.y)) {    // way bigger than another object - another obj is inside moving obj
                        movement = event.target.aCoords.br.y - obj.aCoords.tl.y;
                        if (justMovedObj.increase > movement) {
                            movement = justMovedObj.increase;
                            //justMovedObj.increase = justMovedObj.increase > movement ? justMovedObj.increase : movement;
                        } else {
                            justMovedObj.increase = movement;
                        }
                        //justMovedObj.increase = movement;

                    } //NOTE it looks like intersectsWithObject() is fired when it's not overlapping at all, maybe captured from transition

                    if (movement > 0) {
                        obj.top = obj.top + movement;
                        this.setChildTextInRect(obj, 'up', movement);      //send it downward
                        obj.setCoords();
                        this.canvas[index].requestRenderAll();

                        justMovedObj.newTopLineY = event.target.aCoords.tl.y; //obj.aCoords.tl.y;   //consider moving obj to cover those cases when multiple items overlapped
                        justMovedObj.newBottomLineY = obj.aCoords.br.y;
                    }

                } else {
                    eligibleObjects.push(obj);  // get filtered items without justMovedObject
                }
            }
        });

        // need to push down objects recursively - this has issue with different sized items
        /*while ( justMovedObj.newBottomLineY > -1 && justMovedObj.increase > 0 ) {
            justMovedObj = this.moveOverlappingObjectRecursively(eligibleObjects, justMovedObj.newBottomLineY, justMovedObj.increase, justMovedObj.newTopLineY);
        }*/

        // or just simply move all items below bottomline
        if (justMovedObj.newBottomLineY > -1 && justMovedObj.increase > 0) {
            this.shiftDownItems(eligibleObjects, justMovedObj.newBottomLineY, justMovedObj.increase, justMovedObj.newTopLineY);
        }
    }

    /** find an overlapping object and move it downward */
    moveOverlappingObjectRecursively(tempObjects: any, bottomLineY: number, increase: number, topLineY: number) {
        let movedObj = {newBottomLineY: -1, increase: 0, newTopLineY: -1};
        for (let obj of tempObjects) {
            if ((obj.aCoords.tl.y < bottomLineY && obj.aCoords.br.y > bottomLineY)
                || (obj.aCoords.tl.y < topLineY && obj.aCoords.br.y > topLineY && bottomLineY > obj.aCoords.br.y)
                || (obj.aCoords.tl.y > topLineY && obj.aCoords.br.y < bottomLineY)) {     // bottom line inside obj OR top line inside obj
                obj.top = obj.top + increase;
                this.setChildTextInRect(obj, 'up', increase);      //send it downward
                obj.setCoords();
                obj.canvas.requestRenderAll();

                movedObj.newTopLineY = obj.aCoords.tl.y;
                movedObj.newBottomLineY = obj.aCoords.br.y;
                movedObj.increase = obj.height;

                break;
            }
        }
        return movedObj;
    }

    /** move items downward below certain y position */
    shiftDownItems(tempObjects: any, bottomLineY: number, increase: number, topLineY: number) {
        let shiftDown = false;
        for (let obj of tempObjects) {
            shiftDown = false;
            // below, topline/bottomline inside obj or inside moving object
            // each case stated for clarity and debugging purpose
            if (obj.aCoords.br.y > bottomLineY) {
                shiftDown = true;
            } else if ((obj.aCoords.tl.y >= topLineY && obj.aCoords.tl.y <= bottomLineY) && (obj.aCoords.br.y >= topLineY && obj.aCoords.br.y <= bottomLineY)) {
                shiftDown = true;
            } else if (bottomLineY >= obj.aCoords.br.y && (topLineY >= obj.aCoords.tl.y && topLineY <= obj.aCoords.bl.y)) {   //top line inside
                shiftDown = true;
                increase = increase + obj.height; //bottomLineY - topLineY;
            } else if (topLineY <= obj.aCoords.tl.y && (bottomLineY >= obj.aCoords.tr.y && bottomLineY <= obj.aCoords.br.y)) {    //bottom line inside
                shiftDown = true;
            }

            if (shiftDown) {
                obj.top = obj.top + increase;
                this.setChildTextInRect(obj, 'up', increase);      //send it downward
                obj.setCoords();
                obj.canvas.requestRenderAll();
            }
        }
    }


    /** check if item is overlapping with another one after pushed to new position */
    findOverlappingObjectOnNewPosition(obj: any, movingObj: any, index: number, snapInRegion: any, action: string) {
        return this.canvas[index].getObjects().find((objOther: any) => {
            if (!!objOther.id && objOther.id.indexOf('draggable') === -1
                && objOther !== movingObj && obj !== objOther
                && !!objOther.snapInRegion && objOther.snapInRegion.x === snapInRegion.x && objOther.snapInRegion.y === snapInRegion.y
                && obj.left >= 0 && obj.top >= 0) { /* within canvas & exclude moving obj */
                // // console.log('action: ' + action);
                if ((action === 'up'
                    && (objOther.aCoords.tl.y < (obj.top + movingObj.height)
                        && objOther.aCoords.bl.y > (obj.top + movingObj.height)))    //top or bottom is inside another object when going up?
                    ||
                    (action === 'down'
                        && objOther.aCoords.tl.y < (obj.top - movingObj.height)
                        && objOther.aCoords.bl.y > (obj.top - movingObj.height))) {    //top or bottom is inside another object when going down?
                    // // console.log(objOther);
                    return objOther;
                }
            }
        });
    }

    /** refresh child text position in group rect */
    setChildTextInRect(rect: any, direction: string, targetHeight: number) {
        // also need to consider child instances if this obj is rectangle with child texts
        if (rect.isParent && rect.type === 'rect') {
            rect.canvas._objects.map(child => {
                if (!!child.parent && child.parent === rect.id) {
                    //// console.log(direction + ' child: ' + child.text);
                    if (direction === 'up') {
                        child.top = child.top + targetHeight;
                    } else {    //down
                        child.top = child.top - targetHeight;
                    }
                    child.movedByShuffle = true;//direction;
                    child.setCoords();
                }
            });
        }
    }

    /** Scaling of entire canvas and its objects */
    setScale() {
        if (this.selectedScale !== 'Fit') {
            this.scaleFactor = Number(this.selectedScale) / 100;
            this.canvas.forEach((canvas: any, index) => {
                this.canvas[index].setDimensions({
                    width: Number(this.canvas[index].originalCanvasWidth * this.scaleFactor),
                    height: Number(this.canvas[index].originalCanvasHeight * this.scaleFactor)
                });

                this.canvas[index].setZoom(this.scaleFactor);

                if (this.canvas[index].backgroundImage) {
                    // Need to scale background images as well
                    const bi = this.canvas[index];
                    bi.width = bi.originalBackgroundImageWidth * this.scaleFactor;
                    bi.height = bi.originalBackgroundImageHeight * this.scaleFactor;
                }
                this.canvas[index].getObjects().forEach(el => {
                    el.setCoords();
                });
                this.canvas[index].renderAll();
                this.canvas[index].calcOffset();
            });
        } else {
            this.canvas.forEach((canvas: any, index) => {
                this.scaleFactor = ((window.innerHeight - 200) * 100 / this.canvas[index].originalCanvasHeight) / 100;
                this.canvas[index].setDimensions({
                    width: Number(this.canvas[index].originalCanvasWidth * this.scaleFactor),
                    height: Number(this.canvas[index].originalCanvasHeight * this.scaleFactor)
                });

                this.canvas[index].setZoom(this.scaleFactor);

                if (this.canvas[index].backgroundImage) {
                    // Need to scale background images as well
                    const bi = this.canvas[index];
                    bi.width = bi.originalBackgroundImageWidth * this.scaleFactor;
                    bi.height = bi.originalBackgroundImageHeight * this.scaleFactor;
                }
                this.canvas[index].getObjects().forEach(el => {
                    el.setCoords();
                });
                this.canvas[index].renderAll();
                this.canvas[index].calcOffset();
            });
        }

    }

    /** Handled scrolling of window */
    onMouseWheel(): void {
        this.canvas.forEach((canvas, index) => {
            const elem = canvas.lowerCanvasEl;
            const position = elem.getBoundingClientRect();
            let top = position.top;
            if (position.height < window.innerHeight) {
                top = position.top + (window.innerHeight - position.height)
            }
            if (top <= window.innerHeight && position.bottom >= 0) {
                this.activeCanvasIndex = index;
            }
        });
    }

    /** Switch tab view */
    switchView(viewName: string) {
        if (this.currentView === viewName) {
            $('.editor-area').removeClass('canvas-alignment');
            this.currentView = '';
        } else {
            $('.editor-area').addClass('canvas-alignment');
            this.currentView = viewName;
        }
        if (this.currentView === 'background') {
            return;
        }
        setTimeout(() => {
            if (!!this.currentView) {
                this.draggableBg(viewName, !!this.currentView);
            }
        }, 100, this);

    }

    /** create login fields to register */
    buildLoginFieldsFromQueryParmas() {
        let captured = /commerceParameters=([^&]+)/.exec(this.locationService.path())[1];
        captured = captured.replace(/%3D/g, '='); // need to replace url excape char with =
        captured = captured.replace(/%2F/g, '/');
        // // console.log(captured);
        const queryParams = atob(captured);
        // // console.log(queryParams);

        this.loginFields = new RestLoginFields();
        // post back details
        this.loginFields.customiseReferrer = CustomiseMenuComponent.getParamValue('customiseReferrer', queryParams);
        this.loginFields.source = CustomiseMenuComponent.getParamValue('source', queryParams);
        this.loginFields.errorURL = CustomiseMenuComponent.getParamValue('errorURL', queryParams);
        this.loginFields.templateID = CustomiseMenuComponent.getParamValue('templateID', queryParams);
        this.loginFields.jTemplateID = CustomiseMenuComponent.getParamValue('jTemplateID', queryParams);
        // user details
        this.loginFields.username = CustomiseMenuComponent.getParamValue('username', queryParams);
        this.loginFields.name = CustomiseMenuComponent.getParamValue('name', queryParams);
        if (!this.loginFields.name) {
            this.loginFields.name = this.loginFields.username;
        }
        this.loginFields.email = CustomiseMenuComponent.getParamValue('email', queryParams);
        this.loginFields.country = CustomiseMenuComponent.getParamValue('country', queryParams);
        this.loginFields.department = CustomiseMenuComponent.getParamValue('department', queryParams);
        this.loginFields.division = CustomiseMenuComponent.getParamValue('division', queryParams);
        this.loginFields.mail = CustomiseMenuComponent.getParamValue('mail', queryParams);
        this.loginFields.state = CustomiseMenuComponent.getParamValue('state', queryParams);
        this.loginFields.mobile = CustomiseMenuComponent.getParamValue('mobile', queryParams);
        this.loginFields.phone = CustomiseMenuComponent.getParamValue('phone', queryParams);
        this.loginFields.telephoneNumber = CustomiseMenuComponent.getParamValue('telephoneNumber', queryParams);
        this.loginFields.postalCode = CustomiseMenuComponent.getParamValue('postalCode', queryParams);
        this.loginFields.postcode = CustomiseMenuComponent.getParamValue('postcode', queryParams);
        this.loginFields.streetAddress = CustomiseMenuComponent.getParamValue('streetAddress', queryParams);
        this.loginFields.address1 = CustomiseMenuComponent.getParamValue('address1', queryParams);
        this.loginFields.address2 = CustomiseMenuComponent.getParamValue('address2', queryParams);
        this.loginFields.address3 = CustomiseMenuComponent.getParamValue('address3', queryParams);
    }

    /** It will change design of canvas */
    onSelectDesign(thumb: any): void {
        /* If isCanvasChanged flag is true then only it show warning */
        if (this.isCanvasChanged) {
            let title;
            let text;
            let labelConfirm;
            let labelCancel;
            this.translate.get('label.ReplaceDesign').subscribe((res: string) => {
                title = res;
            });
            this.translate.get('message.ReplaceDesignWarning').subscribe((res: string) => {
                text = res;
            });
            this.translate.get('label.Replace').subscribe((res: string) => {
                labelConfirm = res;
            });
            this.translate.get('label.DontReplace').subscribe((res: string) => {
                labelCancel = res;
            });
            this.swal({
                title: title,
                text: text,
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: labelCancel,
                confirmButtonText: labelConfirm
            }).then((result) => {
                if (result.value) {
                    this.isCanvasChanged = false;
                    this.loginFields.templateID = thumb.name;
                    this.canvas = [];
                    this.grids = [];
                    this.imageRegions = [];
                    this.createNewJobTemplate(false);
                    this.spinner = true;
                    this.objectNotSelected = true;
                    this.isCropMode = false;
                    this.gridTextRegionsByGrid = [];
                    this.activeObject = undefined;
                }
            });
        } else {
            this.isCanvasChanged = false;
            if (!this.loginFields) {
                this.loginFields = {username: this.username}
            }
            this.loginFields.templateID = thumb.name;
            this.canvas = [];
            this.grids = [];
            this.imageRegions = [];
            this.createNewJobTemplate(false);
            this.spinner = true;
            this.objectNotSelected = true;
            this.isCropMode = false;
            this.gridTextRegionsByGrid = [];
            this.activeObject = undefined;
        }
    }

    /**
     * Bind drag and drop events to object and canvas
     * @param viewId
     * @param add
     */
    draggableBg(viewId, add): void {
        $('.canvas-container').each((index) => {
            // let img = new Image();
            // img.src = 'assets/images/icon-image-128.png';

            const handleDragStart = (e) => {
                [].forEach.call(draggableBlocks, (draggableBlock) => {
                    draggableBlock.classList.remove('block_dragging');
                });
                this.activeImageRegionHover = undefined;
                e.dataTransfer.setData('sourceId', e.currentTarget.id);
                e.currentTarget.style.opacity = '0.3';

                if (this.currentView === 'imagetab') {
                    e.dataTransfer.setDragImage(e.target, 0, 0);
                }
            };

            const handleDragOver = (e) => {
                if (e.preventDefault) {
                    e.preventDefault();
                }
                e.dataTransfer.dropEffect = 'copy';

                const draggableBlocks = document.querySelectorAll('#' + this.currentView + ' .draggable-block');

                [].forEach.call(draggableBlocks, (draggableBlock) => {
                    draggableBlock.style.opacity = '1';
                });
                if (e.currentTarget.offsetParent.querySelector('canvas')) {
                    const canvasIndex = e.currentTarget.offsetParent.querySelector('canvas').id.split('_')[1];
                    this.activeCanvasIndex = Number(canvasIndex) - 1;
                }

                if (this.currentView === 'background') { // #6637
                    return;
                }

                const HideControls = {
                    'tl': true,
                    'tr': true,
                    'bl': true,
                    'br': true,
                    'ml': false,
                    'mt': false,
                    'mr': false,
                    'mb': false,
                    'mtr': false
                };
                let showLines = true;
                this.gridTextRegionsByGrid[this.activeCanvasIndex].forEach((textRegion, index) => {
                    if (textRegion.textBlocks) {
                        return;
                    }
                    const checkPos = (textRegion): boolean => {
                        const canvas = this.canvas[this.activeCanvasIndex];
                        const pointer = canvas.getPointer(e, false);
                        const posX = pointer.x;
                        const posY = pointer.y;
                        //return posX >= Number(textRegion.x) && posX <= Number(textRegion.width) && posY >= Number(textRegion.y) && posY <= Number(textRegion.height);
                        // need to consider relevant area
                        return posX >= +textRegion.x && posX <= +textRegion.x + +textRegion.width && posY >= +textRegion.y && posY <= +textRegion.y + +textRegion.height;

                    };
                    if (checkPos(textRegion)) {
                        this.activeTextRegionHover = textRegion;
                    }
                    const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-dots-' + index});
                    if (!!rectObject) {
                        rectObject.visible = true;
                        showLines = false;
                    } else {
                        if (!textRegion.textBlocks) {
                            showLines = false;
                            const rect = this.createDottedArea(index, textRegion);
                            rect.setControlsVisibility(HideControls);
                            this.canvas[this.activeCanvasIndex].add(rect);
                        }
                    }
                });
                if (showLines) {
                    this.showCrossLine(this.activeCanvasIndex);
                }
                const imageRegions = _.find(this.imageRegions, {index: this.activeCanvasIndex});
                Object.keys(imageRegions.res).forEach((key) => {
                    const xmlImages = imageRegions.res[key] as XmlImage[];  // get xmlImage instance

                    if (!xmlImages.length) {
                        return;
                    }
                    this.activeImageRegionHover = undefined;
                    xmlImages.forEach((xmlImage, imgIndex) => {
                        if (xmlImage.vfield[0].xmlId) {
                            return;
                        }
                        const checkPos = (xmlImageObj): boolean => {
                            const canvas = this.canvas[this.activeCanvasIndex];
                            const pointer = canvas.getPointer(e, false);
                            const posX = pointer.x;
                            const posY = pointer.y;
                            //return posX >= Number(textRegion.x) && posX <= Number(textRegion.width) && posY >= Number(textRegion.y) && posY <= Number(textRegion.height);
                            // need to consider relevant area
                            return (posX >= +xmlImageObj.x && posX <= +xmlImageObj.x + +xmlImageObj.width && posY >= +xmlImageObj.y && posY <= +xmlImageObj.y + +xmlImageObj.height) || (+xmlImageObj.x >= posX && +xmlImageObj.x + +xmlImageObj.width <= posX && +xmlImageObj.y >= posY && +xmlImageObj.y + +xmlImageObj.height <= posY);

                        };
                        if (checkPos(xmlImage)) {
                            this.activeImageRegionHover = xmlImage;
                            // const imageRegion = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-imgdots-' + imgIndex,regionId: this.activeImageRegionHover.id});
                            // if(imageRegion) {
                            //     imageRegion.set({stroke: 'Red'});
                            //     this.canvas[this.activeCanvasIndex].renderAll();
                            // }
                            this.activeImageRegionHover.imgIndex = imgIndex;
                        }
                        const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-imgdots-' + imgIndex});
                        if (!!rectObject) {
                            rectObject.visible = true;
                        } else {
                            const rect = this.createImgDottedArea(imgIndex, xmlImage);
                            rect.setControlsVisibility(HideControls);
                            this.canvas[this.activeCanvasIndex].add(rect);
                        }
                    });
                    // Check is image is placed inside which Imgage Region. If image region is there it will change stroke color to red.
                    this.canvas[index].getObjects().forEach(data => {
                        if (this.activeImageRegionHover && data.id && data.id.includes('draggable-imgdots-') && data.regionId && (data.regionId === this.activeImageRegionHover.id)) {
                            data.set({stroke: 'Red'});
                        } else if (data.id && data.id.includes('draggable-imgdots-')) {
                            data.set({stroke: 'orange'});
                        }
                    })

                });


                this.canvas[this.activeCanvasIndex].renderAll();

                return false;
            };

            const handleDragEnter = () => {
            };

            const handleDragLeave = () => {
                this.hideLine(this.activeCanvasIndex);


                this.canvas[this.activeCanvasIndex].renderAll();

                this.activeTextRegionHover = undefined;
                this.activeTextObject = undefined

            };

            // when image or text style is dropped onto canvas
            const handleDrop = (e) => {
                e = e || window.event;
                if (e.preventDefault) {
                    e.preventDefault();
                }
                if (e.stopPropagation) {
                    e.stopPropagation();
                }
                const requiredObjs = this.canvas[this.activeCanvasIndex].getObjects('textboundry');
                this.hideLine(this.activeCanvasIndex);
                this.gridTextRegionsByGrid[this.activeCanvasIndex].forEach((textRegion, index) => {
                    const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-dots-' + index});
                    if (!!rectObject) {
                        rectObject.visible = false;
                    }
                });

                const imageRegions = _.find(this.imageRegions, {index: this.activeCanvasIndex});
                Object.keys(imageRegions.res).forEach((key) => {
                    const xmlImages = imageRegions.res[key] as XmlImage[];  // get xmlImage instance
                    if (!xmlImages.length) {
                        return;
                    }
                    xmlImages.forEach((xmlImage, imgIndex) => {
                        const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-imgdots-' + imgIndex});
                        if (!!rectObject) {
                            rectObject.visible = false;
                        }
                    });
                });

                this.canvas[this.activeCanvasIndex].renderAll();

                if (e.currentTarget.offsetParent.querySelector('canvas')) {
                    const canvasIndex = e.currentTarget.offsetParent.querySelector('canvas').id.split('_')[1];
                    this.activeCanvasIndex = Number(canvasIndex) - 1;
                }

                // const scalefactor = this.selectedScale !== 'Fit' ? Number(this.selectedScale) / 100 : ((window.innerHeight - 200) * 100 / this.canvas[this.activeCanvasIndex].originalCanvasHeight) / 100;

                const source = e.dataTransfer.getData('sourceId');
                const x = e.layerX / this.scaleFactor;
                const y = e.layerY / this.scaleFactor;
                if (this.currentView === 'texteditor') {

                    const self = this;
                    const index = source.split('_')[1];

                    if (this.activeTextRegionHover) {
                        this.activeTextRegionHover.top = Number(this.activeTextRegionHover.y) + (requiredObjs.length * 60);
                    }
                    if (!index) {
                        const sourceElement = document.getElementById(source);
                        let object = JSON.parse(sourceElement.getAttribute('data'));
                        this.addTextRegion(object, +x, +y);
                    } else {
                        this.lastEmptyTextRegion = this.activeTextRegionHover;
                        self.placeTextRegionsForSelectedStyle(index, this.activeTextRegionHover || {});
                    }
                }
                if (this.currentView === 'imagetab') {
                    const img: any = document.querySelector('#' + this.currentView + ' #' + source + ' img');
                    const activeCanvas = this.canvas[this.activeCanvasIndex];
                    // activeCanvas.hoverCursor = 'wait';
                    this.grids[this.activeCanvasIndex].showLoader = true;

                    this.fabricImgCmp({
                        src: img.src,
                        activeCanvasIndex: this.activeCanvasIndex,
                        left: x,
                        top: y,
                        originalURL: img.src,
                        assetId: img.getAttribute('assetid'),
                        asset: JSON.parse(img.getAttribute('asset'))
                    }, (img) => {
                        img.firstDrop = true;
                        activeCanvas.setActiveObject(img);
                        this.lastSelectedObject = activeCanvas.getActiveObject();
                    });

                    // cancel any cropping operation
                    this.cancelCrop();
                }

                if (this.currentView === 'background') {
                    const imgEl: any = document.querySelector('#' + this.currentView + ' #' + source + ' img');
                    const activeCanvas = this.canvas[this.activeCanvasIndex];
                    const asset = JSON.parse(imgEl.getAttribute('asset'));
                    this.grids[this.activeCanvasIndex].showLoader = true;

                    this.customiseMenuService.swapJobGridBackgrond(this.jTemplateId, this.activeCanvasIndex + 1, asset.assetID, asset.catalogue, this.security_token).subscribe((res: any) => {
                        fabric.Image.fromURL(res.instance + '?t=' + new Date() || imgEl.src + '?t=' + new Date(), img => {
                            img.set({
                                activeCanvasIndex: this.activeCanvasIndex
                            });

                            // activeCanvas.width is not true value
                            //const background = img.scaleToWidth(+activeCanvas.width, false);
                            const background = img.scaleToWidth(+activeCanvas.originalCanvasWidth, false);

                            // digital templates need to use left bottom corner in order to be compatible with pdf output on RESIZE - background pdf is big enough to cover different types
                            if (this.customiseMenuSharedService.isDigital(+activeCanvas.originalCanvasWidth, +activeCanvas.originalCanvasHeight)) {
                                //!!! top value must be adjusted to grid height
                                background.set({
                                    originX: 'left',
                                    originY: 'bottom',
                                    top: +activeCanvas.originalCanvasHeight
                                });
                            }

                            activeCanvas.setBackgroundImage(background, el => {
                                activeCanvas.renderAll();
                                this.grids[this.activeCanvasIndex].showLoader = false;
                            });
                        });
                    });

                    // this.swal({
                    //     title: 'Change Background',
                    //     text: 'It will change current menu backgound image with new one.',
                    //     type: 'warning',
                    //     showCancelButton: true,
                    //     confirmButtonColor: '#3085d6',
                    //     cancelButtonColor: '#d33',
                    //     cancelButtonText: 'No',
                    //     confirmButtonText: 'Yes'
                    // }).then((result) => {
                    //     if (result.value) {
                    //         this.customiseMenuService.swapJobGridBackgrond(this.jTemplateId, this.activeCanvasIndex + 1, asset.assetID, asset.catalogue, this.security_token).subscribe((res: any) => {
                    //             fabric.Image.fromURL(res.instance || imgEl.src, img => {
                    //                 img.set({
                    //                     activeCanvasIndex: this.activeCanvasIndex
                    //                 });
                    //                 const background = img.scaleToWidth(+activeCanvas.width, false);
                    //
                    //                 activeCanvas.setBackgroundImage(background, el => {
                    //                     activeCanvas.renderAll();
                    //                     this.spinner = false;
                    //                 });
                    //             });
                    //         });
                    //     } else {
                    //         this.spinner = false;
                    //     }
                    // });
                }

                this.activeTextRegionHover = undefined;
                return false;
            };

            const handleDragEnd = (e) => {

                [].forEach.call(draggableBlocks, (draggableBlock) => {
                    draggableBlock.classList.remove('img_dragging');
                });
                e.currentTarget.style.opacity = '1';
            };

            const canvasContainer = $(this)[0];

            const draggableBlocks = document.querySelectorAll('#' + this.currentView + ' .draggable-block');
            [].forEach.call(draggableBlocks, (draggableBlock) => {
                draggableBlock[add ? 'addEventListener' : 'removeEventListener']('dragstart', handleDragStart, false);
                draggableBlock[add ? 'addEventListener' : 'removeEventListener']('dragend', handleDragEnd, false);
            });

            if (canvasContainer.canvas[index] && canvasContainer.canvas[index].wrapperEl.eventListeners().length <= 1) {
                canvasContainer.canvas[index].wrapperEl[add ? 'addEventListener' : 'removeEventListener']('dragenter', handleDragEnter, this);
                canvasContainer.canvas[index].wrapperEl[add ? 'addEventListener' : 'removeEventListener']('dragover', handleDragOver, this);
                canvasContainer.canvas[index].wrapperEl[add ? 'addEventListener' : 'removeEventListener']('dragleave', handleDragLeave, this);
                canvasContainer.canvas[index].wrapperEl[add ? 'addEventListener' : 'removeEventListener']('drop', handleDrop, true, this);
            }

        }, this);
    }

    /** Change current image object image src */
    replaceCurrentImage(imageData: any): void {
        const activeCanvasIndex = this.activeCanvasIndex;
        const activeCanvas = this.canvas[activeCanvasIndex];
        const selectedObj = activeCanvas.getActiveObject();

        // activeCanvas.remove(selectedObj);
        //
        // this.fabricImgCmp({
        //     src: imageData.assetThumbnailPath,
        //     activeCanvasIndex: activeCanvasIndex,
        //     left: selectedObj.left,
        //     top: selectedObj.top,
        //     originalURL: imageData.assetThumbnailPath,
        //     assetId: imageData.assetID,
        //     asset: JSON.parse(imageData.asset),
        //     zoomScale: selectedObj.zoomScale
        // }, (img) => {
        //     activeCanvas.setActiveObject(img);
        // });

        const current_width = selectedObj.width;
        const current_height = selectedObj.height;

        selectedObj.setSrc(imageData.assetThumbnailPath, (img) => {
            // selectedObj.set({
            //     width: Number(+current_width),
            //     height: Number(+current_height)
            // });
            selectedObj.set({
                width: Number(+JSON.parse(imageData.asset).width),
                height: Number(+JSON.parse(imageData.asset).height)
            });
            selectedObj.scale(selectedObj.zoomScale);
            // selectedObj.set({
            //     width: Number(+current_width),
            //     height: Number(+current_height)
            // });
            selectedObj.originalURL = imageData.assetThumbnailPath;
            selectedObj.assetId = imageData.assetID;
            selectedObj.asset = JSON.parse(imageData.asset);
            activeCanvas.setActiveObject(img);
            this.lastSelectedObject = activeCanvas.getActiveObject();
            activeCanvas.renderAll();
            this.imageDataOps(selectedObj, 'update');
        });

        // activeCanvas.remove(selectedObj);
        // fabric.Image.fromURL(imageData.assetThumbnailPath, function (img) {
        //     img.set({
        //         type: 'image',
        //         scaleX: selectedObj.scaleX,
        //         scaleY: selectedObj.scaleY,
        //         crossOrigin: 'annonymous',
        //         activeCanvasIndex: activeCanvasIndex,
        //         width: img._originalElement.naturalWidth,
        //         height: img._originalElement.naturalHeight,
        //         left: selectedObj.left,
        //         top: selectedObj.top
        //     });
        //     img.originalURL = imageData.assetThumbnailPath;
        //     img.assetId = imageData.assetID;
        //     img.asset = imageData.asset;
        //     activeCanvas.add(img);
        //     activeCanvas.setActiveObject(img);
        //     this.lastSelectedObject = activeCanvas.getActiveObject();
        //     activeCanvas.renderAll();
        // }, {
        //     crossOrigin: 'annonymous'
        // });
    }

    /** Submitted cropped image is handled by this function */  //TODO remove
    cropEventHandler(croppedImage: any): void {
        const activeCanvas = this.canvas[this.activeCanvasIndex];
        const selectedObj = this.lastSelectedObject;
        const activeCanvasIndex = this.activeCanvasIndex;
        const rectObjects = _.filter(this.canvas[this.activeCanvasIndex].getObjects(), {type: 'image'});

        // TODO delete removal code
        /*rectObjects.forEach((obj) => {
            if (obj._originalElement.src === croppedImage.originalURL) {
                activeCanvas.remove(obj);
            }
        });
        activeCanvas.remove(selectedObj);*/

        // update matching image
        /*selectedObj.setSrc(croppedImage.base64, (img: any) => {
            img.set({
                activeCanvasIndex: activeCanvasIndex,
                width: croppedImage.width * croppedImage.zoomScale,     // use original size and apply scaling for whole image
                height: croppedImage.heigth * croppedImage.zoomScale,
                cropperPosition: croppedImage.cropperPosition,
                zoomScale: croppedImage.zoomScale     // this should be applied on crop window
            });
            img.scale(croppedImage.zoomScale);
            activeCanvas.renderAll();
        });*/

        selectedObj.cloneAsImage((clone: any) => {

            // // console.log('cloned object');
            // // console.log(clone);


            clone.set({
                type: 'image',
                crossOrigin: 'annonymous',
                lockScalingFlip: true,
                activeCanvasIndex: activeCanvasIndex,
                width: 50,     // use original size and apply scaling for whole image
                height: 50,
                left: selectedObj.left,
                top: selectedObj.top,
                originalURL: selectedObj.originalURL,
                cropperPosition: selectedObj.cropperPosition,
                zoomScale: selectedObj.scaleX,
                assetId: selectedObj.assetId,
                asset: selectedObj.asset,
                ccImage: selectedObj.ccImage
            });
            clone.setControlsVisibility({     // keep resize handles on 4 corners only to keep ratio
                mb: false, ml: false, mr: false, mt: false
            });
            clone.scale(selectedObj.scaleX);
            activeCanvas.add(clone).renderAll();

        }, {
            multiplier: 1,
            left: 0,	//Cropping left offset
            top: 0,   //Cropping top offset
            width: 50,   //Cropping width
            height: 50,  //Cropping height
        });


        /*this.fabricImgCmp({
            src: croppedImage.base64,
            activeCanvasIndex: activeCanvasIndex,
            left: selectedObj.left,
            top: selectedObj.top,
            originalURL: croppedImage.originalURL,
            assetId: croppedImage.assetId,
            asset: croppedImage.asset,
            cropperPosition: croppedImage.cropperPosition,
            zoomScale: croppedImage.zoomScale
        }, (img) => {
            activeCanvas.setActiveObject(img);
        });*/
    }

    lastActiveImageOpacity;

    /** Remove unnecessary cropbox before putting new one*/
    removeExtraCropBoxes(): void {
        this.canvas.forEach((canEl) => {
            const cropBox = canEl.getObjects().find((obj: any) => {
                if (!!obj.ccImageId && obj.isCropBox) {
                    return obj;
                }
            });

            if (cropBox) {
                canEl.remove(cropBox);
            }
        });
    }

    /** place rect on top of image that needs to be cropped */
    placeCropBoxOnImage() {
        this.isCropMode = true;

        // if imagebounds position is minus and scaled image size is not the same as original, it is cropped image
        const isCroppedImage = this.checkAlreadyCroppedImage(this.lastSelectedObject);
        const activeObj = this.canvas[this.activeCanvasIndex].getActiveObject();

        this.removeExtraCropBoxes();

        let cropRect;
        if (isCroppedImage) {
            // 1. hide the subject image
            activeObj.visible = false;

            // 2. need to add Original image to crop from again
            this.fabricImgCmp({
                src: activeObj.originalURL,
                activeCanvasIndex: this.activeCanvasIndex,
                left: +activeObj.left + +activeObj.ccImage.vfield[0].imagebounds.x,
                top: +activeObj.top + +activeObj.ccImage.vfield[0].imagebounds.y,
                originalURL: activeObj.originalURL,
                assetId: activeObj.assetId,
                asset: activeObj.asset,
                angle: activeObj.ccImage.angle,
                noNeedToSubmit: true      // flag not to add this image to backend on object:added event
            }, (img) => {
                img.ccImage = activeObj.ccImage;
                img.setControlsVisibility({mtr: false});        //angle change is not allowed
                img.scale(activeObj.zoomScale);

                // 3. then place crop box with same size as cropped image
                cropRect = new fabric.Rect({
                    // selected image's location & size
                    left: activeObj.left,
                    top: activeObj.top,
                    width: activeObj.width / activeObj.zoomScale,
                    height: activeObj.height / activeObj.zoomScale,
                    lockScalingFlip: true,
                    //opacity: 0, //0.1,
                    fill: 'rgba(135,206,250, 0.2)',
                    borderColor: 'rgba(0, 0, 255, 0.6)',
                    transparentCorners: true,
                    //lockMovementX: true,  // prevent it from moving by itself
                    //lockMovementY: true,  // prevent it from moving by itself
                    centeredScaling: false, // need to be extended to the selected direction only
                    angle: activeObj.angle,
                    isCropBox: true,
                    ccImageId: activeObj.ccImage.id   // id to bind this crop box to parent image
                });
                cropRect.scale(this.lastSelectedObject.zoomScale);
                cropRect.setControlsVisibility({mtr: false});

                // make original image as active
                this.lastSelectedObject = img;

                this.canvas[this.activeCanvasIndex].add(cropRect);
                // need to bind crop box to original image
                this.bindImageAndCropBox(cropRect, this.activeCanvasIndex, img);

                this.canvas[this.activeCanvasIndex].bringForward(cropRect);
                this.canvas[this.activeCanvasIndex].bringToFront(cropRect);
                this.canvas[this.activeCanvasIndex].renderAll();

                this.canvas[this.activeCanvasIndex].setActiveObject(cropRect);
            });

        } else {
            cropRect = new fabric.Rect({
                // selected image's location & size
                left: activeObj.left,
                top: activeObj.top,
                width: activeObj.width * activeObj.zoomScale,
                height: activeObj.height * activeObj.zoomScale,
                lockScalingFlip: true,
                //opacity: 0, //0.1,
                fill: 'rgba(135,206,250, 0.2)',
                borderColor: 'rgba(0, 0, 255, 0.6)',
                transparentCorners: true,
                //lockMovementX: true,  // prevent it from moving by itself
                //lockMovementY: true,  // prevent it from moving by itself
                centeredScaling: false, // need to be extended to the selected direction only
                angle: activeObj.angle,
                isCropBox: true,
                ccImageId: activeObj.ccImage.id   // id to bind this crop box to parent image
            });
            activeObj.setControlsVisibility({mtr: false});            //angle change is not allowed on base image
            cropRect.setControlsVisibility({mtr: false});     // angle change not allowed on crop box
            //cropRect.scale(this.lastSelectedObject.zoomScale);
            this.canvas[this.activeCanvasIndex].add(cropRect);

            // need to bind crop box to original image
            this.bindImageAndCropBox(cropRect, this.activeCanvasIndex, activeObj);
            // // console.log(this.lastSelectedObject, 'this.lastSelectedObject')
            this.lastActiveImageOpacity = activeObj.opacity;
            activeObj.bringForward();
            activeObj.bringToFront();
            this.canvas[this.activeCanvasIndex].bringForward(cropRect);
            this.canvas[this.activeCanvasIndex].bringToFront(cropRect);
            this.canvas[this.activeCanvasIndex].renderAll();

            this.canvas[this.activeCanvasIndex].setActiveObject(cropRect);
        }
    }

    /** check to see if this image has been cropped already based on ccImage's imagebounds values */
    checkAlreadyCroppedImage(imageToCrop: any): boolean {
        const isCroppedImage =
            +imageToCrop.ccImage.vfield[0].imagebounds.x < 0
            || +imageToCrop.ccImage.vfield[0].imagebounds.y < 0
            || +imageToCrop.ccImage.width !== (+imageToCrop.ccImage.vfield[0].tmatrix.a * +imageToCrop.ccImage.vfield[0].imagebounds.width)
            || +imageToCrop.ccImage.height !== (+imageToCrop.ccImage.vfield[0].tmatrix.a * +imageToCrop.ccImage.vfield[0].imagebounds.height);

        return isCroppedImage;
    }

    /** need to bind crop box (fabricjs rect) and parent image - needs to be called whenever cropbox is resized or moved */
    bindImageAndCropBox(cropBox: any, index: number, image?: any) {
        // need to bind crop box to
        const multiply = fabric.util.multiplyTransformMatrices;     //may move to class letiable
        const invert = fabric.util.invertTransform; //may move to class letiable

        // need to find the parent image to bind this crop box
        let parentImage;
        if (!image) {
            parentImage = this.canvas[index].getObjects().find((obj: any) => {
                if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === cropBox.ccImageId && obj.visible) {
                    return obj;
                }
            });
        } else {
            parentImage = image;
        }
        const bossTransform = parentImage.calcTransformMatrix();
        const invertedBossTransform = invert(bossTransform);
        // need to bind image and crop box together on movement
        const desiredTransform = multiply(
            invertedBossTransform,
            cropBox.calcTransformMatrix()
        );
        // save the desired relation here.:add
        cropBox.relationship = desiredTransform;
    }

    /** crop box should not go beyond parent image area on moving */
    restrictCropBoxInsideParentImageOnMove(event: any, index: number): boolean {
        let needUpdate = false;
        const parentImage = this.canvas[index].getObjects().find((obj: any) => {
            if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === event.target.ccImageId && obj.visible) {
                return obj;
            }
        });
        if (!!parentImage) {

            // vertical movement cannot go beyond parent image area
            if (event.target.aCoords.tl.y <= parentImage.aCoords.tl.y) {  // out of top
                event.target.top = parentImage.top;
                needUpdate = true;
            }
            if (event.target.aCoords.bl.y >= parentImage.aCoords.bl.y) {  // out of bottom
                event.target.top = parentImage.aCoords.bl.y - (event.target.height * event.target.scaleY);
                needUpdate = true;
            }
            // horizontal movement cannot go beyond parent image area
            if (event.target.aCoords.bl.x <= parentImage.aCoords.bl.x) {  // out of left
                event.target.left = parentImage.left;
                needUpdate = true;
            }
            if (event.target.aCoords.br.x >= parentImage.aCoords.br.x) {  // out of right
                event.target.left = parentImage.aCoords.br.x - (event.target.width * event.target.scaleX);
                needUpdate = true;
            }

            if (needUpdate) {
                event.target.setCoords();
            }
        }
        return needUpdate;
    }

    /** crop box should not go beyond parent image area on scaling */
    restrictCropBoxInsideParentImageOnScale(event: any, index: number): boolean {
        let needUpdate = false;
        const parentImage = this.canvas[index].getObjects().find((obj: any) => {
            if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === event.target.ccImageId && obj.visible) {
                return obj;
            }
        });
        if (!!parentImage) {
            // vertical movement cannot go beyond parent image area - need to adjust scaleY (not height value)
            if (event.target.aCoords.tl.y <= parentImage.aCoords.tl.y) {  // out of top
                event.target.top = parentImage.top;
                event.target.scaleY = (event.target.aCoords.bl.y - parentImage.top) / event.target.height;
                needUpdate = true;
            }
            if (event.target.aCoords.bl.y >= parentImage.aCoords.bl.y) {  // out of bottom
                event.target.scaleY = (parentImage.aCoords.bl.y - event.target.top) / event.target.height;
                needUpdate = true;
            }
            // horizontal movement cannot go beyond parent image area - need to adjust scaleX (not width value)
            if (event.target.aCoords.bl.x <= parentImage.aCoords.bl.x) {  // out of left
                event.target.left = parentImage.left;
                event.target.scaleX = (event.target.aCoords.tr.x - parentImage.left) / event.target.width;
                needUpdate = true;
            }
            if (event.target.aCoords.br.x >= parentImage.aCoords.br.x) {  // out of right
                event.target.scaleX = (parentImage.aCoords.tr.x - event.target.left) / event.target.width;
                needUpdate = true;
            }

            if (needUpdate) {
                event.target.setCoords();
            }
        }
        return needUpdate;
    }

    /** when parent image is moved, crop box needs to be moved as well  */
    moveImageAndCropBoxTogether(event: any, index: number) {
        const multiply = fabric.util.multiplyTransformMatrices;

        // find if there exists a crop box
        const cropBox = this.canvas[index].getObjects().find((obj: any) => {
            if (!!obj.ccImageId && obj.isCropBox && obj.ccImageId === event.target.ccImage.id) {
                return obj;
            }
        });

        if (!!cropBox && cropBox.isCropBox) {   //only 1 crop box allowed on image
            if (!cropBox.relationship) {
                return;
            }
            const relationship = cropBox.relationship;
            const newTransform = multiply(
                event.target.calcTransformMatrix(),
                relationship
            );
            const opt = fabric.util.qrDecompose(newTransform);
            cropBox.set({
                flipX: false,
                flipY: false,
            });
            cropBox.setPositionByOrigin(
                {x: opt.translateX, y: opt.translateY},
                'center',
                'center'
            );
            cropBox.set(opt);
            cropBox.setCoords();

            this.canvas[index].setActiveObject(cropBox);
        }
    }

    /** done or cancel - id will be passed: +value done, -value cancel */
    performCropAction(ccImageId: number) {

        const activeCanvas = this.canvas[this.activeCanvasIndex];
        let cropBox;
        // better use exact id but if it's not available find current crop box operating
        if (ccImageId === -1) {
            this.cancelCrop();
            this.customiseMenuService.cropSpinner = false;
            return;
        } else if (ccImageId === 0) {
            cropBox = activeCanvas.getObjects().find((obj: any) => {
                if (!!obj.ccImageId && obj.type === 'rect' && obj.isCropBox) {
                    this.customiseMenuService.cropSpinner = false;
                    return obj;
                }
            });
            if (!!cropBox) {
                ccImageId = +cropBox.ccImageId;
            }
        }

        const strId = '' + (ccImageId <= 0 ? ccImageId * -1 : ccImageId);   //for comparison

        // check
        if (!cropBox) {
            cropBox = activeCanvas.getObjects().find((obj: any) => {
                if (!!obj.ccImageId && obj.type === 'rect' && obj.ccImageId === strId && obj.isCropBox) {
                    this.customiseMenuService.cropSpinner = false;
                    return obj;
                }
            });
        }

        // image that has been cropped before is hidden while it's on crop mode
        const alreadyCroppedImage = activeCanvas.getObjects().find((obj: any) => {
            if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === strId && !obj.visible) {
                this.customiseMenuService.cropSpinner = false;
                return obj;
            }
        });

        // find parent image based on image id - original image
        const parentImage = activeCanvas.getObjects().find((obj: any) => {
            if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === strId && obj.visible) {
                return obj;
            }
        });

        if (!!parentImage && !!cropBox) {

            // if crop image size and base image size is the same, no need to proceed, just get original image back - will compare int values for comparison
            let isCropAreaSameAsImage;
            if (!!alreadyCroppedImage) {    // additional cropping
                isCropAreaSameAsImage = Math.floor(+cropBox.width * +cropBox.scaleX) === Math.floor(alreadyCroppedImage.width)
                    && Math.floor(+cropBox.height * +cropBox.scaleY) === Math.floor(alreadyCroppedImage.height)
                    && Math.floor(cropBox.left) === Math.floor(+alreadyCroppedImage.ccImage.x)
                    && Math.floor(cropBox.top) === Math.floor(+alreadyCroppedImage.ccImage.y);
            } else {    // 1st time crop operation
                isCropAreaSameAsImage = Math.floor(+cropBox.width * +cropBox.scaleX) === Math.floor(+parentImage.width * +parentImage.zoomScale)
                    && Math.floor(+cropBox.height * +cropBox.scaleY) === Math.floor(+parentImage.height * +parentImage.zoomScale)
                    && Math.floor(cropBox.left) === Math.floor(+parentImage.ccImage.x)
                    && Math.floor(cropBox.top) === Math.floor(+parentImage.ccImage.y);
            }
            // this.customiseMenuService.cropSpinner = false;

            // no need to proceed further - minus value < -1 means cropping has been cancelled or crop area is the same as image
            if (ccImageId <= 0 || isCropAreaSameAsImage) {
                // // console.log('no cropping required');
                activeCanvas.remove(cropBox);
                if (alreadyCroppedImage) {
                    alreadyCroppedImage.visible = true;
                    alreadyCroppedImage.setControlsVisibility({mtr: true}); //give angle change back
                    alreadyCroppedImage.sendBackwards();
                    alreadyCroppedImage.sendToBack();
                    activeCanvas.remove(parentImage);   // parent image was added temporarily
                    activeCanvas.renderAll();
                } else {
                    parentImage.setControlsVisibility({mtr: true});            //give angle change back
                    parentImage.sendBackwards();
                    parentImage.sendToBack();
                    activeCanvas.renderAll();
                }
                return;
            }

            // relative to original image
            const cropperPosition = {
                x1: cropBox.left.toFixed(5) - parentImage.left.toFixed(5),
                x2: cropBox.left.toFixed(5) - parentImage.left.toFixed(5) + (cropBox.width * cropBox.scaleX),
                y1: cropBox.top.toFixed(5) - parentImage.top.toFixed(5),
                y2: cropBox.top.toFixed(5) - parentImage.top.toFixed(5) + (cropBox.height * cropBox.scaleY)
            };

            // 1. create clone out of parent image
            parentImage.cloneAsImage((clone: any) => {
                // // console.log('cloned object');
                // // console.log(clone);
                clone.set({
                    type: 'image',
                    crossOrigin: 'annonymous',
                    lockScalingFlip: true,
                    activeCanvasIndex: this.activeCanvasIndex,
                    //width: cropBox.width * cropBox.scaleX / parentImage.zoomScale,
                    //height: cropBox.height * cropBox.scaleY / parentImage.zoomScale,
                    left: cropBox.left,
                    top: cropBox.top,
                    originalURL: parentImage.originalURL,
                    cropperPosition: cropperPosition/*parentImage.cropperPosition*/,
                    zoomScale: parentImage.scaleX,
                    assetId: parentImage.assetId,
                    asset: parentImage.asset,
                    ccImage: parentImage.ccImage,
                    opacity: parentImage.opacity/*,
                    croppedImage: true*/      // when crop button is clicked on already cropped image, it needs to display original image too
                });
                clone.setControlsVisibility({     // keep resize handles on 4 corners only to keep ratio
                    mb: false, ml: false, mr: false, mt: false
                });
                // clone.set({opacity:this.lastActiveImageOpacity});
                //clone.scale(parentImage.zoomScale);   //do not set scale on cropped image

                // 2. remove original parentImage and crop box
                // do not use imageDataOps() for delete due to sync issue
                this.customiseMenuService.deleteImageInGrid(this.jTemplateId, Number(this.activeCanvasIndex) + 1, [parentImage.ccImage.id], this.security_token).subscribe((imageRes: any) => {
                    //// console.log(imageRes, 'image data response');
                    activeCanvas.remove(cropBox);
                    activeCanvas.remove(parentImage);

                    // there might be more than 1 parent images if cropping is done for already cropped image with visible: false
                    // it also needs to be removed
                    if (alreadyCroppedImage) {
                        activeCanvas.remove(alreadyCroppedImage);
                    }

                    // this.customiseMenuService.cropSpinner = false;
                    activeCanvas.add(clone);
                    clone.sendBackwards();
                    clone.sendToBack();
                    activeCanvas.renderAll();
                });

            }, {
                multiplier: 1,      // keep the scale as 1
                left: cropBox.left - parentImage.left, //Cropping left offset: relative to original image
                top: cropBox.top - parentImage.top,  //Cropping top offset: relative to original image
                width: cropBox.width * cropBox.scaleX,      //Cropping width
                height: cropBox.height * cropBox.scaleY     //Cropping height
            });
        } else {
            // this.customiseMenuService.cropSpinner = false;
            // // console.log('crop rect or parent image is not valid!');
        }
    }

    /** need to cancel crop operation when another action is taken - only ONE crop action is allowed */
    cancelCrop() {
        this.isCropMode = false;
        const activeCanvas = this.canvas[this.activeCanvasIndex];

        if (!!activeCanvas) {
            const cropBox = activeCanvas.getObjects().find((obj: any) => {
                if (!!obj.ccImageId && obj.type === 'rect' && obj.isCropBox) {
                    return obj;
                }
            });

            if (!!cropBox) {
                // image that has been cropped before if it is not original image
                const alreadyCroppedImage = activeCanvas.getObjects().find((obj: any) => {
                    if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === cropBox.ccImageId && !obj.visible) {
                        return obj;
                    }
                });

                // find parent image based on image id - original image or already cropped image
                const parentImage = activeCanvas.getObjects().find((obj: any) => {
                    if (!!obj.ccImage && obj.type === 'image' && obj.ccImage.id === cropBox.ccImageId && obj.visible) {
                        return obj;
                    }
                });

                activeCanvas.remove(cropBox);
                if (alreadyCroppedImage) {
                    alreadyCroppedImage.visible = true;
                    alreadyCroppedImage.setControlsVisibility({mtr: true});            //give angle change back
                    activeCanvas.remove(parentImage);   // parent image was added temporarily
                } else {
                    parentImage.setControlsVisibility({mtr: true});            //give angle change back
                }
            }
        }
    }

    /** Fetch more images in replace overlay */
    fetchMoreAssets(catalogue) {
        this.imageCatalogue = catalogue;
        setTimeout(() => {
            if (!!this.currentView) {
                this.draggableBg('imagetab', !!this.currentView);
            }
        }, 100, this);
    }

    /** Fire this event once all background has been loaded */
    bgImagesLoaded() {
        setTimeout(() => {
            if (!!this.currentView) {
                this.draggableBg('background', !!this.currentView);
            }
        }, 100, this);
    }

    // public lastScaledFontSize;

    /** Fonts styling changes */
    setFont(textChanges: any): void {
        this.isCanvasChanged = true;
        let property: any;
        let value: any;
        const fontName = textChanges.fontStyle;
        const fontColor = textChanges.fontColor;
        const fontSize = textChanges.fontSize;
        const fontWeight = textChanges.fontWeight;
        const activeObject = this.canvas[this.activeLastIndex].getActiveObject() || this.activeTextObject;
        if (fontColor) {
            property = 'fill';
            value = fontColor;
        }
        if (fontName) {
            const activeObj = this.canvas[this.activeLastIndex].getActiveObject();
            activeObj.set('fontFamily', fontName);
            this.canvas[this.activeLastIndex].renderAll();
        }
        if (fontSize) {
            property = 'fontSize';
            // const scalefactor = this.selectedScale !== 'Fit' ? Number(this.selectedScale) / 100 : ((window.innerHeight - 200) * 100 / this.canvas[this.activeCanvasIndex].originalCanvasHeight) / 100; //canvas.getZoom();
            //
            const activeObj = this.canvas[this.activeLastIndex].getActiveObject();
            activeObj.set({
                scaleX: 1,
                scaleY: 1
            });
            value = fontSize;
        }
        if (fontWeight) {
            const check = new RegExp('non-').test(fontWeight);
            switch (fontWeight) {
                case 'bold':
                case 'non-bold':
                    property = 'fontWeight';
                    value = check ? 'normal' : 'bold';
                    break;
                case 'italic':
                case 'non-italic':
                    property = 'fontStyle';
                    value = check ? 'normal' : 'italic';
                    break;

                case 'underline':
                case 'non-underline':
                    property = 'underline';
                    value = !check;
                    break;
                case 'Caps':
                    property = 'text';
                    value = this.canvas[this.activeLastIndex].getActiveObject().text.toUpperCase();
                    this.selectedObjFontsStyles.caps = true;
                    this.selectedObjFontsStyles.Title = false;
                    activeObject.set('fontCharacterStyle', 'Caps');
                    break;
                case 'Title':
                    property = 'text';
                    value = this.customiseMenuSharedService.titleCase(this.canvas[this.activeLastIndex].getActiveObject().text.toLowerCase());
                    activeObject.set('fontCharacterStyle', 'Title');
                    this.selectedObjFontsStyles.caps = false;
                    this.selectedObjFontsStyles.Title = true;
                    break;
                case 'Normal':
                    property = 'text';
                    value = this.customiseMenuSharedService.titleCase(this.canvas[this.activeLastIndex].getActiveObject().text.toLowerCase());
                    activeObject.set('fontCharacterStyle', 'Normal');
                    this.selectedObjFontsStyles.caps = false;
                    this.selectedObjFontsStyles.Title = false;
                    break;
            }
        }

        if (textChanges.fontAlign) {
            property = 'textAlign';
            value = textChanges.fontAlign;
        }
        /* Active index changed Due to scrolling thus I have taken activeTextObject */
        activeObject.set(property, value);
        if (!this.canvas[this.activeLastIndex].getActiveObject()) {
            this.canvas[this.activeLastIndex].renderAll(); /* If Active index changed Due to scrolling thus I have taken activeLastIndex */
        }
        if (fontSize) { // #6948
            activeObject.set({
                width: activeObject.calcTextWidth() + 30
            });
        }
        // need to use top left corner value to get the valid one regardless of originX
        // activeObject.ccTextRegion.x = activeObject.aCoords.tl.x;
        // //activeObject.ccTextRegion.x = activeObject.left;
        // activeObject.ccTextRegion.y = activeObject.top;
        // activeObject.ccTextRegion.textBlocks.forEach(textBlockData => {
        //     if (textBlockData.xmlText) {
        //         textBlockData.xmlText.forEach(textObj => {
        //             textObj.pointsize = activeObject.fontSize.toString();
        //             activeObject.ccTextRegion.height = Number(activeObject.height);
        //             activeObject.ccTextRegion.width = Number(activeObject.width);
        //             textObj.color = activeObject.fill; //this.customiseMenuService.getCmykFromRgb(activeObject.fill);
        //             textBlockData.align = activeObject.textAlign;
        //             textObj.font = activeObject.fontFamily.split(',')[0];
        //             textObj.characterStyle = activeObject.underline ? 'underline' : 'plain';
        //             if (activeObject.fontWeight === 'bold') {
        //                 textObj.characterStyle = textObj.characterStyle + ' bold';
        //                 textObj.characterStyle = textObj.characterStyle.replace('plain ', '')
        //             }
        //             if (activeObject.fontStyle === 'italic') {
        //                 textObj.characterStyle = textObj.characterStyle + ' italic';
        //                 textObj.characterStyle = textObj.characterStyle.replace('plain ', '')
        //             }
        //             textObj.vfield.forEach(vfieldData => {
        //                 vfieldData.value = activeObject.text;
        //             });
        //
        //             // multilines - need to increase height of textregion
        //             if (!!activeObject.textLines && activeObject.textLines.length > 1) {
        //                 activeObject.ccTextRegion.height = '' + (+activeObject.fontSize * activeObject.textLines.length + +activeObject.fontSize);
        //             } else {
        //                 activeObject.ccTextRegion.height = '' + (+activeObject.fontSize * 2);
        //             }
        //         });
        //     }
        // });
        this.updatedOnAnotherEvent = true;    // flag to prevent another api call from :modified event
        this.updateActiveTextRegion(false);
        // this.textRegionsToUpdate.push(activeObject.ccTextRegion);
        // this.updateTextObjectInAPI(this.activeLastIndex);
        // this.customiseMenuService.updateBulkTextRegionInJob(this.jTemplateId, Number(this.activeLastIndex) + 1, [activeObject.ccTextRegion], this.security_token).subscribe((updateTextRes: any) => {
        //     this.updatedOnAnotherEvent = false;
        //     // // console.log(updateTextRes, 'updateTextRes');
        // });

        // if(activeObject.width > this.canvas[this.activeCanvasIndex].width) {
        //     activeObject.set('fontSize', this.lastScaledFontSize || fontSize);
        //     activeObject.width = this.canvas[this.activeCanvasIndex].width - 3;
        //     activeObject.left = 0;
        // } else {
        //     this.lastScaledFontSize = fontSize;
        // }
        this.canvas[this.activeLastIndex].renderAll();
    }

    /** Fonts changes event */
    onFontChanges(textChanges: any): void {
        this.setFont(textChanges);
    }

    /** Insert new grid page in canvas */
    addGridPage(index) {
        // new page becomes the LAST page
        // TODO if new page can be inserted to specific position, jTemplateGridIds & originalJTemplateGridIds should be changed to map
        const data = {
            gridID: this.originalJTemplateGridIds[index],   // base template's grid id to make a copy of
            index: this.originalJTemplateGridIds.length + 1,    //target position to insert, start from 1
            templateID: this.baseTemplateId                 // base templateID to
        };
        this.customiseMenuService.insertGridPage(this.jTemplateId, data, this.security_token).subscribe((res: RestResponse) => {
            // // console.log(res, 'res');
            // res instance is xmlGrid
            this.jTemplateGridIds.push(res.instance.jTemplateGridID);
            this.originalJTemplateGridIds.push(data.gridID);

            // initiate newly inserted grid page
            this.setBaseTamplateAndBackground(data.index - 1);
        });
    }

    /** Delete grid page in canvas */
    deleteGridPage(index) {
        let title;
        let text;
        let labelConfirm;
        let labelCancel;
        this.translate.get('label.DeleteGridTitle').subscribe((res: string) => {
            title = res + ' ' + (index + 1);
        });
        this.translate.get('message.DeleteGridWarning').subscribe((res: string) => {
            text = res;
        });
        this.translate.get('label.delete').subscribe((res: string) => {
            labelConfirm = res;
        });
        this.translate.get('label.DontDelete').subscribe((res: string) => {
            labelCancel = res;
        });
        this.swal({
            title: title,
            text: text,
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: labelCancel,
            confirmButtonText: labelConfirm
        }).then((result) => {
            if (result.value) {
                queueScheduler.schedule(() => {
                    // this.customiseMenuService.deleteBulkJobTextRegion(this.jTemplateId, this.activeCanvasIndex + 1, canvasObjects, this.security_token).subscribe(res => {
                    this.customiseMenuService.deleteGridPage(this.jTemplateId, this.jTemplateGridIds[index], index + 1, this.security_token).subscribe(() => {

                        this.grids.splice(index, 1);
                        this.grids.forEach((grid, index) => {
                            grid.id = index + 1;
                            grid.gridName = '' + grid.id;
                        });
                        this.grids = [...this.grids];

                        this.canvas[index].dispose();    // ensure to clear a canvas element and remove all event listeners
                        this.canvas.splice(index, 1);
                        this.canvas.forEach((canvas, index) => {
                            // !!! MUST rebind event since it still has reference to removed canvas
                            this.unbindCanvasEvents(canvas, index);
                            this.bindCanvasEvents(canvas, index);
                        });

                        this.jTemplateGridIds.splice(index, 1);
                        this.originalJTemplateGridIds.splice(index, 1);
                        window.removeEventListener('scroll', this.onMouseWheel, true);
                        window.addEventListener('scroll', this.onMouseWheel.bind(this), true);
                    });

                });
            }
        })
    }

    /** Clear grid page in canvas */
    clearGridPage(index) {
        let title;
        let text;
        let labelConfirm;
        let labelCancel;
        this.translate.get('label.ClearGridTitle').subscribe((res: string) => {
            title = res;
        });
        this.translate.get('message.ClearGridWarning').subscribe((res: string) => {
            text = res;
        });
        this.translate.get('label.yes').subscribe((res: string) => {
            labelConfirm = res;
        });
        this.translate.get('label.no').subscribe((res: string) => {
            labelCancel = res;
        });
        this.swal({
            title: title,
            text: text,
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            cancelButtonText: labelCancel,
            confirmButtonText: labelConfirm
        }).then(async (result) => {
            if (result.value) {
                // setTimeout(async()=> {
                const canvasObjects = [];
                const Objects = [];
                if (this.canvas[index]._objects.length) {
                    // // console.log(this.canvas[index]._objects, 'this.canvas[index]._objects');
                    const data = await this.canvas[index]._objects.forEach(obj => {

                        if (obj.ccTextRegion) {
                            canvasObjects.push(obj.ccTextRegion.id);
                            Objects.push(obj);
                            // this.canvas[index].remove(obj);
                        }
                    });
                    if (canvasObjects.length) {
                        queueScheduler.schedule(() => {
                            this.customiseMenuService.deleteBulkJobTextRegion(this.jTemplateId, this.activeCanvasIndex + 1, canvasObjects, this.security_token).subscribe(res => {
                                // // console.log(res, 'res');
                                Objects.forEach(obj => {
                                    this.canvas[index].remove(obj);
                                });
                            });
                        });
                    }

                }
                // },100)
            }
        })
    }

    public selectionTimeOut;

    /**
     * Bind canvas events
     */
    bindCanvasEvents(canvas: any, index: number): void {
        // this.canvas[index].setZoom(this.scaleFactor);
        canvas.on('mouse:down', event => {

            // this.activeCanvasIndex = index;
            if (!!event.target && !!event.target.id && event.target.type !== 'activeSelection') {
                if (!event.target.isEditing) {
                    const child = [];
                    let snapInRegion;
                    let rectId;
                    let groupEditRules;
                    for (const item of this.canvas[index].getObjects()) {
                        if (item.parent === event.target.id || item.id === event.target.id) {
                            child.push(item);

                            // get snapInRegion from boundary rect to be used on shuffling
                            if (item.type === 'rect') {
                                snapInRegion = item.snapInRegion;
                                rectId = item.id;
                                groupEditRules = item.groupEditRules;
                            }
                        }
                    }

                    if (child.length > 1) {   // prevent single selection
                        this.showDelete = true;
                        const sel = new fabric.ActiveSelection(child, {
                            canvas: this.canvas[index]
                        });
                        sel.setControlsVisibility({
                            mtr: false,
                            mb: false,
                            ml: false,
                            mr: false,
                            mt: false
                        });
                        sel.setOptions({
                            cornerStyle: 'circle',
                            transparentCorners: false,
                            cornerSize: 11,
                            borderColor: '#e65609',
                            cornerColor: '#e65609',
                            cornerStrokeColor: '#e65609',
                            lockScalingFlip: true,
                            padding: 5,
                            borderOpacityWhenMoving: 0.2,
                            absolutePositioned: true,
                            rectId: rectId,      // set underlying rectangle id for convenience,
                            groupEditRules: groupEditRules      // use to see rules for grouped selection
                        });

                        // need to remember the original position to snap it back into designated region when it goes out of guided area
                        sel.originPosition = {
                            x: sel.left, y: sel.top
                        };

                        // apply edit rules
                        if (!!groupEditRules) {
                            sel.lockScalingX = groupEditRules.resizable === '0' ? true : false;
                            sel.lockScalingY = groupEditRules.resizable === '0' ? true : false;
                            sel.lockMovementX = groupEditRules.movable === '0' ? true : false;
                            sel.lockMovementY = groupEditRules.movable === '0' ? true : false;
                            if (groupEditRules.resizable === '0') {
                                sel.setControlsVisibility({
                                    bl: false,
                                    br: false,
                                    tl: false,
                                    tr: false,
                                    mt: false,
                                    mb: false,
                                    ml: false,
                                    mr: false
                                });
                            } else {
                                sel.setControlsVisibility({
                                    bl: true,
                                    br: true,
                                    tl: true,
                                    tr: true
                                });
                            }
                            if (sel.lockMovementX && sel.lockMovementY) {
                                sel.hoverCursor = 'not-allowed';
                            }
                        }

                        sel.setCoords();

                        sel.snapInRegion = snapInRegion;    //from boundary rect
                        this.activeObject = sel;
                        canvas.setActiveObject(sel);
                        /* On click start drag group */
                        canvas._setupCurrentTransform(event.e, sel);
                    } else {
                        event.target.originPosition = {
                            x: event.target.left, y: event.target.top
                        };

                        event.target.setCoords();

                    }
                    //TODO may need to fina a way to be in dragging mode on click and hold
                    canvas.renderAll();
                }
            }
            if (event.target && event.target.type && event.target.type === 'CurvesText') {
                if (event.target.text && event.target.text.includes('{{') && event.target.text.includes('}}')) {
                    event.target.editable = false;
                } else {
                    this.objectNotSelected = false;
                    // both texts in snapInRegion and general text need to be considered
                    //if (event.target.snapInRegion) {
                    //    this.customiseMenuPropertyService.editTextArea = {};
                    //} else {
                    this.customiseMenuPropertyService.editTextArea = event.target.ccTextRegion;
                    this.customiseMenuPropertyService.editTextArea.isStyledText = event.target.isStyledText;    //used to show/hide edit rules button
                    this.customiseMenuPropertyService.activeIndex = index;
                    //}
                    this.activeTextObject = event.target;
                    this.activeLastIndex = index;
                    // only valid for text
                    let upercase = true;
                    let titleCase = false;
                    let letters = event.target.text;
                    for (let i = 0; i < letters.length; i++) {
                        if (letters[i] !== letters[i].toUpperCase()) {
                            upercase = false;
                        }
                    }
                    if (event.target.fontCharacterStyle === 'Normal') {
                        upercase = false;
                    }
                    if (event.target.fontCharacterStyle === 'Title') {
                        titleCase = true;
                    }
                    this.selectedObjFontsStyles = {
                        fontFamily: event.target.fontFamily,
                        fontSize: event.target.fontSize * event.target.scaleX,
                        fontAlign: event.target.textAlign,
                        fontWeight: 'normal',
                        fontStyle: 'normal',
                        underline: event.target.underline ? true : false,
                        caps: upercase,
                        Title: titleCase,
                        color: event.target.fill
                    };
                }
            }
            if (event.target && event.target.type && event.target.type === 'image') {
                this.lastActiveImageOpacity = event.target.opacity;
            }
        });
        canvas.on('mouse:dblclick', event => {
            clearTimeout(this.selectionTimeOut);
            if (event.target.text && event.target.text.includes('{{') && event.target.text.includes('}}')) {
                // event.preventDefault();
                this.customiseMenuPropertyService.dynamicTextTitle = event.target.text;
                // this.customiseMenuPropertyService.dynamicTextFields = event.target.text.split(/[{{}}]/);
                let textData = event.target.text.split(' ');
                let fieldData = [];
                textData.forEach(data => {
                    if (data.match("{{!(.*)}}") && data.match("{{!(.*)}}").length) {
                        fieldData.push({
                            fieldName: data.match("{{!(.*)}}")[1],
                            required: false
                        })
                    } else if (data.match("{{(.*)}}") && data.match("{{(.*)}}").length) {
                        fieldData.push({
                            fieldName: data.match("{{(.*)}}")[1],
                            required: true
                        })
                    }
                });
                this.customiseMenuPropertyService.dynamicTextFields = fieldData;
                // this.customiseMenuPropertyService.dynamicTextFields = event.target.text.match("{{(.*)}}");
                this.convertComponentToDom(TermsAndConditionsComponent);
            }
            if (!!event.target && event.target.type === 'activeSelection') {
                // allow text editing on child text inside group menu
                if (!!event.target._objects && event.target._objects.length > 0) {
                    this.canvas[index].discardActiveObject();


                    const scalefactor = this.selectedScale !== 'Fit' ? Number(this.selectedScale) / 100 : ((window.innerHeight - 200) * 100 / this.canvas[index].originalCanvasHeight) / 100; //canvas.getZoom();
                    // use mouse click position to get the right child text object - check if it is inside text rectangle
                    // console.log();
                    const found = event.target._objects.find(child => {
                        return !!child.ccTextRegion
                            && ((child.aCoords.tl.x * scalefactor) < event.pointer.x && (child.aCoords.tl.x + child.width) * scalefactor > event.pointer.x)
                            && ((child.aCoords.tl.y * scalefactor) < (event.pointer.y) && (child.aCoords.tl.y + child.height) * scalefactor > event.pointer.y);
                    });
                    let textRegions = [];
                    let leading = "0";
                    this.customiseMenuPropertyService.editTextArea = {};
                    // event.target._objects.forEach((obj, index) => {
                    //     if (obj && obj.type === 'CurvesText') {
                    //         if (obj.ccTextRegion.textBlocks[0].leading !== leading) {
                    //             leading = obj.ccTextRegion.textBlocks[0].leading;
                    //             // console.log(obj.ccTextRegion.textBlocks[0].leading)
                    //             textRegions.push(obj.ccTextRegion.textBlocks[0]);
                    //         } else {
                    //             textRegions[textRegions.length - 1].xmlText.push(obj.ccTextRegion.textBlocks[0].xmlText[0]);
                    //         }
                    //     }
                    //     if (index + 1 === event.target._objects.length) {
                    //         this.customiseMenuService.editTextArea.textBlocks = textRegions;
                    //     }
                    // })
                    if (found) {
                        //!!! same code exist under mouse:down event to set editTextArea - added here to ensure grouped text item selection
                        // double click event for grouped texts does not invoke 'mouse:down' event
                        this.customiseMenuPropertyService.editTextArea = found.ccTextRegion;
                        this.customiseMenuPropertyService.editTextArea.isStyledText = found.isStyledText;    //used to show/hide edit rules button
                        this.customiseMenuPropertyService.activeIndex = index;

                        found.enterEditing();
                        if (found.text.length > 0) {  // cursor position to the end of text
                            found.setSelectionStart(found.text.length);
                            found.setSelectionEnd(found.text.length);
                        }
                        this.canvas[index].setActiveObject(found);
                        this.canvas[index].renderAll();
                    }
                }
            }

            // this.activeCanvasIndex = index;
        });
        canvas.on('dragover', event => {
            /* Show cross line inside a dotted line */
            if (event && event.target && event.target.id && event.target.id.includes('draggable-dots-')) {
                this.showCrossInRect(event.target.rectIndex, index, event.target);
            } else {
                this.hideLine(index);
            }
        });

        canvas.on('object:moving', event => {
            clearTimeout(this.selectionTimeOut);
            this.checkIntersectingObject(event, index);
            this.prepShuffling(event, index);
            // this.showCrossInRect(index,this.activeCanvasIndex);
            if (event.target.canvas.lowerCanvasEl) {
                const canvasIndex = event.target.canvas.lowerCanvasEl.id.split('_')[1];
                this.activeCanvasIndex = Number(canvasIndex) - 1;
            }

            let cancelEvent = false;
            if (event.target && event.target.type === 'image') {
                event.target.set({opacity: 0.5}); // Set opacity to 0.5 while moving.
                this.moveImageAndCropBoxTogether(event, index); //TODO may just hide crop rect and only show on :moved event
                /** Prevent object moving beyond the canvas size */
                // let obj = event.target;
                // // if object is too big ignore
                // if (obj.currentHeight > obj.canvas.height || obj.currentWidth > obj.canvas.width) {
                //     return;
                // }
                // obj.setCoords();
                // // top-left  corner
                // if (obj.getBoundingRect().top < 0 || obj.getBoundingRect().left < 0) {
                //     obj.top = Math.max(obj.top, obj.top - obj.getBoundingRect().top);
                //     obj.left = Math.max(obj.left, obj.left - obj.getBoundingRect().left);
                // }
                // // bot-right corner
                // if (obj.getBoundingRect().top + obj.getBoundingRect().height > obj.canvas.height || obj.getBoundingRect().left + obj.getBoundingRect().width > obj.canvas.width) {
                //     obj.top = Math.min(obj.top, obj.canvas.height - obj.getBoundingRect().height + obj.top - obj.getBoundingRect().top);
                //     obj.left = Math.min(obj.left, obj.canvas.width - obj.getBoundingRect().width + obj.left - obj.getBoundingRect().left);
                // }

            } else if (event.target && event.target.type === 'rect' && event.target.isCropBox) {
                // need to contain crop box inside parent image
                cancelEvent = true;
                this.restrictCropBoxInsideParentImageOnMove(event, index);
            }

            if (!cancelEvent) {
                const HideControls = {
                    'tl': true,
                    'tr': true,
                    'bl': true,
                    'br': true,
                    'ml': false,
                    'mt': false,
                    'mr': false,
                    'mb': false,
                    'mtr': false
                };
                let showLines = true;
                this.gridTextRegionsByGrid[this.activeCanvasIndex].forEach((textRegion, index) => {
                    const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-dots-' + index});
                    if (!!rectObject) {
                        rectObject.visible = true;
                        showLines = false;
                    } else {
                        if (!textRegion.textBlocks) {
                            const rect = this.createDottedArea(index, textRegion);
                            showLines = false;
                            rect.setControlsVisibility(HideControls);
                            this.canvas[this.activeCanvasIndex].add(rect);
                        }
                    }
                });
                const imageRegions = _.find(this.imageRegions, {index: this.activeCanvasIndex});
                Object.keys(imageRegions.res).forEach((key) => {
                    const xmlImages = imageRegions.res[key] as XmlImage[];  // get xmlImage instance
                    if (!xmlImages.length) {
                        return;
                    }
                    this.activeImageRegionHover = undefined;
                    xmlImages.forEach((xmlImage, imgIndex) => {
                        if (xmlImage.vfield[0].xmlId) {
                            return;
                        }
                        const checkPos = (xmlImageObj): boolean => {
                            const canvas = this.canvas[this.activeCanvasIndex];
                            const pointer = canvas.getPointer(event, false);
                            const posX = pointer.x;
                            const posY = pointer.y;
                            //return posX >= Number(textRegion.x) && posX <= Number(textRegion.width) && posY >= Number(textRegion.y) && posY <= Number(textRegion.height);
                            // need to consider relevant area
                            // debugger
                            return (posX >= +xmlImageObj.x && posX <= +xmlImageObj.x + +xmlImageObj.width && posY >= +xmlImageObj.y && posY <= +xmlImageObj.y + +xmlImageObj.height) || (+xmlImageObj.x >= posX && +xmlImageObj.x + +xmlImageObj.width <= posX && +xmlImageObj.y >= posY && +xmlImageObj.y + +xmlImageObj.height <= posY);
                            // return (posX >= +xmlImageObj.x && posY >= +xmlImageObj.y) || (+xmlImageObj.x >= posX && +xmlImageObj.y >= posY);
                        };
                        if (checkPos(xmlImage)) {
                            this.activeImageRegionHover = xmlImage;
                        }
                        const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: 'draggable-imgdots-' + imgIndex});
                        if (!!rectObject) {
                            rectObject.visible = true;
                        } else {
                            const rect = this.createImgDottedArea(imgIndex, xmlImage);
                            rect.setControlsVisibility(HideControls);
                            this.canvas[this.activeCanvasIndex].add(rect);
                        }
                    });
                    // Check is image is placed inside which Imgage Region. If image region is there it will change stroke color to red.
                    this.canvas[this.activeCanvasIndex].getObjects().forEach(data => {
                        if (this.activeImageRegionHover && data.id && data.id.includes('draggable-imgdots-') && data.regionId && (data.regionId === this.activeImageRegionHover.id)) {
                            data.set({stroke: 'Red'});
                        } else if (data.id && data.id.includes('draggable-imgdots-')) {
                            data.set({stroke: 'orange'});
                        }
                    })
                });
                if (showLines) {
                    this.showCrossLine(index);
                }
                this.canvas[this.activeCanvasIndex].renderAll();
            }
        });
        canvas.on('object:rotated', event => {
            this.hideLine(index);
            if (event.target && event.target.type === 'image') {
                // this.updateModifications(true, event.target);
                this.imageDataOps(event.target, 'update', true);
                this.moveImageAndCropBoxTogether(event, index);
            }
            this.checkIntersectingWaterMark(event, index)
        });
        canvas.on('object:moved', event => {
            // this.hideCrossLine(this.activeCanvasIndex);
            /* Hide dotted region after object moved */
            // const rectObject = _.find(, {id: 'draggable-dots-' + index});
            this.checkIntersectingWaterMark(event, index)
            this.textRegionsToUpdate = [];
            this.hideLine(index);
            if (event.target && event.target.type === 'image') {
                event.target.set({opacity: this.lastActiveImageOpacity}); // After moving the image set opacity back to original
                // this.updateModifications(true, event.target);
                // this.imageDataOps(event.target, 'update', true);
                // If image is inside Imageregion it should fit inside that region.
                if (!this.activeImageRegionHover) {
                    delete event.target.firstScale;
                }
                if (this.activeImageRegionHover) {
                    const canvasAspect = Number(this.activeImageRegionHover.width) / Number(this.activeImageRegionHover.height);
                    const imgAspect = Number(+event.target.width * +this.scaleFactor) / Number(+event.target.height * +this.scaleFactor);
                    let scaleFactor;

                    if (canvasAspect < imgAspect) {
                        scaleFactor = Number(this.activeImageRegionHover.width) / Number(+event.target.width);
                    } else {
                        scaleFactor = Number(this.activeImageRegionHover.height) / Number(+event.target.height);
                    }
                    if (event.target.firstScale) {
                        scaleFactor = event.target.scaleX;
                    }
                    event.target.zoomScale = scaleFactor;
                    let calcNewLeft = (Number(this.activeImageRegionHover.width) - Number(+event.target.width * event.target.zoomScale
                    )) / 2;
                    let calcNewTop = (Number(this.activeImageRegionHover.height) - Number(+event.target.height * event.target.zoomScale)) / 2;
                    calcNewLeft = calcNewLeft < 0 ? 0 : calcNewLeft;
                    calcNewTop = calcNewTop < 0 ? 0 : calcNewTop;

                    if (!event.target.firstScale) {
                        event.target.set({
                            top: Number(this.activeImageRegionHover.y) + calcNewTop,
                            left: Number(this.activeImageRegionHover.x) + calcNewLeft,
                        });
                    }
                    event.target.scale(scaleFactor);
                    if (event.target.cropperPosition) { // If image has cropperPosition it adjust x and y postion of parrent image so it behave proper in PDF.
                        event.target.ccImage.x = (Number(this.activeImageRegionHover.x) + calcNewLeft) - +event.target.ccImage.vfield[0].imagebounds.x;
                        event.target.ccImage.y = (Number(this.activeImageRegionHover.y) + calcNewTop) - +event.target.ccImage.vfield[0].imagebounds.y;
                        event.target.ccImage.vfield[0].clip.height = event.target.ccImage.vfield[0].clip.height * scaleFactor;
                        event.target.ccImage.vfield[0].clip.width = event.target.ccImage.vfield[0].clip.width * scaleFactor;
                        this.updateBulkImages([event.target.ccImage]);
                    } else {
                        this.imageDataOps(event.target, 'update', true);
                    }
                    event.target.setCoords();
                    this.canvas[this.activeCanvasIndex].renderAll();
                } else {
                    this.imageDataOps(event.target, 'update', true);
                    this.moveImageAndCropBoxTogether(event, index);
                }
            } else if (event.target && event.target.type === 'rect' && event.target.isCropBox) {
                // if it's cropBox it needs to be binded to parent image again
                this.bindImageAndCropBox(event.target, index);

            } else {
                let repositioned = false;
                this.textRegionsToUpdate = [];
                // either group or single items with originPosition details
                if (!!event.target && !!event.target.originPosition) {
                    let snapInRegion;   // quided region where moved obj belongs to
                    if (!!event.target._objects && event.target._objects.length > 0 && event.target.type === 'activeSelection') {
                        const rectangle = event.target._objects.find(obj => {
                            return obj.type === 'rect' && !!obj.snapInRegion;
                        });
                        snapInRegion = !!rectangle ? rectangle.snapInRegion : undefined;
                    } else {    // single item
                        snapInRegion = !!event.target.snapInRegion ? event.target.snapInRegion : undefined;
                    }

                    if (!!snapInRegion) {
                        // see if moved position is completely out of guided area, otherwise keep the new y value
                        if ((event.target.left < snapInRegion.x && event.target.aCoords.tr.x < snapInRegion.x)
                            || (event.target.left > snapInRegion.x + snapInRegion.width && event.target.aCoords.tr.x > snapInRegion.x + snapInRegion.width)
                            || event.target.top < snapInRegion.y || event.target.top > snapInRegion.y + snapInRegion.height) {

                            // if yes, move it back to origin position
                            event.target.left = event.target.originPosition.x;
                            event.target.top = event.target.originPosition.y;
                            event.target.setCoords();
                            this.canvas[index].discardActiveObject();

                        } else {    // inside guided region - just line up x position to left
                            // event.target.left = snapInRegion.x;
                            // const pointer = canvas.getPointer(event.e);
                            let objectLeft = event.target.left + (+event.target.width / 2);
                            if (objectLeft <= snapInRegion.x + (snapInRegion.width / 4)) {
                                event.target.left = snapInRegion.x;
                            } else if (objectLeft >= snapInRegion.x + ((snapInRegion.width / 4) * 3)) {
                                event.target.left = +snapInRegion.x + +snapInRegion.width - +event.target.width;
                            } else {
                                event.target.left = (snapInRegion.x + ((snapInRegion.width / 2))) - (+event.target.width / 2);
                            }
                            event.target.top = event.target.aCoords.tl.y;

                            // need to take care overlapped items
                            this.rearrangeOverlappingObject(event, index);

                            event.target.setCoords();
                        }

                        repositioned = true;
                    }
                } else if (!!event.target._objects && event.target._objects.length > 0 && event.target.type === 'activeSelection') {
                    event.target._objects.forEach(obj => {
                        if (obj.snapInRegion) {
                            console.log(obj, 'obj');
                            let snapInRegion = obj.snapInRegion;
                            if (!!snapInRegion) {
                                // see if moved position is completely out of guided area, otherwise keep the new y value
                                if ((event.target.left < snapInRegion.x && event.target.aCoords.tr.x < snapInRegion.x)
                                    || (event.target.left > snapInRegion.x + snapInRegion.width && event.target.aCoords.tr.x > snapInRegion.x + snapInRegion.width)
                                    || event.target.top < snapInRegion.y || event.target.top + event.target.height > snapInRegion.y + snapInRegion.height) {

                                    // if yes, move it back to origin position
                                    event.target.left = snapInRegion.x;
                                    event.target.top = snapInRegion.y;
                                    event.target.setCoords();
                                    this.canvas[index].discardActiveObject();

                                } else {    // inside guided region - just line up x position to left
                                    // event.target.left = snapInRegion.x;
                                    // const pointer = canvas.getPointer(event.e);
                                    let objectLeft = event.target.left + (+event.target.width / 2);
                                    if (objectLeft <= snapInRegion.x + (snapInRegion.width / 4)) {
                                        event.target.left = snapInRegion.x;
                                    } else if (objectLeft >= snapInRegion.x + ((snapInRegion.width / 4) * 3)) {
                                        event.target.left = +snapInRegion.x + +snapInRegion.width - +event.target.width;
                                    } else {
                                        event.target.left = (snapInRegion.x + ((snapInRegion.width / 2))) - (+event.target.width / 2);
                                    }
                                    event.target.top = event.target.aCoords.tl.y;

                                    // need to take care overlapped items
                                    this.rearrangeOverlappingObject(event, index);

                                    event.target.setCoords();
                                }

                                repositioned = true;
                            }
                        }
                    })
                }
                // clearTimeout(callTimeout);
                //
                // callTimeout = setTimeout(() => {
                //     // console.log('Enter 2000')
                // this.updateActiveTextRegion(true);
                // }, 1000);

                // this.updateActiveTextRegion(true)
                // this.canvas[index].forEachObject((obj, index) => {
                //     // reset shuffle flag
                //     if (!!obj.id && obj.id.indexOf('draggable') === -1) {
                //         obj.movedByShuffle = false; //'none';
                //     }
                //
                //     // ONLY update ccTextRegion x,y and do not try to reposition texts inside group menu - will be updated when it settles down
                //     if (repositioned && obj.type === 'CurvesText') {
                //         if (!!event.target.rectId && obj.parent === event.target.rectId) {    // activeSelection keeps group rectangle's parent id
                //             // moving obj was group active selection and need to reset positions for children because their coords are not recalculated inside activeSelection
                //             // const yDiff = event.target.top - event.target.originPosition.y;
                //             // // console.log(+obj.ccTextRegion.y + yDiff, '+obj.ccTextRegion.y + yDiff;')
                //             // obj.ccTextRegion.y = event.target.top + obj.top;
                //             // use ccTextRegion instead - coords for objects inside activeSelection are not accurate in this case
                //             this.textRegionsToUpdate.push(obj.ccTextRegion);    // add up only those that have actually changed
                //
                //         } else {
                //             if ((+obj.ccTextRegion.x !== obj.aCoords.tl.x) || (+obj.ccTextRegion.y !== obj.aCoords.tl.y)) {
                //                 // x, y position changes need to be updated for other textRegions
                //                 obj.ccTextRegion.x = obj.aCoords.tl.x;
                //                 obj.ccTextRegion.y = obj.aCoords.tl.y;
                //
                //                 this.textRegionsToUpdate.push(obj.ccTextRegion);    // add up only those that have actually changed
                //             }
                //         }
                //         //this.textRegionsToUpdate.push(obj.ccTextRegion);
                //     }
                // });

                this.canvas[this.activeCanvasIndex].renderAll();
            }

        });
        canvas.on('object:rotating', event => {
            clearTimeout(this.selectionTimeOut);
            this.checkIntersectingObject(event, index);
        });
        canvas.on('selection:created', event => {
            // if (event && event.target && (event.target.type === 'activeSelection' || event.target.type === 'CurvesText')) {
            this.activeObject = event.target;
            this.lastSelectedObject = event.target;
            let resizable = true;
            let movable = true;
            this.objectNotSelected = true;
            // }
            // // console.log(event.target.type,'type')
            /* While moving object whole group should move */
            if (event.target.type === 'activeSelection' && !event.target.id) {
                let activeSelectionObjects = [];
                event.target._objects.forEach((obj) => {
                    // // console.log(canvas.getObjects(), 'canvas.getObjects()');
                    let child = _.filter(canvas.getObjects(), (l) => {
                        return (l.parent === obj.parent && l.parent !== '-1' && (l.id && !l.id.includes('draggable-')) && !l.isParent);
                    });
                    if (child.length) {
                        const rectObject = _.find(this.canvas[this.activeCanvasIndex].getObjects(), {id: child[0].parent});
                        activeSelectionObjects.push(rectObject);
                        activeSelectionObjects = activeSelectionObjects.concat(child);
                    } else {
                        if (obj.id && !obj.id.includes('draggable-') && !obj.isParent) {
                            activeSelectionObjects.push(obj);
                        }
                    }
                    if (obj.ccTextRegion && obj.ccTextRegion.editRules && obj.ccTextRegion.editRules.length && obj.ccTextRegion.editRules[0].resizable === '0') {
                        resizable = false
                    }
                    if (obj.ccTextRegion && obj.ccTextRegion.editRules && obj.ccTextRegion.editRules.length && obj.ccTextRegion.editRules[0].movable === '0') {
                        movable = false
                    }
                    if (obj.ccImage && obj.ccImage.editRules && obj.ccImage.editRules.length && obj.ccImage.editRules[0].resizable === '0') {
                        resizable = false
                    }
                    if (obj.ccImage && obj.ccImage.editRules && obj.ccImage.editRules.length && obj.ccImage.editRules[0].movable === '0') {
                        movable = false
                    }
                    // if(obj.ccTextRegion || obj.ccImage) {
                    //     if (!((!obj.ccTextRegion.editRules || !obj.ccTextRegion.editRules.length || obj.ccTextRegion.editRules[0].resizable === '1') || (!obj.ccImage.editRules || !obj.ccImage.editRules.length || obj.ccImage.editRules[0].resizable === '1'))) {
                    //         resizable = false;
                    //     }
                    //     if (!((!obj.ccTextRegion.editRules || !obj.ccTextRegion.editRules.length || obj.ccTextRegion.editRules[0].movable === '1') || (!obj.ccImage.editRules || !obj.ccImage.editRules.length || obj.ccImage.editRules[0].movable === '1'))) {
                    //         movable = false;
                    //     }
                    // }
                });
                activeSelectionObjects = _.uniq(activeSelectionObjects, "id");
                if (!_.isEqual(activeSelectionObjects.sort(), event.target._objects.sort())) { /* If any new object is need to add */
                    canvas.discardActiveObject();
                    const sel = new fabric.ActiveSelection(activeSelectionObjects, {
                        canvas: canvas,
                    });
                    sel.setControlsVisibility({
                        mb: false,
                        mt: false,
                        ml: false,
                        mr: false
                    });
                    // lockMovementX
                    if (!resizable) {
                        sel.set({
                            lockScalingX: true,
                            lockScalingY: true
                        });
                    }
                    if (!movable) {
                        sel.set({
                            lockMovementX: true,
                            lockMovementY: true
                        });
                        sel.hoverCursor = 'not-allowed';
                    }
                    sel.set({hasRotatingPoint: false});
                    this.currentTextRegion = sel;
                    sel.setCoords();
                    canvas.setActiveObject(sel);
                    /* On click start drag group */
                    canvas.requestRenderAll();
                } else {
                    event.target.setControlsVisibility({mb: false, mt: false, ml: false, mr: false});
                    event.target.set({hasRotatingPoint: false});
                    if (!resizable) {
                        event.target.set({
                            lockScalingX: true,
                            lockScalingY: true
                        });
                    }
                    if (!movable) {
                        event.target.set({
                            lockMovementX: true,
                            lockMovementY: true
                        });
                        event.target.hoverCursor = 'not-allowed';
                    }
                    this.currentTextRegion = event.target;
                }
            }
            this.objectSelected(event, index);
            this.selectionTimeOut = setTimeout(() => {
                this.checkIntersectingWaterMark(event, index)
            }, 2000)
        });


        canvas.on('selection:cleared', () => {
            this.activeObject = undefined;
            this.objectNotSelected = true;
            this.showDelete = false;
            this.activeTextObject = undefined;
            this.lastImageObjectSelected = false;
            // this.lastSelectedObject = undefined;
            this.currentTextRegion = undefined;
            this.selectedObjFontsStyles = {
                fontFamily: {},
                fontSize: 10,
                fontAlign: 'center',
                fontWeight: 'normal',
                fontStyle: 'normal',
                underline: false,
                caps: false,
                Title: false,
                color: '#000000'
            };
        });

        canvas.on('selection:updated', event => {
            const type = event.target.get('type');

            // this.activeCanvasIndex = index;
            this.objectNotSelected = true;
            const selectedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
            if (selectedObj && type === 'image') {
                this.lastSelectedObject = selectedObj;
                this.lastImageObjectSelected = true;
                // this.imageEditorConfigs = {
                //     width: selectedObj.width * event.target.scaleX * (Number(this.selectedScale) / 100),
                //     height: selectedObj.height * event.target.scaleY * (Number(this.selectedScale) / 100)
                // };
            }
            if (selectedObj && type === 'CurvesText') {
                this.objectNotSelected = false;
                this.activeTextObject = event.target;
                this.activeLastIndex = index;
                if (selectedObj) {
                    let upercase = true;
                    let titleCase = false;
                    let letters = selectedObj.text || '';
                    for (let i = 0; i < letters.length; i++) {
                        if (letters[i] !== letters[i].toUpperCase()) {
                            upercase = false;
                        }
                    }
                    if (selectedObj.fontCharacterStyle === 'Normal') {
                        upercase = false;
                    }
                    if (selectedObj.fontCharacterStyle === 'Title') {
                        titleCase = true;
                    }
                    this.selectedObjFontsStyles = {
                        fontFamily: selectedObj.fontFamily,
                        fontSize: selectedObj.fontSize * selectedObj.scaleX,
                        fontAlign: selectedObj.textAlign || selectedObj.fontAlign,
                        fontWeight: selectedObj.fontWeight,
                        fontStyle: selectedObj.fontStyle,
                        underline: selectedObj.underline,
                        caps: upercase,
                        Title: titleCase,
                        color: this.customiseMenuSharedService.getRgbFromCmyk(selectedObj.fill)
                    };
                }
            }
            this.selectionTimeOut = setTimeout(() => {
                this.checkIntersectingWaterMark(event, index)
            }, 2000)
            this.objectSelected(event, index);
        });

        // let left1 = 0;
        // let top1 = 0;
        // let scale1x = 0;
        // let scale1y = 0;
        // let width1 = 0;
        // let height1 = 0;
        // let preventScaling = false;

        canvas.on('mouse:up', event => {
            const activeObject = event.target;
            if (activeObject && activeObject.get('type') === 'CurvesText') {
                activeObject.lockScalingX = false;
                activeObject.lockScalingY = false;
                canvas.renderAll();
                return;
            }
        });

        canvas.on('object:scaling', event => {
            clearTimeout(this.selectionTimeOut);
            // const el = event.target;
            // if (el && el.get('type') === 'CurvesText' && (el.fontSize * el.scaleX) >= 299) {
            //     el.lockScalingX = true;
            //     el.lockScalingY = true;
            //     canvas.renderAll();
            //     return;
            // }
            this.showDelete = true;
            this.checkIntersectingObject(event, index, false);
            this.objectNotSelected = true;
            const selectedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
            // const selectedScale = this.selectedScale;
            // const prevnetFn = () => {
            //     let obj = event.target;
            //     obj.setCoords();
            //     let brNew = obj.getBoundingRect();
            //
            //     if (((brNew.width + brNew.left) >= obj.canvas.width) || ((brNew.height + brNew.top) >= obj.canvas.height) || ((brNew.left < 0) || (brNew.top < 0))) {
            //         obj.left = left1;
            //         obj.top = top1;
            //         obj.scaleX = scale1x;
            //         obj.scaleY = scale1y;
            //         obj.width = width1;
            //         obj.height = height1;
            //         preventScaling = true;
            //     } else {
            //         left1 = obj.left;
            //         top1 = obj.top;
            //         scale1x = obj.scaleX;
            //         scale1y = obj.scaleY;
            //         width1 = obj.width;
            //         height1 = obj.height;
            //         preventScaling = false;
            //     }
            // };
            if (selectedObj && event.target.get('type') === 'CurvesText') {
                this.objectNotSelected = false;
                if (event.target.snapInRegion) {
                    this.customiseMenuPropertyService.editTextArea = {};
                } else {
                    this.customiseMenuPropertyService.editTextArea = event.target.ccTextRegion;
                    this.customiseMenuPropertyService.activeIndex = index;
                }
                if (selectedObj && event.transform && event.transform.action === 'scale') {
                    this.selectedObjFontsStyles = {
                        fontSize: event.target.fontSize * event.target.scaleX
                    };
                }/* else if (selectedObj && event.transform.action === 'scaleX') {
                    //prevnetFn();
                }*/
            } else if (event.target && event.target.type === 'rect' && event.target.isCropBox) {
                // need to contain crop box inside parent image
                this.restrictCropBoxInsideParentImageOnScale(event, index);
            }
        });
        //let lastScaledFontSize = 0;
        /* only when text scaling is done (horizontal scaling only)*/
        canvas.on('object:scaled', event => {
            // const el = event.target;
            // if (el && el.get('type') === 'CurvesText' && (el.fontSize * el.scaleX) >= 299) {
            //     el.lockScalingX = true;
            //     el.lockScalingY = true;
            //     canvas.renderAll();
            //     return;
            // }
            // if(event.target.type === 'image' && event.target.firstScale) {
            //     delete event.target.firstScale;
            // }
            if (event.target.type === 'image' && event.target.firstDrop) {
                delete event.target.firstDrop;
                event.target.firstScale = true;
            }
            let obj = event.target;
            obj.setCoords();
            let rect = obj.getBoundingRect();
            let repositioned = false;
            this.textRegionsToUpdate = [];
            // either group or single items with originPosition details
            if (!!event.target && !!event.target.originPosition) {
                let snapInRegion;   // quided region where moved obj belongs to
                if (!!event.target._objects && event.target._objects.length > 0 && event.target.type === 'activeSelection') {
                    const rectangle = event.target._objects.find(obj => {
                        return obj.type === 'rect' && !!obj.snapInRegion;
                    });
                    snapInRegion = !!rectangle ? rectangle.snapInRegion : undefined;
                } else {    // single item
                    snapInRegion = !!event.target.snapInRegion ? event.target.snapInRegion : undefined;
                }
                if (!!snapInRegion) {
                    // see if moved position is completely out of guided area, otherwise keep the new y value
                    if ((event.target.left < snapInRegion.x && event.target.aCoords.tr.x < snapInRegion.x)
                        || (event.target.left > snapInRegion.x + snapInRegion.width && event.target.aCoords.tr.x > snapInRegion.x + snapInRegion.width)
                        || event.target.top < snapInRegion.y || event.target.top > snapInRegion.y + snapInRegion.height) {
                        // if yes, move it back to origin position
                        event.target.left = event.target.originPosition.x;
                        event.target.top = event.target.originPosition.y;
                        event.target.setCoords();
                        this.canvas[index].discardActiveObject();
                    } else {    // inside guided region - just line up x position to left
                        // event.target.left = snapInRegion.x;
                        // const pointer = canvas.getPointer(event.e);
                        // let objectLeft = pointer.x;
                        // if (objectLeft <= snapInRegion.x + (snapInRegion.width / 4)) {
                        //     event.target.left = snapInRegion.x;
                        // } else if (objectLeft >= snapInRegion.x + ((snapInRegion.width / 4) * 3)) {
                        //     event.target.left = +snapInRegion.x + +snapInRegion.width - (+event.target.width * +event.target.scaleX);
                        // } else {
                        //     event.target.left = (snapInRegion.x + ((snapInRegion.width / 2))) - ((+event.target.width * +event.target.scaleX) / 2);
                        // }
                        let objectLeft = event.target.left + (+event.target.width / 2);
                        if (objectLeft <= snapInRegion.x + (snapInRegion.width / 4)) {
                            event.target.left = snapInRegion.x;
                        } else if (objectLeft >= snapInRegion.x + ((snapInRegion.width / 4) * 3)) {
                            event.target.left = +snapInRegion.x + +snapInRegion.width - +event.target.width;
                        } else {
                            event.target.left = (snapInRegion.x + ((snapInRegion.width / 2))) - (+event.target.width / 2);
                        }
                        event.target.top = event.target.aCoords.tl.y;
                        // need to take care overlapped items
                        this.rearrangeOverlappingObject(event, index);
                        event.target.setCoords();
                    }
                    repositioned = true;
                }
            }
            // clearTimeout(callTimeout);
            //
            // callTimeout = setTimeout(() => {
            //     // console.log('Enter 2000')
            // this.updateActiveTextRegion(true);
            // }, 1000);
            this.canvas[this.activeCanvasIndex].renderAll();
            if (event.target.get('type') === 'CurvesText') {
                this.objectNotSelected = false;
                const selectedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
                if (selectedObj && event.transform && event.transform.action === 'scale') {
                    // if (rect.left < 0
                    //     || rect.top < 0
                    //     || rect.left + rect.width > obj.canvas.width
                    //     || rect.top + rect.height > obj.canvas.height) {
                    //
                    //     obj.set('top', obj._stateProperties.top);
                    //     obj.set('left', obj._stateProperties.left);
                    //     obj.set('scaleX', obj._stateProperties.scaleX);
                    //     obj.set('scaleY', obj._stateProperties.scaleY);
                    //     obj.setCoords();
                    //     this.selectedObjFontsStyles = {
                    //         fontSize: lastScaledFontSize
                    //     };
                    // } else {
                    //     this.setFont({
                    //         fontSize: this.selectedObjFontsStyles.fontSize
                    //     });
                    //     lastScaledFontSize = this.selectedObjFontsStyles.fontSize;
                    // }
                    // this.setFont({
                    //     fontSize: this.selectedObjFontsStyles.fontSize
                    // });
                }
            } else if (event.target && event.target.type === 'image') {
                // canvas.discardActiveObject();
                //
                // const canvasObject = _.find(this.canvas[index].getObjects(), {ccImage: event.target.ccImage});
                // // console.log(event.target,'event.target');
                // // console.log(canvasObject,'canvasObject')
                event.target.zoomScale = event.target.scaleX;   //reset zoomScale on image resize
                this.imageDataOps(event.target, 'update', true);
                this.moveImageAndCropBoxTogether(event, index);     //when there is a crop box attached
            } else if (event.target && event.target.type === 'rect' && event.target.isCropBox) {
                // if it's cropBox it needs to be binded to parent image again
                this.bindImageAndCropBox(event.target, index);
            }

            event.target.setCoords();
            this.checkIntersectingWaterMark(event, index)
        });

        /* only when object removed */
        canvas.on('object:removed', event => {
            this.isCanvasChanged = true;

            // when crop box is removed - need to reset mode flag
            if (event.target && event.target.type === 'rect' && event.target.isCropBox) {
                this.isCropMode = false;
            } else if (event.target && event.target.type === 'image') {
                const cropBox = this.canvas[index].getObjects().find((obj: any) => {
                    if (!!obj.ccImageId && obj.isCropBox && obj.type === 'rect' && obj.ccImageId === event.target.ccImage.id) {
                        return obj;
                    }
                });
                if (!!cropBox) {  //this image has crop box on it - crop box needs to be deleted too
                    this.canvas[index].remove(cropBox);
                    this.isCropMode = false;
                }
            }
        });

        /* only when text is modified */
        canvas.on('object:modified', event => {
            // const el = event.target;
            // if (el && el.get('type') === 'CurvesText' && (el.fontSize * el.scaleX) >= 299) {
            //     el.lockScalingX = true;
            //     el.lockScalingY = true;
            //     canvas.renderAll();
            //     return;
            // }
            this.isCanvasChanged = true;
            /* If event is of activeSelection and that activeSelection don't have rectId all the activeSelection object need to updated in pdf */
            if (event.target.type === 'activeSelection') {
                // clearTimeout(callTimeout);
                //
                // callTimeout = setTimeout(() => {
                //     // console.log('Enter 2000')
                this.updateActiveTextRegion(event.target.rectId);
                // }, 1000);
            }
            if (event.target.type === 'CurvesText') {     // clicking group rectangle fires this event - should be prevented
                // this.objectNotSelected = false;
                // const selectedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
                // if (event.target && event.transform && event.transform.action === 'scale') {
                //     this.updateActiveTextRegion(false);
                // }
                this.updateActiveTextRegion(false);
                // event.target.ccTextRegion.x = event.target.aCoords.tl.x; //use top left corner value to get the valid one regardless of orginX //event.target.left;
                // event.target.ccTextRegion.y = event.target.top;
                // // // console.log(event.target.ccTextRegion, 'event.target.ccTextRegion');
                // event.target.ccTextRegion.textBlocks.forEach(textBlockData => {
                //     if (textBlockData.xmlText) {
                //         textBlockData.xmlText.forEach(textObj => {
                //             textObj.pointsize = event.target.fontSize.toString();
                //             textObj.color = event.target.fill; //this.customiseMenuService.getCmykFromRgb(event.target.fill);
                //             textBlockData.align = event.target.textAlign;
                //             textObj.font = event.target.fontFamily.split(',')[0];
                //             textObj.characterStyle = event.target.underline ? 'underline' : 'plain';
                //             if (event.target.fontWeight === 'bold') {
                //                 textObj.characterStyle = textObj.characterStyle + ' bold';
                //                 textObj.characterStyle = textObj.characterStyle.replace('plain ', '')
                //             }
                //             if (event.target.fontStyle === 'italic') {
                //                 textObj.characterStyle = textObj.characterStyle + ' italic';
                //                 textObj.characterStyle = textObj.characterStyle.replace('plain ', '')
                //             }
                //             textObj.vfield.forEach(vfieldData => {
                //                 vfieldData.value = event.target.text;
                //             });
                //
                //             // multilines - need to increase height of textregion
                //             if (!!event.target.textLines && event.target.textLines.length > 1) {
                //                 event.target.ccTextRegion.height = '' + (+event.target.fontSize * event.target.textLines.length + +event.target.fontSize);
                //             } else {
                //                 event.target.ccTextRegion.height = '' + (+event.target.fontSize * 2);
                //             }
                //         });
                //     }
                // });
                // if (!this.updatedOnAnotherEvent && event.target.ccTextRegion && event.target.type === 'CurvesText') {
                //     this.textRegionsToUpdate.push(event.target.ccTextRegion);
                // }
                // queueScheduler is not working in this case - when :scaled or :editing:exited then :modified events fire update calls
            }

            // if (this.textRegionsToUpdate.length > 0) {  // prevent duplicate api calls on setFont
            //     queueScheduler.schedule(() => {
            //         this.updatedOnAnotherEvent = true;    // flag to prevent another api call from :modified event
            //         this.customiseMenuService.updateBulkTextRegionInJob(
            //             this.jTemplateId, index + 1, this.textRegionsToUpdate, this.security_token).subscribe((updatedTextRes: RestResponse) => {
            //             this.updatedOnAnotherEvent = false;
            //             //// console.log(updatedTextRes.instance, 'updated textregions');
            //             this.textRegionsToUpdate = [];
            //         });
            //     });
            // }
            event.target.setCoords();
        });

        /* only when object added */
        canvas.on('object:added', event => {
            this.isCanvasChanged = true;
            if (event.target.type === 'image' && !event.target.noNeedToSubmit) {
                this.imageDataOps(event.target, 'insert');  // brand new image only
                if (this.activeImageRegionHover) {
                    // event.target.scale(event.target.zoomScale);
                    let calcNewLeft = (Number(this.activeImageRegionHover.width) - Number(+event.target.width * event.target.zoomScale)) / 2;
                    let calcNewTop = (Number(this.activeImageRegionHover.height) - Number(+event.target.height * event.target.zoomScale)) / 2;
                    calcNewLeft = calcNewLeft < 0 ? 0 : calcNewLeft;
                    calcNewTop = calcNewTop < 0 ? 0 : calcNewTop;
                    event.target.set({
                        top: Number(this.activeImageRegionHover.y) + calcNewTop,
                        left: Number(this.activeImageRegionHover.x) + calcNewLeft
                    });
                    // event.target.bringToFront();
                    event.target.setCoords();
                }

            }
            const canvasObject = _.find(this.canvas[index].getObjects(), {isWaterMark: true});
            if (canvasObject.opacity < this.canvas[index].getObjects().length) {
                canvasObject.set({opacity: this.canvas[index].getObjects().length + 1});
                this.canvas[index].bringToFront(canvasObject);
            } else {
                canvasObject.set({opacity: canvasObject.opacity + 1});
                this.canvas[index].bringToFront(canvasObject);
            }
            this.canvas[index].renderAll();
        });
        canvas.on('text:editing:entered', event => {
            clearTimeout(this.selectionTimeOut);
            const type = event.target.get('type');
            // this.activeCanvasIndex = index;
            this.showDelete = false;
            this.objectNotSelected = true;
            const selectedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
            if (selectedObj && type === 'CurvesText') {
                this.objectNotSelected = false;
                if (selectedObj) {
                    let upercase = true;
                    let titleCase = false;
                    let letters = event.target.text;
                    for (let i = 0; i < letters.length; i++) {
                        if (letters[i] !== letters[i].toUpperCase()) {
                            upercase = false;
                        }
                    }
                    if (event.target.fontCharacterStyle === 'Normal') {
                        upercase = false;
                    }
                    if (event.target.fontCharacterStyle === 'Title') {
                        titleCase = true;
                    }
                    this.selectedObjFontsStyles = {
                        fontFamily: selectedObj.fontFamily,
                        fontSize: selectedObj.fontSize * selectedObj.scaleX,
                        fontAlign: selectedObj.textAlign || selectedObj.fontAlign,
                        fontWeight: selectedObj.fontWeight,
                        fontStyle: selectedObj.fontStyle,
                        underline: selectedObj.underline,
                        caps: upercase,
                        Title: titleCase,
                        color: this.customiseMenuSharedService.getRgbFromCmyk(selectedObj.fill)
                    };
                }
            }

            if (type === 'CurvesText') {
                // background colour change needed to avoid confusion when overlapped with another text obj
                if (event.target.fill.replace(/\s/g, '') === 'rgb(255,255,255)') { // in case of white and need to cover rgb(255,255,255) & rgb(255, 255, 255)
                    event.target.set('backgroundColor', '#A9A9A9'); // dark grey
                } else {
                    event.target.set('backgroundColor', '#FFFFFF'); // otherwise white background
                }

                if (!!event.target.parent) {
                    event.target.previousHeight = event.target.height;
                }
            }
        });

        canvas.on('text:editing:exited', event => {
            // this.activeCanvasIndex = index;
            event.target.set('backgroundColor', undefined);

            this.textRegionsToUpdate = [];     // repositioned texts need to be submitted back to the server

            // when text edit is done and any size change needs to be reflected to other child element and parent rectangle
            if (event.target.type === 'CurvesText' && !!event.target.parent) {
                if (!!event.target.previousHeight) {
                    let previousTopPlusHeight: number = 0;
                    if (event.target.previousHeight < event.target.height) {
                        let needToIncreaseRect = false;
                        const increase = event.target.height - event.target.previousHeight;

                        if (!!event.target.parent && event.target.parent !== '-1') { // when new lines added to those text objs inside group menu
                            this.canvas[index].forEachObject((obj) => {
                                // apply changes to other child texts in group menu
                                if (!!obj.parent && obj.type === 'CurvesText' && obj.parent === event.target.parent && obj.top > event.target.top + 5) {
                                    if (obj.top < event.target.aCoords.bl.y - 4) {   // if item below has been already increased, need to see if current change makes any effect
                                        obj.top = obj.top + increase;
                                        obj.setCoords();
                                        needToIncreaseRect = true;

                                        // y position shifted down for size increase on item above - need to update this textregion via api
                                        obj.ccTextRegion.x = obj.aCoords.tl.x;
                                        obj.ccTextRegion.y = obj.top;
                                        this.textRegionsToUpdate.push(obj.ccTextRegion);
                                    }
                                }
                                // and parent rect
                                if (!!obj.id && obj.type === 'rect' && obj.id === event.target.parent) {
                                    if (needToIncreaseRect /*when below item increased*/
                                        //|| (increase > 0 && event.target.height > obj.height)/*when target item gets bigger than rect*/
                                        || (increase > 0 && event.target.aCoords.bl.y > obj.aCoords.bl.y)/*when target item gets bigger than rect*/) {
                                        obj.height = obj.height + increase;
                                        obj.setCoords();

                                        previousTopPlusHeight = obj.top + event.target.previousHeight;
                                    }
                                }
                            });

                        } else {    // single text item
                            previousTopPlusHeight = event.target.top + event.target.previousHeight;
                        }


                        // will exclude already updated texts and rect from above group code, also exclude pre-defined text on load
                        if (previousTopPlusHeight > 0 && increase > 0) {
                            this.canvas[index].forEachObject((obj) => {
                                // items/groups below this group may need to be shifted as well if they are overlapping
                                if (!!obj.id && obj.id.indexOf('draggable') === -1
                                    && obj !== event.target && obj.top > previousTopPlusHeight
                                    && obj.id !== event.target.parent && !obj.isPreloaded
                                    && (!obj.parent || obj.parent === '-1' || obj.parent !== event.target.parent)) {

                                    obj.top = obj.top + increase;
                                    if (obj.ccTextRegion) {
                                        obj.ccTextRegion.y = obj.top;
                                        this.textRegionsToUpdate.push(obj.ccTextRegion);
                                    }
                                    obj.setCoords();
                                }
                            });
                        }

                        // NOTE update api call on :modified event
                        // use bulk update to save updated textregions
                        /*if (this.textRegionsToUpdate.length > 0) {
                            queueScheduler.schedule(() => {
                                this.updatedOnAnotherEvent = true;    // flag to prevent another api call from :modified event
                                this.customiseMenuService.updateBulkTextRegionInJob(
                                    this.jTemplateId, index + 1, textRegionsToUpdate, this.security_token).subscribe((updatedTextRes: RestResponse) => {
                                    this.updatedOnAnotherEvent = false;
                                    //// console.log(updatedTextRes.instance, 'updated textregions from text:editing:exited');
                                });
                            });

                        }*/

                        canvas.requestRenderAll();
                    }
                }
            }
        });

        canvas.on('text:changed', event => {
            if (this.selectedObjFontsStyles.caps) {
                event.target.text = event.target.text.toUpperCase();
            } else if (this.selectedObjFontsStyles.Title) {
                event.target.text = this.customiseMenuSharedService.titleCase(event.target.text);
            } else {

            }
        });
    }

    /** remove events binding - !!! need to include all events from bindCanvasEvents() */
    unbindCanvasEvents(canvas: any, index: number) {
        canvas.off('mouse:down');
        canvas.off('mouse:dblclick');
        canvas.off('dragover');
        canvas.off('object:moving');
        canvas.off('object:moved');
        canvas.off('object:rotating');
        canvas.off('object:rotated');
        canvas.off('object:selected');
        canvas.off('selection:created');
        canvas.off('selection:cleared');
        canvas.off('selection:updated');
        canvas.off('object:scaling');
        canvas.off('object:scaled');
        canvas.off('object:removed');
        canvas.off('object:modified');
        canvas.off('object:added');
        canvas.off('text:editing:entered');
        canvas.off('text:editing:exited');
        canvas.off('text:changed');
        canvas.off('after:render');
    }

    // updateBulkTextRegionInJob(index: number, textRegionsToUpdate: any): void {
    //     // console.log('update ajaxCalls', JSON.stringify(this.ajaxCalls));
    //     this.customiseMenuService.updateBulkTextRegionInJob(
    //         this.jTemplateId, index + 1, textRegionsToUpdate, this.security_token).subscribe((updatedTextRes: RestResponse) => {
    //         // console.log(updatedTextRes.instance, 'updated textregions');
    //         this.ajaxCalls.pop();
    //         if (this.ajaxCalls.length) {
    //             this.updateBulkTextRegionInJob(index, textRegionsToUpdate);
    //         }
    //     });
    // }

    /** Add text on canvas by clicking body text button of canvas dropdown */
    addTextRegion(object, x?, y?) {
        // cancel any cropping operation
        this.cancelCrop();

        const data: TextRegion = {
            vJInterParaSpace: '0',
            angle: '0.000000',
            baselineFirstOffsetMetric: 'ascent',
            baselineMinFirstOffset: '0',
            firstBaselineOffset: object.fontSize,
            height: '57.401611328125',
            id: '-1',
            shape: 'rect',
            textInset: '0,0,0,0',
            valign: 'top',
            width: '' + (Number(object.textValue.length) * Number(object.fontSize)), // should be the same as fabric text width from addFabricTextWithTextRegion()
            x: x || '10',
            y: y || '10',
            parent: '-1',
            textBlocks: [{
                align: 'center',
                extraParagraphSpacing: '0',
                firstLineIndent: '0',
                id: '0',
                keepTogether: 'false',
                leading: object.fontSize, //'28.8',
                leftIndent: '0',
                rightIndent: '0',
                spaceAfter: '0',
                spaceBefore: '0',
                tabStops: '1\\36\\left\\\\\\',
                xmlText: [{
                    baselineShift: '0.000000',
                    characterStyle: 'plain',
                    color: 'rgb(0, 0, 0)',
                    font: object.fontFamily,
                    horizontalScale: '100.000000',
                    pointsize: object.fontSize,
                    vfield: [{
                        display: 'true',
                        editRowHeight: '1',
                        editable: '1',
                        id: '12345:0',
                        index: '1',
                        name: object.textValue,
                        type: 'text',
                        visible: 'true',
                        styleID: '1',
                        elementIndex: '1',
                        value: object.textValue
                    }]
                }]
            }
            ]
        };
        /*  If index is passed initially all the task will perform on index not in activeIndex */
        // will place fabric text obj first then will submit to the backend
        const fabricText = this.addFabricTextWithTextRegion(data, false, '-1', undefined, undefined, undefined, this.activeCanvasIndex, true);
        this.insertTextRegionRecursively([fabricText], 0, false);

        // make it edit mode on free text insert, which will ensure it can be seen, even if it is black font on black background
        fabricText.canvas.setActiveObject(fabricText);
        fabricText.enterEditing();
        if (fabricText.text.length > 0) {  // cursor position to the end of text with selection
            fabricText.setSelectionStart(fabricText.text.length);
            fabricText.setSelectionEnd(fabricText.text.length);
        }
    }

    /** USE it to add fabric text onto canvas with menu item and submit textRegions to backend
     * invoked by selectMenuStyle() or drag/drop on style choice
     * menu style will have one or more textRegions depending on the number of vfields - i.e. one vfield creates a matching textRegion */
    placeTextRegionsForSelectedStyle(styleIndex: any, emptyTextRegion?: any) {
        // cancel any cropping operation
        this.cancelCrop();

        this.textEditorCursorStyle = 'wait';
        this.canvas[this.activeCanvasIndex].discardActiveObject();

        let newTexts: any[] = [];
        const textRegions: TextRegion[] = this.groupTextRegions.get('' + styleIndex);    // need to cover both number and string
        const parentId = textRegions.length > 1 ? '' + Date.now() + '' + Math.floor(Math.random() * Math.floor(1000)) : '-1';
        const lockMovement = textRegions.length > 1;

        // TODO for the time being, the first empty block will be used to place styled menu by default on click - only when there is one empty region ???
        if (!emptyTextRegion) {
            //streams/dev-cm/GoWorks/src/app/main/customise-menu/customise-menu.component.ts#140
            if (this.lastEmptyTextRegion && this.gridTextRegionsByGrid[this.activeCanvasIndex].filter(data => data.id === this.lastEmptyTextRegion.id).length) {
                emptyTextRegion = this.lastEmptyTextRegion;
            } else {
                for (let idx = 0; idx < this.gridTextRegionsByGrid[this.activeCanvasIndex].length; idx++) {
                    let region = this.gridTextRegionsByGrid[this.activeCanvasIndex][idx];
                    if (!region.textBlocks) {
                        emptyTextRegion = region;
                        break;
                    }
                }
            }
        }

        //queue
        let snapInRegion;   // guided area's position and size
        if (!!emptyTextRegion && !!emptyTextRegion.id) {    // hover case gives blank object {}, need to check id
            snapInRegion = {
                x: +emptyTextRegion.x,
                y: +emptyTextRegion.y,
                width: +emptyTextRegion.width,
                height: +emptyTextRegion.height
            };

            if (textRegions.length === 1) {   // single item needs to occupy the full width
                textRegions[0].width = emptyTextRegion.width;
            }
            let largestTopPlusHeight = 0;
            //let totalHeight = +emptyTextRegion.y;
            for (const item of this.canvas[this.activeCanvasIndex].getObjects()) {
                if (item && !!item.id && !!item.parent && item.type === 'CurvesText' && !item.isExisting && item.rectId === emptyTextRegion.id && (item.left < (+emptyTextRegion.x + +emptyTextRegion.width)) && (item.left + item.width > (+emptyTextRegion.x)) && (item.top < (+emptyTextRegion.y + +emptyTextRegion.height)) && (item.top + item.height > (+emptyTextRegion.y))) {
                    // then find the biggest top+height value
                    if (largestTopPlusHeight < item.top + item.height) {
                        largestTopPlusHeight = item.top + item.height;
                        if (largestTopPlusHeight + 10 >= (+emptyTextRegion.y + +emptyTextRegion.height)) {
                            this.displayToaster('warning', [this.getTranslateWord('Itlookslikethedesignatedareaisfullyused')]);
                            this.textEditorCursorStyle = 'pointer'; //temporary measure to prevent overlapping on menu texts
                            return; // no need to go further
                        }
                    }
                    //totalHeight = totalHeight + (item.aCoords.bl.y - item.aCoords.tl.y);
                }
            }
        } else {
            this.textEditorCursorStyle = 'pointer'; //temporary measure to prevent overlapping on menu texts
            // there is no designated area to put menu
            this.displayToaster('warning', [this.getTranslateWord('Thereisnodesignatedregiontoplaceitemonthispage')]);
            return; // no need to go further
        }
        //insert fabric texts onto canvas first
        newTexts = this.addTextsBeforeSubmit(textRegions, lockMovement, parentId, emptyTextRegion, snapInRegion, undefined, true);

        // TODO how to deal with dynamic change of observable ???
        /*of(this.addTextsBeforeSubmit(textRegions, lockMovement, parentId, emptyTextRegion, snapInRegion)).pipe(
            observeOn(queueScheduler),
            //concatAll()
            //delayWhen(event => interval(this.textInProgress ? 1000: 0))
        ).subscribe( texts => {
            this.insertTextRegionRecursively(texts, 0);
        });*/

        // 3. insert text regions to the back-end
        this.insertTextRegionRecursively(newTexts, 0, true);
    }

    /** insert fabric texts onto canvas (as a group when necessary) before server submission */
    addTextsBeforeSubmit(textRegions: TextRegion[], lockMovement: boolean, parentId: string, emptyTextRegion?: any, snapInRegion?: any, fabricTexts?: any, isNotExting?: boolean, canvasIndex?: number) {

        //return new Observable(subscriber => {
        //this.textInProgress = true;
        let newTexts: any[] = [];
        let groupEditRules: EditRules = this.customiseMenuSharedService.buildEditRules();
        if (!!fabricTexts) {
            newTexts = fabricTexts;
        } else {
            // 1. add fabric text to canvas for matching textRegion
            textRegions.forEach((textRegion: TextRegion) => {
                // each text region has only 1 child text block, 1 xmlText and 1 vfield
                let fabricText;
                if (isNotExting) {
                    fabricText = this.addFabricTextWithTextRegion(textRegion, lockMovement, parentId, emptyTextRegion, undefined, undefined, undefined, false, true);
                } else {
                    fabricText = this.addFabricTextWithTextRegion(textRegion, lockMovement, parentId, emptyTextRegion, undefined, undefined, undefined);
                }
                fabricText.snapInRegion = snapInRegion;
                fabricText.isStyledText = true;
                newTexts.push(fabricText);

                // every text obj in the same group shares the same rules
                if (!!textRegion.editRules) {
                    groupEditRules = textRegion.editRules[0];
                }
            });

            groupEditRules = !!textRegions[0].editRules && textRegions[0].editRules.length > 0 ? textRegions[0].editRules[0] : this.customiseMenuSharedService.buildEditRules();
        }

        // 2. when there are more than 1 texts, use rectangle to group them together
        if (newTexts.length > 1) {
            // need to find boundary rectangle size
            let largetstWidth = newTexts[newTexts.length - 1].aCoords.tl.x/*left*/ + newTexts[newTexts.length - 1].width - newTexts[0].aCoords.tl.x/*left*/;    // assume it's one liner by default
            let largetstHeight = newTexts[0].height;    // assume it's one liner by default
            let previousY = newTexts[0].top;
            // check more than 1 lines required and adjust containing rectangle size
            let textRegions = [];
            newTexts.forEach((fabricText: any) => {
                const width = fabricText.aCoords.tl.x/*left*/ + fabricText.width - newTexts[0].aCoords.tl.x/*left*/;
                if (largetstWidth < width) {
                    largetstWidth = width;
                }

                if (previousY < fabricText.top) {
                    previousY = fabricText.top;
                    largetstHeight = fabricText.top + fabricText.height - newTexts[0].top;
                }
                if (fabricText.ccTextRegion) {
                    textRegions.push(fabricText.ccTextRegion);
                }
                fabricText.snapInRegion = snapInRegion;
            });
            const boundaryRect = new fabric.Rect({
                left: newTexts[0].aCoords.tl.x,  //Update to consider letiation on originX  newTexts[0].left,
                top: newTexts[0].top,
                width: largetstWidth,
                height: largetstHeight, // newTexts[0].height,
                opacity: 0,
                // fill : '#000000',
                // borderColor: '#1ac9f0',
                lockMovementX: true,  // prevent it from moving by itself
                lockMovementY: true,  // prevent it from moving by itself
                id: parentId,         // parent value of child text instances
                isParent: true,
                snapInRegion: snapInRegion,  // keep guided area's position and size
                groupEditRules: groupEditRules  // will use to apply rules to group selection
            });
            if (canvasIndex || canvasIndex === 0) {
                this.canvas[canvasIndex].add(boundaryRect);
            } else {
                this.canvas[this.activeCanvasIndex].add(boundaryRect);
            }


        } else {    // single item - extend width to the same as empty textregion
            newTexts[0].width = emptyTextRegion.width;
            newTexts[0].snapInRegion = snapInRegion;  // keep guided area's position and size

        }
        if (canvasIndex || canvasIndex === 0) {
            this.canvas[canvasIndex].renderAll();
        } else {
            this.canvas[this.activeCanvasIndex].renderAll();
        }


        //    subscriber.next(newTexts);
        //    subscriber.complete();
        //});
        //this.textInProgress = false;
        return newTexts;
    }

    /** when inserting textRegion in a row as a group, ensure previous one is submitted successfully */
    insertTextRegionRecursively(fabricTexts: any[], i: number, doCall: boolean = true) {
        // // console.log('Insert ajaxCalls', JSON.stringify(this.ajaxCalls));
        if (fabricTexts.length) {
            this.groupText = [];

            // Arial backup font added from textEditorCompoent to be removed for server submission
            fabricTexts.forEach((text, index) => {
                const currentFont = fabricTexts[index].ccTextRegion.textBlocks[0].xmlText[0].font;
                if (currentFont.endsWith(',Arial')) {
                    fabricTexts[index].ccTextRegion.textBlocks[0].xmlText[0].font = currentFont.replace(',Arial', '');
                }


                // convert rgb back to cmyk - NO need to convert anymore
                //const currentColor = fabricTexts[i].ccTextRegion.textBlocks[0].xmlText[0].color;
                //// console.log(currentColor, 'currentColor');
                //fabricTexts[i].ccTextRegion.textBlocks[0].xmlText[0].color = currentColor;//this.customiseMenuService.getCmykFromRgb(currentColor);


                fabricTexts[index].ccTextRegion.textBlocks[0].xmlText[0].vfield[0].constraints = undefined; //no need to pass this info

                // need to use top left corner value to get the valid one regardless of originX
                fabricTexts[index].ccTextRegion.x = fabricTexts[index].aCoords.tl.x;
                this.groupText.push(fabricTexts[index].ccTextRegion)
            });
            if (fabricTexts.length === this.groupText.length) {
                queueScheduler.schedule(() => {
                    this.customiseMenuService.insertBulkTextRegionInJob(this.jTemplateId, this.activeCanvasIndex + 1, this.groupText, this.security_token).subscribe((res: RestResponse) => {
                        if (res.instance) {
                            this.groupText.forEach((text, index) => {
                                let tabstop = undefined;
                                if (fabricTexts[index].ccTextRegion.textBlocks[0].xmlText[0].tabStop) {
                                    tabstop = JSON.parse(JSON.stringify(fabricTexts[index].ccTextRegion.textBlocks[0].xmlText[0].tabStop));
                                }
                                fabricTexts[index].ccTextRegion = res.instance[text.id] as TextRegion;   // casting
                                if (tabstop) {
                                    fabricTexts[index].ccTextRegion.textBlocks[0].xmlText[0].tabStop = tabstop;
                                }
                                fabricTexts[index].id = res.instance[text.id].id;
                            });
                            this.textEditorCursorStyle = 'pointer'; //temporary measure to prevent overlapping on menu texts
                        }
                    });
                });

                // this.customiseMenuService.insertBulkTextRegionInJob(this.jTemplateId, this.activeCanvasIndex + 1, this.groupText, this.security_token).subscribe((res: RestResponse) => {
                //     this.groupText.forEach((text, index) => {
                //         fabricTexts[index].ccTextRegion = res.instance[text.id] as TextRegion;   // casting
                //         fabricTexts[index].id = res.instance[text.id].id;
                //     });
                //     if (doCall) {
                //         this.ajaxCalls.pop();
                //         if (this.ajaxCalls.length) {
                //             this.insertTextRegionRecursively(fabricTexts, i + 1);
                //         }
                //     }
                // });

                // this.queue.subscribe(async data => {
                //     await data.subscribe(async res => {
                //         await this.groupText.forEach((text, index) => {
                //             fabricTexts[index].ccTextRegion = res.instance[text.id] as TextRegion;   // casting
                //             fabricTexts[index].id = res.instance[text.id].id;
                //         });
                //         res.complete();
                //     });
                // });
                // this.queue.next(this.customiseMenuService.insertBulkTextRegionInJob(this.jTemplateId, this.activeCanvasIndex + 1, this.groupText, this.security_token));

                // this.insertBulkTextRegionInJob().then((res: RestResponse) => {
                //     this.groupText.forEach((text, index) => {
                //         fabricTexts[index].ccTextRegion = res.instance[text.id] as TextRegion;   // casting
                //         fabricTexts[index].id = res.instance[text.id].id;
                //     });
                // });
            }
            //// console.log(fabricTexts[i].ccTextRegion);
            // this.customiseMenuService.insertTextRegionInJob(this.jTemplateId, this.activeCanvasIndex + 1, fabricTexts[i].ccTextRegion, this.security_token).subscribe((res: RestResponse) => {
            //     this.canvasObject = [];
            //     if (res.statusCode === 200) {
            //         fabricTexts[i].ccTextRegion = res.instance as TextRegion;   // casting
            //         fabricTexts[i].id = res.instance.id;    // !!! set textregion id value to fabric test
            //         // console.log(fabricTexts[i]);
            //
            //         this.insertTextRegionRecursively(fabricTexts, i + 1);
            //     } else {
            //         // TODO may change border colour or something and as user to delete and retry
            //     }
            // });
        }
    }

    /** Delete any object of grid page in canvas */
    removeObject() {
        const doomedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
        if (doomedObj && (doomedObj.type === 'image')) {
            if (!doomedObj.ccImage.editRules || !doomedObj.ccImage.editRules.length || doomedObj.ccImage.editRules && doomedObj.ccImage.editRules.length && doomedObj.ccImage.editRules[0].deletable === '1') {
                this.canvas[this.activeCanvasIndex].remove(doomedObj);
                this.canvas[this.activeCanvasIndex].renderAll();
                this.imageDataOps(doomedObj, 'delete');
            }
            return;
        }

        if (doomedObj) {
            if (!doomedObj.isEditing) {
                if ((!!doomedObj.groupEditRules && doomedObj.groupEditRules.deletable === '1') /*grouped texts*/
                    || (!!doomedObj.ccTextRegion && (!doomedObj.ccTextRegion.editRules || !doomedObj.ccTextRegion.editRules.length || doomedObj.ccTextRegion.editRules[0].deletable === '1')) /*single text*/) {
                    const activeObject = this.canvas[this.activeCanvasIndex].getActiveObject();
                    // How to delete multiple objects?
                    // if(activeObject !== null && activeObject.type === 'rectangle') {
                    if (activeObject !== null) {
                        if (activeObject._objects) {
                            if (this.canvas[this.activeCanvasIndex].getActiveObject()) {
                                this.canvas[this.activeCanvasIndex].discardActiveObject();
                            }
                            let textRegions = [];
                            activeObject._objects.forEach(obj => {
                                if (obj.ccTextRegion) {
                                    textRegions.push(obj.ccTextRegion.id)
                                }
                                this.canvas[this.activeCanvasIndex].remove(obj);
                            });
                            if (textRegions.length) {
                                // if (!this.ajaxCalls.length) {
                                //     this.ajaxCallCounter = 0;
                                //     this.deleteBulkJobTextRegion(textRegions);
                                // }
                                // this.ajaxCalls.push(this.ajaxCallCounter++);

                                queueScheduler.schedule(() => {
                                    this.customiseMenuService.deleteBulkJobTextRegion(this.jTemplateId, this.activeCanvasIndex + 1, textRegions, this.security_token).subscribe(res => {
                                        // // console.log(res, 'res');
                                    });
                                });
                            }
                        } else {
                            this.canvas[this.activeCanvasIndex].remove(activeObject);
                            this.canvas[this.activeCanvasIndex].renderAll();
                            if (activeObject.ccTextRegion) {
                                this.customiseMenuService.deleteJobTextRegion(this.jTemplateId, this.activeCanvasIndex + 1, activeObject.ccTextRegion.id, this.security_token).subscribe(res => {
                                    // // console.log(res, 'res');
                                });
                            }
                        }
                    }
                } else {
                    const activeObject = this.canvas[this.activeCanvasIndex].getActiveObject();
                    let textRegions = [];
                    let imageRegions = [];
                    let isNotDeletable = false;
                    if (activeObject._objects) {
                        activeObject._objects.forEach((obj, index) => {
                            if (obj.ccTextRegion && obj.ccTextRegion.editRules && obj.ccTextRegion.editRules.length && obj.ccTextRegion.editRules[0].deletable === '0') {
                                isNotDeletable = true;
                            }
                            if (obj.ccImage && obj.ccImage.editRules && obj.ccImage.editRules.length && obj.ccImage.editRules[0].deletable === '0') {
                                isNotDeletable = true;
                            }
                        });
                        if (isNotDeletable) {
                            if (!doomedObj.rectId) {
                                this.displayToaster('error', [`You can not delete item as one of the item doesn't allow deleting.`])
                            }
                        } else {
                            this.canvas[this.activeCanvasIndex].discardActiveObject();
                            activeObject._objects.forEach((obj, index) => {
                                if (obj.ccTextRegion && (!obj.ccTextRegion.editRules || !obj.ccTextRegion.editRules.length || obj.ccTextRegion.editRules[0].deletable === '1')) { // ActiveSelection contain text
                                    textRegions.push(obj.ccTextRegion.id)
                                } else if (obj.ccImage && (!obj.ccImage.editRules || !obj.ccImage.editRules.length || obj.ccImage.editRules[0].deletable === '1')) { // ActiveSelection contain Image
                                    // this.imageDataOps(obj, 'delete');
                                    imageRegions.push(obj.ccImage.id)
                                }
                                this.canvas[this.activeCanvasIndex].remove(obj);
                            });
                            if (textRegions.length) {
                                this.customiseMenuService.deleteBulkJobTextRegion(this.jTemplateId, this.activeCanvasIndex + 1, textRegions, this.security_token).subscribe(res => {
                                    // // console.log(res, 'res');
                                });
                            }
                            if (imageRegions.length) {
                                this.customiseMenuService.deleteImageInGrid(this.jTemplateId, this.activeCanvasIndex + 1, imageRegions, this.security_token).subscribe(res => {
                                    // // console.log(res, 'res');
                                });
                            }
                        }
                    }
                }
            }
        }
    }

    /* When arrows key down then this function is called to update position based on key pressed in canvas */
    moveObject(key) {
        const activeIndex = this.canvas[this.activeCanvasIndex].getActiveObject() ? this.activeCanvasIndex : this.activeLastIndex;
        const activeObject = this.canvas[activeIndex].getActiveObject();
        let movable = true
        if (activeObject) {
            // if(obj.ccTextRegion && obj.ccTextRegion.editRules && obj.ccTextRegion.editRules.length && obj.ccTextRegion.editRules[0].deletable === '0'){
            //     isNotDeletable = true;
            // }
            // if(obj.ccImage && obj.ccImage.editRules && obj.ccImage.editRules.length && obj.ccImage.editRules[0].deletable === '0'){
            //     isNotDeletable = true;
            // }
            if (activeObject._objects && activeObject._objects.length) {
                activeObject._objects.forEach((obj) => {
                    if (obj.ccTextRegion && obj.ccTextRegion.editRules && obj.ccTextRegion.editRules.length && obj.ccTextRegion.editRules[0].movable === '0') {
                        movable = false;
                    }
                    if (obj.ccImage && obj.ccImage.editRules && obj.ccImage.editRules.length && obj.ccImage.editRules[0].movable === '0') {
                        movable = false;
                    }
                })
            } else {
                if (activeObject.ccTextRegion && activeObject.ccTextRegion.editRules && activeObject.ccTextRegion.editRules.length && activeObject.ccTextRegion.editRules[0].movable === '0') {
                    movable = false;
                }
                if (activeObject.ccImage && activeObject.ccImage.editRules && activeObject.ccImage.editRules.length && activeObject.ccImage.editRules[0].movable === '0') {
                    movable = false;
                }
            }
            if (movable) {
                if (key === 37 || key === 52) {
                    if (activeObject.snapInRegion) {
                        if (+activeObject.snapInRegion.x < activeObject.left - 1) {
                            activeObject.left = activeObject.left - 1;
                        }
                    } else {
                        activeObject.left = activeObject.left - 1;
                    }
                } else if (key === 38 || key === 56) {
                    if (activeObject.snapInRegion) {
                        if (+activeObject.snapInRegion.y < activeObject.top - 1) {
                            activeObject.top = activeObject.top - 1;
                        }
                    } else {
                        activeObject.top = activeObject.top - 1;
                    }
                } else if (key === 39 || key === 54) {
                    if (activeObject.snapInRegion) {

                        if ((+activeObject.width + activeObject.left + 1) < (+activeObject.snapInRegion.x + +activeObject.snapInRegion.width)) {
                            activeObject.left = activeObject.left + 1;
                        }
                    } else {
                        activeObject.left = activeObject.left + 1;
                    }
                } else if (key === 40 || key === 50) {
                    if (activeObject.snapInRegion) {
                        if ((+activeObject.height + activeObject.top + 1) < (+activeObject.snapInRegion.y + +activeObject.snapInRegion.height)) {
                            activeObject.top = activeObject.top + 1;
                        }
                    } else {
                        activeObject.top = activeObject.top + 1;
                    }
                }
                activeObject.setCoords();
                this.canvas[activeIndex].renderAll();
            } else {
                this.displayToaster('error', [`You can not move item as one of the item doesn't allow moving.`])
            }
        }
    }

    public callTimeout;

    /* When arrows key up then this function is called to pass new position data in api */
    updateActiveTextRegion(isRect: Boolean) {
        const activeIndex = this.canvas[this.activeCanvasIndex].getActiveObject() ? this.activeCanvasIndex : this.activeLastIndex;
        const activeObject = this.canvas[activeIndex] && this.canvas[activeIndex].getActiveObject();
        if (activeObject && (activeObject.type === 'activeSelection' || activeObject.type === 'CurvesText')) {
            if (activeObject.type === 'activeSelection' && !activeObject.text) {
                this.canvas[activeIndex].discardActiveObject();
                // canvas.renderAll();
                this.textRegionsToUpdate = [];
                const activeSelectionObjects = [];
                activeObject._objects.forEach(obj => {
                    if (obj.type === 'CurvesText') {
                        const canvasObject = _.find(this.canvas[activeIndex].getObjects(), {id: obj.id});
                        activeSelectionObjects.push(canvasObject);
                        this.traverseTextRegion(canvasObject);
                        // obj.ccTextRegion.x = canvasObject.aCoords.tl.x;
                        // obj.ccTextRegion.y = canvasObject.top;
                        // obj.ccTextRegion.width = canvasObject.width * canvasObject.scaleX;
                        // obj.ccTextRegion.textBlocks.forEach(textBlockData => {
                        //     if (textBlockData.xmlText) {
                        //         textBlockData.xmlText.forEach(textObj => {
                        //             textObj.pointsize = canvasObject.fontSize * canvasObject.scaleX;
                        //             // multilines - need to increase height of textregion
                        //             if (!!obj.textLines && obj.textLines.length > 1) {
                        //                 obj.ccTextRegion.height = '' + (((+canvasObject.fontSize * canvasObject.textLines.length + +canvasObject.fontSize)) * canvasObject.scaleX);
                        //             } else {
                        //                 obj.ccTextRegion.height = '' + (((+canvasObject.fontSize * 2)) * canvasObject.scaleX);
                        //             }
                        //         });
                        //     }
                        // });
                        // this.textRegionsToUpdate.push(Object.assign({}, obj.ccTextRegion));
                    }
                    if (obj.isParent) {
                        activeSelectionObjects.push(obj);
                    }
                });

                const sel = new fabric.ActiveSelection(activeSelectionObjects, {
                    canvas: this.canvas[activeIndex],
                });
                sel.setControlsVisibility({
                    mtr: false,
                    mb: false,
                    ml: false,
                    mr: false,
                    mt: false
                });
                if (isRect && activeObject.rectId) {
                    sel.setOptions({
                        cornerStyle: 'circle',
                        transparentCorners: false,
                        cornerSize: 11,
                        borderColor: '#e65609',
                        cornerColor: '#e65609',
                        cornerStrokeColor: '#e65609',
                        lockScalingFlip: true,
                        padding: 5,
                        borderOpacityWhenMoving: 0.2,
                        absolutePositioned: true,
                        rectId: activeObject.rectId      // set underlying rectangle id for convenience,
                    });
                    // need to remember the original position to snap it back into designated region when it goes out of guided area
                    sel.originPosition = {
                        x: sel.left, y: sel.top
                    };
                    this.activeObject = sel;
                    sel.snapInRegion = activeObject.snapInRegion;    //from boundary rect
                }
                sel.setCoords();
                this.canvas[activeIndex].setActiveObject(sel);
                /* On click start drag group */
                this.canvas[activeIndex].requestRenderAll();
            } else if (activeObject.type === 'CurvesText') {
                this.traverseTextRegion(activeObject);
            }

        }
        if (this.textRegionsToUpdate.length) {
            if (!this.updateTextAjaxCalls.length) {
                this.updateTextAjaxCalls = [this.textRegionsToUpdate];
                clearTimeout(this.callTimeout);

                this.callTimeout = setTimeout(() => {
                    this.updateTextObjectInAPI(activeIndex);
                });
            } else {
                this.updateTextAjaxCalls.push(this.textRegionsToUpdate);
            }

        }
    }

    traverseTextRegion(activeObject: any): void {
        activeObject.ccTextRegion.x = activeObject.left;
        activeObject.ccTextRegion.y = activeObject.top;
        activeObject.ccTextRegion.angle = +activeObject.angle > 0 ? '' + (360 - +activeObject.angle) : '' + (0 - activeObject.angle);
        activeObject.ccTextRegion.textBlocks.forEach(textBlockData => {
            if (textBlockData.xmlText) {
                textBlockData.xmlText.forEach(textObj => {
                    textObj.pointsize = (+activeObject.fontSize * activeObject.scaleX).toString();
                    activeObject.ccTextRegion.height = Number(activeObject.height);
                    activeObject.ccTextRegion.width = Number(activeObject.width) * activeObject.scaleX;
                    textObj.color = this.customiseMenuSharedService.hexToRgb(activeObject.fill); //this.customiseMenuService.getCmykFromRgb(activeObject.fill);
                    textBlockData.align = activeObject.textAlign;
                    textObj.font = activeObject.fontFamily.split(',')[0];
                    textObj.characterStyle = activeObject.underline ? 'underline' : 'plain';
                    if (activeObject.fontWeight === 'bold') {
                        textObj.characterStyle = textObj.characterStyle + ' bold';
                        textObj.characterStyle = textObj.characterStyle.replace('plain ', '')
                    }
                    if (activeObject.fontStyle === 'italic') {
                        textObj.characterStyle = textObj.characterStyle + ' italic';
                        textObj.characterStyle = textObj.characterStyle.replace('plain ', '')
                    }
                    textObj.vfield.forEach(vfieldData => {
                        vfieldData.value = activeObject.text;
                    });

                    // multilines - need to increase height of textregion
                    if (!!activeObject.textLines && activeObject.textLines.length > 1) {
                        activeObject.ccTextRegion.height = '' + (+activeObject.fontSize * activeObject.textLines.length + +activeObject.fontSize) * activeObject.scaleY;
                    } else {
                        activeObject.ccTextRegion.height = '' + (+activeObject.fontSize * 2) * activeObject.scaleY;
                    }
                });
            }
        });
        this.textRegionsToUpdate.push(activeObject.ccTextRegion)
    }

    public updateTextAjaxCalls = [];

    /** Update text region in api */
    updateTextObjectInAPI(activeIndex) {
        this.updatedOnAnotherEvent = true;    // flag to prevent another api call from :modified event
        this.customiseMenuService.updateBulkTextRegionInJob(
            this.jTemplateId, activeIndex + 1, this.updateTextAjaxCalls[0], this.security_token).subscribe((updatedTextRes: RestResponse) => {
            this.updatedOnAnotherEvent = false;
            //// console.log(updatedTextRes.instance, 'updated textregions');
            this.textRegionsToUpdate = [];
            this.updateTextAjaxCalls.shift();
            if (this.updateTextAjaxCalls.length) {
                this.updateTextObjectInAPI(activeIndex);
            }
        }, (err: any) => {
            // console.log('------400 error-----------', err);
            if (this.updateTextAjaxCalls.length) {
                this.updateTextObjectInAPI(activeIndex);
            }
        });
    }

    // deleteBulkJobTextRegion(textRegions: any): void {
    //     // console.log('delete ajaxCalls', JSON.stringify(this.ajaxCalls));
    //     this.customiseMenuService.deleteBulkJobTextRegion(this.jTemplateId, this.activeCanvasIndex + 1, textRegions, this.security_token).subscribe(res => {
    //         this.ajaxCalls.pop();
    //         if (this.ajaxCalls.length) {
    //             this.deleteBulkJobTextRegion(textRegions);
    //         }
    //     });
    // }

    /** construct download link based on conversion type */
    getDownloadLink(type) {
        let finalType: string;  // TODO may need to amend param values
        let lowres = 'false';
        const bleeds = 'true';
        const overprint = 'true';
        if (type === 'lowres') {
            finalType = 'pdf';
            lowres = 'true';
        } else if (type === 'print') {
            finalType = 'pdf';
        } else if (type === 'jpg') {   // will get zipped images
            finalType = 'jpg';
        } else if (type === 'png') {   // will get zipped images
            finalType = 'png';
        }

        const downloadLink = `${this.commonService._restv2api}TemplateService/v1/jobTemplate/${this.jTemplateId}/${finalType}?token=${this.security_token}&bleeds=${bleeds}&overprint=${overprint}&lowres=${lowres}`;
        // // console.log('downloadLink - ' + downloadLink);
        return downloadLink;
    }

    /** insert matching fabric text instance onto canvas with passed text region details
     * pass -1 for parentId if you don't need grouping using boundary rectangle */
    addFabricTextWithTextRegion(textRegionToCopy: TextRegion, lockMovement: boolean, parentId: string, emptyTextRegion?: any, xMousePos?: any, yMousePos?: any, index?: number, isGeneral?: boolean, isNotExting?: boolean) {
        // !!!will CLONE textRegion using JSON util and newly created fabricjs text will keep cloned textRegion

        const textRegion = JSON.parse(JSON.stringify(textRegionToCopy)) as TextRegion;
        textRegion.parent = parentId;   // need to be carried onto backend and saved

        const textBlock = textRegion.textBlocks[0];
        const xmlText = textBlock.xmlText[0];

        let largestTopPlusHeight = 0;
        // emptyTextRegion provide container to locate fabric text instances
        if (!!emptyTextRegion) {

            // when styled texts are inserted, it needs to apply updated size ratio to x,y, width,height and pointsize
            if (!this.customiseMenuSharedService.isDigital(+this.originalSize.width, +this.originalSize.height)) {    // paper size change only
                if (this.originalSize.name !== this.selectedSize.name) {
                    let ratio = 0;
                    // get ratio increased or decreased and apply changed to all textregions
                    if (+this.selectedSize.height >= +this.selectedSize.width) {  //portrait
                        ratio = +this.selectedSize.height / +this.originalSize.height;
                    } else {     //landscape
                        ratio = +this.selectedSize.width / +this.originalSize.width;
                    }

                    textRegion.x = '' + (+textRegion.x * ratio);
                    textRegion.y = '' + (+textRegion.y * ratio);
                    textRegion.width = '' + (+textRegion.width * ratio);
                    textRegion.height = '' + (+textRegion.height * ratio);
                    xmlText.pointsize = '' + (+xmlText.pointsize * ratio);

                    textBlock.leading = '' + (+textBlock.leading * ratio);
                    textBlock.spaceBefore = '' + (+textBlock.spaceBefore * ratio);
                    textRegion.prePositionY = +textRegion.prePositionY * ratio;
                }
            }

            textRegion.snapTextRegionId = emptyTextRegion.id;
            // NEED to check if there are existing texts in the destination - if yes, new item needs to be placed below the last item
            //let totalHeight = 0;
            largestTopPlusHeight = this.getLargestTopPostionInSameTextFlow(index, emptyTextRegion);   // will be start y position for following GROUP of textregions - !!! it does not consider text item within the same group

            // !!! y position doesn't seem be fully dictated by coding - reapplied those already added values to textregion's y
            textRegion.x = '' + (+textRegion.x + +emptyTextRegion.x);
            if (textRegion.firstLineInGroup) { // the first line item in the same text style group
                if (largestTopPlusHeight === 0) { // 1st style in the same textflow region
                    textRegion.y = emptyTextRegion.y;   //to be lined up with empty area top y position
                } else {
                    textRegion.y = '' + (largestTopPlusHeight + +textRegion.y);
                }

            } else {    // 2nd+ line item in the same text style group
                const leadingMinusPointSize = +textBlock.leading - +xmlText.pointsize;
                if (largestTopPlusHeight === 0) {     // 1st style in the same textflow region
                    if (textRegion.lineNo === 1) {
                        //textRegion.y = '' + (+emptyTextRegion.y + +textRegion.y - textRegion.prePositionY + (+textBlock.leading - +xmlText.pointsize));
                        textRegion.y = '' + (+emptyTextRegion.y + +textRegion.y - textRegion.prePositionY + +textBlock.spaceBefore + leadingMinusPointSize);
                    } else {
                        textRegion.y = '' + (+emptyTextRegion.y + +textRegion.y + +textBlock.spaceBefore + leadingMinusPointSize);
                    }

                } else {
                    textRegion.y = '' + (largestTopPlusHeight + +textRegion.y + +textBlock.spaceBefore + leadingMinusPointSize);
                }
            }
            // // console.log('largestTopPlusHeight: ' + largestTopPlusHeight);

            // if width is larger than container, apply container width
            if (+textRegion.width > emptyTextRegion.width) {
                textRegion.width = '' + emptyTextRegion.width;
            }
        }

        // only one child element each for a textRegion
        //const textBlock = textRegion.textBlocks[0];
        //const xmlText = textBlock.xmlText[0];
        const vfield = xmlText.vfield[0];
        const fontName = xmlText.font.split(',')[0];
        // textBlock.deductNumber = textBlock.deductNumber || 0;

        if (xmlText.color.includes('cmyk')) {
            xmlText.color = this.customiseMenuSharedService.getRgbFromCmyk(xmlText.color);
        }
        if (xmlText.characterStyle.toLowerCase().includes('caps')) {
            vfield.value = vfield.value.toUpperCase();
        }
        let underline = false;
        if (xmlText.characterStyle.toLowerCase().includes('underline')) {
            underline = true;
        }
        let fontWeight = 'normal';
        if (xmlText.characterStyle.toLowerCase().includes('bold')) {
            fontWeight = 'bold'
        }

        // all new lines need to be considered      //TODO other special chars
        vfield.value = vfield.value.replace(/\r/g, '\r\n');

        let textRegionWidth = Number(textRegion.width);

        if (!lockMovement && isGeneral) {
            textRegionWidth = (Number(vfield.value.length) * Number(xmlText.pointsize));
        }
        // // console.log(textRegion, 'textRegion1');
        // this.customiseMenuService.getFont(`${fontName}`, this.security_token).then((res) => {
        const text = new fabric.CurvesText(vfield.value, {
            fontFamily: fontName,
            width: textRegionWidth,
            angle: +textRegion.angle > 0 ? -textRegion.angle + 360 : 0,
            //!!! when alignment is right, left value will be object right by changing originX to right - i.e. top right corner x value will be set as left
            originX: textBlock.align === 'right' ? 'right' : 'left',

            left: +textRegion.x + (xMousePos ? +xMousePos : 0),
            top: +textRegion.y + (yMousePos ? +yMousePos : 0),
            textAlign: textBlock.align,
            fill: this.customiseMenuSharedService.getRgbFromCmyk(xmlText.color),
            fontSize: xmlText.pointsize,
            lineHeight: 1,
            editingBorderColor: '#023cf7',
            lockMovementX: lockMovement,  // prevent it from moving by itself
            lockMovementY: lockMovement,  // prevent it from moving by itself
            underline: underline,
            fontWeight: fontWeight,
            // centeredScaling: true, cornerStyle: circle/rect, editingBorderColor :rgba(102,153,255,0.25), lockScalingFlip: false
            cornerStyle: 'circle',
            // cornerSize: 12,
            // cornerColor: '#FFFFFF',
            lockScalingFlip: true,
            ccTextRegion: textRegion,      // !!! will keep matching textRegion TODO refresh with inserted textRegion on beckend submission
            parent: parentId                // parentId of -1 - no boundary rectangle required
        });
        if (textRegion.editRules) {
            text.editable = this.customiseMenuSharedService.getBoolean(textRegion.editRules[0].editable);  //textRegion.editRules[0].editable && textRegion.editRules[0].editable === '0' ? false : true;
            text.lockMovementX = textRegion.editRules[0].movable && textRegion.editRules[0].movable === '0' ? true : false;
            text.lockMovementY = textRegion.editRules[0].movable && textRegion.editRules[0].movable === '0' ? true : false;
            // text.lockScalingX = textRegion.editRules[0].resizable && textRegion.editRules[0].resizable === '0' ? true : false;
            // text.lockScalingY = textRegion.editRules[0].resizable && textRegion.editRules[0].resizable === '0' ? true : false;
            if (textRegion.editRules[0].resizable && textRegion.editRules[0].resizable === '0') {
                text.setControlsVisibility({
                    bl: false,
                    br: false,
                    tl: false,
                    tr: false,
                    mt: false,
                    mb: false,
                    ml: false,
                    mr: false
                });
            } else {
                text.setControlsVisibility({
                    bl: true,
                    br: true,
                    tl: true,
                    tr: true,
                    ml: true,
                    mr: true,
                    mt: true
                });
            }
        }
        // !!! NOTE extra cooking required since fabricjs text item's height is different from pointsize and the difference needs to be taken into account
        // TODO what is really needed is the height from just added (not render to canvas yet) before current one
        if (!!emptyTextRegion) {
            const gap = +text.height - (+xmlText.pointsize * +vfield.editRowHeight);    //get difference for a single row
            //let difference = +text.height - (+xmlText.pointsize * +vfield.editRowHeight);
            let difference = gap * +vfield.editRowHeight;    // get difference for the number of rows
            if (!textRegion.firstLineInGroup && difference > 0) {    // 2nd+ line item in the same text style group
                if (largestTopPlusHeight === 0) {     // 1st style in the same textflow region
                    if (textRegion.lineNo + 1 === textRegion.totalNoOfRows && textRegion.lineNo === 2) {
                        difference = +textBlock.leading;
                    }

                    if (textRegion.lineNo === 1) {
                        text.top = text.top + difference;
                        textRegion.y = '' + (+textRegion.y + difference);
                    } else if (textRegion.lineNo === 2) {
                        if (textRegion.preEditRowHeight > 1 && textRegion.lineNo + 1 === textRegion.totalNoOfRows) {
                            text.top = text.top + (gap + gap * textRegion.preEditRowHeight);
                            textRegion.y = '' + (+textRegion.y + (gap + gap * textRegion.preEditRowHeight));
                        } else {
                            text.top = text.top - difference;
                            textRegion.y = '' + (+textRegion.y - difference);
                        }

                    } else if (textRegion.lineNo > 2) {
                        text.top = text.top + difference * textRegion.lineNo;
                        textRegion.y = '' + (+textRegion.y + difference * textRegion.lineNo);
                    }

                } else {
                    if (textRegion.lineNo > 1) {
                        difference = difference + (difference * (textRegion.lineNo + (textRegion.preEditRowHeight > 1 ? textRegion.preEditRowHeight : 0)));
                        if (textRegion.lineNo + 1 === textRegion.totalNoOfRows && textRegion.preEditRowHeight > 1) {
                            difference = +textBlock.leading + (gap + gap * textRegion.preEditRowHeight);
                        } else if (textRegion.lineNo > 2) {
                            difference = difference + +textBlock.leading;
                        }
                    }
                    text.top = text.top + difference;
                    textRegion.y = '' + (+textRegion.y + difference);
                }
            }
        }


        if (!isNotExting) {
            text.isExisting = true;
        } else {
            text.rectId = emptyTextRegion.id;
        }
        // no handlers needed if movement is locked
        if (lockMovement) {
            text.setControlsVisibility({
                tl: false, tr: false, br: false, bl: false, mtr: true,
                mb: false, ml: false, mr: false, mt: false
            });
        } else {
            text.setControlsVisibility({
                mtr: true, mb: false, mt: false    // vertical handler removed - user needs to change font size make text bigger or smaller
            });
            // this.canvas[index || this.activeCanvasIndex].centerObject(text);
        }
        if (index || index === 0) { /*  If index is passed initially all the task will perform on index not in activeIndex */
            this.canvas[index].add(text);
        } else {
            this.canvas[this.activeCanvasIndex].add(text);
        }
        if (!lockMovement && isGeneral) {   // free text stays in the middle
            // text.viewportCenterH();
            text.setCoords();
        }

        return text;
    }

    /** get the largest y postion in the same text flow - just added item is not being retrieved by getObjects() */
    getLargestTopPostionInSameTextFlow(index: number, emptyTextRegion: any): number {
        let largestTopPlusHeight = 0;
        if (!index || index < 0) {
            index = this.activeCanvasIndex;
        }

        for (const item of this.canvas[index].getObjects()) {
            if (!!item.id && !!item.parent && item.type === 'CurvesText' && item.rectId === emptyTextRegion.id && (item.left < (+emptyTextRegion.x + +emptyTextRegion.width)) && (item.left + item.width > (+emptyTextRegion.x)) && (item.top < (+emptyTextRegion.y + +emptyTextRegion.height)) && (item.top + item.height > (+emptyTextRegion.y))) {    // check those group rectangles and single menu item
                // find those items inside guided region
                if (item.top >= +emptyTextRegion.y) {
                    // then find the biggest top+height value
                    if (largestTopPlusHeight < item.top + item.height) {
                        largestTopPlusHeight = item.top + item.height;
                    }
                }
            }
        }

        // will keep it as new variable called largestPositionY for each of guided empty region
        //emptyTextRegion.largestPositionY = largestTopPlusHeight;

        return largestTopPlusHeight;
    }

    /** Reset image object to original state */
    resetImageObject(): void {
        const activeIndex = this.canvas[this.activeCanvasIndex].getActiveObject() ? this.activeCanvasIndex : this.activeLastIndex;
        const selectedObj = this.canvas[activeIndex] && this.canvas[activeIndex].getActiveObject();
        const activeCanvas = this.canvas[activeIndex];
        this.lastSelectedObject = selectedObj;
        this.lastImageObjectSelected = true;
        selectedObj.rotate(0);
        this.imageDataOps(selectedObj, 'delete');
        activeCanvas.remove(selectedObj);
        let left = selectedObj.left;
        let top = selectedObj.top;
        if (selectedObj.cropperPosition) {
            left = +selectedObj.left + +selectedObj.ccImage.vfield[0].imagebounds.x;
            top = +selectedObj.top + +selectedObj.ccImage.vfield[0].imagebounds.y;
        }
        this.fabricImgCmp({
            src: selectedObj.originalURL,
            activeCanvasIndex: selectedObj.activeCanvasIndex || this.activeCanvasIndex,
            left: left,
            top: top,
            originalURL: selectedObj.originalURL,
            assetId: selectedObj.assetid,
            asset: selectedObj.asset,
            zoomScale: selectedObj.zoomScale
        }, (img) => {
            activeCanvas.setActiveObject(img);
        });

        // fabric.Image.fromURL(selectedObj.originalURL, function (img) {
        //     img.set({
        //         type: 'image',
        //         scaleX: .25,
        //         scaleY: .25,
        //         width: img._originalElement.naturalWidth,
        //         height: img._originalElement.naturalHeight,
        //         left: selectedObj.left,
        //         top: selectedObj.top,
        //         lockScalingFlip: true
        //     });
        //     activeCanvas.remove(selectedObj);
        //     img.originalURL = selectedObj.originalURL;
        //     img.assetId = selectedObj.assetId;
        //     img.asset = selectedObj.asset;
        //     img.zoomScale = selectedObj.zoomScale;
        //     activeCanvas.add(img);
        //     activeCanvas.setActiveObject(img);
        //     activeCanvas.renderAll();
        // });
    }

    /**
     * Rotate image left or right
     */
    rotate(side) {
        const activeIndex = this.canvas[this.activeCanvasIndex].getActiveObject() ? this.activeCanvasIndex : this.activeLastIndex;
        const selectedObj = this.canvas[activeIndex] && this.canvas[activeIndex].getActiveObject();
        const activeCanvas = this.canvas[activeIndex];
        if (selectedObj.angle <= 360 && selectedObj.angle - 90 >= -360) {
            if (side === 'right') {
                selectedObj.rotate(selectedObj.angle + 45);
            } else {
                selectedObj.rotate(selectedObj.angle - 45);
            }
        } else {
            selectedObj.rotate(0);
        }
        if (selectedObj.type === 'image') {
            this.imageDataOps(selectedObj, 'update');
        }
        if (selectedObj.type === 'CurvesText') {
            this.updateActiveTextRegion(false);
            // this.textRegionsToUpdate.push(selectedObj.ccTextRegion)
            // this.updateTextAjaxCalls = [this.textRegionsToUpdate];
            // clearTimeout(this.callTimeout);
            //
            // this.callTimeout = setTimeout(() => {
            //     this.updateTextObjectInAPI(activeIndex);
            // });
        }
        selectedObj.setCoords();
        activeCanvas.renderAll();
        activeCanvas.calcOffset();
    }

    /**
     * Change Image z-index.
     * Send to Front will assign the biggest zindex value.
     * Send to Back will allcate the smallest zindex.
     */
    changeIndex(type) {
        const activeIndex = this.canvas[this.activeCanvasIndex].getActiveObject() ? this.activeCanvasIndex : this.activeLastIndex;
        const selectedObj = this.canvas[activeIndex] && this.canvas[activeIndex].getActiveObject();
        const activeCanvas = this.canvas[activeIndex];
        activeCanvas.discardActiveObject();
        if (type === 'front') {
            this.imageZIndex = this.imageZIndex + 1;
            selectedObj.set({opacity: this.imageZIndex});
            // selectedObj.bringForward(cropRect);
            activeCanvas.bringToFront(selectedObj);
            const canvasObject = _.find(activeCanvas.getObjects(), {isWaterMark: true});
            // canvasObject.set({opacity: this.canvas[index].getObjects().length + 1});
            activeCanvas.bringToFront(canvasObject);
            this.imageDataOps(selectedObj, 'update');
        } else {
            let imageObjects = [];
            const canvasObjects = _.filter(this.canvas[activeIndex].getObjects(), (data) => {
                return data.type === 'image' && data.ccImage !== selectedObj.ccImage
            });
            canvasObjects.forEach(obj => {
                obj.set({opacity: obj.opacity + 1});
                obj.ccImage.zindex = +obj.ccImage.zindex + 1;
                imageObjects.push(obj.ccImage);
            });
            selectedObj.set({opacity: 1});
            selectedObj.ccImage.zindex = 0;
            imageObjects.push(selectedObj.ccImage);
            this.updateBulkImages(imageObjects);
            selectedObj.sendToBack();

        }
        activeCanvas.renderAll();

    }

    updateBulkImages(imageObjects) {
        this.customiseMenuService.updateImageInGrid(this.jTemplateId, Number(this.activeCanvasIndex) + 1, imageObjects, this.security_token).subscribe((imageRes: any) => {
            // console.log(imageRes, 'imageRes');
        });
    }

    /**
     * Operations on Image data on server - DO NOT use 2 different operation in a row due to sync issue
     */
    imageDataOps(imageData: any, action: string, scaled?: Boolean) {
        let reqImgData = new XmlImage();
        let vFieldVal = new vfield();
        //let constraintsVal = new Constraint();
        let xmlIdVal = new XmlId();
        let tMatrixVal = new XmlTMatrix();
        let clipVal = new XmlClip();
        let imageBoundsVal = new XmlImageBounds();
        let imgId = _.now() + Math.floor(Math.random() * Math.floor(1000));   // ensure it's unique;
        const toString = (o) => {
            if (!o) {
                return;
            }
            Object.keys(o).forEach(k => {
                if (typeof o[k] === 'object') {
                    return toString(o[k]);
                }

                o[k] = '' + o[k];
            });

            return o;
        };


        if (!_.isEmpty(imageData.ccImage, true)) {
            //imgId = imageData.ccImage[Object.keys(imageData.ccImage)[0]].id;
            imgId = imageData.ccImage.id;
        }

        if (action === 'delete') {
            this.customiseMenuService.deleteImageInGrid(this.jTemplateId, Number(this.activeCanvasIndex) + 1, [imgId], this.security_token).subscribe((imageRes: any) => {
                // // console.log(imageRes, 'image data response');
            });

        } else {
            let xVal = 0;
            let yVal = 0;
            let wVal = 0;
            let hVal = 0;
            // const cropperPostion = {
            //     x1: cropBox.left - parentImage.left,
            //     x2: cropBox.left - parentImage.left + (cropBox.width * cropBox.scaleX),
            //     y1: cropBox.top - parentImage.top,
            //     y2: cropBox.top - parentImage.top + (cropBox.height * cropBox.scaleY)
            // };
            if (imageData.cropperPosition) {    // when crop is done via crop window
                xVal = imageData.cropperPosition.x1;
                yVal = imageData.cropperPosition.y1;
                wVal = (imageData.cropperPosition.x2 - imageData.cropperPosition.x1);
                hVal = (imageData.cropperPosition.y2 - imageData.cropperPosition.y1);
            }
            if (this.activeImageRegionHover) {
                const canvasAspect = Number(this.activeImageRegionHover.width) / Number(this.activeImageRegionHover.height);
                const imgAspect = Number(+imageData.width) / Number(+imageData.height);
                let scaleFactor;
                if (canvasAspect < imgAspect) {
                    scaleFactor = Number(this.activeImageRegionHover.width) / Number(+imageData.width);
                } else {
                    scaleFactor = Number(this.activeImageRegionHover.height) / Number(+imageData.height);
                }
                // imageData.left = Number(this.activeImageRegionHover.x);
                // imageData.top = Number(this.activeImageRegionHover.y);
                // imageData.zoomScale = scaleFactor;
            }
            reqImgData.id = imgId;
            reqImgData.x = xVal > 0 ? (imageData.left + (xVal * imageData.zoomScale)) : imageData.left;
            reqImgData.y = imageData.top.toString();
            reqImgData.width = wVal > 0 ? '' + wVal : '' + (+imageData.width * imageData.zoomScale);
            reqImgData.height = hVal > 0 ? '' + hVal : '' + (+imageData.height * imageData.zoomScale);
            // angle value from fabric image is clock wise unlike backend pdf creator
            reqImgData.angle = +imageData.angle > 0 ? '' + (360 - +imageData.angle) : '' + (0 - imageData.angle);
            reqImgData.shape = imageData.shape || 'rect';
            reqImgData.zindex = imageData.opacity || 0;      // -1 puts the image behind other contents

            reqImgData.editRules = imageData.ccImage && (imageData.ccImage.EditRules || imageData.ccImage.editRules);
            reqImgData = toString(reqImgData);

            if (!imageData.ccImage || (imageData.ccImage && !imageData.ccImage.EditRules && !imageData.ccImage.editRules)) {
                reqImgData.editRules = null;
            }
            vFieldVal.display = imageData.display || 'true';
            vFieldVal.editRowHeight = imageData.editRowHeight || '1';
            vFieldVal.elementIndex = imageData.elementIndex || '1';
            vFieldVal.id = imgId + ':0';
            vFieldVal.editable = '1';
            vFieldVal.index = imageData.index || '1';
            vFieldVal.name = imageData.name || imageData.assetId;
            vFieldVal.styleID = imageData.styleID || '1';
            vFieldVal.type = 'image';
            vFieldVal.visible = imageData.visible || 'true';
            vFieldVal = toString(vFieldVal);

            xmlIdVal.catalogue = this.imageCatalogue;
            xmlIdVal.s3 = 'false';      // TODO s3 and filesafe flag might be updated depending on asset's location later
            xmlIdVal.filesafe = 'true';
            xmlIdVal.value = imageData.assetId;
            xmlIdVal = toString(xmlIdVal);

            tMatrixVal.a = imageData.zoomScale || '1';
            tMatrixVal.b = '0';
            tMatrixVal.c = '0';
            tMatrixVal.d = imageData.zoomScale || '1';
            tMatrixVal.e = '0';
            tMatrixVal.f = '0';

            if (imageData.cropperPosition && scaled) {
                reqImgData.width = (+reqImgData.width * imageData.zoomScale).toString();
                reqImgData.height = (+reqImgData.height * imageData.zoomScale).toString();
            }
            tMatrixVal = toString(tMatrixVal);
            clipVal.x = '0'; //no need to change
            clipVal.y = '0'; //no need to change
            clipVal.width = reqImgData.width;   // same as image area size
            clipVal.height = reqImgData.height; // same as image area size

            clipVal = toString(clipVal);

            // based on clip's x,y position, it's 0 or minus value since crop cannot go out of image bound currently
            imageBoundsVal.x = '' + -(xVal); // depends on crop location
            imageBoundsVal.y = '' + -(yVal); // depends on crop location
            //original width & height required
            if (imageData.cropperPosition && scaled) {
                imageBoundsVal.x = '' + -(xVal * imageData.zoomScale); // depends on crop location
                imageBoundsVal.y = '' + -(yVal * imageData.zoomScale); // depends on crop location
            }

            // go around - when both values are zero, cropping is not applied
            if (imageData.cropperPosition && imageBoundsVal.x === '0' && imageBoundsVal.y === '0') {
                imageBoundsVal.y = '-1.01';  //apply minimum value to make it happen
            }

            imageBoundsVal.width = (+imageData.asset.width).toString();
            imageBoundsVal.height = (+imageData.asset.height).toString();
            imageBoundsVal = toString(imageBoundsVal);
            vFieldVal.xmlId = xmlIdVal;
            vFieldVal.tmatrix = tMatrixVal;
            vFieldVal.clip = clipVal;
            vFieldVal.imagebounds = imageBoundsVal;
            if (!vFieldVal.name || vFieldVal.name === 'undefined') {
                vFieldVal.name = this.lastSelectedObject.ccImage.vfield[0].name;
            }
            if (!vFieldVal.xmlId.value || vFieldVal.xmlId.value === 'undefined') {
                vFieldVal.xmlId.value = this.lastSelectedObject.ccImage.vfield[0].xmlId.value;
            }
            reqImgData.vfield = [vFieldVal];
            let imgEl = imageData;
            this.canvas[this.activeCanvasIndex].renderAll();
            if (action === 'insert') {
                queueScheduler.schedule(() => {
                    this.customiseMenuService.insertImageInGrid(this.jTemplateId, Number(this.activeCanvasIndex) + 1, [reqImgData], this.security_token).subscribe((imageRes: any) => {
                        imgEl.ccImage = imageRes.instance[imgId];
                        this.imageEditorCursorStyle = 'pointer';
                        // // console.log(imgEl, 'imgEl');
                        this.grids[this.activeCanvasIndex].showLoader = false;
                        // this.canvas[this.activeCanvasIndex].hoverCursor = 'Default';
                        // // console.log(imageRes, 'image data response');
                    });
                })
            }

            if (action === 'update') {
                queueScheduler.schedule(() => {
                    this.customiseMenuService.updateImageInGrid(this.jTemplateId, Number(this.activeCanvasIndex) + 1, [reqImgData], this.security_token).subscribe((imageRes: any) => {
                        imgEl.ccImage = imageRes.instance[imgId];
                        this.applyImageEditRulesOnObject(imgEl);
                        this.imageEditorCursorStyle = 'pointer';
                        // // console.log(imgEl, 'imgEl');
                        this.grids[this.activeCanvasIndex].showLoader = false;
                        // this.canvas[this.activeCanvasIndex].hoverCursor = 'Default';
                        // // console.log(imageRes, 'image data response');
                    });
                });
            }
        }
    }

    /** Apply Image rules local object */
    applyImageEditRulesOnObject(imgEl: any): void {
        const rules = imgEl && imgEl.ccImage && imgEl.ccImage.editRules;

        if (rules && rules.length) {
            imgEl.set({
                lockSkewingX: rules[0].resizable === '0' ? true : false,
                lockScalingY: rules[0].resizable === '0' ? true : false,
                lockMovementX: rules[0].movable === '0' ? true : false,
                lockMovementY: rules[0].movable === '0' ? true : false,
                editable: rules[0].editable === '0' ? true : false
            });
        }
        this.lastSelectedObject.ccImage = imgEl.ccImage;
        const dummyObj = _.clone(this.lastSelectedObject);
        this.lastSelectedObject = null;
        this.lastSelectedObject = dummyObj;
    }


    /** Save grid page on save button click */
    saveJobTemplate(base) {
        let data = {
            base: base,
            categoryID: this.categoryId,
            name: this.jobTemplateName
        };
        if (base) {
            let title = '';
            let text;
            let labelConfirm = '';
            let labelCancel = '';
            this.translate.get('label.SaveJobTemplate').subscribe((res: string) => {
                title = res;
            });
            this.translate.get('message.JobTemplateNameWarning').subscribe((res: string) => {
                text = res;
            });
            this.translate.get('label.Save').subscribe((res: string) => {
                labelConfirm = res;
            });
            this.translate.get('label.cancel').subscribe((res: string) => {
                labelCancel = res;
            });
            this.swal({
                title: title,
                input: 'text',
                html: '<input type="checkbox" id="editRulesBox" name="editRules" value="editRules" checked>Apply customised rules',
                focusConfirm: false,
                customClass: 'save-design',
                preConfirm: () => {
                    const checkBox: any = document.getElementById('editRulesBox');
                    const checkBoxVal = checkBox ? checkBox.checked : false;
                    if (!checkBoxVal) {
                        this.canvas.forEach((canvas: any, index) => {
                            this.canvas[index].getObjects().forEach((el: any) => {
                                if (el.type === 'image' && el.ccImage) {
                                    el.ccImage.editRules = null;
                                }
                                if (el.type === 'CurvesText' && el.ccTextRegion) {
                                    el.ccTextRegion.editRules = null;
                                }
                                if (el.type === 'rect' && el.groupEditRules) {
                                    el.groupEditRules = null;
                                }
                            });
                            this.canvas[index].renderAll();
                        });
                    }
                },
                inputPlaceholder: 'Base Template Name',
                inputAttributes: {
                    autocapitalize: 'off',
                    palceholder: 'Enter Base Template Name'
                },
                inputValidator: (value) => {
                    if (!value) {
                        return text;
                    }
                },
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: labelCancel,
                confirmButtonText: labelConfirm
            }).then((result) => {
                if (result.value) {
                    data.name = result.value;
                    this.showSaveSpinner = true;
                    // const checkBox: any = document.getElementById('editRulesBox');
                    // const checkBoxVal = checkBox ? checkBox.checked : false;
                    // if (checkBoxVal) {
                    //     let imgList = [];
                    //     let textsList = [];
                    //     this.canvas[this.activeCanvasIndex].getObjects().forEach((el: any) => {
                    //         if (el.type === 'image' && el.ccImage) {
                    //             imgList.push(el.ccImage);
                    //         }
                    //         if (el.type === 'CurvesText' && el.ccTextRegion) {
                    //             textsList.push(el.ccTextRegion);
                    //         }
                    //     });
                    //
                    //     this.customiseMenuService.updateImageInGrid(this.jTemplateId, this.activeCanvasIndex + 1, imgList, this.security_token).subscribe((imageRes: any) => {
                    //         this.customiseMenuService.updateBulkTextRegionInJob(
                    //             this.jTemplateId, this.activeCanvasIndex + 1, textsList, this.security_token).subscribe(() => {
                    //             this.customiseMenuService.saveJobTemplate(this.jTemplateId, data, this.security_token).subscribe((res) => {
                    //                 if (res.statusCode === 200) {
                    //                     this.displayToaster('success', [res.message]);
                    //                     this.baseTemplateId = res.key;
                    //                     this.selectedBaseTempId = this.baseTemplateId.toString();
                    //                     this.designThumbnailUrls = [];
                    //                     this.designLoading = true;
                    //                     this.getDesignImages();
                    //                 }
                    //             });
                    //         });
                    //     });
                    // } else {
                    this.customiseMenuService.saveJobTemplate(this.jTemplateId, data, this.security_token).subscribe((res) => {
                        if (res.statusCode === 200) {
                            this.displayToaster('success', [res.message]);
                            this.baseTemplateId = res.key;
                            this.selectedBaseTempId = this.baseTemplateId.toString();
                            this.designThumbnailUrls = [];
                            this.designLoading = true;

                            this.getDesignImages();
                        }
                    });
                    // }
                }
            });
        } else {
            this.showSaveSpinner = true;
            this.customiseMenuService.saveJobTemplate(this.jTemplateId, data, this.security_token).subscribe((res) => {
                if (res.statusCode === 200) {
                    this.translate.get('message.JobTemplateSaveSuccess').subscribe((res: string) => {
                        this.displayToaster('success', [res]);
                    });
                    this.showSaveSpinner = false;
                }
            });
        }
    }

    /** New design template images server call */
    getDesignImages() {
        this.customiseMenuService.getDesignTemplateThumbnailUrls(this.categoryId, this.security_token)
            .subscribe((res: RestResponse) => {
                if (res.statusCode === 200) {
                    this.breadcumbs = res.message.split('/');
                    this.breadcumbs.forEach((data, i) => {
                        this.breadcumbs[i] = data.trim();
                    });
                    this.designThumbnailUrls = res.instance;
                    this.designLoading = false;
                    this.showSaveSpinner = false;
                } else {
                    console.error('Failed to retrieve design thumbnail urls!')
                }
            });
    }

    /** New design template images server call */
    getBackgroundImages() {
        this.customiseMenuService.getBackgroundAssets(1, 100, this.baseTemplateId, this.security_token).subscribe((page: Page<Asset>) => {
            if (!!page.rows && page.rows.length > 0) {
                page.rows.map(asset => {
                    asset.assetThumbnailPath = config.restv2api + config.assetThumbPath + `?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.customiseMenuService.security_token}`;
                    this.backGroundImages.push(asset);
                });
            }
        });
    }


    /** empty testregion is used as snap in container for texts */
    createImgDottedArea(index: number, imageRegion: any): any {
        const activeCanvas = this.canvas[this.activeCanvasIndex];
        let dWidth = Number(imageRegion.width);
        let dHeight = Number(imageRegion.height);
        let dLeft = Number(imageRegion.x);
        //let dLeft = Number(imageRegion.x) + this.canvasMargin;
        let dTop = Number(imageRegion.y);
        //let dTop = Number(imageRegion.y) + this.canvasMargin;
        // width and height needs to be dealt separately - activeCanvas width/height is not reliable, just check x,y position of 0
        if (dLeft <= 0) {
            dWidth = dWidth - 3;
            dLeft = 0;
        }
        if (dTop <= 0) {
            dHeight = dHeight - 3;
            dTop = 0;
        }
        return new fabric.Rect({
            id: 'draggable-imgdots-' + index,
            left: dLeft,
            top: dTop,
            width: dWidth,
            height: dHeight,
            fill: 'transparent',
            stroke: 'orange',
            strokeDashArray: [10, 5],
            strokeWidth: 2, // strokeWidth to two so that it is visible while dropping image.
            selectable: false,
            regionId: imageRegion.id
        });
    }

    /** empty testregion is used as snap in container for texts */
    createDottedArea(index: number, textRegion: TextRegion): any {
        return new fabric.Rect({
            id: 'draggable-dots-' + index,
            rectIndex: index,
            left: Number(textRegion.x),
            top: Number(textRegion.y),
            width: Number(textRegion.width),
            height: Number(textRegion.height),
            fill: 'transparent',
            stroke: '#fa6352',
            strokeDashArray: [10, 5],
            strokeWidth: 1,
            selectable: false
        });
    }

    /** Show Cross Line */
    showCrossLine(index) {
        const lineObjectVertical = _.find(this.canvas[index].getObjects(), {id: 'draggable-line-vertical' + index});
        const lineObjectHorizontal = _.find(this.canvas[index].getObjects(), {id: 'draggable-line-horizontal' + index});
        if (!!lineObjectVertical) {
            lineObjectVertical.visible = true;
            lineObjectHorizontal.visible = true;
        } else {
            const verticalLine = new fabric.Line([this.canvas[index].originalCanvasWidth / 2, 0, this.canvas[index].originalCanvasWidth / 2, this.canvas[index].originalCanvasHeight], {
                strokeWidth: 2,
                id: 'draggable-line-vertical' + index,
                stroke: 'blue',
            });
            this.canvas[index].add(verticalLine);
            const horizontalLine = new fabric.Line([0, this.canvas[index].originalCanvasHeight / 2, this.canvas[index].originalCanvasWidth, this.canvas[index].originalCanvasHeight / 2], {
                strokeWidth: 2,
                id: 'draggable-line-horizontal' + index,
                stroke: 'blue',
            });
            this.canvas[index].add(horizontalLine);
        }
    }

    /** Hide Cross line and Dotted Line */
    hideLine(index) {
        this.canvas[index].getObjects().forEach(data => {
            if (data && data.id) {
                if (data.id.includes('draggable-dots-')) {
                    data.visible = false;
                } else if (data.id.includes('draggable-line-vertical')) {
                    data.visible = false;
                } else if (data.id.includes('draggable-line-horizontal')) {
                    data.visible = false;
                } else if (data.id.includes('draggable-imgdots-')) {
                    data.visible = false;
                }
            }
        });
    }

    /** Show Cross lines inside dotted area */
    showCrossInRect(index, canvasIndex, rect?) {
        const lineObjectVertical = _.find(this.canvas[canvasIndex].getObjects(), {id: 'draggable-line-vertical' + index});
        const lineObjectHorizontal = _.find(this.canvas[canvasIndex].getObjects(), {id: 'draggable-line-horizontal' + index});
        if (!!lineObjectVertical) {
            lineObjectVertical.visible = true;
            lineObjectHorizontal.visible = true;
        } else {
            if (rect) {
                const verticalLine = new fabric.Line([rect.width / 2, 0, rect.width / 2, rect.height], {
                    left: Number(rect.left) + (rect.width / 2),
                    top: Number(rect.top),
                    strokeWidth: 2,
                    id: 'draggable-line-vertical' + index,
                    stroke: 'blue',
                });
                this.canvas[this.activeCanvasIndex].add(verticalLine);
                const horizontalLine = new fabric.Line([0, rect.height / 2, rect.width, rect.height / 2], {
                    left: Number(rect.left),
                    top: Number(rect.top) + (rect.height / 2),
                    strokeWidth: 2,
                    id: 'draggable-line-horizontal' + index,
                    stroke: 'blue',
                });
                this.canvas[canvasIndex].add(horizontalLine);
            }
        }
    }

    /** Hide Cross lines inside dotted area */
    hideCrossLine(index, canvasIndex) {
        const lineObjectVertical = _.find(this.canvas[canvasIndex].getObjects(), {id: 'draggable-line-vertical' + index});
        const lineObjectHorizontal = _.find(this.canvas[canvasIndex].getObjects(), {id: 'draggable-line-horizontal' + index});
        if (!!lineObjectVertical) {
            lineObjectVertical.visible = false;
            lineObjectHorizontal.visible = false;
        }
    }

    /** On window resize */
    @HostListener('window:resize', ['$event'])
    onResize(event) {
        if (this.selectedScale === 'Fit') {
            this.canvas.forEach((canvas: any, index) => {
                this.scaleFactor = ((event.target.innerHeight - 200) * 100 / this.canvas[index].originalCanvasHeight) / 100;
                this.canvas[index].setDimensions({
                    width: Number(this.canvas[index].originalCanvasWidth * this.scaleFactor),
                    height: Number(this.canvas[index].originalCanvasHeight * this.scaleFactor)
                });

                this.canvas[index].setZoom(this.scaleFactor);

                if (this.canvas[index].backgroundImage) {
                    // Need to scale background images as well
                    const bi = this.canvas[index];
                    bi.width = bi.originalBackgroundImageWidth * this.scaleFactor;
                    bi.height = bi.originalBackgroundImageHeight * this.scaleFactor;
                }
                this.canvas[index].renderAll();
                this.canvas[index].calcOffset();
            });
        }
    }

    /** Function to align texts group vertically distributed,*/
    verticallyCenterAlign(): void {
        const canvas = this.canvas[this.activeCanvasIndex];
        // let objects = canvas.getActiveObject() && canvas.getActiveObject().getObjects && canvas.getActiveObject().getObjects() || canvas.getObjects();
        let topPos = 0;
        let textRegion = _.filter(canvas.getObjects(), (obj) => {
            return (obj.id && obj.id.indexOf('draggable-dots') !== -1);
        });
        let reqObjects = _.filter(canvas.getObjects(), (obj) => {
            return (obj.snapInRegion);
        });
        if (!this.currentTextRegion && textRegion.length > 1) {
            return this.swal("Sorry!", "Please Select Groups from any text region first!", "error");
        }
        if (textRegion.length > 1) {
            const lObjects = canvas.getActiveObject() && canvas.getActiveObject().getObjects && canvas.getActiveObject().getObjects();
            reqObjects = _.filter(canvas.getObjects(), (obj) => {
                return (JSON.stringify(lObjects[0].snapInRegion) === JSON.stringify(obj.snapInRegion));
            });
        }
        // let uObjs = _.compact(_.uniq(_.map(reqObjects, 'parent')));
        let uObjs = [];
        reqObjects.forEach(data => {
            if (data.parent && data.parent !== '-1') {
                uObjs.push(data.parent);
            } else if (data.parent === '-1') {
                uObjs.push(data.id);
            }
        });
        uObjs = _.uniq(uObjs);
        if (!textRegion || !textRegion.length) {
            return this.swal("Sorry!", "There is no text region for this template grid.!", "error");
        }
        if (!uObjs.length) {
            return this.swal("Sorry!", "There are no text groups available to distribute vertically.!", "error");
        }
        textRegion = textRegion.length === 1 ? textRegion[0] : this.currentTextRegion;
        canvas.discardActiveObject();
        this.textRegionsToUpdate = [];
        let lastGroupHeight = 0;
        for (let i = 0; i < uObjs.length; i++) {
            const item = uObjs[i];
            // let child = _.filter(reqObjects, (l) => {
            //     return (l.parent === item && l.parent !== '-1') || (l.isParent && l.parent !== '-1' && l.parent === item);
            // });
            let child = _.filter(reqObjects, (l) => {
                return l.parent === item || (l.id === item && l.isParent);
            });
            let singleChild = _.filter(reqObjects, (l) => {
                return (l.parent === '-1' && l.id === item);
            });
            if (singleChild.length && !child.length) {
                singleChild.forEach(obj => {
                    if (i === 0) {
                        topPos = (singleChild.length && singleChild[0].snapInRegion) ? singleChild[0].snapInRegion.y : textRegion.top;
                    } else {
                        topPos = topPos + (lastGroupHeight + 15);
                    }
                    obj.set({top: topPos});
                    lastGroupHeight = obj.height;
                    obj.setCoords();
                    if (obj.type === 'CurvesText') {
                        const canvasObject = _.find(canvas.getObjects(), {id: obj.id});
                        obj.ccTextRegion.x = canvasObject.aCoords.tl.x;
                        obj.ccTextRegion.y = canvasObject.top;
                        obj.ccTextRegion.width = canvasObject.width * canvasObject.scaleX;
                        obj.ccTextRegion.textBlocks.forEach(textBlockData => {
                            if (textBlockData.xmlText) {
                                textBlockData.xmlText.forEach(textObj => {
                                    textObj.pointsize = canvasObject.fontSize * canvasObject.scaleX;
                                    // multilines - need to increase height of textregion
                                    if (!!canvasObject.textLines && canvasObject.textLines.length > 1) {
                                        obj.ccTextRegion.height = '' + (((+canvasObject.fontSize * canvasObject.textLines.length + +canvasObject.fontSize)) * canvasObject.scaleX);
                                    } else {
                                        obj.ccTextRegion.height = '' + (((+canvasObject.fontSize * 2)) * canvasObject.scaleX);
                                    }
                                });
                            }
                        });
                        this.textRegionsToUpdate.push(obj.ccTextRegion);
                    }
                });
            }
            if (child.length) {
                let sel = new fabric.ActiveSelection(child, {
                    canvas: canvas
                });

                if (i === 0) {
                    topPos = (child.length && child[0].snapInRegion) ? child[0].snapInRegion.y : textRegion.top;
                } else {
                    topPos = topPos + (lastGroupHeight + 15);
                }

                sel.set({
                    left: textRegion.left,
                    top: topPos
                });
                lastGroupHeight = sel.height;
                sel.setObjectsCoords();
                sel.setCoords();
                canvas.setActiveObject(sel);
                // this.updateActiveTextRegion(false, true);
                canvas.discardActiveObject();

                sel.forEachObject((obj) => {
                    // const canvasObject = _.find(canvas.getObjects(), {id: obj.id});
                    // if (obj.type === 'CurvesText') {
                    //     obj.ccTextRegion.x = obj.aCoords.tl.x;
                    //     obj.ccTextRegion.y = obj.aCoords.tl.y;
                    //     this.textRegionsToUpdate.push(obj.ccTextRegion)
                    // }
                    if (obj.type === 'CurvesText') {
                        const canvasObject = _.find(canvas.getObjects(), {id: obj.id});
                        obj.ccTextRegion.x = canvasObject.aCoords.tl.x;
                        obj.ccTextRegion.y = canvasObject.top;
                        obj.ccTextRegion.width = canvasObject.width * canvasObject.scaleX;
                        obj.ccTextRegion.textBlocks.forEach(textBlockData => {
                            if (textBlockData.xmlText) {
                                textBlockData.xmlText.forEach(textObj => {
                                    textObj.pointsize = canvasObject.fontSize * canvasObject.scaleX;
                                    // multilines - need to increase height of textregion
                                    if (!!canvasObject.textLines && canvasObject.textLines.length > 1) {
                                        obj.ccTextRegion.height = '' + (((+canvasObject.fontSize * canvasObject.textLines.length + +canvasObject.fontSize)) * canvasObject.scaleX);
                                    } else {
                                        obj.ccTextRegion.height = '' + (((+canvasObject.fontSize * 2)) * canvasObject.scaleX);
                                    }
                                });
                            }
                        });
                        this.textRegionsToUpdate.push(obj.ccTextRegion);
                    }
                });
            }
        }

        canvas.requestRenderAll();
        if (this.textRegionsToUpdate.length) {
            this.updateTextAjaxCalls = [this.textRegionsToUpdate];
            this.updateTextObjectInAPI(this.activeCanvasIndex);
        }
        // if (this.textRegionsToUpdate.length) {
        //     this.customiseMenuService.updateBulkTextRegionInJob(
        //         this.jTemplateId, this.activeCanvasIndex + 1, this.textRegionsToUpdate, this.security_token).subscribe((updatedTextRes: RestResponse) => {
        //         this.updatedOnAnotherEvent = false;
        //         this.textRegionsToUpdate = [];
        //     });
        // }
    }

    /** Selection of current active object and config changes in canvas */
    objectSelected(event, index) {
        if (event.target.isEditing) {
            this.showDelete = false;
        } else {
            this.showDelete = true;
        }
        // this.activeCanvasIndex = index;
        this.objectNotSelected = true;
        const selectedObj = this.canvas[this.activeCanvasIndex].getActiveObject();
        if (selectedObj && event.target.get('type') === 'image') {
            selectedObj.imageCatalogue = this.imageCatalogue;
            this.lastSelectedObject = selectedObj;
            this.lastImageObjectSelected = true;
            this.customiseMenuPropertyService.selectedImage = selectedObj;
            this.customiseMenuPropertyService.editImageRules = selectedObj.ccImage && selectedObj.ccImage.EditRules || [];
            // this.imageEditorConfigs = {
            //     width: selectedObj.width * event.target.scaleX * (this.selectedScale / 100),
            //     height: selectedObj.height * event.target.scaleY * (this.selectedScale / 100)
            // };
        }
        if (selectedObj && event.target.get('type') === 'CurvesText') {
            if (event.target.text && event.target.text.includes('{{') && event.target.text.includes('}}')) {
                event.target.editable = false;
            } else {
                this.objectNotSelected = false;
                this.activeTextObject = event.target;
                this.activeLastIndex = index;
                // only valid for text
                // // console.log(event.target.text, 'event.target.text.isUpperCase()');
                let upercase = true;
                let titleCase = false;
                let letters = event.target.text;
                for (let i = 0; i < letters.length; i++) {
                    if (letters[i] !== letters[i].toUpperCase()) {
                        upercase = false;
                    }
                }
                if (event.target.fontCharacterStyle === 'Normal') {
                    upercase = false;
                }
                if (event.target.fontCharacterStyle === 'Title') {
                    titleCase = true;
                }
                this.selectedObjFontsStyles = {
                    fontFamily: event.target.fontFamily,
                    fontSize: event.target.fontSize * event.target.scaleX,
                    fontAlign: event.target.textAlign,
                    fontWeight: 'normal',
                    fontStyle: 'normal',
                    underline: event.target.underline ? true : false,
                    caps: upercase,
                    Title: titleCase,
                    color: event.target.fill
                };
            }
        }
    }

    /** Admin can give access modifier for image editing */
    submitImageEditRules(rules: any): void {
        const activeObj = this.canvas[this.activeCanvasIndex].getActiveObject();

        activeObj.ccImage.EditRules = [{
            editable: rules.editable,
            deletable: rules.deletable,
            movable: rules.movable,
            resizable: rules.resizable
        }];
        this.imageDataOps(activeObj, 'update');
    }

    /** Admin can give access modifier for texts editing */
    setEditTextRules(rules: any): void {
        // const activeObject = _.find(this.canvas[this.customiseMenuPropertyService.activeIndex].getObjects(), {ccTextRegion: this.customiseMenuPropertyService.editTextArea});
        const activeObject = this.canvas[this.customiseMenuPropertyService.activeIndex].getActiveObject();
        activeObject.editable = rules.editable ? true : false;
        activeObject.lockMovementX = rules.movable ? false : true;
        activeObject.lockMovementY = rules.movable ? false : true;
        if (!rules.resizable) {
            activeObject.setControlsVisibility({
                bl: false,
                br: false,
                tl: false,
                tr: false,
                mt: false,
                mb: false,
                ml: false,
                mr: false
            });
        } else {
            activeObject.setControlsVisibility({
                bl: true,
                br: true,
                tl: true,
                tr: true,
                ml: true,
                mr: true
            });
        }
        // activeObject.lockScalingX = rules.resizable ? false : true;
        // activeObject.lockScalingY = rules.resizable ? false : true;
        let upercase = true;
        let titleCase = false;
        let letters = activeObject.text;
        for (let i = 0; i < letters.length; i++) {
            if (letters[i] !== letters[i].toUpperCase()) {
                upercase = false;
            }
        }
        if (activeObject.fontCharacterStyle === 'Normal') {
            upercase = false;
        }
        if (activeObject.fontCharacterStyle === 'Title') {
            titleCase = true;
        }
        this.selectedObjFontsStyles = {
            fontFamily: activeObject.fontFamily,
            fontSize: activeObject.fontSize * activeObject.scaleX,
            fontAlign: activeObject.textAlign || activeObject.fontAlign,
            fontWeight: activeObject.fontWeight,
            fontStyle: activeObject.fontStyle,
            underline: activeObject.underline,
            caps: upercase,
            Title: titleCase,
            color: this.customiseMenuSharedService.getRgbFromCmyk(activeObject.fill)
        };
        this.canvas[this.customiseMenuPropertyService.activeIndex].renderAll();
        // doomedObj.ccTextRegion.editRules[0]
        if (!this.customiseMenuPropertyService.editTextArea.editRules) {
            this.customiseMenuPropertyService.editTextArea.editRules = [{}]
        }
        this.customiseMenuPropertyService.editTextArea.editRules[0].deletable = rules.deletable ? '1' : '0';
        this.customiseMenuPropertyService.editTextArea.editRules[0].editable = rules.editable ? '1' : '0';
        this.customiseMenuPropertyService.editTextArea.editRules[0].movable = rules.movable ? '1' : '0';
        this.customiseMenuPropertyService.editTextArea.editRules[0].resizable = rules.resizable ? '1' : '0';
        this.updateTextAjaxCalls.push([this.customiseMenuPropertyService.editTextArea]);
        this.updateTextObjectInAPI(this.customiseMenuPropertyService.activeIndex);
    }

    /** Change current canvas background color*/
    changeBackgroundColor(color: string): void {
        let activeCanvas = this.canvas[this.activeCanvasIndex];

        this.grids[this.activeCanvasIndex].showLoader = true;
        this.customiseMenuService.applyJobGridBackgroundColour(this.jTemplateId, this.activeCanvasIndex + 1, this.customiseMenuSharedService.hexToRgb(color), this.security_token).subscribe(() => {
            activeCanvas.backgroundImage = false;
            activeCanvas.setBackgroundColor(color, () => {
                activeCanvas.renderAll();
                this.grids[this.activeCanvasIndex].showLoader = false;
            });
        }, () => {
            this.grids[this.activeCanvasIndex].showLoader = false;
        });
    }

    /** Change current canvas size */
    changeSize() {
        let data = {
            height: this.selectedSize.height,
            width: this.selectedSize.width
        };
        this.customiseMenuService.resizeJobTemplate(this.jTemplateId, data, this.security_token).subscribe((response: any) => {
            this.spinner = true;
            this.objectNotSelected = true;
            this.isCropMode = false;
            this.jTemplateId = response.instance;
            this.activeCanvasIndex = 0;
            this.templateSizes.forEach((sizeData) => {
                if (sizeData.name === this.selectedSize.name) {
                    sizeData.selected = "selected";
                } else {
                    sizeData.selected = "";
                }
            });
            this.loadFontsPng(true, false, true);
        });
    }

    // Fetch predefined textGroups for Text Tabs
    getTextTabData() {
        // make service call to see if there is already cooked version of text styles as textregions
        this.textStyleSvgs = [];
        this.customiseMenuService.getTemplateStyleSvgByTemplateId(this.baseTemplateId, this.security_token)
            .subscribe((res: RestResponse) => {
                if (res.statusCode === 200) {
                    this.textStyleSvgs = res.instance;
                    this.textStyleSvgs = [...this.textStyleSvgs];
                }
            })
    }

    /** Upload Images overlay */
    uploadImages(): void {
        this.convertComponentToDom(ImageUploadComponent);
    }

    /** Open Share Model */
    openShareModel() {
        let title = '';
        let text;
        let labelConfirm = '';
        let labelCancel = '';
        this.translate.get('label.ShareJobTemplate').subscribe((res: string) => {
            title = res;
        });
        this.translate.get('label.email').subscribe((res: string) => {
            text = res;
        });
        this.translate.get('label.Share').subscribe((res: string) => {
            labelConfirm = res;
        });
        this.translate.get('label.cancel').subscribe((res: string) => {
            labelCancel = res;
        });
        this.swal({
            title: title,
            text: text,
            input: 'email',
            showCancelButton: true,
            confirmButtonText: labelConfirm,
            cancelButtonText: labelCancel,
            showLoaderOnConfirm: true,
            preConfirm: (email) => {
                return new Promise((resolve) => {
                    const data = {
                        email: email.toLowerCase()
                    }
                    this.customiseMenuService.shareJobTemplate(this.jTemplateId, data, this.security_token).subscribe(response => {
                        resolve(response)
                    }, err => {
                        resolve(err)
                    })
                })
            },
            allowOutsideClick: () => !this.swal.isLoading()
        }).then((result) => {
            this.displayToaster('success', ['Email has been sent successfully!']);
        })
    }

    /** Update TermsandCondition **/
    updateTermsandCondition() {
        const activeIndex = this.canvas[this.activeCanvasIndex].getActiveObject() ? this.activeCanvasIndex : this.activeLastIndex;
        const activeObject = this.canvas[activeIndex].getActiveObject();
        if (activeObject.text) {
            this.customiseMenuPropertyService.dynamicTextFields.forEach(data => {
                if (data.required) {
                    activeObject.text = activeObject.text.replace(`{{${data.fieldName}}}`, data.value);
                    // activeObject.text = '123';
                    activeObject.editable = true;
                    this.canvas[activeIndex].renderAll();
                } else {
                    activeObject.text = activeObject.text.replace(`{{!${data.fieldName}}}`, data.value ? data.value : '');
                    activeObject.editable = true;
                    // activeObject.text = '456';
                    this.canvas[activeIndex].renderAll();
                }
            })
        }

    }
}
