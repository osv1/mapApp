import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadArtworkComponent } from './download-artwork.component';

describe('DownloadArtworkComponent', () => {
  let component: DownloadArtworkComponent;
  let fixture: ComponentFixture<DownloadArtworkComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownloadArtworkComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadArtworkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
