import {Component, Input, Output, OnInit, SimpleChanges, EventEmitter, Injector} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";
import {CustomiseMenuService} from "../customise-menu.service";
import * as _ from 'lodash';

declare var $: any;

@Component({
    selector: 'app-download-artwork',
    templateUrl: './download-artwork.component.html',
    styleUrls: ['./download-artwork.component.css']
})
export class DownloadArtworkComponent extends BaseComponent implements OnInit {
    downloadSize = [];
    downloadOption = ['PDF - Hi Res', 'PDF - Lo Res', 'PNG', 'JPG'];
    @Input() templateSizes: any;
    @Input() jTemplateId: number;
    @Input() security_token: string;
    socialView: boolean = false;

    constructor(inj: Injector, private customiseMenuPropertyService: CustomiseMenuPropertyService, private customiseMenuService: CustomiseMenuService) {
        super(inj)
    }

    ngOnInit() {
        // allow click inside dropdown
        $(document).on('click', '.dropdown-menu .download-container', function (e) {
            e.stopPropagation();
        });
    }

    ngOnChanges(templateSizes: SimpleChanges) {
        this.downloadSize = [];
        this.templateSizes.forEach(data => {
            data.selectedType = 'PDF - Lo Res';
            if (data.selected === 'selected') {
                data.checkedSize = true;
                this.downloadSize.push(data);
            } else {
                data.checkedSize = false;
            }
        });

        const socialView = _.filter(this.templateSizes, (val) => {
            if (val.name === 'Instagram' || val.name === 'Facebook') {
                return true;
            }
        });

        if (socialView.length) {
            this.socialView = true;
        } else {
            this.socialView = false;
        }
    }

    // Update downloadSize array when we select any type.
    selectedCheckbox(size) {
        if (this.downloadSize.filter(data => data.name === size.name).length) {
            this.downloadSize = this.downloadSize.filter(data => data.name !== size.name);
        } else {
            this.downloadSize.push(size);
        }
    }

    // update option in downloadSize array
    updateOption(size, type) {
        if (this.downloadSize.filter(data => data.name === size.name).length) {
            this.downloadSize.filter(data => data.name === size.name)[0].selectedType = type;
        }
    }

    /** construct download link based on conversion type */
    getDownloadLink(type) {
        this.downloadSize.forEach((data) => {
            let finalType: string = 'pdf';  // TODO may need to amend param values
            let lowres = 'false';
            const bleeds = 'true';
            const overprint = 'true';
            if (data.selectedType === 'PDF - Lo Res') {
                finalType = 'pdf';
                lowres = 'true';
            } else if (data.selectedType === 'JPG') {   // will get zipped images
                finalType = 'jpg';
            } else if (data.selectedType === 'PNG') {   // will get zipped images
                finalType = 'png';
            }

            const downloadLink = `${this.commonService._restv2api}TemplateService/v1/jobTemplate/${this.jTemplateId}/${finalType}?token=${this.security_token}&bleeds=${bleeds}&overprint=${overprint}&lowres=${lowres}&width=${data.width}&height=${data.height}`;
            if (data.selectedType !== 'PDF - Lo Res') {
                this.swal({
                    title: 'You are about to make a purchase',
                    html: 'By clicking purchase, your artwork will be locked for further editing and your account will be charged.',
                    focusConfirm: false,
                    customClass: 'save-design',
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: "Don't Purchase",
                    confirmButtonText: "Purchase"
                }).then((result) => {
                    if (result.value) {
                        this.swal({
                            title: 'Costs',
                            html: 'Costs of the template is $1.M.',
                            focusConfirm: false,
                            customClass: 'save-design',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            cancelButtonText: "Don't Proceed",
                            confirmButtonText: "Proceed"
                        }).then((result) => {
                            if (result.value) {
                                this.customiseMenuService.lockJTemplate(this.jTemplateId, this.security_token).subscribe((res) => {
                                    this.downloadSize.forEach((data) => {
                                        let finalType: string = 'pdf';  // TODO may need to amend param values
                                        let lowres = 'false';
                                        const bleeds = 'true';
                                        const overprint = 'true';
                                        if (data.selectedType === 'PDF - Lo Res') {
                                            finalType = 'pdf';
                                            lowres = 'true';
                                        } else if (data.selectedType === 'JPG') {   // will get zipped images
                                            finalType = 'jpg';
                                        } else if (data.selectedType === 'PNG') {   // will get zipped images
                                            finalType = 'png';
                                        }

                                        const downloadLink = `${this.commonService._restv2api}TemplateService/v1/jobTemplate/${this.jTemplateId}/${finalType}?token=${this.security_token}&bleeds=${bleeds}&overprint=${overprint}&lowres=${lowres}&width=${data.width}&height=${data.height}`;
                                        window.open(downloadLink, '_blank');
                                    });

                                    if (res.statusCode === 200) {
                                        this.customiseMenuPropertyService.locked = true;
                                    } else {
                                        this.customiseMenuPropertyService.locked = null;
                                    }
                                }, () => {
                                    this.customiseMenuPropertyService.locked = null;
                                });
                            }

                        });
                    }

                });
                return;
            }
            window.open(downloadLink, '_blank');
        });
    }
}
