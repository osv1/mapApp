import {Component, OnInit, Injector} from '@angular/core';
import {CustomiseMenuService} from '../customise-menu.service';
import {TextRegion} from "../../../common/models/TextRegion";
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";
import {BaseComponent} from '../../../common/commonComponent';
import {RestResponse} from "../../../common/models/RestResponse";
import {EditRules} from "../../../common/models/EditRules";

declare const fabric: any;

/** manipulate 1. base template's pre-defined text styles from texts tab or 2. text from canvas */
@Component({
    selector: 'app-edit-text-rules',
    templateUrl: './edit-text-rules.component.html',
    styleUrls: ['./edit-text-rules.component.css']
})
export class EditTextRulesComponent extends BaseComponent implements OnInit {
    scaleFactor: number = 0.6;
    canvas;
    editRules: any = {};
    canvasHeight: number;

    constructor(inj: Injector, public customiseMenuPropertyService: CustomiseMenuPropertyService, private customiseMenuService: CustomiseMenuService) {
        super(inj)
    }

    ngOnInit(): void {
        if (this.customiseMenuPropertyService.editTextArea.editRules && this.customiseMenuPropertyService.editTextArea.editRules.length) {
            this.editRules.editable = this.customiseMenuPropertyService.editTextArea.editRules[0].editable && this.customiseMenuPropertyService.editTextArea.editRules[0].editable === '0' ? false : true;
            this.editRules.deletable = this.customiseMenuPropertyService.editTextArea.editRules[0].deletable && this.customiseMenuPropertyService.editTextArea.editRules[0].deletable === '0' ? false : true;
            this.editRules.movable = this.customiseMenuPropertyService.editTextArea.editRules[0].movable && this.customiseMenuPropertyService.editTextArea.editRules[0].movable === '0' ? false : true;
            this.editRules.resizable = this.customiseMenuPropertyService.editTextArea.editRules[0].resizable && this.customiseMenuPropertyService.editTextArea.editRules[0].resizable === '0' ? false : true;
        } else {
            this.editRules = {
                editable: true,
                deletable: true,
                movable: true,
                resizable: true
            }
        }
    }

    ngAfterViewInit() {
        this.canvas = new fabric.Canvas(`editorCanvas`, {
            width: 335,
            height: 80,
            stateful: true,
            crossOrigin: 'anonymous'
        });

        this.canvas.originalCanvasWidth = 380;
        this.canvas.originalCanvasHeight = 80;

        // TODO this.customiseMenuPropertyService.templateTextStyleSvg with svg definition exist simply display the svg

        if (this.customiseMenuPropertyService.editTextArea) {
            // this.placeTextRegionsForSelectedStyle(1, this.customiseMenuService.editTextArea || {});
            let top = 0;
            let height = 0;
            let width = 0;
            this.customiseMenuPropertyService.editTextArea.textBlocks.forEach((textBlock) => {
                top = top + 20;
                textBlock.xmlText.forEach((xmlTextObj, idx) => {
                    xmlTextObj.vfield.forEach((vfieldObj) => {
                        let underline = false;
                        if (xmlTextObj.characterStyle.toLowerCase().includes('underline')) {
                            underline = true;
                        }
                        let fontWeight = 'normal';
                        if (xmlTextObj.characterStyle.toLowerCase().includes('bold')) {
                            fontWeight = 'bold'
                        }

                        let textRegionWidth = (Number(vfieldObj.value.length) * Number(xmlTextObj.pointsize));
                        width = width + +textRegionWidth;

                        let left = xmlTextObj.tabStop ? xmlTextObj.tabStop.left * this.scaleFactor : 0 * this.scaleFactor;
                        const fontName = xmlTextObj.font.split(',')[0];
                        const text = new fabric.CurvesText(vfieldObj.value, {
                            fontFamily: fontName,
                            width: textRegionWidth,
                            originX: textBlock.align === 'right' ? 'right' : 'left',
                            left: +this.customiseMenuPropertyService.editTextArea.x || left,
                            top: top,
                            textAlign: textBlock.align,
                            fill: +this.customiseMenuPropertyService.editTextArea.x ? this.getRgbFromCmyk(xmlTextObj.color) : 'rbg(0, 0, 0)',
                            fontSize: xmlTextObj.pointsize,
                            lineHeight: 1,
                            editingBorderColor: '#023cf7',
                            lockMovementX: true,  // prevent it from moving by itself
                            lockMovementY: true,  // prevent it from moving by itself
                            underline: underline,
                            fontWeight: fontWeight,
                            cornerStyle: 'circle',
                            lockScalingFlip: true,
                            selectable: false,
                            editable: false
                        });
                        height = height + text.height;
                        this.canvas.add(text);
                        this.canvas.renderAll();
                    })
                });
                if (this.customiseMenuPropertyService.editTextArea.x) {
                    this.canvasHeight = height + 40;
                    this.$('.texteditor_container').css({height:this.canvasHeight})
                    this.canvas.setDimensions({
                        width: Number(width),
                        height: Number(this.canvasHeight)
                    });
                    this.canvas.originalCanvasWidth = width;
                    this.canvas.originalCanvasHeight = this.canvasHeight;
                    this.canvas.renderAll();
                } else {
                    this.canvasHeight = 80;
                    this.$('.texteditor_container').css({height:this.canvasHeight})
                }
            })


        }
    }

    /** cmyk to rgb conversion */
    getRgbFromCmyk(cmykValue: string) {
        if (cmykValue.indexOf('cmyk') !== -1) {
            const cmykObj = (cmykValue.replace('cmyk', '').replace('(', '').replace(')', '')).split(',');
            let R = 255 * (1 - Number(cmykObj[0]) / 255) * (1 - Number(cmykObj[3]) / 255);
            let G = 255 * (1 - Number(cmykObj[1]) / 255) * (1 - Number(cmykObj[3]) / 255);
            let B = 255 * (1 - Number(cmykObj[2]) / 255) * (1 - Number(cmykObj[3]) / 255);

            // if text is white background colour needs to be updated
            if (R === 255 && G === 255 && B === 255) {
                return 'black';
            }

            // to int value
            R = parseInt('' + R, 10);
            G = parseInt('' + G, 10);
            B = parseInt('' + B, 10);

            return `rgb(${R}, ${G}, ${B})`;
        }
        // if text is white background colour needs to be updated
        if (cmykValue === 'rgb(255, 255, 255)' || cmykValue === '#ffffff') {
            return 'black';
        }
        return cmykValue;
    }

    /** save edit rules and svg definition to backend */
    saveToSvg() {
        const svg = this.canvas.toSVG({
            suppressPreamble: true
        });
        console.log(svg, 'svg');

        if (!!this.customiseMenuPropertyService.templateTextStyleSvg) {       // opened from pre-defined style from texts tab
            this.customiseMenuPropertyService.templateTextStyleSvg.preTextRegion.editRules = this.convertEditRules();
            // all textregions in the same group will share the same edit rules
            this.customiseMenuPropertyService.templateTextStyleSvg.textRegions.forEach((textRegion: TextRegion) => {
                textRegion.editRules = this.convertEditRules();
            })
            this.customiseMenuPropertyService.templateTextStyleSvg.svgDefinition = svg;

            // update templateStyleSvg
            this.customiseMenuService.updateTemplateTextStyleSvg(this.customiseMenuPropertyService.baseTemplateId, this.customiseMenuPropertyService.templateTextStyleSvg, this.customiseMenuPropertyService.apiToken)
                .subscribe((res: RestResponse) => {
                    if (res.statusCode !== 200) {
                        console.error('Failed to update textStyleSvg!')
                    }
                    this.customiseMenuPropertyService.templateTextStyleSvg = null;
                });

        } else {    // opened from canvas text object - apply rules to jtemplate textregions
            if (this.customiseMenuPropertyService.editTextArea.x) {
                this.broadcaster.broadcast('setTextRules', this.editRules);
            }
        }
        this.closeModel();
    }

    /** convert boolean values to string flags */
    convertEditRules(): EditRules[] {
        const editRulesArray: EditRules[] = [];
        let editRules = new EditRules();
        editRules.editable = this.editRules.editable ? '1' : '0';
        editRules.deletable = this.editRules.deletable ? '1' : '0';
        editRules.movable = this.editRules.movable ? '1' : '0';
        editRules.resizable = this.editRules.resizable ? '1' : '0';
        editRulesArray.push(editRules);
        return editRulesArray;
    }
}
