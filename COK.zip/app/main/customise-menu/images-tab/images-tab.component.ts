import {Component, Injector, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {CustomiseMenuService} from "../customise-menu.service";
import {Page} from "../../../common/models/Page";
import {Asset} from "../../../common/models/Asset";
import {config} from "../../../../assets/config/configs";
import {BaseComponent} from '../../../common/commonComponent';
import {queueScheduler} from "rxjs";
import * as _ from 'lodash';


@Component({
    selector: 'app-images-tab',
    templateUrl: './images-tab.component.html',
    styleUrls: ['./images-tab.component.css']
})
export class ImagesTabComponent extends BaseComponent implements OnInit {
    @Input() token: string;
    @Output() loadMoreAssets: any = new EventEmitter();
    @Input() cursorStyle: string;   //'pointer' or 'wait' just after imaged style is selected
    searchText: any;
    searchFilter: string = '';
    //thumbPath: string = 'AssetService/v1/get/asset/preview';    //use AssetService preview to be able to resize return image    //'PreviewService/get/assetThumbnail';
    pageAssets: Page<Asset> = new Page<Asset>();    // pageful of assets to display
    assetImages: Asset[] = [];
    assetMetaData = [];
    assetTypes: string[] = [];      // asset search filters
    displayMessage = '';
    successMessage = '';
    JSON: any = JSON;
    public imageSpinner = false;
    constructor(inj: Injector, private customiseMenuService: CustomiseMenuService) {
        super(inj);
        // this.getImageTypes();
        this.commonService.isUploadLocal = false;
        this.commonService.imageTypeFields = [];
        this.fileUploaderService.ngOnInit();
        this.broadcaster.on('fileupload').subscribe((success) => {
            this.imageSpinner = true;
            this.addAssetDetails(this.assetMetaData,success);
        });
        this.broadcaster.on('fileAlreadyUploaded').subscribe((success) => {
            this.displayToaster('error',['File already exits'])
        });
    }

    /** respond data-bound input properties (re)sets - token */
    ngOnChanges() {
        this.pageAssets.page = 0;
        this.pageAssets.pageSize = 20;
    }

    /** called every time this tab displays */
    ngOnInit() {
        this.getAssetMeta();

        this.broadcaster.on('fileupload').subscribe((success: any) => {

        });

        // reload the last search text for initial search
        if (window.localStorage) {  // localStorage supported
            this.searchText = !!localStorage.getItem('searchTxt') ? localStorage.getItem('searchTxt') : '';
            this.pageAssets.search = this.searchText;
        }

        // get a list of filters
        this.fetchAssetFilters();
        // let's get asset images to display
        this.fetchMoreAssets();
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Function to add  the assets                          //
    ///////////////////////////////////////////////////////////////////////////
    addAssetDetails(assetData,fileMetaList) {
        // Call prepMetadataForSubmission function
        const returnAssetMetaDataList: any = this.prepMetadataForSubmission(assetData, undefined, undefined, true);
        // Puneet - matching the call

        if (returnAssetMetaDataList === null) {
            this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.imageSpinner = false;
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            return;
        }

        if (fileMetaList.length === 0) {
            this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.imageSpinner = false;
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            return;
        }

        // now allow multiple files
        /*if ( this.fileMetaList != null && this.fileMetaList.length > 1 ) {
            sharedService.displayToaster('error', [$translate('MultiFilesAreNOTSupported')], 5000, $translate('MultipleFiles'));
            return;
        }*/

        if (fileMetaList) {

            // pick up required details only and create a file list to submit
            const filesToAdd: any = [];

            fileMetaList.forEach((f, index) => {
                let fileMeta: any;
                if(f.length) {
                    fileMeta = {
                        fileName: f[0].fileName,
                        fileSize: '',
                        fileType: f[0].fileType,
                        realFileName: f[0].realFileName
                    };
                } else {
                    fileMeta = {
                        fileName: f.fileName,
                        fileSize: '',
                        fileType: f.fileType,
                        realFileName: f.realFileName
                    };
                }
                filesToAdd.push(fileMeta);
            });
            const fileData = {
                categoryID: 0, // Right now it is static but need to be dynamic
                catalogue: "COKE",
                metadata: [
                    "F_RecordName|=|" + filesToAdd[0].fileName ? filesToAdd[0].fileName.split('.')[0] : ''
                ],
                fileMeta: filesToAdd
            }
            queueScheduler.schedule(() => {
                this.customiseMenuService.addAssetImage(fileData, this.customiseMenuService.security_token).subscribe((res: any) => {
                    if (res.statusCode === 200) {
                        this.translate.get('NewAssetHasBeenAddedSuccessfully').subscribe((res: string) => {
                            this.displayMessage = res;
                        });
                        this.translate.get('Success').subscribe((res: string) => {
                            this.successMessage = res;
                        });
                        res.instanceList.forEach(obj => {
                            this.assetImages.unshift(obj);
                        });
                        this.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
                        this.loadMoreAssets.emit(_.chain(this.assetImages).map('catalogue').uniq().value()[0]);
                        this.imageSpinner = false;
                    } else {
                        this.imageSpinner = false;
                    }
                });
            });
        } else {
            this.imageSpinner = false;
            this.translate.get('PleaseUploadFileAtleastToAddTheAsset').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        }
    }

    /** get a types of assets*/
    getImageTypes(clientID?) {
        const clientid = clientID ? clientID : 0;
        this.commonService.callApi(this.setSecurePath() + '/element/getClientStyleFieldOptions' +
            '', this.attachToken({
            clientID: clientid,
            typeID: 2,
            uid: 0
        }), 'post').then((fieldOptions: any) => {
            this.commonService.imageTypeFields = fieldOptions;
            let match = this.commonService.imageTypeFields.find((type) => {
                return this.constants.STYLE_FIELD_TYPE_IMAGE === type.displayName.toLowerCase();
            });
            this.commonService.artworkFieldName = !!match ? match.key : ''; // set default value
        });
    }

    /** get a metadata of assets*/
    getAssetMeta() {
        this.assetMetaData = [];
        this.commonService.callApiRestV2('AssetService/asset/getAssetMetaDataListWithoutValue', {
            catalogue: 'GOWORKS',
            token: this.token
        }, 'post').then(
            (assetmetaData: any) => {
                this.assetMetaData = assetmetaData;
                this.assetMetaData.forEach((data: any) => {
                    data.editingURL = data.fieldValue === null || data.fieldValue === '' || data.fieldValue === undefined;
                });
            }
        );
    }

    /** get a pageful of assets for next page */
    fetchMoreAssets() {
        this.pageAssets.inProgress = true;
        this.customiseMenuService.searchImageAssets(this.pageAssets.page + 1, this.pageAssets.pageSize, this.pageAssets.search, this.token, this.searchFilter)
            .subscribe((page: Page<Asset>) => {
                //set missing variable from return page instance
                page.inProgress = true;
                page.noMore = false;
                //page instance with current options inc. page, fetchSize, search ...
                this.pageAssets = page;
                if (!!page.rows && page.rows.length > 0) {
                    page.rows.map(asset => {
                        //asset.assetThumbnailPath = config.restv2api + this.thumbPath + `?format=jpeg&catalogue=${asset.catalogue}&assetID=${asset.assetID}&token=${this.token}`;
                        // update to use AssetService preview call to allow scaled version to avoid the issue that arises when the actual image size is smaller than thumbnail
                        asset.assetThumbnailPath = config.restv2api + config.assetThumbPath/*'AssetService/v1/get/asset/preview'*/ + `?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.token}`;
                        this.assetImages.push(asset);
                    });

                } else {
                    this.pageAssets.noMore = true;
                    console.log('No assets to display!');
                }
                this.pageAssets.inProgress = false;
                this.loadMoreAssets.emit(_.chain(page.rows).map('catalogue').uniq().value()[0]);

                // keep the last search text
                if (window.localStorage) {  // localStorage supported
                    localStorage.setItem('searchTxt', this.pageAssets.search);
                }

            });
    }

    /** get available asset types to populate filters */
    fetchAssetFilters() {
        this.customiseMenuService.getAssetFilters('', this.token)
            .subscribe((assetTypes: string[]) => {
                this.assetTypes = assetTypes;
            });
    }

    /** Function to search  the assets */
    searchAssets(searchText?: string) {
        this.searchText = searchText || this.searchText || '';
        this.pageAssets.page = 0;
        this.pageAssets.noMore = false;
        this.pageAssets.search = this.searchText;
        this.assetImages = [];
        this.fetchMoreAssets();
    }

    /** Function to set default  the asset */
    setDefaultPic(event: any) {
        event.target.src = 'assets/images/no-image.png';
        event.target.parentElement.parentElement.style.pointerEvents = 'none';
    }

    /** on/off search filter */
    toggleSearchFilter(assetType: string) {
        if ( this.searchFilter === assetType ) {
            this.searchFilter = '';
        } else {
            this.searchFilter = assetType;
        }

        // need to refresh asset search results based on filter selected
        this.searchAssets();
    }
}
