import {Injectable} from '@angular/core';
import {EditRules} from "../../common/models/EditRules";

@Injectable({
    providedIn: 'root'
})
export class CustomiseMenuSharedService {
    constructor() {

    }

    /** cmyk to rgb conversion */
    getRgbFromCmyk(cmykValue: string) {
        if (cmykValue.indexOf('cmyk') !== -1) {
            const cmykObj = (cmykValue.replace('cmyk', '').replace('(', '').replace(')', '')).split(',');
            let R = 255 * (1 - Number(cmykObj[0]) / 255) * (1 - Number(cmykObj[3]) / 255);
            let G = 255 * (1 - Number(cmykObj[1]) / 255) * (1 - Number(cmykObj[3]) / 255);
            let B = 255 * (1 - Number(cmykObj[2]) / 255) * (1 - Number(cmykObj[3]) / 255);

            // to int value
            R = parseInt('' + R, 10);
            G = parseInt('' + G, 10);
            B = parseInt('' + B, 10);

            return `rgb(${R}, ${G}, ${B})`;
        }
        return cmykValue;
    }

    /** convert string into titlecase */
    titleCase(str) {

        str = str.toLowerCase().split(' ');

        let final = [];

        for (let word of str) {
            final.push(word.charAt(0).toUpperCase() + word.slice(1));
        }

        return final.join(' ')

    }

    /** Convert color hex to rgba */
    hexToRgb(hex: string): string {
        let c;
        if (/^#([A-Fa-f0-9]{3}){1,2}$/.test(hex)) {
            c = hex.substring(1).split('');
            if (c.length == 3) {
                c = [c[0], c[0], c[1], c[1], c[2], c[2]];
            }
            c = '0x' + c.join('');
            return 'rgb(' + [(c >> 16) & 255, (c >> 8) & 255, c & 255].join(',') + ')';
        }

        return hex;
    }

    /** return array of single editRules*/
    buildEditRulesAsArray(): EditRules[] {
        const editRulesAsArray: EditRules[] = [];
        const editRules = this.buildEditRules();
        editRulesAsArray.push(editRules);
        return editRulesAsArray;
    }

    /** build up editRules */
    buildEditRules(): EditRules {
        const editRules = new EditRules();
        editRules.editable = '1';
        editRules.deletable = '1';
        editRules.movable = '1';
        editRules.resizable = '1';
        //TODO other varialbes to set
        return editRules;
    }

    /** get true/false from string flag '1' or '0' */
    getBoolean(flag: string): boolean {
        return !!flag && flag === '1' ? true : false;
    }

    /** decides if it is digital template by grid size */
    isDigital(width: number, height: number): boolean {
        if (width === 1080 && height === 1080) {    //instagram
            return true;
        } else if (width === 1200 && height === 628){   //facebook
            return true;
        } else {
            return false;
        }
    }
}
