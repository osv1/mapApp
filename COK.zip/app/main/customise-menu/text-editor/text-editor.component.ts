import {Component, Input, OnInit, Output, EventEmitter, SimpleChanges, Injector} from '@angular/core';
import {TextRegion} from '../../../common/models/TextRegion';
import {TextBlock} from '../../../common/models/TextBlock';
import {xmlText} from '../../../common/models/xmlText';
import {vfield} from "../../../common/models/vfield";
import {FieldRule} from "../../../common/models/FieldRule";
import {TabStop} from "../../../common/models/TabStop";
import {Constraint} from "../../../common/models/Constraint";
// import {CustomiseMenuService} from '../customise-menu.service';
import {BaseComponent} from '../../../common/commonComponent';
import {EditTextRulesComponent} from '../edit-text-rules/edit-text-rules.component';
import {CustomiseMenuPropertyService} from '../customise-menu-property.service';
import {CustomiseMenuService} from "../customise-menu.service";
import {TemplateTextStyleSvg} from "../../../common/models/TemplateTextStyleSvg";
import {RestResponse} from "../../../common/models/RestResponse";
import {EditRules} from "../../../common/models/EditRules";
import {CustomiseMenuSharedService} from "../customise-menu-shared.service";

/** responsible for working out textRegions from base template's eligible text-types */
@Component({
    selector: 'app-text-editor',
    templateUrl: './text-editor.component.html',
    styleUrls: ['./text-editor.component.css']
})
export class TextEditorComponent extends BaseComponent implements OnInit {
    @Output() textStylesAsGroupTextRegions = new EventEmitter();    // will be used in customiseMenu component
    @Input() textStylesRaw: any;
    @Input() maxTextWidth: string;
    @Input() fieldRules: FieldRule[];
    //@Input() textFlowRegionWidth: string;   // the 1st empty region width
    //@Output() textblock = new EventEmitter();
    //@Output() addTextBlock = new EventEmitter();
    @Output() outTextRegions = new EventEmitter();  // multiple regions
    @Input() cursorStyle: string;   //'pointer' or 'wait' just after text style is selected
    @Output() addTextRegion = new EventEmitter();    // will be used in customiseMenu component
    cardBackColour: string = '#FFFFFF'; // white by default
    largestTabStopLeft: number = 0;     // used to adjust card width
    textsTabWidth: number = 0;
    scaleFactor: number = 0.6;
    formattedTextStylesAsTextRegions: TextRegion[] = [];    // text-styles will be formatted as textRegion to be ready for insertion onto canvas
    mapGroupTextRegions = new Map<string, TextRegion[]>();    // key : style id & value : array of text regions to be displayed
    JSON: any = JSON;
    @Input() textStyleSvgs:any;
    svgDefinitions: string[] = [];      //use svg def to display styles when all styles has svgs

    constructor(inj: Injector,
                public customiseMenuPropertyService: CustomiseMenuPropertyService,
                private customiseMenuService: CustomiseMenuService,
                private customiseMenuSharedService: CustomiseMenuSharedService) {
        super(inj)
    }

    // respond data-bound input properties (re)sets
    ngOnChanges(changes: SimpleChanges) {
        if (!this.customiseMenuPropertyService.baseTemplateId || !this.customiseMenuPropertyService.apiToken) {
            return;
        }
        this.initialTextRegion()
    }

    ngOnInit(): void {
        this.initialTextRegion()
    }

    ngAfterViewInit() {
    }

    /** fired when menu item is clicked - will pass selected style index value to main customise component */
    selectMenuStyle(fontStyle: object, index): void {
        if (this.cursorStyle !== 'wait') {    // TODO temp measure - do not allow insert while previous operation is still in progress
            this.outTextRegions.emit(index);
        }
    }
    initialTextRegion(){
        this.cardBackColour = '#FFFFFF';
        this.largestTabStopLeft = 0;
        this.textsTabWidth = 0;
        if (!this.textStylesRaw) {
            this.textStylesRaw = [];
        }
        if (!!this.textStyleSvgs && this.textStyleSvgs.length > 0) {
            this.formattedTextStylesAsTextRegions = [];     // already cooked style to display items under texts tab
            // use already cooked styles as textregions - no need to process template's text style
            this.mapGroupTextRegions = new Map<string, TextRegion[]>();
            this.textStyleSvgs.forEach((textStyleSvg: TemplateTextStyleSvg, index: number) => {
                this.formattedTextStylesAsTextRegions.push(textStyleSvg.preTextRegion);    //for texts tab
                this.mapGroupTextRegions.set('' + index, textStyleSvg.textRegions);   //for canvas

                // tabStop will not be saved to backend - reset manually here
                this.formattedTextStylesAsTextRegions.forEach((textRegion: TextRegion, index: number) => {
                    textRegion.textBlocks.forEach((textBlock: TextBlock) => {
                        let validVfieldIdx = 0;
                        textBlock.xmlText.forEach((xmlText: any) => {
                            if (xmlText.vfield && xmlText.vfield.length > 0) {
                                // only valid when vfield exists to be eligible index
                                xmlText.tabStop = this.getLeftTextPositionFromTabStops(textBlock.tabStops, validVfieldIdx);
                                validVfieldIdx += 1;
                            }

                            // when the 1st one is empty one
                            if ((!xmlText.vfield || xmlText.vfield.length === 0) && validVfieldIdx === 0) {
                                validVfieldIdx = 1;
                            }
                        });
                    });
                });

                this.textStylesAsGroupTextRegions.emit(this.mapGroupTextRegions);   //pass to main customiseComponent

                if (!!textStyleSvg.svgDefinition) {
                    this.svgDefinitions.push(textStyleSvg.svgDefinition); //TODO use svg def to display styles when all styles has svgs
                }
            });

        } else {    // process template's text style
            this.formatTextStyles(this.textStylesRaw);
        }

        if (this.largestTabStopLeft > 1 && this.largestTabStopLeft < 400) {  // allow full width
            this.textsTabWidth = this.largestTabStopLeft + 90;
            this.scaleFactor = 1;   //no scaling needed
        } else {
            this.textsTabWidth = 400;
            this.scaleFactor = 0.6;
        }
    }
    /** use consistent models to represent text styles to get them added easily as TextRegion in canvas */
    formatTextStyles(textStyleArr: any): void {
        this.mapGroupTextRegions = new Map<string, TextRegion[]>();
        this.formattedTextStylesAsTextRegions = new Array<TextRegion>();
        textStyleArr.forEach((textStyle: any) => {
            if (textStyle.name !== 'Column Break') {
                let textRegion: TextRegion = new TextRegion();
                textRegion.id = textStyle.id;	// !!! region id holds id value of style
                //textRegion.name = textStyle.name;
                //textRegion['display-format'] = textStyle['display-format'];
                textRegion.textBlocks = new Array<TextBlock>();
                // textblock might have single object or an array of multiple items - need to consider both cases
                if (Array.isArray(textStyle.textblock)) {	// array of textblocks
                    textStyle.textblock.forEach((textblock: any) => {      // array of textblocks
                        let textBlock: TextBlock = this.buildTextBlock(textblock, true);
                        textBlock.xmlText = new Array<xmlText>();
                        if (Array.isArray(textblock.text)) {   // array of texts
                            //let validVfieldIdx = 0;
                            textblock.text.forEach((text: any) => {
                                let tempText = this.buildXmlTextWithVFeild(text, textStyle.id);
                                /*if (tempText.vfield && tempText.vfield.length > 0) {  //TODO maybe done after structure is built to overcome unusual case
                                    // only valid when vfield exists to be eligible index
                                    tempText.tabStop = this.getLeftTextPositionFromTabStops(textblock.tabStops, validVfieldIdx);
                                    validVfieldIdx += 1;
                                }*/
                                textBlock.xmlText.push(tempText);
                            });
                            textRegion.textBlocks.push(textBlock);
                        } else {
                            if (!!textblock.tabStops && textblock.tabStops.split('\\\\\\').length > 2) {
                                //console.log('tabStop: ' + textblock.tabStops);
                                // add this text to previous textBlock at position 0
                                textRegion.textBlocks[textRegion.textBlocks.length - 1].xmlText.splice(0, 0, this.buildXmlTextWithVFeild(textblock.text, textStyle.id));

                            } else {
                                if (!!textblock.text) {
                                    textBlock.xmlText.push(this.buildXmlTextWithVFeild(textblock.text, textStyle.id));
                                    textRegion.textBlocks.push(textBlock);
                                }
                            }
                        }
                        //textRegion.textBlocks.push(textBlock);
                    });

                } else {	// single textbloock
                    let textBlock: TextBlock = this.buildTextBlock(textStyle.textblock, true);
                    if (Array.isArray(textStyle.textblock.text)) {     // array of texts
                        //let validVfieldIdx = 0;
                        textStyle.textblock.text.forEach((text: any): void => {
                            let tempText = this.buildXmlTextWithVFeild(text, textStyle.id);
                            /*if (tempText.vfield && tempText.vfield.length > 0) {  //TODO maybe done after structure is built
                                // only valid when vfield exists to be eligible index
                                tempText.tabStop = this.getLeftTextPositionFromTabStops(textStyle.textblock.tabStops, validVfieldIdx);
                                validVfieldIdx += 1;
                            }*/
                            textBlock.xmlText.push(tempText);
                        });
                    } else {
                        if (textStyle.textblock.text) {
                            if (!!textStyle.textblock.tabStops && textStyle.textblock.tabStops.split('\\\\\\').length > 2) {    // unusual case since single text present
                                //console.log('tabStop: ' + textStyle.textblock.tabStops);
                                // add this text to previous textBlock at position 0
                                textRegion.textBlocks[textRegion.textBlocks.length - 1].xmlText.splice(0, 0, this.buildXmlTextWithVFeild(textStyle.textblock.text, textStyle.id));

                            } else {
                                textBlock.xmlText.push(this.buildXmlTextWithVFeild(textStyle.textblock.text, textStyle.id));
                            }
                        }
                    }
                    textRegion.textBlocks.push(textBlock);
                }
                this.formattedTextStylesAsTextRegions.push(textRegion);
            }
        });

        // NOW apply tabStops and get left position to display menu items in texts tab
        this.formattedTextStylesAsTextRegions.forEach((textRegion: TextRegion, index: number) => {
            textRegion.textBlocks.forEach((textBlock: TextBlock) => {
                let validVfieldIdx = 0;
                textBlock.xmlText.forEach((xmlText: any) => {
                    if (xmlText.vfield && xmlText.vfield.length > 0) {
                        // only valid when vfield exists to be eligible index
                        xmlText.tabStop = this.getLeftTextPositionFromTabStops(textBlock.tabStops, validVfieldIdx);
                        validVfieldIdx += 1;
                    }

                    // when the 1st one is empty one
                    if ((!xmlText.vfield || xmlText.vfield.length === 0) && validVfieldIdx === 0) {
                        validVfieldIdx = 1;
                    }
                });

                // if any of xmlText has tabStop

            });

            // each text will have its own textRegions
            this.mapGroupTextRegions.set(/*textRegion.id*/'' + index, this.getTextRegionsAsGroup(textRegion));
        });
        // console.log(this.mapGroupTextRegions);
        this.textStylesAsGroupTextRegions.emit(this.mapGroupTextRegions);   //pass to main customiseComponent

        // save processed textregions to backend, so above cooking will not happen again
        this.formattedTextStylesAsTextRegions.forEach((textRegion: TextRegion, index: number) => {
            const styleSvg = new TemplateTextStyleSvg();
            styleSvg.templateTextStyleSvgID = -1;
            styleSvg.styleName = textRegion.id;
            styleSvg.templateID = this.customiseMenuPropertyService.baseTemplateId;
            styleSvg.preTextRegion = textRegion;
            styleSvg.textRegions = this.mapGroupTextRegions.get('' + index);
            styleSvg.svgDefinition = '';

            // inset new templateStyleSvg for each single/group style
            this.customiseMenuService.insetTemplateTextStyleSvg(this.customiseMenuPropertyService.baseTemplateId, styleSvg, this.customiseMenuPropertyService.apiToken)
                .subscribe((res: RestResponse) => {
                    if (res.statusCode !== 200) {
                        console.error('Failed to insert textStyleSvg!')
                    }
                });
        });
    }

    // textRegion
    //		|- textBlock
    //				|- text / xmlText
    //						|- vfield

    /** textblock from text-styles needs to be modified to be fit into TextBlock */
    buildTextBlock(textblock: any, reqTabStops: boolean): TextBlock {
        let textBlock: TextBlock = new TextBlock();
        textBlock.id = textblock.id;
        textBlock.align = textblock.align;
        textBlock.extraParagraphSpacing = textblock.extraParagraphSpacing;
        textBlock.firstLineIndent = textblock.firstLineIndent;
        textBlock.keepTogether = textblock.keepTogether;
        textBlock.leading = textblock.leading;
        textBlock.leftIndent = textblock.leftIndent;
        textBlock.rightIndent = textblock.rightIndent;
        textBlock.spaceAfter = textblock.spaceAfter;
        textBlock.spaceBefore = textblock.spaceBefore;
        textBlock.tabStops = reqTabStops ? textblock.tabStops : '1\\36\\left\\\\\\';    //require tabStops to generate pdf
        textBlock.xmlText = new Array<xmlText>();	//placeholder to have xmlText instances
        return textBlock;
    }

    /** text from text-styles needs to be modified to be fit into xmlText */
    buildXmlTextWithVFeild(text: any, styleId: string): xmlText {
        let tempText: xmlText = new xmlText();
        tempText.baselineShift = text['baseline-shift'];
        tempText.characterStyle = text['character-style'];
        tempText.horizontalScale = text.horizontalScale;
        tempText.color = this.getRgbFromCmyk(text.color);
        tempText.font = text.font + ',Arial'; // Arial will be applied when there is no matching font found
        tempText.pointsize = text.pointsize;

        tempText.vfield = new Array<vfield>();
        if (text.vfield) {
            let tempVfield = new vfield();
            tempVfield.display = text.vfield.display;
            tempVfield.editRowHeight = text.vfield.editRowHeight;
            tempVfield.editable = text.vfield.editable;
            tempVfield.id = text.vfield.id;
            tempVfield.index = text.vfield.index;
            tempVfield.name = text.vfield.name;
            tempVfield.type = text.vfield.type;

            let match = this.fieldRules.find((fieldRule: FieldRule) => {
                return fieldRule.fieldID === tempVfield.id;
            });
            tempVfield.value = !!match ? (match.defaultValue !== '' ? match.defaultValue : text.vfield.name) : text.vfield.name;
            // TODO may attach fieldrule constraint to vfield
            tempVfield.constraints = !!match ? match.constraints : undefined;

            // caps - uppercase flag     //TODO italic, bold, underline
            if (tempText.characterStyle.indexOf("caps") != -1) {
                tempVfield.value = tempVfield.value.toUpperCase();
            }

            tempVfield.styleID = styleId;    // TODO may use this to refer fieldID on fieldRules to apply constraint after textRegion is saved to backend
            tempVfield.elementIndex = text.vfield.elementIndex;
            tempVfield.visible = text.vfield.visible;
            tempText.vfield.push(tempVfield);
        }

        return tempText;
    }

    /** get left position of xmlText from textBlock's tabStops - further cooking required to keep font size but scale down positions */
    getLeftTextPositionFromTabStops(tabStops: string, index: number) {
        let tabStopDecoded;
        if (!!tabStops) {
            let tabStopsData = tabStops.split('\\\\\\');    // "1\340.157\right", "2\388.346\right", "3\464.882\right", "4\510.236\right", ""]
            //console.log(tabStopsData);
            for (let i = 0; i < tabStopsData.length; i++) {
                let tabData = tabStopsData[i];
                if (tabData.length > 0) {
                    let tabStop = tabData.split('\\');
                    if (+tabStop[0] === index) {
                        let left = parseInt(tabStop[1], 10); // * this.scaleFactor;
                        if (index % 2 === 1) {
                            left = left - 35;
                        }
                        if (tabStopsData.length > 3 && (index === 1 || index === 2)) { // gives extra space for the 1st pair
                            left = left - 35;
                        }
                        tabStopDecoded = {
                            index: +tabStop[0],
                            left: left,
                            align: tabStop[2],
                            symbol: !!tabStop[3] ? tabStop[3] : ''
                        };

                        // update to get the largest value from tab stop on specified index
                        if (left > this.largestTabStopLeft) {
                            this.largestTabStopLeft = left;
                        }

                        break;
                    } /*else {
                        // see if values from tab stops other than specified index needs more space
                        if ( +tabStop[1] > this.largestTabStopLeft) {
                            this.largestTabStopLeft = +tabStop[1];
                        }
                    }*/
                }
            }
        }
        //console.log(tabStopDecoded);
        return tabStopDecoded;
    }

    /** cmyk to rgb conversion */
    getRgbFromCmyk(cmykValue: string): string {
        if (cmykValue.indexOf('cmyk') != -1) {
            let cmykObj = (cmykValue.replace('cmyk', '').replace('(', '').replace(')', '')).split(',');
            let R = 255 * (1 - Number(cmykObj[0]) / 255) * (1 - Number(cmykObj[3]) / 255);
            let G = 255 * (1 - Number(cmykObj[1]) / 255) * (1 - Number(cmykObj[3]) / 255);
            let B = 255 * (1 - Number(cmykObj[2]) / 255) * (1 - Number(cmykObj[3]) / 255);

            // if text is white background colour needs to be updated
            if (R === 255 && G === 255 && B === 255) {
                this.cardBackColour = 'darkgrey';
            }

            // to int value
            R = parseInt('' + R, 10);
            G = parseInt('' + G, 10);
            B = parseInt('' + B, 10);

            return `rgb(${R}, ${G}, ${B})`;
        }
        return cmykValue;
    }

    /** will generate multiple text regions from pre-defined styled textRegion's xmlText */
    getTextRegionsAsGroup(origTextRegion: TextRegion): TextRegion[] {
        let groupTextRegions: TextRegion[] = [];
        let y = !!origTextRegion.y ? +origTextRegion.y : 0;
        let validVfieldIdx = 0;
        let mapTabStops = new Map<number, TabStop>();
        let preSpaceAfter = 0;
        let tempIncreaseY = 0;
        let prePositionY = 0;
        let totalNoOfRows = 1;
        for (let origTextBlockIndex = 0; origTextBlockIndex < origTextRegion.textBlocks.length; origTextBlockIndex++) {
            const origTextBlock = origTextRegion.textBlocks[origTextBlockIndex];

            // space before comes on top of textregion & space after from previous item needs to be added to next item
            preSpaceAfter = origTextRegion.textBlocks[origTextBlockIndex - 1] ? +origTextRegion.textBlocks[origTextBlockIndex - 1].spaceAfter : 0;

            // NOTE addFabricTextWithTextRegion() - canvas getObjects() does not include just added text item, y position setting here needs to consider line order in the same text style
            tempIncreaseY = +origTextBlock.spaceBefore + preSpaceAfter;
            if (y === 0 || y === +origTextRegion.y) {     // 1st line
                if (!!origTextBlock.xmlText && origTextBlock.xmlText.length > 0) {
                    tempIncreaseY = tempIncreaseY + +origTextBlock.leading - +origTextBlock.xmlText[0].pointsize;
                }

            } else {    // 2nd+ lines
                tempIncreaseY = tempIncreaseY + +origTextBlock.leading;
            }

            prePositionY = y;   // need to keep to subtract for the very 1st text style group in textflow

            y = y + tempIncreaseY;

            if (!!origTextBlock.tabStops) {
                mapTabStops = this.getTabStopsAsMap(origTextBlock.tabStops);
            } else {
                mapTabStops = null;
            }
            validVfieldIdx = 0;
            origTextBlock.xmlText.forEach((xmlText: xmlText) => {    // should be in the same line
                //for(let xmlTextIndex=0; xmlTextIndex < origTextBlock.xmlText.length; xmlTextIndex++) {
                //const xmlText = origTextBlock.xmlText[xmlTextIndex];
                if (!!xmlText.vfield && xmlText.vfield.length > 0) {  // each xmlText object with vfield details will have its own textRegion and textBlock
                    //textRegion.x will be determined by tabStop value initially
                    let textRegion = this.buildTextRegion(origTextRegion, !!mapTabStops && !!mapTabStops.get(validVfieldIdx) ? '' + mapTabStops.get(validVfieldIdx).left : '0', '' + y);
                    textRegion.firstLineInGroup = origTextBlockIndex === 0;
                    textRegion.preSpaceAfter = preSpaceAfter;
                    textRegion.prePositionY = prePositionY;
                    textRegion.lineNo = origTextBlockIndex;
                    textRegion.totalNoOfRows = origTextRegion.textBlocks.length;

                    // get text's max row numbers from previous line's style
                    const preTexts = groupTextRegions.filter(textRegion => {
                        return textRegion.lineNo === origTextBlockIndex - 1;
                    });
                    if (preTexts) {
                        let rowHeight = 1;
                        for (let preText of preTexts) {
                            if (rowHeight < +preText.textBlocks[0].xmlText[0].vfield[0].editRowHeight) {
                                rowHeight = +preText.textBlocks[0].xmlText[0].vfield[0].editRowHeight;
                            }
                        }
                        textRegion.preEditRowHeight = rowHeight;

                    } else {
                        textRegion.preEditRowHeight = 1;
                    }

                    textRegion.height = '' + (+xmlText.pointsize * +xmlText.vfield[0].editRowHeight);  // editRowHeight: number of rows

                    let width = +xmlText.pointsize * 0.6 * (xmlText.vfield[0].value.length > 0 ? xmlText.vfield[0].value.length : 1);
                    if (xmlText.vfield[0].constraints) {  // apply constraint when present
                        let constraintMaxlength = xmlText.vfield[0].constraints.find((constraint: Constraint) => {
                            return constraint.constraintName === 'maxLength';
                        });
                        if (!!constraintMaxlength) {
                            width = +xmlText.pointsize * 0.6 * +constraintMaxlength.constraintValue;
                            /*if (xmlText.vfield[0].editRowHeight === '1') {
                                width = +xmlText.pointsize * 0.6 * +constraintMaxlength.constraintValue;
                            } else {    // if it needs 3 lines and max 150 letters, 150 / 3 will be used
                                width = +xmlText.pointsize * 0.5 * (+constraintMaxlength.constraintValue / +xmlText.vfield[0].editRowHeight);
                            }*/

                            // set maxLength rule set by indesign to textregion
                            if (textRegion.editRules.length === 0) {
                                let editRules = this.customiseMenuSharedService.buildEditRules();
                                textRegion.editRules[0] = editRules;
                            }
                            textRegion.editRules[0].maxLength = constraintMaxlength.constraintValue;
                        }
                    }
                    // adjustment on text width - in most cases, signle item or long description needs to have the max width in textflow area
                    textRegion.width = '' + (width > +this.maxTextWidth ? this.maxTextWidth : width);
                    /*if (+textRegion.width > +this.maxTextWidth / 2) {
                        textRegion.width = '' + +this.maxTextWidth / 2;
                    }*/
                    let textBlock = this.buildTextBlock(origTextBlock, false);  // will NOT use tabStops anymore
                    // !!! ALIGNMENT will determine originX of fabric text
                    textBlock.align = !!mapTabStops && !!mapTabStops.get(validVfieldIdx) ? mapTabStops.get(validVfieldIdx).align : textBlock.align/*'left'*/;
                    if (textBlock.align === 'right') {
                        textBlock.tabStops = textBlock.tabStops.replace('left', 'right');

                        if (!!xmlText.tabStop.symbol && xmlText.tabStop.symbol.length > 0) {//TODO ... symbols
                            const preTextRegion = groupTextRegions[groupTextRegions.length - 1];
                            if (!!preTextRegion && preTextRegion.textBlocks[0].xmlText[0].tabStop && preTextRegion.textBlocks[0].xmlText[0].tabStop.align === 'right') {
                                // right align - x position is right top corner
                                preTextRegion.width = '' + (+textRegion.x - +textRegion.width - +preTextRegion.x);
                                preTextRegion.x = '' + (+textRegion.x - +textRegion.width);
                                const noOfSymbols = Math.floor((+preTextRegion.width - preTextRegion.textBlocks[0].xmlText[0].vfield[0].value.length) / (+xmlText.pointsize * 0.5));
                                const symbolsPrefix = xmlText.tabStop.symbol.repeat(noOfSymbols);   // create a series of symbols to attach
                                preTextRegion.textBlocks[0].xmlText[0].vfield[0].value = symbolsPrefix + preTextRegion.textBlocks[0].xmlText[0].vfield[0].value
                            }
                        }
                    }

                    textBlock.xmlText.push(xmlText);
                    textRegion.textBlocks.push(textBlock);
                    groupTextRegions.push(textRegion);
                    //console.log(textRegion);
                    validVfieldIdx += 1;
                }

                // when the 1st one is empty one
                if ((!xmlText.vfield || xmlText.vfield.length === 0) && validVfieldIdx === 0) {
                    validVfieldIdx = 1;
                }
            });
        }
        return groupTextRegions;
    }

    /** build textRegion details with empty child textBlocks and new id*/
    buildTextRegion(textRegion: any, x: string, y: string): TextRegion {
        let tempTextRegion: TextRegion = new TextRegion();
        tempTextRegion.id = '' + Date.now() + '' + Math.floor(Math.random() * Math.floor(100));   // ensure it's unique
        tempTextRegion.vJInterParaSpace = !!textRegion.vJInterParaSpace ? textRegion.vJInterParaSpace : '0';
        tempTextRegion.angle = !!textRegion.angle ? textRegion.angle : '0.000000';
        tempTextRegion.baselineFirstOffsetMetric = !!textRegion.baselineFirstOffsetMetric ? textRegion.baselineFirstOffsetMetric : 'ascent';
        tempTextRegion.baselineMinFirstOffset = !!textRegion.baselineMinFirstOffset ? textRegion.baselineMinFirstOffset : '0';
        tempTextRegion.firstBaselineOffset = !!textRegion.firstBaselineOffset ? textRegion.firstBaselineOffset : '0';
        tempTextRegion.shape = !!textRegion.shape ? textRegion.shape : 'rect';
        tempTextRegion.textInset = !!textRegion.textInset ? textRegion.textInset : '0,0,0,0';
        tempTextRegion.valign = !!textRegion.valign ? textRegion.valign : 'top';
        tempTextRegion.height = textRegion.height; //'57.401611328125';
        tempTextRegion.width = textRegion.width; //'510.2362365722656';
        tempTextRegion.x = x;
        tempTextRegion.y = y;
        tempTextRegion.textBlocks = new Array<TextBlock>();
        tempTextRegion.editRules = new Array<EditRules>();

        return tempTextRegion;
    }

    /** build up editRules */

    /*buildEditRules(): EditRules {
        let editRules = new EditRules();
        editRules.editable = '1';
        editRules.deletable = '1';
        editRules.movable = '1';
        editRules.resizable = '1';
        return editRules;
    }*/

    /** for convenience, make tabStops as map with key & value pairs */
    getTabStopsAsMap(tabStops: string): Map<number, TabStop> {
        let map = new Map();
        let tabStopsData = tabStops.split('\\\\\\');    // "1\340.157\right", "2\388.346\right", "3\464.882\right", "4\510.236\right", ""]
        for (let i = 0; i < tabStopsData.length; i++) {
            let tabData = tabStopsData[i];
            if (tabData.length > 0) {
                let tabStop = tabData.split('\\');  //1\340.157\right

                let tabStopDecoded = new TabStop();
                tabStopDecoded.index = +tabStop[0]; // 1
                tabStopDecoded.left = +tabStop[1];  // 340.157
                tabStopDecoded.align = tabStop[2];  // right
                tabStopDecoded.symbol = !!tabStop[3] ? tabStop[3] : '';  // right


                map.set(+tabStop[0], tabStopDecoded);  // key: index & value: TabStop obj with all details
            }
        }
        return map; // e.g. 1: {1,340.157,right}, ....
    }

    openEditRules(textRegion) {
        // need to consider already processed text styles
        if (!!this.textStyleSvgs && this.textStyleSvgs.length > 0) {
            const matchingStyle = this.textStyleSvgs.find((styleSvg: TemplateTextStyleSvg) => {
                return styleSvg.styleName === textRegion.id;
            });
            if (!!matchingStyle) {
                this.customiseMenuPropertyService.templateTextStyleSvg = matchingStyle;
            } else {
                this.customiseMenuPropertyService.templateTextStyleSvg = null;
            }
        } else {
            this.customiseMenuPropertyService.templateTextStyleSvg = null;
        }

        this.customiseMenuPropertyService.editTextArea = textRegion;
        this.convertComponentToDom(EditTextRulesComponent);
    }

    /** pop up edit rules modal for already processed textregions */
    openEditRulesForSvg(templateTextStyleSvg: TemplateTextStyleSvg) {
        this.customiseMenuPropertyService.templateTextStyleSvg = templateTextStyleSvg;
    }
}
