import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {Page} from "../../../common/models/Page";
import {Asset} from "../../../common/models/Asset";
import {CustomiseMenuService} from "../customise-menu.service";
import {queueScheduler} from "rxjs";

@Component({
    selector: 'app-image-upload',
    templateUrl: './image-upload.component.html',
    styleUrls: ['./image-upload.component.css']
})
export class ImageUploadComponent extends BaseComponent implements OnInit {
    pageAssets: Page<Asset> = new Page<Asset>();    // pageful of assets to display
    assetImages: Asset[] = [];
    assetMetaData = [];
    displayMessage = '';
    successMessage = '';
    JSON: any = JSON;
    imageSpinner = false;
    uploadedImgURL: any;

    constructor(inj: Injector, private customiseMenuService: CustomiseMenuService) {
        super(inj);
        this.commonService.isUploadLocal = false;
        this.commonService.imageTypeFields = [];
        this.fileUploaderService.ngOnInit();
        this.broadcaster.on('fileupload').subscribe((success) => {
            this.imageSpinner = true;
            this.addAssetDetails(this.assetMetaData, success);
        });
        this.broadcaster.on('fileAlreadyUploaded').subscribe((success) => {
            this.displayToaster('error', ['File already exits'])
        });
    }

    ngOnInit() {
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Function to upload images                            //
    ///////////////////////////////////////////////////////////////////////////
    addAssetDetails(assetData, fileMetaList) {
        const returnAssetMetaDataList: any = this.prepMetadataForSubmission(assetData, undefined, undefined, true);

        if (returnAssetMetaDataList === null) {
            this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.imageSpinner = false;
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            return;
        }

        if (fileMetaList.length === 0) {
            this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.imageSpinner = false;
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            return;
        }

        if (fileMetaList) {
            // pick up required details only and create a file list to submit
            const filesToAdd: any = [];

            fileMetaList.forEach((f, index) => {
                let fileMeta: any;
                if (f.length) {
                    fileMeta = {
                        fileName: f[0].fileName,
                        fileSize: '',
                        fileType: f[0].fileType,
                        realFileName: f[0].realFileName
                    };
                } else {
                    fileMeta = {
                        fileName: f.fileName,
                        fileSize: '',
                        fileType: f.fileType,
                        realFileName: f.realFileName
                    };
                }
                filesToAdd.push(fileMeta);
            });
            const fileData = {
                categoryID: 0, // Right now it is static but need to be dynamic 
                catalogue: "COKE",
                metadata: [
                    "F_RecordName|=|" + filesToAdd[0].fileName.split('.')[0]
                ],
                fileMeta: filesToAdd
            };
            queueScheduler.schedule(() => {
                this.customiseMenuService.addAssetImage(fileData, this.customiseMenuService.security_token).subscribe((res: any) => {
                    if (res.statusCode === 200) {
                        this.translate.get('NewAssetHasBeenAddedSuccessfully').subscribe((res: string) => {
                            this.displayMessage = res;
                        });
                        this.translate.get('Success').subscribe((res: string) => {
                            this.successMessage = res;
                        });
                        res.instanceList.forEach(obj => {
                            this.assetImages.unshift(obj);
                        });
                        this.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
                        this.imageSpinner = false;
                    } else {
                        this.imageSpinner = false;
                    }
                });
            });
        } else {
            this.imageSpinner = false;
            this.translate.get('PleaseUploadFileAtleastToAddTheAsset').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        }
    }

    /** Generate base64 from image url */
    readURL(input): void {
        if (input.target && input.target.files && input.target.files[0]) {
            let reader = new FileReader();

            reader.onload = (e: any) => {
                this.uploadedImgURL = e.target.result;
            };

            reader.readAsDataURL(input.target.files[0]);
        }
    }
}
