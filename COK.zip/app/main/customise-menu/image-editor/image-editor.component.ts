import {Component, OnInit, Input, Output, EventEmitter, Injector, SimpleChanges} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {ImagesOverlayComponent} from '../images-overlay/images-overlay.component';
import {CustomiseMenuService} from '../customise-menu.service';
import {EditImageRulesComponent} from "../edit-image-rules/edit-image-rules.component";
import {CustomiseMenuPropertyService} from "../customise-menu-property.service";

@Component({
    selector: 'app-image-editor',
    templateUrl: './image-editor.component.html',
    styleUrls: ['./image-editor.component.css']
})
export class ImageEditorComponent extends BaseComponent implements OnInit {
    @Input() imageEditorConfigs: any;
    @Input() isCanvasCropMode: any;
    @Input() state: any;
    @Output() resetImageObject = new EventEmitter();
    @Output() undo = new EventEmitter();
    @Output() redo = new EventEmitter();
    @Output() placeCropBox = new EventEmitter();    // will place rect on top of image
    @Output() finalAction = new EventEmitter();    // done or cancel
    @Output() rotate = new EventEmitter();    // done or cancel
    @Output() removeObject = new EventEmitter();
    @Input() showDelete: any;
    @Output() changeIndex = new EventEmitter();
    isEditorCropMode: boolean = false;                    // flag to show/hide tools/buttons on image editor
    isImageEditEnable = true;
    // isDesignLocked: any = null;
    constructor(public inj: Injector, public service: CustomiseMenuService,public customiseMenuPropertyService:CustomiseMenuPropertyService) {
        super(inj);
    }

    ngOnChanges(changes: SimpleChanges) {
        if ( !!changes.isCanvasCropMode ) { // notify crop mode change
            this.isEditorCropMode = this.isCanvasCropMode;
        }

        const rules = this.imageEditorConfigs && this.imageEditorConfigs.ccImage&& this.imageEditorConfigs.ccImage.editRules;
        if(rules && rules.length) {
            this.isImageEditEnable = rules[0].editable === '1' ? true : false;
        }

        // if(this.customiseMenuPropertyService.locked) {
        //   this.isDesignLocked = true;
        // } else {
        //   this.isDesignLocked = null;
        // }

    }

    ngOnInit() {

    }

    /** Crop button click handler to open modal window */
    startCrop(): void {
        this.isEditorCropMode = true;
        //this.service.imageEditorConfigs = this.imageEditorConfigs;
        //this.convertComponentToDom(ImageCropComponent);
        this.placeCropBox.emit();
    }

    /** when corp area is selected and confirmed */
    doneCrop(): void {
        this.service.cropSpinner = true;
        if ( !!this.imageEditorConfigs && this.imageEditorConfigs.ccImage ) {
            this.finalAction.emit(+this.imageEditorConfigs.ccImage.id);
        } else {
            this.finalAction.emit(0);   // will try to find current crop box available
        }
        // this.isEditorCropMode = false;
    }

    /** stop cropping */
    cancelCrop(): void {
        if ( !!this.imageEditorConfigs && this.imageEditorConfigs.ccImage ) {
            this.finalAction.emit(-this.imageEditorConfigs.ccImage.id);     // pass minus value
        } else {    // when image lost focus and cancel is clicked
            this.finalAction.emit(-1);   // will try to find current crop box available
        }
        this.isEditorCropMode = false;
    }

    /** Reset button click handler to reset image to original url */
    resetImage(): void {
        this.resetImageObject.emit();
    }

    /** Undo button click handler for image */
    startUndo(): void {
        this.undo.emit();
    }

    /** Redo button click handler for image */
    startRedo(): void {
        this.redo.emit();
    }

    /** Replace button click handler to change current image src */
    replaceImage(): void {
        this.convertComponentToDom(ImagesOverlayComponent);
    }

    /** Remove selected object*/
    removeImages() {
        this.removeObject.emit();
    }

    /** Edit Image rules defined using this overlay */
    openEditRules() {
        this.customiseMenuPropertyService.editImageRules = this.imageEditorConfigs;
        this.convertComponentToDom(EditImageRulesComponent);
    }
}
