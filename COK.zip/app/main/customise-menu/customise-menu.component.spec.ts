import {async, ComponentFixture, TestBed} from '@angular/core/testing';
import {HttpClientModule} from '@angular/common/http';
import {RouterModule, Routes} from '@angular/router';
import { FormsModule } from '@angular/forms';
import {APP_BASE_HREF} from '@angular/common';
import {TranslateModule} from '@ngx-translate/core';
import { Toast, ToastrService, ToastPackage, ToastrModule } from 'ngx-toastr';

import {CustomiseMenuComponent} from './customise-menu.component';
import {DesignsTabComponent} from './designs-tab/designs-tab.component';
import {LayoutTabComponent} from './layout-tab/layout-tab.component';
import {BackgroundTabComponent} from './background-tab/background-tab.component';
import {ImagesTabComponent} from './images-tab/images-tab.component';
import {ApprovalsTabComponent} from './approvals-tab/approvals-tab.component';
import {Broadcaster} from '../../common/BroadCaster';
import {DataService} from '../../common/DataService';
import { CommonService } from '../../common/common.service';

declare var $: any;

describe('CustomiseMenuComponent', () => {
	let component: CustomiseMenuComponent;
	let fixture: ComponentFixture<CustomiseMenuComponent>;

	const appRoutes: Routes = [
		{path: 'designs', component: CustomiseMenuComponent}
	];

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [
				CustomiseMenuComponent,
				DesignsTabComponent,
				LayoutTabComponent,
				BackgroundTabComponent,
				ImagesTabComponent,
				ApprovalsTabComponent
			],
			imports: [
				FormsModule,
				HttpClientModule,
				RouterModule.forRoot(appRoutes),
				TranslateModule.forRoot(),
				ToastrModule.forRoot()
			],
			providers: [
				CommonService,
				Broadcaster,
				DataService,
				ToastrService,
				{provide: APP_BASE_HREF, useValue : '/' }
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CustomiseMenuComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('Dynamic background image is loaded on canvas', () => {
		//	TODO
	});

	it('open side panel to choose different components', () => {
		//	TODO
	});

	it('canvas and its elements should scaled', () => {
		//	TODO
	});

	it('Design tab click should render its elements', () => {
		//	TODO
	});

	it('Layout tab click should render its elements', () => {
		//	TODO
	});

	it('Background tab click should render its elements', () => {
		//	TODO
	});

	it('Images tab click should render its elements', () => {
		//	TODO
	});

	it('Images tab should upload image', () => {
		//	TODO
	});

	it('Approvals tab click should render its elements', () => {
		//	TODO
	});
});
