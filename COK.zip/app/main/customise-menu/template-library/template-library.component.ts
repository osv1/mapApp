import {Component, OnInit, Injector} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {CustomiseMenuService} from '../customise-menu.service';
import {RestLoginFields} from '../../../common/models/RestLoginFields';
import {TemplateColourPalette} from '../../../common/models/TemplateColourPalette';

@Component({
    selector: 'app-template-library',
    templateUrl: './template-library.component.html',
    styleUrls: ['./template-library.component.css']
})
export class TemplateLibraryComponent extends BaseComponent implements OnInit {
    displayMessage: string;
    successMessage: string;
    assetMetaData = [];
    loginFields: RestLoginFields;
    fontsFiles = [];
    backgroundFiles = [];
    fileUploadType = '';
    isReadXml = false;
    submitted = false;
    categoryList = [];
    templateData: any = {
        requireCommerceProduct: 0,
        downloadOnly: 0,
        sizeOptions: []
    };
    backgroundName = [];
    realBackGroundName = [];
    isValidBackground = true;
    downloadOptionList = ['All Print - Portrait', 'A3 (842 * 1190)', 'A4 (595 * 842)', 'A5 (420 * 595)', 'A6 (298 * 420)'];
    showFileLoader = '';
    newPaletteColor = 'transparent';
    colorPalletList = [];
    colorList = [];
    selectedPalette: TemplateColourPalette;
    newPalette: TemplateColourPalette;
    assetFileUploadUrl = 'AssetService/v1/asset/upload';
    fontFileUploadUrl = 'TemplateService/v1/font/upload';
    fontName = [];
    constructor(inj: Injector, public customiseMenuService: CustomiseMenuService) {
        super(inj);
        this.commonService.isUploadLocal = false;
        this.commonService.imageTypeFields = [];

        this.broadcaster.on('fileupload').subscribe((success) => {
            this.addAssetDetails(this.assetMetaData, success);
        });
        this.broadcaster.on('fileAlreadyUploaded').subscribe(() => {
            this.displayToaster('error', ['File already exits']);
        });
    }

    ngOnInit() {
        this.customiseMenuService.getColourPalettes(0, 2079, this.getToken('accessToken')).subscribe((res: any) => {
            this.colorPalletList = res.instance;
        });
        // debugger
        this.customiseMenuService.registerRestV2(this.loginFields).subscribe((res: any) => {
            if (res.statusCode === 200) {
                this.customiseMenuService.security_token = res.key;
                // tslint:disable-next-line:max-line-length no-shadowed-variable

                // this.commonService.restUser.restUploadUrl = res.instance.baseUrl + '/template/upload/' + res.key;
                // tslint:disable-next-line:max-line-length
                this.commonService.restUser.restUploadUrl = this.commonService._restv2api + this.assetFileUploadUrl + '?token=' + this.customiseMenuService.security_token;
                // tslint:disable-next-line:max-line-length no-shadowed-variable
                this.customiseMenuService.getTemplateAndCategoryList(1, 20, '', 0, 0, this.customiseMenuService.security_token).subscribe(res => {
                    if (res.categories && res.categories.length) {
                        this.categoryList = res.categories;
                    }
                });
                this.fileUploaderService.ngOnInit();
            }
        });
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Function to upload images                            //
    ///////////////////////////////////////////////////////////////////////////
    addAssetDetails(assetData, fileMetaList) {
        const returnAssetMetaDataList: any = this.prepMetadataForSubmission(assetData, undefined, undefined, true);

        if (returnAssetMetaDataList === null) {
            this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            return;
        }

        if (!fileMetaList || fileMetaList.length === 0) {
            this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
            return;
        }

        if (fileMetaList) {
            // pick up required details only and create a file list to submit
            const filesToAdd: any = [];

            fileMetaList.forEach((f) => {
                let fileMeta: any;
                if (f.length) {
                    fileMeta = {
                        fileName: f[0].fileName,
                        fileSize: '',
                        fileType: f[0].fileType,
                        realFileName: f[0].realFileName
                    };
                } else {
                    fileMeta = {
                        fileName: f.fileName,
                        fileSize: '',
                        fileType: f.fileType,
                        realFileName: f.realFileName
                    };
                }
                filesToAdd.push(fileMeta);
            });
            this.showFileLoader = '';
            if (this.fileUploadType === 'xml') {
                this.backgroundFiles = [];
                this.fontsFiles = [];
                this.templateData.xmlName = filesToAdd[0].realFileName;
                // tslint:disable-next-line:max-line-length
                this.customiseMenuService.readUploadedXml(filesToAdd[0].realFileName, this.customiseMenuService.security_token).subscribe((res: any) => {
                    if (res.statusCode === 200) {
                        this.backgroundFiles = res.instance.background;
                        res.instance.fonts.forEach(fontName=>{
                            this.fontsFiles.push({name:fontName,isValid:false})
                        });
                        this.isReadXml = true;
                    }
                });
            }
            if (this.fileUploadType === 'background') {
                if (!this.isValidBackground) {
                    this.backgroundName = [];
                    this.realBackGroundName = [];
                }
                this.backgroundName.push('/' + filesToAdd[0].fileName);
                this.realBackGroundName.push(filesToAdd[0].realFileName);
                // tslint:disable-next-line:max-line-length
                JSON.stringify(this.backgroundFiles) !== JSON.stringify(this.backgroundName) ? this.isValidBackground = false : this.isValidBackground = true;
            }
            if (this.fileUploadType === 'fonts') {
                this.fontsFiles.forEach((data,i)=>{
                    if(this.fontName.indexOf(data.name) !== -1){
                        this.fontsFiles[i].isValid = true;
                    }
                })
            }
        } else {
            this.translate.get('PleaseUploadFileAtleastToAddTheAsset').subscribe((res: string) => {
                this.displayMessage = res;
            });
            this.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Check validation of font and background              //
    ///////////////////////////////////////////////////////////////////////////
    onFileSelected(event, methodName) {
        let isValid = true;
        let blockedFileTypes = []
        if (this.fileUploadType === 'fonts') {
            this.fileUploaderService.setFileUploadUrl(`${this.commonService._restv2api}${this.fontFileUploadUrl}?token=${this.customiseMenuService.security_token}`);
            blockedFileTypes = ['.otf', '.ttf']
        }
        if (this.fileUploadType === 'background') {
            this.fileUploaderService.setFileUploadUrl(`${this.commonService._restv2api}${this.assetFileUploadUrl}?token=${this.customiseMenuService.security_token}`);
            blockedFileTypes = ['.pdf']
        }
        if (this.fileUploadType === 'xml') {
            this.fileUploaderService.setFileUploadUrl(`${this.commonService._restv2api}${this.assetFileUploadUrl}?token=${this.customiseMenuService.security_token}`);
        }
        for (let i = 0; i < event.length; i++) {
            const dotIdx = event[i].name.lastIndexOf('.');
            const ext = event[i].name.substring(dotIdx, event[i].name.length).toLowerCase();
            if (blockedFileTypes.length && blockedFileTypes.indexOf(ext) === -1) {
                isValid = false;
            } else if (this.fileUploadType === 'fonts') {
                this.fontName.push(event[i].name.replace('.otf', '').replace('.ttf', ''))
            }
        }
        if (isValid) {
            this.fileUploaderService[methodName](event);
        } else {
            this.showFileLoader = '';
            this.displayToaster('error', ['File Type is not valid'])
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Save Template                                        //
    ///////////////////////////////////////////////////////////////////////////
    saveTemplate(form) {
        this.submitted = true;
        if (form.valid && this.backgroundName.length && this.templateData.xmlName && this.isValidBackground) {
            let isValidFonts = true;
            if(this.fontsFiles.length){
                this.fontsFiles.forEach(data=>{
                    if(!data.isValid){
                        isValidFonts = false;
                    }
                })
            }
            if (!isValidFonts) {
                let title;
                let text;
                let labelConfirm;
                let labelCancel;
                this.translate.get('label.TemplateSave').subscribe((res: string) => {
                    title = res;
                });
                this.translate.get('message.FontRequiredWarning').subscribe((res: string) => {
                    text = res;
                });
                this.translate.get('label.yes').subscribe((res: string) => {
                    labelConfirm = res;
                });
                this.translate.get('label.no').subscribe((res: string) => {
                    labelCancel = res;
                });
                this.swal({
                    title: title,
                    text: text,
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: labelCancel,
                    confirmButtonText: labelConfirm
                }).then((result) => {
                    if (result.value) {
                        this.templateData.pdfName = this.realBackGroundName[0];
                        this.customiseMenuService.createBaseTemplate(this.templateData, this.customiseMenuService.security_token).subscribe(res => {
                            if (res.statusCode === 200) {
                                this.displayToaster('success', [res.message]);
                                this.router.navigate(['/customiseMenu'], { queryParams: {baseTemplateId:res.key}});
                            }
                        })
                    }
                })
            }else{
                this.templateData.pdfName = this.realBackGroundName[0];
                this.customiseMenuService.createBaseTemplate(this.templateData, this.customiseMenuService.security_token).subscribe(res => {
                    if (res.statusCode === 200) {
                        this.displayToaster('success', [res.message]);
                        this.router.navigate(['/customiseMenu'], { queryParams: {baseTemplateId:res.key}});
                    }
                })
            }
        }
    }
    ///////////////////////////////////////////////////////////////////////////
    //                  Save Publish Template                                //
    ///////////////////////////////////////////////////////////////////////////
    savePublishTemplate(form) {
        this.submitted = true;
        if (form.valid && this.backgroundName.length && this.templateData.xmlName && this.isValidBackground) {
            let isValidFonts = true;
            if(this.fontsFiles.length){
                this.fontsFiles.forEach(data=>{
                    if(!data.isValid){
                        isValidFonts = false;
                    }
                })
            }
            if (!isValidFonts) {
                let title;
                let text;
                let labelConfirm;
                let labelCancel;
                this.translate.get('label.TemplateSaveAndPublish').subscribe((res: string) => {
                    title = res;
                });
                this.translate.get('message.FontRequiredWarning').subscribe((res: string) => {
                    text = res;
                });
                this.translate.get('label.yes').subscribe((res: string) => {
                    labelConfirm = res;
                });
                this.translate.get('label.no').subscribe((res: string) => {
                    labelCancel = res;
                });
                this.swal({
                    title: title,
                    text: text,
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    cancelButtonText: labelCancel,
                    confirmButtonText: labelConfirm
                }).then((result) => {
                    if (result.value) {
                        this.templateData.pdfName = this.realBackGroundName[0];
                        this.customiseMenuService.createBaseTemplate(this.templateData, this.customiseMenuService.security_token).subscribe(res => {
                            if (res.statusCode === 200) {
                                this.customiseMenuService.publishBaseTemplate(res.key, this.customiseMenuService.security_token).subscribe(response => {
                                    if (response.statusCode === 200) {
                                        this.displayToaster('success', [response.message]);
                                        this.router.navigate(['/customiseMenu'], { queryParams: {baseTemplateId:res.key}});
                                    }
                                })
                            }
                        })
                    }
                });
            }else {
                this.templateData.pdfName = this.realBackGroundName[0];
                this.customiseMenuService.createBaseTemplate(this.templateData, this.customiseMenuService.security_token).subscribe(res => {
                    if (res.statusCode === 200) {
                        this.customiseMenuService.publishBaseTemplate(res.key, this.customiseMenuService.security_token).subscribe(response => {
                            if (response.statusCode === 200) {
                                this.displayToaster('success', [response.message]);
                                this.router.navigate(['/customiseMenu'], { queryParams: {baseTemplateId:res.key}});
                            }
                        })
                    }
                })
            }
        }
    }

    ///////////////////////////////////////////////////////////////////////////
    //                  Update Download Size                                 //
    ///////////////////////////////////////////////////////////////////////////
    downloadSize(event, data) {
        if (event.target.checked) {
            // tslint:disable-next-line:no-unused-expression
            this.templateData.sizeOptions.indexOf(data) === -1 ? this.templateData.sizeOptions.push(data) : '';
        } else {
            this.templateData.sizeOptions = this.templateData.sizeOptions.filter(obj => obj !== data);
        }
    }

    selectNewColourPalette(newColor: string): void {
        this.newPalette = new TemplateColourPalette();
        this.newPalette.colours = [newColor];
    }

    /** Change color of fonts */
    updateColorPallet(color: string, index: number): void {
        this.colorList[index] = color;

        this.selectedPalette.colours = this.colorList;

        // tslint:disable-next-line:max-line-length no-shadowed-variable
        this.customiseMenuService.updateColourPalette(this.selectedPalette, this.getToken('accessToken')).subscribe(() => {
            return this.swal('Success!', 'Colour palette updated successfully!', 'success');
        }, () => {
            return this.swal('Sorry!', 'Colour palette update failed!', 'error');
        });
    }

    // /** Create new color pallet for fonts */
    // createColorPallet(obj?: any): void {
    //     const data = new TemplateColourPalette();
    //
    //     data.clientID = 20179;
    //     data.colours = [];
    //     data.paletteName = obj.paletteName || '';
    //     data.templateColourPaletteID = 0
    //
    //     // tslint:disable-next-line:max-line-length no-shadowed-variable
    //     this.customiseMenuService.createColourPalette(data, this.getToken('accessToken')).subscribe((res: any) => {
    //
    //     });
    // }

    /** Create new colour palette based on checkbox state*/
    checkBoxSelection(): void {
        const checkBox: any = document.getElementById('savecheckbox');
        const checkBoxVal = checkBox ? checkBox.checked : false;
        if (checkBoxVal) {
            this.swal({
                text: 'Create a new colour palette.',
                input: 'text',
                focusConfirm: false,
                customClass: 'save-design',
                inputPlaceholder: 'Name your new palette',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                cancelButtonText: 'Cancel',
                confirmButtonText: 'Create'
            }).then((result) => {
                if (result.value) {
                    this.newPalette.clientID = 20179;
                    this.newPalette.templateColourPaletteID = 0;
                    this.newPalette.paletteName = result.value || '';
                    this.newPalette.templateColourPaletteID = 0;

                    // tslint:disable-next-line:max-line-length no-shadowed-variable
                    this.customiseMenuService.createColourPalette(this.newPalette, this.getToken('accessToken')).subscribe(() => {
                        return this.swal('Success!', 'New colour palette created successfully!', 'success');
                    }, () => {
                        return this.swal('Sorry!', 'New palette creation failed!', 'error');
                    });
                }
            });
        }
    }
}
