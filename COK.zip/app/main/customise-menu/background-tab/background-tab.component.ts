import {Component, EventEmitter, OnInit, Input, Output} from '@angular/core';
import {CustomiseMenuService} from '../customise-menu.service';
import {Page} from "../../../common/models/Page";
import {Asset} from "../../../common/models/Asset";
import {config} from "../../../../assets/config/configs";

@Component({
    selector: 'app-background-tab',
    templateUrl: './background-tab.component.html',
    styleUrls: ['./background-tab.component.css']
})
export class BackgroundTabComponent implements OnInit {
    @Input() backGroundImages = [];
    @Input() cursorStyle: string;
    @Output() bgImagesLoaded = new EventEmitter();
    @Output() bgColor = new EventEmitter();
    color: string = '#2720e9';
    JSON: any = JSON;
    pageAssets: Page<Asset> = new Page<Asset>();
    constructor(public customiseMenuService: CustomiseMenuService) {

    }

    ngOnInit() {
        // this.pageAssets.inProgress = true;
        // this.customiseMenuService.getBackgroundAssets(1, 100, this.baseTemplateId, this.customiseMenuService.security_token).subscribe((page: Page<Asset>) => {
        //     page.inProgress = true;
        //     page.noMore = false;
        //     if (!!page.rows && page.rows.length > 0) {
        //         page.rows.map(asset => {
        //             asset.assetThumbnailPath = config.restv2api + config.assetThumbPath + `?catalogue=${asset.catalogue}&scale=0.1&id=${asset.assetID}&token=${this.customiseMenuService.security_token}`;
        //             this.backGroundImages.push(asset);
        //         });
        //         this.bgImagesLoaded.emit();
        //     } else {
        //         this.pageAssets.noMore = true;
        //         console.log('No assets to display!');
        //     }
        //     this.pageAssets.inProgress = false;
        // });
        this.bgImagesLoaded.emit();
    }

    /** Set background color*/
    changeBgColor(color: string): void {
        this.bgColor.emit(color);
    }

    /** Function to set default  the asset */
    setDefaultPic(event: any) {
        event.target.src = 'assets/images/no-image.png';
        event.target.parentElement.parentElement.style.pointerEvents = 'none';
    }

}
