import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BackgroundTabComponent } from './background-tab.component';

describe('BackgroundTabComponent', () => {
  let component: BackgroundTabComponent;
  let fixture: ComponentFixture<BackgroundTabComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BackgroundTabComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BackgroundTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
