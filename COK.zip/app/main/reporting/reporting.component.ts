import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from "../../common/commonComponent";
import { ReportingService } from './reporting.service';
import {DomSanitizer} from '@angular/platform-browser';

@Component({
  selector: 'app-reporting',
  templateUrl: './reporting.component.html',
  styleUrls: ['./reporting.component.css']
})
export class ReportingComponent extends BaseComponent implements OnInit{



  public selectDashboardOption = [];
  public selectDashboard;
  public reportHtml;
  constructor(inj: Injector,private reportingSerivce : ReportingService,private sanatizer : DomSanitizer) {
    super(inj);
  }


  ngOnInit(){
    this.getReportNameDetails();
  }


  getReportNameDetails(){


    this.reportingSerivce.getReportTypeNames().subscribe((res :any ) => {
      console.log(res);

      if(res.statusCode === 200) {
        this.selectDashboardOption = res.instance;
        this.selectDashboard = this.selectDashboardOption[0];
        this.isAuthorized();
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message)
      }
    })
  }

  changeDashboardOption(option){
    console.log(option);
    this.selectDashboard = option;
    this.isAuthorized();
  }


  isAuthorized(){
    this.reportingSerivce.isAuthenticated().subscribe((res :any ) => {
      console.log(res);
      if(res.statusCode === 200) {
        if(res.instance){
          let selectedReportPath = this.selectDashboard.ViewPath;
          selectedReportPath = selectedReportPath.replace("{token}", res.instance);
          this.reportHtml =  this.sanatizer.bypassSecurityTrustResourceUrl(selectedReportPath);
          console.log(this.reportHtml);
        }
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message)
      }
    })
  }
}
