import {Injectable} from '@angular/core';
import {CommonService} from '../../common/common.service';
import {from, Observable, Subject} from "rxjs";

@Injectable()
export class ReportingService {


  private subject = new Subject<any>();
  baseUrl = 'commerceService/v1/report/tableau';

  constructor(private commonService: CommonService) {
  }
  // http://localhost:8080/rest_v2/commerceService/v1/report/tableau/paths/?token=
  // https://api-hein-dev.goworks.com.au/rest_v2/commerceService/v1/report/tableau/paths/?token=d740e81f-0e6e-4b6e-b3e8-e38ef30b6ff2
  getReportTypeNames(): Observable<any> {
    const observable = from(this.commonService.callApi(this.baseUrl + '/paths/', '', 'get', true));
    return observable;
  }

  // http://localhost:8080/rest_v2/commerceService/v1/report/tableau/login/?token=

  isAuthenticated(): Observable<any> {
    const observable = from(this.commonService.callApi(this.baseUrl +'/login/', '', 'get', true));
    return observable;
  }
}
