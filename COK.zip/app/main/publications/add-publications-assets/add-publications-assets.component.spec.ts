import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPublicationsAssetsComponent } from './add-publications-assets.component';

describe('AddPublicationsAssetsComponent', () => {
  let component: AddPublicationsAssetsComponent;
  let fixture: ComponentFixture<AddPublicationsAssetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPublicationsAssetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPublicationsAssetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
