import {Component, ElementRef, Injector, OnInit, ViewChild} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {PublicationService} from '../publication.service';
import {environment} from "../../../../environments/environment";

declare var moment: any;

@Component({
  selector: 'app-add-publications-assets',
  templateUrl: './add-publications-assets.component.html',
  styleUrls: ['./add-publications-assets.component.css']
})
export class AddPublicationsAssetsComponent extends BaseComponent implements OnInit {
  @ViewChild('fileInput') fileInput: ElementRef;
  assetsDetails: any = {};
  displayMessage: any;
  errorMessage: any;
  successMessage: any;
  assetMetaData: any[];
  assetMetaDataArray: any = [];
  categoryId;
  catalogue;
  assetsId;
  assestTitle;
  getSingleAssetsDetails: any;
  assetPreviewPath: any;
  assetPreviewPathArray: any;
  assetsStatus: any = false;
  isViewStatus: any;
  public config = (<any>environment);
  public isEdit : boolean;
  imageDescription: any;
  imageName: any;

  constructor(inj: Injector, private publicationService: PublicationService) {
    super(inj);

  }

  ngOnInit() {
    this.publicationService.getCategoryData.subscribe((success: any) => {
      this.categoryId = success.categoryId;
      this.catalogue = success.catalogue;
      this.assetsId = success.assetsId;
      this.assestTitle = success.assetsName;
      this.isEdit = success.isEdit;
      this.isViewStatus = success.isView;
    });

    this.commonService.imageTypeFields = [''];
    this.fileUploaderService.ngOnInit();
    if (this.assetsId) {
      this.assetsStatus = true;
      // for edit assets
      this.getAssetsDetails();
    } else {
      // for add assets
      this.getAssetsData();
    }
  }



  openFileUpload() {
    this.fileInput.nativeElement.click();
  }

  getAssetsData() {
    this.assetMetaData = [];
    let data = {
      catalogue: this.catalogue,
      token: this.getToken('accessToken')
    }
    this.publicationService.getAssetsMetaData(data).subscribe((res: any) => {
      this.assetMetaData = res;
      this.assetMetaData.forEach((data: any) => {
        if (data.fieldName === 'F_RecordName' || data.fieldName === 'F_Description') {

          this.assetMetaDataArray.push(data);
        }
      });
      console.log("this.assetMetaDataArray", this.assetMetaDataArray);
    })
  }

  addAssetDetails(assetData ?) {
    // Call prepMetadataForSubmission function
    console.log(assetData);
    console.log(this.isEdit);
    const returnAssetMetaDataList: any = this.prepMetadataForSubmission(assetData, undefined, undefined, true);
    // Puneet - matching the call

    if (returnAssetMetaDataList === null) {
      this.translate.get('PleaseKeyInMandatoryField').subscribe((res: string) => {
        this.displayMessage = res;
      });
      this.translate.get('MissingFields').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
      return;
    }


    if(this.isEdit) {
      let data = {
        loginUserName: JSON.parse(this.getToken('userDetail')).userName,
        userClientID: JSON.parse(this.getToken('userDetail')).defaultClientID,
        uid: JSON.parse(this.getToken('userDetail')).userID,
        categoryID: parseInt(this.categoryId),
        catalogue: this.catalogue,
        metadata: returnAssetMetaDataList,
      };
      console.log(data);
      this.publicationService.updateMetaListWithoutFile(data, this.assetsId).subscribe((res: any) => {
        if (res.statusCode === 200) {
          this.translate.get('AssetHasBeenUpdatedSuccessfully').subscribe((res: string) => {
            this.successMessage = res;
            this.$('#childModal').modal('hide');
          });
          this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
          this.publicationService.closePopup();
        } else {
          this.translate.get('SomethingWentWrong').subscribe((res: string) => {
            this.errorMessage = res;
          });
          this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
        }
      })

      if (this.fileUploaderService.fileMetaList.length !== 0) {
        var filesToAdd: any = [];
        for (let index = 0; index < this.fileUploaderService.fileMetaList.length; index++) {
          filesToAdd.push({
            fileName: this.fileUploaderService.fileMetaList[index].fileName,
            fileSize: '',
            fileType: this.fileUploaderService.fileMetaList[index].fileType,
            realFileName: this.fileUploaderService.fileMetaList[index].realFileName
          });
        }
        let data = {
          loginUserName: JSON.parse(this.getToken('userDetail')).userName,
          userClientID: JSON.parse(this.getToken('userDetail')).defaultClientID,
          uid: JSON.parse(this.getToken('userDetail')).userID,
          categoryID: parseInt(this.categoryId),
          catalogue: this.catalogue,
          fileMeta: filesToAdd
        };
        this.publicationService.updateFileMetaListOriginal(data,this.assetsId,this.catalogue).subscribe((res: any) => {
          if (res.statusCode === 200) {
            this.publicationService.updateFileMetaListThumbnail(data,this.assetsId,this.catalogue).subscribe((res: any) => {
              if (res.statusCode === 200) {
                this.$('#childModal').modal('hide');
                this.publicationService.closePopup();
              }else {
                this.translate.get('SomethingWentWrong').subscribe((res: string) => {
                  this.errorMessage = res;
                });
                this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
              }
            })
          } else {
            this.translate.get('SomethingWentWrong').subscribe((res: string) => {
              this.errorMessage = res;
            });
            this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
          }
        })
      }
    }else {
      if (this.fileUploaderService.fileMetaList) {
        if (this.fileUploaderService.fileMetaList.length === 0) {
          this.translate.get('PleaseSelectFileFirst').subscribe((res: string) => {
            this.displayMessage = res;
          });
          this.translate.get('FileUpload').subscribe((res: string) => {
            this.errorMessage = res;
          });
          this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
          return;
        }
        var filesToAdd: any = [];
        for (let index = 0; index < this.fileUploaderService.fileMetaList.length; index++) {
          filesToAdd.push({
            fileName: this.fileUploaderService.fileMetaList[index].fileName,
            fileSize: '',
            fileType: this.fileUploaderService.fileMetaList[index].fileType,
            realFileName: this.fileUploaderService.fileMetaList[index].realFileName
          });
        }
        let data = {
          loginUserName: JSON.parse(this.getToken('userDetail')).userName,
          userClientID: JSON.parse(this.getToken('userDetail')).defaultClientID,
          uid: JSON.parse(this.getToken('userDetail')).userID,
          categoryID: parseInt(this.categoryId),
          catalogue: this.catalogue,
          metadata: returnAssetMetaDataList,
          fileMeta: filesToAdd
        };
        this.publicationService.addAssets(data).subscribe((res: any) => {
          if (res.statusCode === 200) {
            this.translate.get('AssetHasBeenAddedSuccessfully').subscribe((res: string) => {
              this.successMessage = res;
              this.$('#childModal').modal('hide');
            });
            this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
            this.publicationService.closePopup();
          } else {
            this.translate.get('SomethingWentWrong').subscribe((res: string) => {
              this.errorMessage = res;
            });
            this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
          }
        })
      }
    }

  }

  prepMetadataForSubmission(metaList, id, isPressJob, isAddAsset, isTaskCopy ?, isProcurement ?, addNooshProjectId ?) {
    const metaIdValuePairs = [];
    // angular.forEach(metaList, function (meta, index) {
    if (metaList !== null || metaList !== undefined) {
      console.log(metaList);
      for (let index = 0; index < metaList.length; index++) {     // use for loop to break out of looping
        const meta = metaList[index];
        // extra care for date and other spcial display types
        if (typeof meta.fieldDisplayType === 'string') {
          if (meta.fieldDisplayType.toLowerCase().indexOf('noneditable') === -1 || isPressJob || (addNooshProjectId
            && addNooshProjectId === true && meta.fieldName === 'NooshProjectID') || (meta.fieldName === 'Project_Name')) {
            // Press job needs to allow noneditable fields to be updated

            if (meta.fieldDisplayType === 'date') { // update date format to make the field eligible for database insert
              if (meta.fieldValue !== '') {
                meta.fieldValue = this.localToUtcWithInputFormat(meta.fieldValue);
              }
              // jquery plugin version
              /*meta.fieldValue = $('#date-' + id + '-' + meta.fieldID).val();
               if ( meta.fieldValue == undefined ) {
               meta.fieldValue = '';
               }*/
            } else if (meta.fieldDisplayType === 'multipleselect') {
              if (isAddAsset) {
                if (meta.fieldValue) {
                  meta.fieldValue = meta.fieldValue.toString();
                }
              } else {
                let checked = '';
                meta.multiValues.forEach((selectOpt, metaIndex) => {
                  if (selectOpt.selected !== '') {
                    checked = checked + ',' + selectOpt.selected;
                  }
                });
                meta.fieldValue = checked.substring(1);
              }
            }

            // mandatory field checkup
            if (meta.mandatory && (meta.fieldValue === '' || meta.fieldValue == null ||
              (meta.fieldDisplayType === 'file' && meta.fieldValue === 0))) {
              // updated to use fieldName
              if (typeof meta.fieldName === 'string') {
                if (isProcurement && meta.fieldName.toLowerCase() === 'contact' /*meta.fieldID=='62'*/) {
                  // skip checking ergo contact ID if procurement channel is added after import
                } else {
                  return null;
                }
              } else {
                return null;
              }

            }

            // metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);

            if (isTaskCopy) {
              metaIdValuePairs.push(meta.fieldID + '_' + meta.jobMetaDataID /*taskCopyUD*/ + '|-|' + meta.fieldValue + '|,|');

            } else {

              if (meta.fieldID === undefined) {  // Filestor 3.7 metadata
                metaIdValuePairs.push(meta.fieldName + '|=|' + meta.fieldValue);
              } else {                            // JAS metadata
                if (meta.fieldValue.id === undefined) {
                  metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);
                } else {  // in case of id is used for value
                  metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue.id);
                }
              }
            }
          }
        } else {
          return null;
        }
      }
    }
    // });
    return metaIdValuePairs;
  }

  localToUtcWithInputFormat(strLocalDateTime, inputFormat ?) {
    // when input format is not set use default
    if (!inputFormat) {
      inputFormat = this.defultInputFormat; // 'DD/MM/YYYY HH:mm';
    }

    // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
    const momentTime = moment(strLocalDateTime).subtract(moment(strLocalDateTime).utcOffset(), 'm');
    const formattedUtcDateTime = momentTime;
    return formattedUtcDateTime.format(this.defaultFormat);
  }

  deleteAssets() {
    let data = {
      assetID: this.assetsId,
      catalogue: this.catalogue,
      token: this.getToken('accessToken')
    }
    this.publicationService.deleteAssets(data).subscribe((res: any) => {
      if (res.statusCode == 200) {
        this.translate.get('AssetHasBeenDeletedSuccessfully').subscribe((res: string) => {
          this.successMessage = res;
          this.$('#childModal').modal('hide');
          this.publicationService.closePopup();
        });
        this.commonService.displayToaster('success', [this.displayMessage], 5000, this.successMessage);
      } else {
        this.translate.get('SomethingWentWrong').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      }
    })
  }

  getAssetsDetails() {
    let data = {
      assetID: this.assetsId,
      catalogue: this.catalogue,
      token: this.getToken('accessToken'),
      categoryID: this.categoryId,
      uid: JSON.parse(this.getToken('userDetail')).userID
    }
    this.publicationService.getAssetsDetails(data).subscribe((res: any) => {
      if (res.statusCode == 200) {
        this.isEdit = true;
        this.getSingleAssetsDetails = res.instance.metaList;
        if (res.instance.assetS3PreviewPath) {
          this.assetPreviewPathArray = JSON.parse(res.instance.assetS3PreviewPath);
          this.assetPreviewPath = this.assetPreviewPathArray[0].s3Path+ '?t=' + new Date().getTime();;
        }
        this.getSingleAssetsDetails.forEach((data: any) => {
          if (data.fieldName === 'F_RecordName' || data.fieldName === 'F_Description') {
            this.assetMetaDataArray.push(data);
          }
        });
        this.imageName = this.assetMetaDataArray[0].fieldValue;
        this.imageDescription = this.assetMetaDataArray[1].fieldValue;
      }
    })
  }
  assetsDownload(assetData){
    let data = {
      assetID: this.assetsId,
      catalogue: this.catalogue,
      token: this.getToken('accessToken'),
      fileName: assetData[0].fieldValue
    }
    let downloadURL = this.config.apiUrl+'AssetService/v1/asset/' + data.catalogue+'/'+ data.assetID+'/download/' + '?token=' + data.token + '&fileName='+ data.fileName;
    window.open(downloadURL);
  }

}
