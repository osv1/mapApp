import {Component, OnInit, Injector, Input, ViewChild} from '@angular/core';
import {BaseComponent} from '../../common/commonComponent';
import {PublicationService} from './publication.service';
import {AddPublicationsAssetsComponent} from './add-publications-assets/add-publications-assets.component';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'app-publications',
  templateUrl: './publications.component.html',
  styleUrls: ['./publications.component.css'],
  // directives: [PublicationsComponent]
})
export class PublicationsComponent extends BaseComponent implements OnInit {

  category;
  public getAssetsCategories;
  public categoryItem = [];
  @ViewChild('ulSubmenu') ulSubmenu;
  public expandedNodes = [];
  public assetCategories;
  listPage: any = {
    rows: [],
    page: 0,
    pageSize: 100,
    totalSize: 0,
    order: 'AssetCreated',
    dir: 'down',
    search: '',
    catalogue: 'Assets',
    categoryID: -1,
    findDuplicate: false,
    searchCurrent: false
  };
  assetLisItems = [];
  noMoreAssets = false;
  categoryLisItems = [];
  currentDate;
  public totalCount;
  public config = (<any>environment);
  public isLoading;
  public selectedCategory: any = {};
  public categorySearch = '';

  public shortByValue: any[];
  public sortName = this.constants.shortByValuePublication[0];
  public fetchSize = this.constants.pageValue[0];
  public sortDetails: any;
  public pageValue: any;
  public catalog: any = {};
  public userDetails: any = {};
  public isFilter: boolean = false;
  public isAdmin :boolean;
  public isAdminRightsForEdit : boolean;

  @Input() private dirs: Array<''>;
  closeAssetsPopup: boolean;
  categoryData: any = {};
  publicationImageDescription: any;
  isPublication: boolean = true;
  categoryIDs = ['0'];

  constructor(inj: Injector, private publicationService: PublicationService) {
    super(inj);
  }

  ngOnInit() {
    this.userDetails = JSON.parse(this.getToken('userDetail'));
    if(this.userDetails.moduleRoles['3'] == '1'){
      this.isAdmin = true;
    }
    this.listPage.page = 1;
    this.shortByValue = this.constants.shortByValuePublication;
    this.pageValue = this.constants.pageValue;
    this.listPage.fetchSize = this.constants.pageValue[0].size;
    this.publicationService.closeAssetsModel.subscribe((success: any) => {
      this.closeAssetsPopup = true;
      if (success.length) {
        if (this.catalog.categoryIDs) {
          this.loadAllPublications();
        } else {
          this.loadMoreCategoriesAndAssets(this.selectedCategory);
        }
      }
    });
    // this.getAssetsTreeMenu();

    this.category =

      [
        {
          'label': 'Documents',
          'data': 'Documents Folder',
          'expandedIcon': 'fa fa-folder-open',
          'collapsedIcon': 'fa fa-folder',
          'children': [{
            'label': 'Work',
            'data': 'Work Folder',
            'expandedIcon': 'fa fa-folder-open',
            'collapsedIcon': 'fa fa-folder',
            'children': [{
              'label': 'Expenses.doc',
              'icon': 'fa fa-file-word-o',
              'data': 'Expenses Document'
            }, {'label': 'Resume.doc', 'icon': 'fa fa-file-word-o', 'data': 'Resume Document'}]
          },
            {
              'label': 'Home',
              'data': 'Home Folder',
              'expandedIcon': 'fa fa-folder-open',
              'collapsedIcon': 'fa fa-folder',
              'children': [{'label': 'Invoices.txt', 'icon': 'fa fa-file-word-o', 'data': 'Invoices for this month'}]
            }]
        },
        {
          'label': 'Pictures',
          'data': 'Pictures Folder',
          'expandedIcon': 'fa fa-folder-open',
          'collapsedIcon': 'fa fa-folder',
          'children': [
            {'label': 'barcelona.jpg', 'icon': 'fa fa-file-image-o', 'data': 'Barcelona Photo'},
            {'label': 'logo.jpg', 'icon': 'fa fa-file-image-o', 'data': 'PrimeFaces Logo'},
            {'label': 'primeui.png', 'icon': 'fa fa-file-image-o', 'data': 'PrimeUI Logo'}]
        },
        {
          'label': 'Movies',
          'data': 'Movies Folder',
          'expandedIcon': 'fa fa-folder-open',
          'collapsedIcon': 'fa fa-folder',
          'children': [{
            'label': 'Al Pacino',
            'data': 'Pacino Movies',
            'children': [{
              'label': 'Scarface',
              'icon': 'fa fa-file-video-o',
              'data': 'Scarface Movie'
            }, {'label': 'Serpico', 'icon': 'fa fa-file-video-o', 'data': 'Serpico Movie'}]
          },
            {
              'label': 'Robert De Niro',
              'data': 'De Niro Movies',
              'children': [{
                'label': 'Goodfellas',
                'icon': 'fa fa-file-video-o',
                'data': 'Goodfellas Movie'
              }, {'label': 'Untouchables', 'icon': 'fa fa-file-video-o', 'data': 'Untouchables Movie'}]
            }]
        }
      ];


    // this.getAssetsTreeMenu()
    // this.categoryItem.push({title: 'Assets',id: -1})
    // this.categoryItem = this.setTreeRoot();
    // this.selectedCategory = {id: -1, title: 'Assets', catalogue: '', children: []}
    let catalogue = {
      id: 0,
      catalogue: 'HEINEKEN'
    };
    this.selectedTreeMenuForAssets1(catalogue);
    this.checkAdminRights();
    // this.getAssetsTreeMenu();
    // console.log(this.ulSubmenu);
  }


  allPublicationsList() {
    this.isPublication = true;
    let selectedCategory = {
      id: 0,
      catalogue: '',

    };
    let event = {
      event_id: this.constants.ASSET_CATEGORY.event_id,
      event_desc: this.constants.ASSET_CATEGORY.event_desc,
      attributes: this.constants.LOG_ALL_ITEM,
      categoryId : 0
    };
    this.logService.createLog(event);
    this.resetPageSize();
    this.loadAllPublications(selectedCategory);
  }


  setTreeRoot() {
    return [{id: -1, title: 'Assets', catalogue: '', children: []}];
  }

  selectedTreeMenuForAssets1(catalogues) {
    console.log(catalogues);
    let data = {
      catalogue: catalogues.catalogue ? catalogues.catalogue : 'HEINEKEN',
      parentID: catalogues.id,
      token: this.getToken('accessToken'),
      // uid: JSON.parse(this.getToken('userDetail')).userID,
      uid: 1,
      categoryID: 0
    };

    this.publicationService.getCategotyItems(data).subscribe((res: any) => {
      if (res.statusCode === 200) {
        this.categoryItem = res.instance; // [];
        /*this.categoryItem[0] = {
          id: res.instance[0].id,
          title: res.instance[0].title,
          catalogue: res.instance[0].catalogue,
          children: res.instance[0].children,
          expanded: true
        };*/

        res.instance.map(category => {
          if (category.id) {
            this.categoryIDs.push(category.id.toString());
          }
        });
        this.allPublicationsList();
        // this.selectedCategory = {
        //   id: res.instance[0].id,
        //   title: res.instance[0].title,
        //   catalogue: res.instance[0].title,
        //   children: res.instance[0].children,
        //   expanded: true
        // }
        // this.categoryItem[0].children = res.instance;
        // this.categoryItem[0].catalogue = res.instance[0].title;
        // this.categoryItem[0].expanded = true;
      }
      // this.loadMoreCategoriesAndAssets(this.selectedCategory)
    });
  }

  selectedTreeMenuForAssets(catalogue) {
    this.isPublication = false;
    this.selectedCategory = catalogue;

    console.log(catalogue);
    this.selectedCategory.catalogue = catalogue.catalogue === 'undefined' ? catalogue.title : catalogue.catalogue;
    let data = {
      catalogue: catalogue.catalogue === 'undefined' ? catalogue.title : catalogue.catalogue,
      parentID: catalogue.id,
      token: this.getToken('accessToken'),
      // uid: JSON.parse(this.getToken('userDetail')).userID,
      uid: 1,
      categoryID: 0
    };

    this.isLoading = true;
    let event = {
      event_id: this.constants.ASSET_CATEGORY.event_id,
      event_desc: this.constants.ASSET_CATEGORY.event_desc,
      attributes: catalogue.catalogue ? catalogue.catalogue : '',
      categoryId : catalogue.id ? catalogue.id : ''
    };
    this.logService.createLog(event);
    // catalogue.children = [{id: 1, title: 'GoWorks', catalogue: '', children: []}]
    if (catalogue.id !== -1) {


      this.publicationService.getCategotyItems(data).subscribe((res: any) => {
        if (res.statusCode === 200) {
          console.log(res.instance);

          // catalogue.children = [{id: res.instance[0].id, title: res.instance[0].title, catalogue: '', children: []}]

          catalogue.children = res.instance.map(res1 => {
            return {
              id: res1.id,
              title: res1.title,
              catalogue: res1.catalogue,
              children: []
            };
          });
          if (catalogue.children.length) {
            catalogue.isExpanded = catalogue.isExpanded ? !catalogue.isExpanded : true;
          }

          this.categoryItem[0].children.map(res => {
            delete res.selected;
          });
          this.isLoading = false;
        }
        this.resetPageSize();
        this.loadMoreCategoriesAndAssets(this.selectedCategory);
        // console.log(this.categoryItem)
      });
    } else {
      catalogue.isExpanded = catalogue.isExpanded ? !catalogue.isExpanded : true;
    }

  }

  checkAdminRights(){
    if (this.userDetails.moduleRoles) {
      if (this.userDetails.moduleRoles['3'] == '1') {
        this.isAdminRightsForEdit = true;
      }
    } else {
     this.isAdminRightsForEdit = false;
    }
  }

  resetPageSize() {
    this.listPage.page = 1;
  }


  sortBy(data, key) {
    console.log('data', data);
    this.sortDetails = data;

    if (key == 'sortby') {
      this.listPage.dir = data.dir;
      this.listPage.order = data.order;
    }
    if (key == 'show') {
      this.listPage.fetchSize = data.size;
    }
    // setTimeout(() => {
    if (this.catalog.catalogue === '') {
      this.loadAllPublications(this.selectedCategory);
    } else {
      if (this.catalog.categoryIDs) {
        this.loadAllPublications();
      } else {
        this.loadMoreCategoriesAndAssets(this.selectedCategory);
      }
    }
    // }, 300)

  }

  next() {
    this.listPage.page = this.listPage.page + 1;
    if (this.catalog.catalogue === '') {
      this.loadAllPublications(this.selectedCategory);
    } else {
      if (this.catalog.categoryIDs) {
        this.loadAllPublications();
      } else {
        this.loadMoreCategoriesAndAssets(this.selectedCategory);
      }
    }

  }

  prev() {
    this.listPage.page = this.listPage.page - 1;
    if (this.catalog.catalogue === '') {
      this.loadAllPublications(this.selectedCategory);
    } else {
      if (this.catalog.categoryIDs) {
        this.loadAllPublications();
      } else {
        this.loadMoreCategoriesAndAssets(this.selectedCategory);
      }
    }
  }


  searchCategory(search) {
    this.listPage.search = search;
    this.catalog.search = search;
    this.listPage.search = this.listPage.search ? this.listPage.search : ' ';
    this.catalog.search = this.catalog.search ? this.catalog.search : ' ';
    let event = {
      event_id: this.constants.ASSET_SEARCH.event_id,
      event_desc: this.constants.ASSET_SEARCH.event_desc,
      attributes: search,
      categoryId : 0
    };
    this.logService.createLog(event);
    let parmasData = this.serialize(this.catalog);
    if (this.catalog.catalogue === '') {
      this.publicationService.getAllLatestCatalouge(parmasData).subscribe((categoryAndAssetListPage: any) => {
        this.assetCategories = categoryAndAssetListPage.instance.rows;
        this.totalCount = Math.ceil(categoryAndAssetListPage.instance.totalSize / categoryAndAssetListPage.instance.pageSize);
      });
    } else {
      if (this.catalog.categoryIDs) {
        this.loadAllPublications();
      } else {
        this.publicationService.getCategoriesRangeMenu(parmasData).subscribe((categoryAndAssetListPage: any) => {
          this.assetCategories = categoryAndAssetListPage.instance.assets;
          this.totalCount = Math.ceil(categoryAndAssetListPage.instance.totalSize / categoryAndAssetListPage.instance.pageSize);

        });
      }
    }


  }

  loadAllPublications(assetCategoryObject?) {
    console.log(assetCategoryObject);
    console.log(this.categoryItem);

    let listOrder;
    if (this.listPage.order === 'AssetCreated') {
      listOrder = this.constants.F_ASSETS_CREATED;
    } else {
      listOrder = this.constants.F_ASSETS_NAME;
    }


    this.catalog = {
      'catalogue': 'HEINEKEN',
      'categoryIDs': this.categoryIDs,
      'dir': this.listPage.dir,
      'fetchSize': Number(this.listPage.fetchSize),
      'findDuplicate': false,
      // "uid": JSON.parse(this.getToken('userDetail')).userID,
      'uid': 1,
      'order': listOrder,
      'page': this.listPage.page,
      'search': this.listPage.search ? this.listPage.search : ' ',
      'fromDate': ' ',
      'toDate': ' ',
      'searchCurrent': this.listPage.searchCurrent,
      'token': this.getToken('accessToken')
    };

    let parmasData = this.serialize(this.catalog);
    console.log(parmasData);
    this.publicationService.getAllLatestCatalouge(parmasData).subscribe((categoryAndAssetListPage: any) => {
      console.log(categoryAndAssetListPage);
      this.assetCategories = categoryAndAssetListPage.instance.rows;
      this.assetCategories.forEach(res => {
        res.assetThumbnailPath = res.assetThumbnailPath + '?t=' + new Date().getTime();
      });
      this.totalCount = Math.ceil(categoryAndAssetListPage.instance.totalSize / categoryAndAssetListPage.instance.pageSize);

    });
  }

  // get categories and assets
  loadMoreCategoriesAndAssets(assetCategoryObject?) {

    console.log(this.listPage.search)
    console.log(assetCategoryObject);

    this.catalog = {
      'catalogue': assetCategoryObject.catalogue ? assetCategoryObject.catalogue : 'HEINEKEN',
      'categoryID': assetCategoryObject.id ? Number(assetCategoryObject.id) : 0,
      'dir': this.listPage.dir,
      // 'fetchSize': Number(this.listPage.fetchSize),
      'fetchSize': Number(this.listPage.fetchSize),
      'findDuplicate': false,
      // "uid": JSON.parse(this.getToken('userDetail')).userID,
      'uid': 1,
      'order': this.listPage.order,
      'page': this.listPage.page,
      'search': this.listPage.search ? this.listPage.search : ' ',
      'fromDate': ' ',
      'toDate': ' ',
      'searchCurrent': this.listPage.searchCurrent,
      'token': this.getToken('accessToken')
    };

    let parmasData = this.serialize(this.catalog);
    console.log(parmasData);
    this.publicationService.getCategoriesRangeMenu(parmasData).subscribe((categoryAndAssetListPage: any) => {
      console.log(categoryAndAssetListPage);
      this.assetCategories = categoryAndAssetListPage.instance.assets;
      this.assetCategories.forEach(res => {
        res.assetThumbnailPath = res.assetThumbnailPath + '?t=' + new Date().getTime();
      });
      this.totalCount = Math.ceil(categoryAndAssetListPage.instance.totalSize / categoryAndAssetListPage.instance.pageSize);

    });
  }

  openAssetsAddEditModel(categoryDetails, isViewStatus, assetsId?) {
    this.categoryData = {
      categoryId: categoryDetails.id,
      assetsName: this.selectedCategory.title,
      catalogue: categoryDetails.catalogue ? categoryDetails.catalogue : 'HEINEKEN',
      isView: isViewStatus
    };
    if (categoryDetails.id === -1) {
      this.categoryData.categoryId = 0;
    }
    if (assetsId) {
      this.categoryData.assetsId = assetsId;
    }
    this.convertComponentToDom(AddPublicationsAssetsComponent, 'childModal', 'childModalContent');
    this.publicationService.assetsAddEditDetails(this.categoryData);

  }


  openAssetsEditModel(categoryDetails, isViewStatus, assetsId?) {
    this.categoryData = {
      categoryId: categoryDetails.cid,
      assetsName: categoryDetails.catalogue,
      catalogue: categoryDetails.catalogue ? categoryDetails.catalogue : '2019',
      isEdit: true,
      isView: isViewStatus
    };
    if (categoryDetails.cid === -1) {
      this.categoryData.categoryId = 0;
    }
    if (assetsId) {
      this.categoryData.assetsId = assetsId;
    }
    this.convertComponentToDom(AddPublicationsAssetsComponent, 'childModal', 'childModalContent');
    this.publicationService.assetsAddEditDetails(this.categoryData);
    console.log(this.categoryData);
  }

  assetsViewArticle(categoryDetails, assetsData?) {
    console.log(categoryDetails);
    let data = {
      assetID: categoryDetails.assetID,
      catalogue: categoryDetails.catalogue,
      token: this.getToken('accessToken'),
      fileName: assetsData.recordName
    };

    let event = {
      event_id: this.constants.ASSET_VIEW.event_id,
      event_desc: this.constants.ASSET_VIEW.event_desc,
      attributes: categoryDetails.assetID,
      categoryId : categoryDetails.cid
    };
    this.logService.createLog(event);
    let downloadURL = this.config.apiUrl + 'AssetService/v1/asset/' + data.catalogue + '/' + data.assetID + '/download/' + '?token=' + data.token + '&fileName=' + data.fileName;
    window.open(downloadURL);
  }
}
