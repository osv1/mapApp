import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {CommonService} from '../../common/common.service';
import {from, Observable} from "rxjs";
import * as constants from '../../common/constants';

@Injectable()
export class PublicationService {


  public baseUrl = 'AssetService/v1/asset';
  public baseUrlAssets = 'AssetService/v1/assets';
  public url = 'AssetService/asset';

  constructor(private commonService: CommonService) {

  }


  getAllPublicationTreeList(data) {
    const observable = from(this.commonService.callApi(this.url + '/' + constants.constants.publicationService.getAssetCategoryTreeItems, data,
      constants.constants.method.post, false));
    return observable;
  }

  // all
  getCategoriesRangeMenu(data) {
    const observable = from(this.commonService.callApi(this.baseUrlAssets + '/' + constants.constants.publicationService.categories +'/'+ constants.constants.publicationService.all + '?' + data,
      '', constants.constants.method.get, false));
    return observable;
  }

  getCategotyItems(data) {
    const observable = from(this.commonService.callApi(this.baseUrl + '/' + constants.constants.publicationService.category + '/' + data.parentID +
      '?' + constants.constants.publicationService.token + '=' + data.token + '&' + constants.constants.publicationService.categoryID + '=' +
      data.categoryID + '&' + constants.constants.publicationService.catalogue + '=' + data.catalogue + '&' + constants.constants.publicationService.uid + '=' +
      data.uid, data, constants.constants.method.get, false));
    return observable;
  }


  addAssets(data) {
    const observable = from(this.commonService.callApi(this.baseUrl, data, constants.constants.method.post, true));
    return observable;
  }

  updateMetaListWithoutFile(data, assetId) {
    const observable = from(this.commonService.callApi(this.baseUrl + '/' + assetId + '/' + constants.constants.publicationService.assetMetaData, data, 'put', true));
    return observable;
  }

  updateFileMetaListOriginal(data, assetId, catalogue) {
    const observable = from(this.commonService.callApi(this.baseUrl + '/' + catalogue + '/' + assetId + '/' + constants.constants.publicationService.original,
      data, constants.constants.method.put, true));
    return observable;
  }

  updateFileMetaListThumbnail(data, assetId, catalogue) {
    const observable = from(this.commonService.callApi(this.baseUrl + '/' + catalogue + '/' + assetId + '/' + constants.constants.publicationService.thumbnail,
      data, constants.constants.method.put, true));
    return observable;
  }

  getAssetsMetaData(data) {
    const observable = from(this.commonService.callApi(this.url + '/' + constants.constants.publicationService.getAssetMetaDataListWithoutValue, data, 'post', false));
    return observable;
  }


  deleteAssets(data) {
    const observable = from(this.commonService.callApi(this.baseUrlAssets + '/' + data.assetID + '?' + constants.constants.publicationService.catalogue + '=' +
      data.catalogue + '&' + constants.constants.publicationService.token + '=' + data.token, '', constants.constants.method.delete, false));
    return observable;
  }

  getAssetsDetails(data) {
    const observable = from(this.commonService.callApi(this.baseUrlAssets + '/' + data.assetID + '?' + constants.constants.publicationService.token + '=' +
      data.token + '&' + constants.constants.publicationService.categoryID + '=' + data.categoryID + '&' + constants.constants.publicationService.catalogue + '=' +
      data.catalogue + '&' + constants.constants.publicationService.uid + '=' + data.uid, '', constants.constants.method.get, false));
    return observable;
  }

  getAllLatestCatalouge(data) {
    const observable = from(this.commonService.callApi(this.baseUrlAssets + '/' + constants.constants.publicationService.category + '/' + constants.constants.publicationService.search + '/allPublications' + '?' + data, '', constants.constants.method.get, false));
    return observable;
  }

  public getCategoryData = new BehaviorSubject<any>([]);
  itemCategoryData = this.getCategoryData.asObservable();

  assetsAddEditDetails(data: any) {
    this.getCategoryData.next(data);
  }

  public closeAssetsModel = new BehaviorSubject<any>([]);
  itemData = this.closeAssetsModel.asObservable();

  closePopup() {
    this.closeAssetsModel.next('isDelete');
  }


}

//https://api-hein-dev.goworks.com.au/rest_v2/AssetService/v1/assets/category/search?catalogue=&categoryID=0&dir=up&fetchSize=12&findDuplicate=false&uid=3561&order=AssetCreated&page=1&search=1&token=cf032719-c973-4db7-9f23-175160dd4e29
