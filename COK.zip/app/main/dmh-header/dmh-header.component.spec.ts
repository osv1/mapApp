import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DmhHeaderComponent } from './dmh-header.component';

describe('DmhHeaderComponent', () => {
  let component: DmhHeaderComponent;
  let fixture: ComponentFixture<DmhHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DmhHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DmhHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
