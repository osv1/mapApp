import {
  Component,
  Injector,
  AfterViewInit,
  OnInit,
  Input,
  ViewChild,
  ViewContainerRef,
  NgModule,
  NgModuleRef,
  Compiler
} from '@angular/core';
import {BaseComponent} from '../../common/commonComponent';
import {Router} from '@angular/router';
import {OnlineOrderingPreviewService} from '../online-ordering/online-ordering-preview/online-ordering-preview.service';
import {OnlineOrderingCartService} from '../online-ordering/online-ordering-cart/online-ordering-cart.service';
import {OnlineOrderingSummaryService} from '../online-ordering/online-ordering-summary/online-ordering-summary.service';
import {environment} from '../../../environments/environment';
import {APP_BASE_HREF} from '@angular/common';

declare function customInput(): any;

import {HttpClient, HttpHeaders} from '@angular/common/http';


declare var jQuery: any;
import {LoginService} from '../../public/login/login.service';
import {AssetTilesService} from '../asset-tiles/asset-tiles.service';
import {forEach} from "@angular/router/src/utils/collection";

// todo : for local need to replace template url due to build error
// templateUrl: './dmh-header.component.html',

@Component({
  selector: 'app-dmh-header',
  //templateUrl: environment.envnName === 'km' ? './dmh-header.component.html' : './generic-header.component.html',
  templateUrl:'./generic-header.component.html',
  styleUrls: ['./dmh-header.component.css']
})


export class DmhHeaderComponent extends BaseComponent implements OnInit, AfterViewInit {
  cartItem: any = 0;
  url: any;
  redirectURL: any;
  cartListArray: any = [];
  totalSite;
  totalPrice;
  userDetails;
  menuRoutes: any = [];
  public languageType: any;
  public homepageUrl: any = [];
  public languageArray = this.constants.languageArray[0];
  activeUrl: any;
  pathArray: any = [];
  isAdmin: any;
  public constants = this.constants;
  public env = environment;
  @ViewChild('dynamicTemplate', {read: ViewContainerRef}) dynamicTemplate;
  basketAssetsDetails: any;
  basketlength: any = 0;
  assetsIdArray: any = [];
  displayMessage: any;
  errorMessage: any;
  selectedCategory: any;
  selectedAssetsId;

  constructor(inj: Injector, public router: Router, private onlineOrderingPreviewService: OnlineOrderingPreviewService,
              private onlineOrderingCartService: OnlineOrderingCartService, private loginService: LoginService, private _compiler: Compiler,
              private _m: NgModuleRef<any>,
              private onlineOrderingSummaryService: OnlineOrderingSummaryService, public assetTilesService: AssetTilesService) {
    super(inj);
    this.cartItem = this.getToken('cartItem');
  }

  ngAfterViewInit() {
    // customInput();
    // Header Cart Link


    jQuery('header .cart').click((e) => {
      if (this.cartListArray.length) {
        this.$('body').addClass('intro');
        if (jQuery(window).width() > 992) {
          e.preventDefault();
        }
      }
    });

    // this.$(document).on('click', '.dropdown-menu .download-container', function (e) {
    //   e.stopPropagation();

    jQuery('.dropdown .folder-dd').click(function (e) {
      e.stopPropagation();
    });

    // Hamburger
    jQuery('.nav-icon-outer').click(function (e) {
      e.preventDefault();
      if (jQuery('.mobile-menu .open').hasClass('active')) {
        jQuery('.mobile-menu .open').removeClass('active');
        jQuery('.nav-icon-outer').removeClass('openNav');
      } else {
        jQuery('.mobile-menu .open').addClass('active');
        jQuery('.nav-icon-outer').addClass('openNav');
      }
      /*jQuery('.nav-icon-outer').toggleClass('active');
      jQuery('.hnk-main header').toggleClass('fixed');
      jQuery('.mobile-menu .closed').toggleClass('active');*/
    });

    // Close Nav on route change
    setTimeout(function () {
      jQuery('.nav-link').click(function (e) {
        e.preventDefault();
        jQuery('.mobile-menu .open').removeClass('active');
        jQuery('.nav-icon-outer').removeClass('openNav');
        jQuery('.hnk-main header').removeClass('fixed');
      });
    }, 2000);

    // this.componentFactoryResolver
    //  //   // .resolveComponentFactory(DmhHeaderComponent).template =  './e.component.html';
    //  // console.log( this.componentFactoryResolver
    //  //   .resolveComponentFactory(DmhHeaderComponent),'componentRef')
    //  // componentRef.templateUrl =  './e.component.html';
    //  const tmpCmp = Component({
    //    moduleId: module.id, templateUrl: require('./dmh-header.component.html')
    //  })(class {
    //  });
    //  const tmpModule = NgModule({declarations: [tmpCmp]})(class {
    //  });
    //
    //  this._compiler.compileModuleAndAllComponentsAsync(tmpModule)
    //    .then((factories) => {
    //      const f = factories.componentFactories[0];
    //      const cmpRef = f.create(this.injector, [], null, this._m);
    //      cmpRef.instance.name = 'dynamic';
    //      this.dynamicTemplate.insert(cmpRef.hostView);
    //    });
  }

  getDynamicTemplate() {
    let myTemplateUrl = './container-dmh.html';

    // if (environment.envnName === this.constants.enviromentValues.heineken) {
    //   myTemplateUrl = './another-template.component.html';
    // }


  }

  ngOnInit() {
    this.getMenuItems();
    this.selectedAssetsId = [];
    this.languageArray = this.constants.languageArray;
    this.languageType = this.constants.languageArray[0].languageType;
    this.homepageUrl = this.router.url;
    this.assetTilesService.getSelectedCategory().subscribe((res: any) => {
      if (res) {
        this.selectedCategory = res;
        this.getNameFromUrl();
      } else {
        this.selectedCategory = undefined;
      }
    })

    this.router.events.subscribe((param: any) => {
      console.log(param);
      this.homepageUrl = param.url;
      this.selectedCategory = undefined;
      this.activeUrl = param.url;
    });
    this.loginService.getUserName().subscribe(res => {
      this.userDetails = JSON.parse(this.getToken('userDetail'));
      this.getMenuItems()
    });

    this.userDetails = JSON.parse(this.getToken('userDetail'));

    this.onlineOrderingPreviewService.getCartTotal().subscribe(res => {
      console.log(res);
      if (res) {
        this.getCartDetails();
        this.cartItem = res.text;
      }
    });
    this.assetTilesService.getAssetsBasketTotal().subscribe(res => {
      console.log('res===>>?/', res);
      if (res) {
        this.getAllbasketAssets();
      }
    });

    this.getCartDetails();

    // To change Title on browser according to Heineken and DMH.
    if (jQuery('.hnk-main').length > 0) {
      jQuery('title').text('Heineken');
      jQuery('link[rel=icon]').attr('href', 'assets/images/hnk-images/hnk_favicon.ico');
    } else {
      jQuery('title').text('Konica Minolta');
      jQuery('link[rel=icon]').attr('href', 'favicon.ico');
    }

    this.getAllbasketAssets();
  }


  getNameFromUrl() {
    if (this.selectedCategory) {
      return {name: this.selectedCategory, route: ''}
    } else {
      if (this.homepageUrl === '/assets-tiles') {
        return {name: 'All Assets', route: '/onlineOrdering/select'}
      } else if (this.homepageUrl === '/homepage') {
        return {name: 'Home', route: '/homepage'}
      } else if (this.homepageUrl === '/account') {
        return {name: 'Your Account', route: '/homepage'}
      } else if (this.homepageUrl === '/assets-folder') {
        return {name: 'Assets Folder', route: '/assets-folder'}
      } else if (this.homepageUrl === '/assets-tiles/download-assets') {
        return {name: 'Your Asset Downloads', route: '/assets-tiles/download-assets'}
      } else {
        return {name: 'Custom Collateral', route: '/onlineOrdering/select'}
      }
    }
  }

// close minicart
  closeCart() {
    this.$('body').removeClass('intro');
  }

  // view cart
  viewMiniCart() {
    this.$('body').removeClass('intro');
  }

  // it will give all added items of cart and we assign cart details to cartListArray
  // method : GET
  // params : TRUE , need to send TOKEN
  getCartDetails() {
    this.totalPrice = 0;
    this.onlineOrderingCartService.getJobCartDetails().subscribe((res: any) => {
      this.cartListArray = [];
      if (res.instance) {
        if (res.instance.items) {
          this.totalPrice = 0;
          this.cartListArray = res.instance.items;
          this.cartListArray.map(item => {
            item.cost = this.setSelectPriceWithDiscount(item, item.discounts[0].tiers[0].quantity);
          });
          this.cartListArray.map(res => {
            this.totalPrice = this.totalPrice + parseFloat(res.cost);
          });
        }
      } else {
        // this.commonService.displayToaster('error', res.message);
      }
    });
  }

  getMenuItems() {
    this.userDetails = JSON.parse(this.getToken('userDetail'));
    if (this.userDetails) {
      if (environment.envnName === this.constants.enviromentValues.DMH) {
        if (this.userDetails) {
          console.log(this.userDetails);
          this.getSsoLoginDetails(this.userDetails.userID)
        }
      } else {
        this.getDetailsAfterSsoLogin();
      }
    }


  }//dummy comment to test

  getDetailsAfterSsoLogin() {
    this.loginService.getMenuItems().subscribe((res: any) => {
      if (this.userDetails.moduleRoles) {

        if (environment.envnName === this.constants.enviromentValues.DMH) {
          let ssoAdmin = this.getToken('isSsoAdmin')
          if (ssoAdmin) {
            this.isAdmin = true;
          }
        } else {
          if (this.userDetails.moduleRoles['3'] == '1') {
            this.isAdmin = true;
          }
        }
        if (this.isAdmin) {
          this.menuRoutes = res;
        } else {
          this.menuRoutes = res.filter(data => data.pathName != this.constants.IS_ADMIN_VALUE);
        }
      }
    });
  }


  getSsoLoginDetails(userId) {
    this.loginService.getSsoUserDetails(userId).subscribe((res: any) => {
      console.log(res.instance.RoleName.split(','));
      let roles = [];
      roles = res.instance.RoleName.split(',')
      roles.map(adminRole => {
        if (adminRole === 'Admin') {
          console.log('Admin')
          this.setToken("isSsoAdmin", 'true');
        }
      })
      this.getDetailsAfterSsoLogin();
    })
  }

  //name: "Catalog"
  //it will send product data for unit price and send object for total price
  // it will update total and add handling in total;
  getUnitPriceAndTotal() {
    const data = [];
    this.cartListArray.map(res => {
      data.push({
        product_id: Number(res.itemCode),
        quantity: res.qtys[0],
        itemID: res.itemID
      });


    });

    if (data) {
      this.onlineOrderingSummaryService.getUnitPriceAndTotal(data).subscribe((res: any) => {
        if (res) {
          let tempKeys = Object.values(res.instance);
          this.cartListArray.map(res => {
            tempKeys.map((res1: any) => {
              if (res.itemCode === res1.product_id && res.qtys[0] === Number(res1.quantity)) {
                res.cost = <any>res1.total_price.toFixed(2);
              }
            });
          });
          this.totalPrice = 0;
          this.cartListArray.map(res => {
            this.totalPrice = this.totalPrice + parseFloat(res.cost);
          });
          let num = parseFloat(this.totalPrice.toString());
          this.totalPrice = <any>num.toFixed(2);

          // this.cartListArray.map(reZs => {
          //   this.totalPrice = this.totalPrice + (res.qtys[0] * res.price);
          // })
          // let num = parseFloat(this.totalPrice.toString());
          // this.totalPrice = <any>num.toFixed(2)

        }
      });
    }
  }

  logOut() {
    const logoutUrl = window.location.origin;
    const data = {
      token: this.getToken('accessToken')
    };
    window.localStorage.clear();
    try {
      document.cookie.split(';').forEach(function (c) {
        document.cookie = c.replace(/^ +/, '').replace(/=.*/, '=;expires=' + new Date().toUTCString() + ';path=/');
      });
    } catch (e) {
      console.log("err", e);
    }

    this.loginService.unRegister(data).subscribe((res: any) => {
      if (res) {
        if (environment.envnName === this.constants.enviromentValues.DMH) {
          window.location.href = 'https://www.mykonicaminolta.com';
        } else {
          this.router.navigate(['/login']);
        }
      }
    });
  }

  getAllbasketAssets() {
    console.log("getAllbasketAssets====", this.assetsIdArray);

    const data = {
      token: this.getToken('accessToken'),
      fetchSize: 10,
      page: 1
    };
    this.assetTilesService.getAllbasketAssets(data).subscribe((res: any) => {
      if (res) {
        this.basketAssetsDetails = res.instance.assets;
        this.assetsIdArray = [];
        this.selectedAssetsId = [];
        this.basketAssetsDetails.forEach((obj) => {
          obj.check = true;
          this.assetsIdArray.push(obj.assetID);
          this.selectedAssetsId.push({
            assetId: obj.assetID,
            cid: obj.cid
          })
        });
        this.basketlength = res.instance.assets.length;
      }
    });
  }

  downloadSelectedAssets(assetsId, assetCategory) {

    console.log(assetCategory)
    const data = {
      token: this.getToken('accessToken'),
      catalouge: this.isCCEP(), // Remove Hard coded
      assetID: assetsId
    };
    let event = {
      event_id: this.constants.ASSET_DOWNLOAD.event_id,
      event_desc: this.constants.ASSET_DOWNLOAD.event_desc,
      attributes: assetsId,
      categoryId: assetCategory.cid
    };
    this.logService.createLog(event);
    this.url = this.env.apiUrl + 'AssetService/v1/asset/' + data.catalouge + '/download?token=' + data.token + '&fileName=&assetIDs=' + data.assetID + '&timestamp=' + new Date().getTime().toString();
    window.open(this.url);
    this.deleteSingleAsset(data)
  }

  downloadMultiSelectedAssets() {
    console.log("downloadMultiSelectedAssets-====", this.assetsIdArray)
    if (this.assetsIdArray.length > 0) {
      const data = {
        token: this.getToken('accessToken'),
        catalouge: this.isCCEP(), // Remove Hard coded
        assetsIds: this.assetsIdArray.toString(),
      };

      for (let i = 0; i < this.selectedAssetsId.length; i++) {
        let event = {
          event_id: this.constants.ASSET_DOWNLOAD.event_id,
          event_desc: this.constants.ASSET_DOWNLOAD.event_desc,
          attributes: this.selectedAssetsId[i].assetId,
          categoryId: this.selectedAssetsId[i].cid
        };
        this.logService.createLog(event);
      }

      this.url = this.env.apiUrl + 'AssetService/v1/asset/' + data.catalouge + '/download?token=' + data.token + '&fileName=&assetIDs=' + data.assetsIds + '&timestamp=' + new Date().getTime().toString();
      window.open(this.url);
      // this.assetsIdArray = [];
      this.assetsIdArray.forEach((obj) => {
        var assestDelete = {
          assetID: obj
        }
        console.log("obj", assestDelete);
        this.deleteSingleAsset(assestDelete);
      })
      // this.deleteSingleAsset(data);
      // this.clearAllAssetsBasket();
    } else {
      this.translate.get('PleaseSelectAtleastOneAsset').subscribe((res: string) => {
        this.displayMessage = res;
      });
      this.translate.get('Error').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster('error', [this.displayMessage], 5000, this.errorMessage);
    }

  }


  clearAllAssetsBasket() {
    const data = {
      token: this.getToken('accessToken')
    };
    this.assetTilesService.clearAssetsbasket(data).subscribe((res: any) => {
      this.getAllbasketAssets();
    });
  }

  selectAssets(assets, event, index) {
    console.log("assets", assets)
    if (assets.check === true) {
      this.assetsIdArray.push(assets.assetID);
      this.selectedAssetsId.push({
        assetId: assets.assetID,
        cid: assets.cid
      })
    } else if (assets.check === false) {
      console.log("this.assetsIdArray===b=", this.assetsIdArray);
      let indexs = this.assetsIdArray.indexOf(assets.assetID);
      let assetsIndex = this.selectedAssetsId.findIndex(res => res.assetId === assets.assetID)
      console.log(indexs)
      console.log(assetsIndex)
      this.assetsIdArray.splice(indexs, 1);
      this.selectedAssetsId.splice(assetsIndex, 1);
      console.log("this.assetsIdArray=a===", this.assetsIdArray);
      console.log("this.assetsIdArray=a===", this.selectedAssetsId);
    }
  }

  deleteSingleAsset(data) {
    let category = {
      token: this.getToken('accessToken'),
      catalogue: this.isCCEP(), // Remove Hard coded
      assetID: data.assetID,
      fetchSize: 5,
      page: 1
    }

    this.assetTilesService.deleteSingleAsset(category).subscribe((assetsDelete: any) => {
      if (assetsDelete.statusCode === this.constants.SUCCESS_CODE) {
        let indexs = this.basketAssetsDetails.indexOf(data);
        this.basketAssetsDetails.splice(indexs, 1);
        this.basketlength = this.basketAssetsDetails.length;
        this.getAllbasketAssets();
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, assetsDelete.message)
      }
    })
  }


  loadAssetsFolder() {
    this.getAllbasketAssets();
  }
}




