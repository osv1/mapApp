import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {CommonService} from '../../../common/common.service';
import {from, Observable} from "rxjs";
import * as constants from '../../../common/constants';

@Injectable()
export class OnlineOrderingSelectPreviewService {

  constructor(private commonService: CommonService) {

  }

  getAllSelectedItem(productId) {
    const observable = from(this.commonService.callApi('commerceService/v1/products/'+productId+'/', '', 'get', true));
    return observable;
  }

  getPdfPreviewDetails(templateId) {
    const observable = from(this.commonService.callApi('TemplateService/v1/templateS3Cache/' + templateId + '?', '', 'get', true));
    return observable;
  }
}
