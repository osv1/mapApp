import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingSelectPreviewService} from './online-ordering-select-preview.service';

@Component({
  selector: 'app-online-ordering-select-preview',
  templateUrl: './online-ordering-select-preview.component.html',
  styleUrls: ['./online-ordering-select-preview.component.css']
})
export class OnlineOrderingSelectPreviewComponent extends BaseComponent implements OnInit {

  productId;
  products;
  productInfo: any = {};
  public errorMessage;
  pdfUrl: any;
  productsResponese: any;

  constructor(inj: Injector, private onlineOrderingSelectPreviewService: OnlineOrderingSelectPreviewService) {
    super(inj);
  }

  ngOnInit() {
    this.productId = this.activatedRoute.snapshot.params['id'];

    this.getProductDetails();
  }


  getProductDetails() {

    this.onlineOrderingSelectPreviewService.getAllSelectedItem(this.productId).subscribe((res: any) => {
      this.productsResponese = res.custom_fields.en;
      this.products = this.productsResponese.filter(data => data.name != 'PDF URL' && data.field_display == "1");
      this.pdfUrl = this.productsResponese.filter(data => data.name === 'PDF URL')[0];
      this.productInfo.productName = res.name;
      this.productInfo.productImg = res.image;
      this.productInfo.templates = res.templates;
    })
  }

  pdfPreview() {
      if (this.pdfUrl != null) {
        window.open(this.pdfUrl.text);
      } else {
        this.translate.get('PdfNotFound').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      }
  }

}
