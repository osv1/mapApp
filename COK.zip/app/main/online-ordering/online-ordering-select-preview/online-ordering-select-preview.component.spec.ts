import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingSelectPreviewComponent } from './online-ordering-select-preview.component';

describe('OnlineOrderingSelectPreviewComponent', () => {
  let component: OnlineOrderingSelectPreviewComponent;
  let fixture: ComponentFixture<OnlineOrderingSelectPreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingSelectPreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingSelectPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
