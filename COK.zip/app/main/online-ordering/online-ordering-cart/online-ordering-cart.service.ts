// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {CommonService} from '../../../common/common.service';
import {from, Observable, Subject} from "rxjs";
@Injectable()
export class OnlineOrderingCartService {


  private subject = new Subject<any>();

  setPreviewData(message: any) {
    this.subject.next(message);
  }

  getPreviewData() : Observable<any>{
    return this.subject.asObservable();
  }
  constructor(private commonService : CommonService) {
  }

  getJobCartDetails() : Observable<any>{
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag', '', 'get', true));
    return observable;
  }

  removeCartItem(uid,clientId,jobBagID,itemID) : Observable<any>{
    let data = {
      uid,
      clientId
    }
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/item/'+jobBagID+'/ecommerce'+'/' +itemID, data, 'delete', true));
    return observable;
  }

  updateJobBag(jobBagID,cartJobBag) : Observable<any>{
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/'+jobBagID, cartJobBag, 'put', true))
    return observable;
  }

}
