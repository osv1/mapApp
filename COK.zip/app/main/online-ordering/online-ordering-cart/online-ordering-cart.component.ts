import {Component, OnInit, Injector} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingPreviewService} from "../online-ordering-preview/online-ordering-preview.service";
import {OnlineOrderingCartService} from './online-ordering-cart.service';
import {OnlineOrderingService} from "../online-ordering-select/online-ordering.service";
import {OnlineOrderingSummaryService} from '../online-ordering-summary/online-ordering-summary.service';
import {environment} from "../../../../environments/environment";

@Component({
    selector: 'app-online-ordering-cart',
    templateUrl: './online-ordering-cart.component.html',
    styleUrls: ['./online-ordering-cart.component.css']
})
export class OnlineOrderingCartComponent extends BaseComponent implements OnInit {


    public cartListArray = [];
    public cartJobBag: any = {};
    public image;
    public selected = 0;
    public totalSite = 0;
    public updateCartButton: boolean = false;
    public isLoaded: boolean = true;
    public productQuantity: any;
    public successMessage: any;
    stepRoute: string = '';

    constructor(inj: Injector, private onlineOrderingPreviewService: OnlineOrderingPreviewService,
                private onlineOrderingCartService: OnlineOrderingCartService, private onlineOrderingService: OnlineOrderingService,
                private onlineOrderingSummaryService: OnlineOrderingSummaryService) {
        super(inj);
    }


    ngOnInit() {
        this.getCartDetails();
        this.getProductQuantity();
        if (environment.envnName === this.constants.enviromentValues.DMH) {
            this.stepRoute = 'DMH'
        } else if (environment.envnName === this.constants.enviromentValues.cokeMain) {
            this.stepRoute = 'cokeMain'
        }
    }


// it will get Product Quantity
    // method : GET
    // params : TRUE
    // data : Product Quantity

    getProductQuantity() {
        this.onlineOrderingService.getProductQuantity().subscribe((res: any) => {
            if (res) {
                this.productQuantity = res;
            }
        })
    }

    // it will give all added items of cart and we assign cart details to cartListArray
    // method : GET
    // params : TRUE , need to send TOKEN
    getCartDetails() {
        this.totalSite = 0;
        this.onlineOrderingCartService.getJobCartDetails().subscribe((res: any) => {
            if (res) {
                if (res.instance.items) {
                    this.cartListArray = res.instance.items;
                    if (res.instance.items[0]) {
                        this.setToken('ItemId', res.instance.items[0].itemID)
                    }
                    this.onlineOrderingCartService.setPreviewData(this.cartListArray[0])
                    // this.cartListArray.map(res => {
                    //   this.totalSite = this.totalSite + (res.qtys[0] * res.price)
                    // })
                    this.getUnitPriceAndTotal();
                    // let num = parseFloat(this.totalSite.toString());
                    // this.totalSite = <any>num.toFixed(2)
                }
                this.isLoaded = false;
                this.cartJobBag = res.instance;
                this.cartJobBag.jobBagID = res.instance.jobBagID;
            } else {
                this.commonService.displayToaster('error', res.message);
            }
        });
    }

    //it will send product data for unit price and send object for total price
    // it will update total and add handling in total;
    getUnitPriceAndTotal() {
        let data = [];
        this.cartListArray.map(res => {
            data.push({
                product_id: Number(res.itemCode),
                quantity: res.qtys[0],
                itemID: res.itemID
            });
        })
        this.onlineOrderingSummaryService.getUnitPriceAndTotal(data).subscribe((res: any) => {
            if (res) {
                let tempKeys = Object.values(res.instance);
                this.cartListArray.map(res => {
                    tempKeys.map((res1: any) => {
                        if (res.itemCode === res1.product_id && res.qtys[0] === Number(res1.quantity)) {
                            res.cost = <any>res1.total_price.toFixed(2);
                        }
                    })
                })
                this.cartListArray.map(res => {
                    this.totalSite = this.totalSite + parseFloat(res.cost)

                })
                let num = parseFloat(this.totalSite.toString());
                this.totalSite = <any>num.toFixed(2)
            }
        });
    }

    setItemId(itemCode, itemId) {
        this.setToken('ItemId', itemId);
        this.router.navigate(['/onlineOrdering/customization/' + itemCode])
    }

    toFixedValue(num, qty) {
        if (num * qty) {
            let amount = num * qty
            let num1 = parseFloat(amount.toString());
            return num1.toFixed(2)
        }
    }

    setPreviewPageData(page) {
        this.setToken('ItemId', page.itemID)
        this.onlineOrderingCartService.setPreviewData(page)
    }

    navigateToPreview(page) {
        this.router.navigate(['/onlineOrdering/preview/' + page.jTemplateID + '/' + page.itemCode])
    }

    // it will remove individual cart item from the jobbag
    // method : DELETE
    // params : TRUE , need to send TOKEN
    // DATA : UID and CLIENTID
    removeItemCart(itemID) {
        let templateId = this.getToken('templateId');
        let event = {
            event_id: this.constants.ABANDONED_CART.event_id,
            event_desc: this.constants.ABANDONED_CART.event_desc,
            productId: itemID,
            templateId: templateId
        }
        this.logService.createLog(event);
        this.onlineOrderingCartService.removeCartItem(this.cartJobBag.uid, this.cartJobBag.clientID, this.cartJobBag.jobBagID, itemID).subscribe((res: any) => {
            if (res) {
                this.onlineOrderingPreviewService.setCartTotal(res.instance.items.length);
                this.getCartDetails();
                this.translate.get('CartItemRemovedSuccessfully').subscribe((res: string) => {
                    this.successMessage = res;
                });
                this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage)
            } else {
                this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
            }
        })
    }


    // it will update the job bag on update basket button click
    // method : PUT
    // params : FALSE
    // DATA : CART JOBBAG  OBJECT
    updateJobBag() {
        this.updateCartButton = true;
        this.onlineOrderingCartService.updateJobBag(this.cartJobBag.jobBagID, this.cartJobBag).subscribe((res: any) => {
            this.updateCartButton = false;
            if (res) {
                if (res.instance.items) {
                    this.getCartDetails();
                    this.translate.get('CartItemUpdatedSuccessfully').subscribe((res: string) => {
                        this.successMessage = res;
                    });
                    this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage)
                }
                this.cartJobBag = res.instance;
            } else {
                this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
            }
        })
    }
}
