import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingCartComponent } from './online-ordering-cart.component';

describe('OnlineOrderingCartComponent', () => {
  let component: OnlineOrderingCartComponent;
  let fixture: ComponentFixture<OnlineOrderingCartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingCartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingCartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
