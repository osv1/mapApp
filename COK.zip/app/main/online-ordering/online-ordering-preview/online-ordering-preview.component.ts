import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {Router} from "@angular/router";
import { OnlineOrderingPreviewService } from './online-ordering-preview.service';
import { OnlineOrderingCartService } from '../online-ordering-cart/online-ordering-cart.service';
import { OnlineOrderingShippingService } from '../online-ordering-shipping/online-ordering-shipping.service'
import { OnlineOrderingSummaryService } from '../online-ordering-summary/online-ordering-summary.service';
import {OnlineOrderingService} from '../online-ordering-select/online-ordering.service';
declare var $: any;

@Component({
  selector: 'app-online-ordering-preview',
  templateUrl: './online-ordering-preview.component.html',
  styleUrls: ['./online-ordering-preview.component.css']
})
export class OnlineOrderingPreviewComponent extends BaseComponent implements OnInit {
  public itemList: any = []
  public jtemplateId: any;
  qty: any;
  pdfResponse: any;
  highPdfResponse: any;
  pageType: any;
  pageDetails: any = {};
  templateId: any;
  productId: any = '';
  userDetail: any;
  jobBagId: any;
  CurrentJobBag: any;
  public productData: any = {};
  qtyarray:any = [];
  includeForm : Boolean = false;
  jobBagID;
  model;
  public errorMessage: any;
  public successMessage: any;
  public itemData;
  public matchExistingItemId;
  public cartJobBag: any = {};
  public productDetails;
  public restrictUser = false;
  constructor(inj: Injector, public router: Router,private onlineOrderingPreviewService : OnlineOrderingPreviewService,
              private onlineOrderingCartService : OnlineOrderingCartService,
              private onlineOrderingShippingService : OnlineOrderingShippingService,
              private onlineOrderingSummaryService : OnlineOrderingSummaryService,
              private onlineOrderingService : OnlineOrderingService) {
    super(inj);
    this.jtemplateId = this.activatedRoute.snapshot.params['id'];
    this.productId = this.activatedRoute.snapshot.params['productId'];
    this.userDetail = JSON.parse(this.getToken('userDetail'))
    this.qty = JSON.parse(this.getToken('qty'))
    this.qtyarray.push(this.qty)

  }

  ngOnInit() {
    console.log(this.jtemplateId);

    // this.onlineOrderingCartService.setPreviewData(data)
    this.getCartPreview();
    this.getproductDetails();
    this.getExisitingJobBag();
    // debugger;
    // this.onlineOrderingCartService.setPreviewData(data)
  }

  addEventLogs(customizeEvent){
    let templateId = this.getToken('templateId');
    let event = {
      event_id : customizeEvent.event_id,
      event_desc : customizeEvent.event_desc,
      productId: this.productId,
      jTemplateId:this.jtemplateId,
      templateId :templateId,
      model : this.productDetails.model ? this.productDetails.model : '',
      categoryId : this.productDetails.categoryID ? this.productDetails.categoryID : ''
    }
    this.logService.createLog(event);
  }



   // it will get all product details
  // method : GET
  // params : TRUE
  // data : productData
  getproductDetails() {
    this.onlineOrderingPreviewService.getproductDetails(this.productId).subscribe((res:any) =>{
      if (res) {
        console.log("product-----",res);
        this.getProductPrice(res);
        var item = {"name": res.name, "type": this.constants.PRODUCT_DETAILS_TYPE, "product": res};
        this.productDetails = res;
        this.productData = item;
        this.model = res.model
        let data = {
          itemCode : this.productId,
          jTemplateID :  this.jtemplateId
        }

        this.onlineOrderingCartService.setPreviewData(data)
      }
    })
  }

  getProductPrice(productsDetail){
    if(productsDetail.discounts && productsDetail.discounts.length) {
      let price = this.setSelectPriceWithDiscount(productsDetail, productsDetail.discounts[0].tiers[0].quantity);
      if (price === this.constants.price) {
        this.restrictUser = true;
        this.onlineOrderingService.setBreadCrumbsRestrictions(price);
      }
    } else {
      this.displayToaster(this.constants.TOAST_ERROR,'Invalid Product');
    }
  }

  // it will get all cart preview
  // method : GET
  // params : TRUE
  // data : item List
  getCartPreview() {
    this.onlineOrderingPreviewService.getCartPreview(this.jtemplateId).subscribe((res:any) =>{
      if (res) {
        this.pdfResponse = res.lowResS3;
        this.highPdfResponse = res.highResS3;
        this.itemList = JSON.parse(res.pagePreviews);
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
      }
    })
  }

  openCancelModal(){
    this.$('#cancelOrderModal').modal('show');
  }

  hideCancelModal(){
    this.$('#cancelOrderModal').modal('hide');
  }
  // show cart details on popUp


  showDetails(page, pageIndex) {
    this.pageType = pageIndex;
    if(page){
      this.pageDetails = page;
    }
    this.$('#commonModal').modal('show');
    console.log("commonModal")

  }

// download cart details pdf
  downloadPdf() {
    this.addEventLogs(this.constants.DOWNLOAD_PDF_PROOF)
    if(this.pdfResponse != null){
      window.open(this.highPdfResponse);
    }else{
      this.translate.get('PdfNotFound').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage)
    }


  }

  navigateToCustomization(){
    this.router.navigate(['onlineOrdering/customization/'+this.productId]);
  }

  // show backword and forword cart details on popUp


  showItemDetails(page, pageIndex) {
    if (pageIndex && (pageIndex === 'forward' || pageIndex === 'backward')) {
      if (pageIndex === 'forward' && this.pageType < this.itemList.length - 1) {
        this.pageType = (this.pageType + 1);
        page = this.itemList[this.pageType];
      } else if (pageIndex === 'backward' && this.pageType > 0) {
        this.pageType = (this.pageType - 1);
        page = this.itemList[this.pageType];
      }
    } else if (pageIndex >= 0) {
      this.pageType = pageIndex;
    }
    if(page){
      this.pageDetails = page;
    }
  }



  // it will remove all items of cart
  // method : POST
  // params : TRUE , need to send TOKEN
  cancelOrder(){
    let itemID = this.getToken('ItemId');

    if(itemID) {
      this.onlineOrderingCartService.removeCartItem(this.cartJobBag.uid, this.cartJobBag.clientID, this.cartJobBag.jobBagID, itemID).subscribe((res: any) => {
        if (res) {
          this.addEventLogs(this.constants.CANCEL_ORDER)
          this.onlineOrderingPreviewService.setCartTotal(res.instance.items.length);
          this.translate.get('CartItemRemovedSuccessfully').subscribe((res: string) => {
            this.successMessage = res;
          });
          this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
          this.router.navigate(['onlineOrdering/select'])
        } else {
          this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
        }
      })
    } else {
      this.router.navigate(['onlineOrdering/select'])
      this.translate.get('ItemCancelSuccessfully').subscribe((res: string) => {
        this.successMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
    }
  }

  getExisitingJobBag(){
    this.onlineOrderingShippingService.getJobBag().subscribe((res :any) => {
      if(res.instance){
        this.cartJobBag = res.instance;
        this.jobBagID = res.instance.jobBagID;
        this.itemData = res.instance.items;
        console.log(this.jobBagID);
      }
      // console.log(this.jobBagDetails);
    })
  }

  // Add to Job bag(if job bag already exist then only get otherwise add to new job bag)

  addToCart(){
    this.onlineOrderingPreviewService.checkJobBag().subscribe((res:any) =>{
      if (res.instance) {
        this.jobBagId = res.instance.jobBagID;
        this.CurrentJobBag = res.instance;
        this.insertJobBag();
      } else {
        this.onlineOrderingPreviewService.addToCart().subscribe((res:any) =>{
          this.jobBagId = res.instance.jobBagID;
          this.CurrentJobBag = res.instance;
          this.insertJobBag();
        })
      }
    })
  }


  setStorageValues(){
    this.onlineOrderingPreviewService.setCartTotal('');
    let  count = this.getToken('stepCount');
    this.stepArray.push(count);
    this.stepArray.push(3);
    this.setToken("stepCount", this.stepArray);
  }
  // insert item in job bag based on job bag object
  // method : POST

   insertJobBag(){
     let data = {
       token: this.getToken('accessToken')
     }
       let jobBagItem = {
         "jobBagItem": {
           "type": this.productData.type,
           "itemID": 0,
           "itemCode": this.productId,
           "name": this.productData.name,
           "qtys": this.qtyarray,
           "model":this.model,
           "specifications": "",
           "files": [],
           "assets": [],
           "templateID": 0,
           "jTemplateID": parseInt(this.jtemplateId),
           "thumbnail": this.itemList[0].s3Path,
           "pdfPreview": this.pdfResponse,
           "highResPdfUrl":this.highPdfResponse,
           "productTypeID": "0",
           "price": this.productData.product.price,
           "discounts" : this.productDetails.discounts ? this.productDetails.discounts : [],
           "jobBagItemOptions": [],
           "template": {},
           "metadata": []
         }
       }
       console.log(this.getToken('ItemId'));

       let item =this.getToken('ItemId')
       console.log(this.itemData)

     if(item) {
       this.itemData.map(res => {
         if (res.itemID === Number(item)) {
           this.matchExistingItemId = true;
         }
       })
     }
     if(this.matchExistingItemId){
       this.setStorageValues();
       this.translate.get('CartItemUpdatedSuccessfully').subscribe((res: string) => {
         this.successMessage = res;
       });
       this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
       this.router.navigate([('/onlineOrdering/cart')])
     } else {
       this.onlineOrderingPreviewService.insertCartToJobBag(this.jobBagId, this.userDetail.defaultClientID, jobBagItem, data.token).subscribe((res: any) => {
         this.CurrentJobBag = res.instance;
        this.setStorageValues();
         this.translate.get('ItemAddedToCartSuccessfully').subscribe((res: string) => {
           this.successMessage = res;
         });
         this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
         this.router.navigate([('/onlineOrdering/cart')])
       })
     }
   }




}


