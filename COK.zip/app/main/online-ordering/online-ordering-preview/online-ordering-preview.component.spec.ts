import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingPreviewComponent } from './online-ordering-preview.component';

describe('OnlineOrderingPreviewComponent', () => {
  let component: OnlineOrderingPreviewComponent;
  let fixture: ComponentFixture<OnlineOrderingPreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingPreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
