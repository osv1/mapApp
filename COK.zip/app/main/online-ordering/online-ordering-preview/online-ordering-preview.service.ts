// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {CommonService} from '../../../common/common.service';
import {from, Observable, Subject} from "rxjs";

@Injectable()
export class OnlineOrderingPreviewService {

  private subject = new Subject<any>();

  sendMessage(message: any) {
    this.subject.next({ text: message });
  }

  setCartTotal(message: any) {
    this.subject.next({ text: message });
  }

  getCartTotal(){
    return this.subject.asObservable();
  }
  constructor(private commonService : CommonService) {
  }
  getproductDetails(productID) : Observable<any>{
    const observable = from(this.commonService.callApi('commerceService/v1/products/' + productID + '/', '', 'get', true));
    return observable;
  }

  getCartPreview(jtemplateId){
    const observable  = from(this.commonService.callApi('TemplateService/v1/jobTemplateS3Cache/' + jtemplateId + '?', '', 'get', true));
    return observable;
  }
  checkJobBag(){
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/', '', 'get', true));
    return observable;
  }

  addToCart(){
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/', '', 'post', true));
    return observable;
  }

  insertCartToJobBag(jobBagId,defaultClientID,jobBagItem,token){
    const  observable = from(this.commonService.callApi('jobbagService/v1/jobbag/item/'+jobBagId+'?clientId='+defaultClientID+'&token='+token
      ,jobBagItem, 'post', false));
    return observable;
  }

}
