import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingCustomizeComponent } from './online-ordering-customize.component';

describe('OnlineOrderingCustomizeComponent', () => {
  let component: OnlineOrderingCustomizeComponent;
  let fixture: ComponentFixture<OnlineOrderingCustomizeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingCustomizeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingCustomizeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
