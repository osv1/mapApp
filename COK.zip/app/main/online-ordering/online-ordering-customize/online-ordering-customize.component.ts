import {ChangeDetectorRef, Component, ElementRef, Injector, OnInit, ViewChild} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingCustomizationService} from './online-ordering-customization.service';
import {OnlineOrderingService} from "../online-ordering-select/online-ordering.service";
import {OnlineOrderingSummaryService} from '../online-ordering-summary/online-ordering-summary.service';
import {OnlineOrderingPreviewService} from '../online-ordering-preview/online-ordering-preview.service';

declare var $: any;


@Component({
    selector: 'app-online-ordering-customize',
    templateUrl: './online-ordering-customize.component.html',
    styleUrls: ['./online-ordering-customize.component.css']
})
export class OnlineOrderingCustomizeComponent extends BaseComponent implements OnInit {

    public customization: any = {};
    public userDetail;
    public submitted = false;
    public productDetails: any = {};
    public cartListArray = [];
    public cartJobBag: any = {};
    public includeContactForm: Boolean = false;
    public isAvailableForm: Boolean = false;
    public successMessage: any;
    public errorMessage: any;
    countries: any = [];
    templateId: any;
    public jobBagID;
    userId: any;
    public ccepObj: any = {};

    constructor(inj: Injector, private onlineOrderingCustomizationService: OnlineOrderingCustomizationService, private onlineOrderingService: OnlineOrderingService,
                private onlineOrderingSummaryService: OnlineOrderingSummaryService, private onlineOrderingPreviewService: OnlineOrderingPreviewService) {
        super(inj);

        this.userDetail = JSON.parse(this.getToken('userDetail'))
        this.customization.productId = this.activatedRoute.snapshot.params['id'];
        this.ccepObj.productId = this.activatedRoute.snapshot.params['id'];
        ;
        this.ccepObj.token = this.getToken('accessToken');
    }


    // Here first getTemplateStamp function called for getting jtemplateID
    // Assign data from local storage for pre filled inputs
    ngOnInit() {
        setTimeout(() => {
            this.createTemplateStamp();
        }, 1000);
        this.getproductDetails();
        this.getCartDetails();

        if (!JSON.parse(this.getToken('customizationDetails'))) {
            let name = this.userDetail.name.split(" ")
            this.customization.firstName = name[0];
            this.customization.lastName = name[1];
            this.customization.email = this.userDetail.email;
            this.customization.mobilePhone = this.userDetail.phone;
            this.customization.companyName = this.userDetail.division;
            this.customization.street1 = this.userDetail.address2;
            this.customization.street2 = this.userDetail.address3;
            this.customization.city = this.userDetail.address1;
            this.customization.stateOrProviance = this.userDetail.state;
            // this.customization.country = this.userDetail.country;
            this.customization.zipCode = this.userDetail.zipCode;
        } else {
            this.customization = JSON.parse(this.getToken('customizationDetails'));
        }
        this.getCountry();
        this.getUserImage();

        // this.getUserImageUpload();
    }


    getUserImageUpload() {
        this.onlineOrderingCustomizationService.getUserUploadedImage().subscribe(res => {
            console.log(res);
        })
    }


    // it will remove all items of cart
    // method : POST
    // params : TRUE , need to send TOKEN
    cancelOrder() {
        let itemID = this.getToken('ItemId');

        if (itemID) {
            this.onlineOrderingCustomizationService.removeCartItem(this.cartJobBag.uid, this.cartJobBag.clientID, this.cartJobBag.jobBagID, itemID).subscribe((res: any) => {
                if (res) {
                    this.addEventLogs(this.constants.CANCEL_ORDER);
                    this.onlineOrderingPreviewService.setCartTotal(res.instance.items.length);
                    this.translate.get('CartItemRemovedSuccessfully').subscribe((res: string) => {
                        this.successMessage = res;
                    });
                    this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
                    this.router.navigate(['onlineOrdering/select'])
                } else {
                    this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
                }
            })
        } else {
            this.translate.get('ItemCancelSuccessfully').subscribe((res: string) => {
                this.successMessage = res;
            });
            this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
            this.router.navigate(['onlineOrdering/select'])
        }
    }

    // it will remove individual cart item from the jobbag
    // method : DELETE
    // params : TRUE , need to send TOKEN
    // DATA : UID and CLIENTID
    removeItemCart() {
        let itemID = this.getToken('ItemId');

        if (itemID) {
            this.onlineOrderingCustomizationService.removeCartItem(this.cartJobBag.uid, this.cartJobBag.clientID, this.cartJobBag.jobBagID, itemID).subscribe((res: any) => {
                if (res) {
                    this.onlineOrderingPreviewService.setCartTotal(res.instance.items.length);
                    this.translate.get('CartItemRemovedSuccessfully').subscribe((res: string) => {
                        this.successMessage = res;
                    });
                    this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage)
                    this.router.navigate(['onlineOrdering/select'])
                } else {
                    this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
                }
            })
        } else {
            this.router.navigate(['onlineOrdering/select'])
        }
    }

    //getTemplateStamp function for getting  jtemplateID
    // todo : remove hard coded template Id , once template object is fetched from commerce product object.
    // method : POST
    // params : FALSE
    // DATA : token and templateID
    addEventLogs(customizeEvent) {
        let event = {
            event_id: customizeEvent.event_id,
            event_desc: customizeEvent.event_desc,
            productId: this.customization.productId,
            jTemplateId: this.customization.jtemplateID,
            templateId: this.templateId,
            model: this.productDetails.model ? this.productDetails.model : '',
            categoryId: this.productDetails.categoryID ? this.productDetails.categoryID : ''
        }
        this.logService.createLog(event);
    }

    createTemplateStamp() {
        this.templateId = this.getToken('templateId');
        this.ccepObj.templateId = this.templateId
        this.onlineOrderingCustomizationService.createJobTemplateStamp(this.templateId).subscribe((res: any) => {
            if (res) {
                this.customization.jtemplateID = res.jtemplateID;
                this.addEventLogs(this.constants.CUSTOMIZE_PRODUCT);
                console.log(this.customization);
                if (res.statusCode === 200) {
                } else {
                    this.commonService.displayToaster('error', res.message);
                }
            }
        })
    }

    getCountry() {
        this.onlineOrderingCustomizationService.getCountryList().subscribe((res: any) => {
            this.countries = res;

            // this.customization = JSON.parse(this.getToken('customizationDetails'));
            if (this.customization.country) {
                this.customization.country = this.customization.country;
            } else {
                if (this.countries.length != 0) {
                    this.customization.country = 'United States';
                }
            }

        })
    }

    removeUserDetails() {
        let jtemplateID = this.customization.jtemplateID;
        this.customization = {};
        this.customization.jtemplateID = jtemplateID;
    }

    openCancelModal() {
        this.$('#cancelOrderModal').modal('show');
    }

    hideCancelModal() {
        this.$('#cancelOrderModal').modal('hide');
    }

    // it will give all added items of cart and we assign cart details to cartListArray
    // method : GET
    // params : TRUE , need to send TOKEN
    getCartDetails() {
        this.onlineOrderingCustomizationService.getJobCartDetails().subscribe((res: any) => {
            if (res.instance) {
                if (res.instance.items) {
                    this.cartListArray = res.instance.items;
                }
                this.cartJobBag = res.instance;
                this.cartJobBag.jobBagID = res.instance.jobBagID;
                this.jobBagID = res.instance.jobBagID;
            } else {
                // this.commonService.displayToaster('error', res.message);
            }
        });
    }

    // getTemplateStamp function for getting jtemplateID
    // method : GET
    // params : TRUE
    // DATA : token
    getproductDetails() {
        let productID;
        productID = this.customization.productId;
        this.onlineOrderingCustomizationService.productDetails(productID).subscribe((res: any) => {
            if (res) {
                this.productDetails = res;
                this.getProductPrice(this.productDetails);
            }
        })
    }


    getProductPrice(productsDetail) {
        if (productsDetail.discounts && productsDetail.discounts.length) {
            let price = this.setSelectPriceWithDiscount(productsDetail, productsDetail.discounts[0].tiers[0].quantity);
            if (price === this.constants.price) {
                this.onlineOrderingService.setBreadCrumbsRestrictions(price);
            }
        } else {
            this.displayToaster(this.constants.TOAST_ERROR, 'Invalid Product');
        }
    }

    getUserdetail() {
        this.onlineOrderingService.getUserDetails().subscribe((res: any) => {
            if (res.statusCode === 200) {
                let userDetail = JSON.stringify(res.instance);
                this.setToken("userDetail", userDetail)
                this.userId = res.instance.userID;

            } else {
                this.commonService.displayToaster('error', res.message);
            }
        })
    }

    getUserImage() {
        let userId = JSON.parse(this.getToken('userDetail')).userID;
        this.onlineOrderingService.getS3UserImage(userId).subscribe((res: any) => {
            console.log(res);
            if (res.statusCode === 200) {
                this.customization.avatar = res.instance;
            } else {
                this.commonService.displayToaster('error', res.message);
            }
        })
    }

    createInputMask(mobileNumber) {
        console.log(mobileNumber)
        return mobileNumber.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3")
    }

    // updateCustomization function called for updating customize form with concate string
    // required fileds for sending data are logo, jTemplateID ,address
    // method : PUT
    // params : TRUE
    // DATA : token
    // todo : need to add dynamic brand image upload.
    updateCustomization(isNavigate) {
        let regx = new RegExp('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$');
        let isValidEmail = regx.test(this.customization.email)
        if (!this.includeContactForm) {
            if (!isValidEmail) {
                this.translate.get('InvalidEmail').subscribe((res: string) => {
                    this.errorMessage = res;
                });
                this.commonService.displayToaster('error', this.errorMessage);
                return;
            }
        }

        this.addEventLogs(this.constants.CUSTOMIZE_PRODUCT_VIEW);

        if (this.customization.avatar) {
            this.submitted = true;
            this.customization.email = this.customization.email ? this.customization.email.toLowerCase() : this.customization.email;
            this.customization.lastName = this.customization.lastName ? this.customization.lastName : "";
            let concatedString = this.constants.LABEL_CONTACT + '\n' + this.customization.firstName + " " + this.customization.lastName.concat(
                (this.customization.companyName ? '\n' + this.customization.companyName : "") +
                (this.customization.street1 ? '\n' + this.customization.street1 : "") +
                (this.customization.street2 ? ((!this.customization.street1) ? '\n' + this.customization.street2 + " " : " , " + this.customization.street2) + " " : "") +
                (this.customization.city ? ((!this.customization.street1 && !this.customization.street2) ? '\n' + this.customization.city + " " : '\n' + this.customization.city) + " " : "") +
                (this.customization.stateOrProviance ?
                    ((!this.customization.street1 && !this.customization.street2 && !this.customization.city) ?
                        '\n' + this.customization.stateOrProviance + " " : (!this.customization.city) ? '\n' + this.customization.stateOrProviance
                            : ', ' + this.customization.stateOrProviance + " ") : "") +

                (this.customization.zipCode ?
                    ((!this.customization.street1 && !this.customization.street2 && !this.customization.city && !this.customization.stateOrProviance) ?
                        '\n' + this.customization.zipCode + " " :
                        (!this.customization.city && !this.customization.stateOrProviance) ? '\n' + this.customization.zipCode
                            : ', ' + this.customization.zipCode + " ") : "") +
                (this.customization.country ?
                    ((!this.customization.street1 && !this.customization.street2 && !this.customization.city && !this.customization.stateOrProviance && !this.customization.zipCode)
                        ? '\n' + this.customization.country
                        : (!this.customization.city && !this.customization.stateOrProviance && !this.customization.zipCode) ?
                            '\n' + this.customization.country : ', ' + this.customization.country) : "") +
                (this.customization.email ? '\n' + this.customization.email.toLowerCase() : "") +
                (this.customization.mobilePhone ? '\n' + this.constants.LABEL_MOBILE + this.customization.mobilePhone.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3") : "") +
                (this.customization.phone ? '\n' + this.constants.LABEL_PHONE + this.customization.phone.replace(/(\d{3})(\d{3})(\d{4})/, "($1) $2-$3") : "") +
                (this.customization.fax ? '\n' + this.constants.LABEL_FAX + this.constants.LABEL_PLUS_SYMBOL + this.customization.fax.replace(/(\d{1})(\d{3})(\d{3})(\d{4})/, "$1 ($2) $3 $4") : ""));

            if (!this.cartListArray) {
                this.onlineOrderingCustomizationService.updateJobTemplateStamp(this.customization.jtemplateID, concatedString, this.customization.avatar, this.includeContactForm).subscribe((res: any) => {
                    if (res) {
                        this.submitted = false;
                        this.setToken('customizationDetails', JSON.stringify(this.customization))
                        // this.getUserdetail();
                        this.translate.get('CustomizationEditedSuccessfully').subscribe((res: string) => {
                            this.successMessage = res;
                        });
                        this.commonService.displayToaster('success', this.successMessage)
                        this.isAvailableForm = !this.isAvailableForm
                        if (isNavigate) {

                            this.router.navigate(['/onlineOrdering/preview/' + this.customization.jtemplateID + '/' + this.productDetails.product_id])
                        }

                    } else {
                        this.commonService.displayToaster('error', res.message);
                    }
                })
            } else {
                this.onlineOrderingCustomizationService.updateExistingJobTemplateStamp(this.customization.jtemplateID, concatedString, this.customization.avatar, this.includeContactForm).subscribe((res: any) => {
                    if (res) {
                        this.submitted = false;
                        this.setToken('customizationDetails', JSON.stringify(this.customization))
                        this.translate.get('CustomizationEditedSuccessfully').subscribe((res: string) => {
                            this.successMessage = res;
                        });
                        this.commonService.displayToaster('success', this.successMessage);
                        this.isAvailableForm = !this.isAvailableForm
                        if (isNavigate) {

                            this.router.navigate(['/onlineOrdering/preview/' + this.customization.jtemplateID + '/' + this.productDetails.product_id])
                        }
                    } else {
                        this.commonService.displayToaster('error', res.message);
                    }
                })
            }
        } else {
            this.translate.get('LogoImageUploadIsRequired').subscribe((res: string) => {
                this.errorMessage = res;
            });
            this.commonService.displayToaster('error', this.errorMessage);
        }
    }


    saveCustomization() {
        if (this.customization.avatar) {
            this.submitted = true;


            let concatedString = this.customization.firstName.concat('\n' + (this.customization.street1 ? this.customization.street1 + '\n' : "")
                + (this.customization.street2 ? this.customization.street2 + '\n' : "") +
                (this.customization.city ? this.customization.city + '\n' : "") +
                (this.customization.stateOrProviance ? this.customization.stateOrProviance + '\n' : "") +
                (this.customization.zipCode ? this.customization.zipCode + '\n' : "") +
                (this.customization.country ? this.customization.country : ""));

            if (!this.cartListArray) {
                this.onlineOrderingCustomizationService.updateJobTemplateStamp(this.customization.jtemplateID, concatedString, this.customization.avatar, this.includeContactForm).subscribe((res: any) => {
                    if (res) {
                        this.setToken('customizationDetails', JSON.stringify(this.customization))
                        this.submitted = false;
                        // this.getUserdetail();
                        this.translate.get('CustomizationEditedSuccessfully').subscribe((res: string) => {
                            this.successMessage = res;
                        });
                        this.commonService.displayToaster('success', this.successMessage);
                    } else {
                        this.commonService.displayToaster('error', res.message);
                    }
                })
            } else {
                // if (form.valid) {
                this.onlineOrderingCustomizationService.updateExistingJobTemplateStamp(this.customization.jtemplateID, concatedString, this.customization.avatar, this.includeContactForm).subscribe((res: any) => {
                    if (res) {
                        this.setToken('customizationDetails', JSON.stringify(this.customization))
                        this.submitted = false;
                        // this.getUserdetail();
                        this.translate.get('CustomizationEditedSuccessfully').subscribe((res: string) => {
                            this.successMessage = res;
                        });
                        this.commonService.displayToaster('success', this.successMessage);
                    } else {
                        this.commonService.displayToaster('error', res.message);
                    }
                })
            }
        } else {
            this.translate.get('LogoImageUploadIsRequired').subscribe((res: string) => {
                this.errorMessage = res;
            });
            this.commonService.displayToaster('error', this.errorMessage);
        }
    }


    validateEmail() {
        let regx = new RegExp('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$');
        regx.test(this.customization.email);

        console.log(regx.test(this.customization.email))
    }

    // Image cropping Functions started
    // Crop image functionality
    imageChangedEvent: any = '';
    imageCoverChangedEvent: any = '';
    croppedImage: any = '';
    sliceSize: any;
    ImageURL: any;

    // modalRef: BsModalRef;
    hideModal() {
        this.closeModel();
    }

    loadImageFailed() {
        // this.modalRef.hide();
    }

    imageCropped(event) {
        //this.count++;
        this.croppedImage = event;
        var ImageURL = event.base64;
        // Split the base64 string in data and contentType
        var block = ImageURL.split(";");
        // Get the content type of the image
        var contentType = block[0].split(":")[1];// In this case "image/gif"
        // get the real base64 content of the file
        var realData = block[1].split(",")[1];// In this case "R0lGODlhPQBEAPeoAJosM...."

        // Convert it to a blob to upload
        this.b64toBlob(realData, contentType, this.sliceSize);

    }

    imageCoverCropped(event) {
        this.croppedImage = undefined;
        this.ImageURL = undefined;
        //this.count++;
        this.croppedImage = event;
        this.ImageURL = event.base64;
        // Split the base64 string in data and contentType
        var block = this.ImageURL.split(";");
        // Get the content type of the image
        var contentType = block[0].split(":")[1];// In this case "image/gif"
        // get the real base64 content of the file
        var realData = block[1].split(",")[1];// In this case "R0lGODlhPQBEAPeoAJosM...."

        // Convert it to a blob to upload
        this.b64toBlob(realData, contentType, this.sliceSize);

    }

    public file: any;

    b64toBlob(b64Data, contentType, sliceSize) {
        this.file = undefined;
        contentType = contentType || '';
        sliceSize = sliceSize || 512;
        var byteCharacters = atob(b64Data);
        var byteArrays = [];
        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }

        console.log(contentType)
        let imageType = contentType.substr(6)
        var blob = new Blob(byteArrays, {type: contentType});
        this.file = new File([blob], "adil." + imageType, {type: contentType, lastModified: Date.now()});
    }

    error;
    public filesize: any;
    public imageData2: any;

    validateProfileImage(event, template) {
        this.imageChangedEvent = undefined;
        if (event.target.files.length) {
            var input = event.target;
            this.error = "";
            var allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
            this.filesize = event.target.files[0].size / 1024 / 1024;
            console.log(event.target.files[0])
            console.log(this.filesize)
            if (this.filesize <= 5 && allowedExtensions.exec(event.target.value)) {
                this.imageChangedEvent = event;
                $('#parentLargeModal').modal('show');
                return true;
            } else if (!allowedExtensions.exec(event.target.value)) {
                this.translate.get('Please select jpeg, jpg or png file.').subscribe((res: string) => {
                    this.error = res;
                });
                this.commonService.displayToaster(this.constants.TOAST_ERROR, this.error);
                return false;
            } else if (this.filesize > 5) {
                this.translate.get('Please upload image less than 5MB.').subscribe((res: string) => {
                    this.error = res;
                });
                this.commonService.displayToaster(this.constants.TOAST_ERROR, this.error);
                return false;
            }
            return true;
        }
    }


    // redirect to ccep module
    customCCEPTemplate() {
        this.router.navigate(['/customiseMenu'], {
            queryParams: {
                categoryId: this.ccepObj.categoryId || 0,
                jTempalteID: this.ccepObj.jTempalteId || 0,
                productCategoryID: this.ccepObj.productCategoryId || 0,
                templateID: this.ccepObj.templateId || 0,
                productID: this.ccepObj.productId || 0,
                token: this.ccepObj.token
            }
        });
    }


    // when image cropped it will submit to api and return new image url which is used to send in updateTemplate api
    // method : GET
    // params : TRUE
    // DATA : token and file name
    submitcropped() {
        this.closeModel();
        let fd = new FormData();
        fd.append('fileNames', this.file);
        this.commonService.callApi('UserService/v1/user/avatar/upload', fd, 'post', true, true).then((res: any) => {
            if (res.statusCode === 200) {
                console.log(res);
                this.customization.avatar = res.instance;
                // this.router.navigate(['/onlineOrdering/preview/'+this.customization.jtemplateID])
            } else {
                this.commonService.displayToaster('error', res.message)
            }
        });
    }

    // Image cropping function

}
