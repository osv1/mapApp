// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {CommonService} from '../../../common/common.service';
import { constants} from '../../../common/constants';
import {from, Observable} from "rxjs";

@Injectable()
export class OnlineOrderingCustomizationService {


  constructor(private commonService: CommonService) {
  }

  createJobTemplateStamp(templateId): Observable<any> {
    let data = {
      templateID: parseInt(templateId),
    }
    const observable = from(this.commonService.callApi('TemplateService/v1/jobTemplateStamp', data, 'post', true));
    return observable;
  }

  getJobCartDetails(): Observable<any> {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag', '', 'get', true));
    return observable;
  }

  productDetails(productID): Observable<any> {
    const observable = from(this.commonService.callApi('commerceService/v1/products/' + productID + '/', '', 'get', true));
    return observable;
  }

  getUserUploadedImage(){
    const observable = from(this.commonService.callApi('UserService/v1/user/avatar/upload', '', 'get', true));
    return observable;
  }

  updateJobTemplateStamp(jtemplateID, concatedString, avatar, isContactInformationIncluded): Observable<any> {

    let data;
    if (isContactInformationIncluded) {
      data = {
        jTemplateID: jtemplateID,
        fields: {"logo": avatar}
      }
    } else {
      data = {
        jTemplateID: jtemplateID,
        fields: {"address": concatedString, "logo": avatar}
      }
    }

    const observable = from(this.commonService.callApi('TemplateService/v1/jobTemplateStamp', data, 'post', true));
    return observable;
  }

  removeCartItem(uid,clientId,jobBagID,itemID) : Observable<any>{
    let data = {
      uid,
      clientId
    }
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/item/'+jobBagID+'/ecommerce'+'/' +itemID, data, 'delete', true));
    return observable;
  }

  updateExistingJobTemplateStamp(jtemplateID, concatedString, avatar, isContactInformationIncluded): Observable<any> {
    let data;
    if (isContactInformationIncluded) {
      data = {
        jTemplateID: jtemplateID,
        fields: {"logo": avatar}

      }
    } else {
      data = {
        jTemplateID: jtemplateID,
        fields: {"address": concatedString, "logo": avatar}
      }
    }

    const observable = from(this.commonService.callApi('TemplateService/v1/jobTemplateStamp', data, 'put', true));
    return observable;
  }

  getCountryList(): Observable<any> {
    const observable = from(this.commonService.callApi('commerceService/v1/countries', '', 'get', true));
    return observable;
  }

  getZoneList(country_id): Observable<any> {
    const observable = from(this.commonService.callApi('commerceService/v1/country/' + country_id + '/zones/', '', 'get', true));
    return observable;
  }

}
