import {Component, Injector, Input, OnInit} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingCartService} from '../online-ordering-cart/online-ordering-cart.service';
import {LoginService} from "../../../public/login/login.service";
import {environment} from "../../../../environments/environment";
import {OnlineOrderingService} from '../online-ordering-select/online-ordering.service';
import {take} from 'rxjs/operators'

@Component({
    selector: 'app-breadcrumbs',
    templateUrl: './breadcrumbs.component.html',
    styleUrls: ['./breadcrumbs.component.css']
})
export class BreadcrumbsComponent extends BaseComponent implements OnInit {

    @Input('route') route;
    public bradCrumbsData: any = {};
    countvalue: any;
    productId; //254 for check
    jTemplateId; // 22389 for check
    isSubscribed: Boolean = false;
    jobbagId: any;
    bradCrumbsMenu: Boolean = true;
    resArray: any = [];

    constructor(inj: Injector, private onlineOrderingCartService: OnlineOrderingCartService, private loginService: LoginService,
                private onlineOrderingService: OnlineOrderingService) {
        super(inj);

    }

    ngOnInit() {
        this.getBreadcrumeData();
        this.bradCrumbsMenu = true;
        if (environment.envnName === this.constants.enviromentValues.heineken) {
            this.bradCrumbsMenu = false;
        } else if (environment.envnName === this.constants.enviromentValues.DMH) {
            this.getBreadcrumeData();
            this.bradCrumbsMenu = true;
            this.getBreadCrumbsRestrictions();
            this.getPreviewData();
        } else if (environment.envnName === this.constants.enviromentValues.cokeMain) {
            this.getBreadcrumeData();
            this.bradCrumbsMenu = true;
        }
        if (this.getToken('itemCode') && this.getToken('jTemplateID')) {
            this.productId = this.getToken('itemCode');
            this.jTemplateId = this.getToken('jTemplateID')
        }
    }

    getBreadCrumbsRestrictions() {
        this.onlineOrderingService.getBreadCrumbsRestrictions().pipe(take(1)).subscribe((res: any) => {
            if (res) {
                if (res === this.constants.price) {
                    this.loginService.getBreadcrumbData().subscribe((res: any) => {
                        if (res) {
                            if (this.bradCrumbsData.steps) {
                                this.bradCrumbsData.steps = this.bradCrumbsData.steps.filter(res => res.id <= 3);
                                console.log(this.bradCrumbsData.steps)
                            }
                        }
                    })
                }
            }
        })
    }


    getPreviewData() {
        this.onlineOrderingCartService.getPreviewData().subscribe((res: any) => {
            if (res) {
                this.productId = res.itemCode;
                this.jTemplateId = res.jTemplateID;
            }
            this.bradCrumbsData.steps[2].redirectURL = '/onlineOrdering/preview/' + this.jTemplateId + '/' + this.productId;
            this.bradCrumbsData.steps[1].redirectURL = '/onlineOrdering/customization/' + this.productId;
        })
    }

    getBreadcrumeData() {
        this.loginService.getBreadcrumbData().subscribe((res: any) => {
            if (res) {
                this.resArray = [
                    {
                        "desc": "1. Select",
                        "visited": "true",
                        "active": "false",
                        "redirectURL": "",
                        "storeURL": [
                            "https://ccep-dev.kmms.com.au/",
                            "http://commerce-usdev.goworks.com.au/heineken/"
                        ],
                        "id": 1
                    },
                    {
                        "desc": "2. Customize",
                        "visited": "false",
                        "active": "false",
                        "redirectURL": "",
                        "storeURL": [
                            "https://ccep-dev.kmms.com.au/",
                            "http://commerce-usdev.goworks.com.au/heineken/"
                        ],
                        "id": 2
                    },
                    {
                        "desc": "3. Cart",
                        "visited": "false",
                        "active": "false",
                        "redirectURL": "",
                        "storeURL": [
                            "https://ccep-dev.kmms.com.au/"
                        ],
                        "id": 3
                    },
                    {
                        "desc": "4. Checkout",
                        "visited": "false",
                        "active": "false",
                        "redirectURL": "",
                        "storeURL": [
                            "https://ccep-dev.kmms.com.au/"
                        ],
                        "id": 4
                    },
                    {
                        "desc": "5. Done",
                        "visited": "false",
                        "active": "false",
                        "redirectURL": "",
                        "storeURL": [
                            "https://ccep-dev.kmms.com.au/"
                        ],
                        "id": 5
                    }
                ]

                this.bradCrumbsData.steps = res;
                this.bradCrumbsData.steps.map((res: any) => {
                    res.redirectURL = decodeURIComponent(this.router.url);
                })
                this.setCokeSteps(Number(this.route))
                if (environment.envnName === this.constants.enviromentValues.cokeMain) {
                    this.setCokeSteps(Number(this.route))
                } else if (environment.envnName === this.constants.enviromentValues.DMH) {
                    this.setStep(Number(this.route))
                }

            }
        })
    }

    setCokeSteps(step) {
        if (this.bradCrumbsData.steps[step - 1].disabled)
            return;
        this.bradCrumbsData.steps.map(s => {
            if (s.id != step) {
                s.visited = false;
                s.active = false;
                s.redirectURL = this.router.url;
            }
            if (s.id < step) {
                s.visited = true;
                if ((s.visited == true) && (s.desc == "1. Select")) {
                    s.redirectURL = '/onlineOrdering/select'
                }
                if ((s.visited == true) && (s.desc == "2. Customize")) {
                        // s.redirectURL = '/customiseMenu';

                }
                if ((s.visited == true) && (s.desc == "3. Cart")) {
                    s.redirectURL = '/onlineOrdering/cart'
                }
                if ((s.visited == true) && (s.desc == "4. Checkout")) {
                    s.redirectURL = '/onlineOrdering/shipping'
                }
                if ((s.visited == true) && (s.desc == "5. Done")) {
                    s.redirectURL = '/onlineOrdering/done/' + this.activatedRoute.snapshot.params['id'];
                }
            }
        });
        this.bradCrumbsData.steps[step - 1].visited = false;
        this.bradCrumbsData.steps[step - 1].active = true;
    }

    setStep(step) {
        console.log("qqq")
        if (this.bradCrumbsData.steps[step - 1].disabled)
            return;

        this.bradCrumbsData.steps.map(s => {
            if (s.id != step) {
                s.visited = false;
                s.active = false;
                s.redirectURL = this.router.url;
            }

            if (s.id < step) {
                s.visited = true;
                if ((s.visited == true) && (s.desc == "1. Select")) {
                    s.redirectURL = '/onlineOrdering/select'
                }
                if ((s.visited == true) && (s.desc == "2. Customize")) {
                    if (this.productId) {
                        s.redirectURL = '/onlineOrdering/customization/' + this.productId;
                    }
                }
                if ((s.visited == true) && (s.desc == "3. Preview")) {
                    if (this.productId && this.jTemplateId) {
                        s.redirectURL = '/onlineOrdering/preview/' + this.jTemplateId + '/' + this.productId;
                    }
                }
                if ((s.visited == true) && (s.desc == "4. Cart")) {
                    s.redirectURL = '/onlineOrdering/cart'
                }
                if ((s.visited == true) && (s.desc == "5. Shipping")) {
                    s.redirectURL = '/onlineOrdering/shipping'
                }
                if ((s.visited == true) && (s.desc == "6. Summary")) {
                    s.redirectURL = '/onlineOrdering/summary'
                }
                if ((s.visited == true) && (s.desc == "7. Done")) {
                    s.redirectURL = '/onlineOrdering/done/' + this.activatedRoute.snapshot.params['id'];
                }
            }
        });
        this.bradCrumbsData.steps[step - 1].visited = false;
        this.bradCrumbsData.steps[step - 1].active = true;
    }

}
