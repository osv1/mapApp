import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingSummaryComponent } from './online-ordering-summary.component';

describe('OnlineOrderingSummaryComponent', () => {
  let component: OnlineOrderingSummaryComponent;
  let fixture: ComponentFixture<OnlineOrderingSummaryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingSummaryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
