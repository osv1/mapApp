import {Component, Injector, OnInit} from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingSummaryService} from "./online-ordering-summary.service";
import {OnlineOrderingPreviewService} from "../online-ordering-preview/online-ordering-preview.service";

@Component({
  selector: 'app-online-ordering-summary',
  templateUrl: './online-ordering-summary.component.html',
  styleUrls: ['./online-ordering-summary.component.css']
})
export class OnlineOrderingSummaryComponent extends BaseComponent implements OnInit {
  cartSummaryArray: any = [];
  cartSummaryData: any;
  totalSite: any = 0;
  apporveSumbit: boolean = false;
  jobBagID;
  isLoaded: boolean = true;
  highResPdfUrl: any;
  handlingFeeDetails: any;
  public errorMessage: any;
  public successMessage: any;
  public totalHandlingFees;

  constructor(inj: Injector, private onlineOrderingSummaryService: OnlineOrderingSummaryService, private onlineOrderingPreviewService: OnlineOrderingPreviewService) {
    super(inj);
  }

  ngOnInit() {
    this.getHandlingFee();
    this.getCartSummaryDetails();
  }

  getHandlingFee() {
    this.onlineOrderingSummaryService.getHandlingFee().subscribe((res: any) => {
      if (res.statusCode == 200) {
        console.log("res---", res);
        this.handlingFeeDetails = res.instance.value.toFixed(2);
      }
    })
  }


  // it will give all added items of cart
  // method : GET
  // params : TRUE , need to send TOKEN
  getCartSummaryDetails() {
    this.isLoaded = true
    this.onlineOrderingSummaryService.getCartSummaryDetails().subscribe((res: any) => {
      if (res.instance) {
        this.jobBagID = res.instance.jobBagID;
        if (res.instance.items) {
          this.cartSummaryArray = res.instance.items;
          this.cartSummaryData = res.instance;
          this.getUnitPriceAndTotal();
        }

        this.isLoaded = false;
      }
    });
  }


  //it will send product data for unit price and send object for total price
  // it will update total and add handling in total;
  getUnitPriceAndTotal() {
    let data = [];
    this.cartSummaryArray.map(res => {
      data.push({
        product_id: Number(res.itemCode),
        quantity: res.qtys[0],
        itemID: res.itemID
      });


    })
    this.onlineOrderingSummaryService.getUnitPriceAndTotal(data).subscribe((res: any) => {
      if (res) {
        let tempKeys = Object.values(res.instance);
        this.cartSummaryArray.map(res =>{
          tempKeys.map((res1:any) => {
            if(res.itemCode === res1.product_id && res.qtys[0] === Number(res1.quantity)){
              res.cost = <any>res1.total_price.toFixed(2);
            }
          })
        })
        this.cartSummaryArray.map(res => {
          this.totalSite = this.totalSite + parseFloat(res.cost);

        })
        let num = parseFloat(this.totalSite.toString());
        this.totalSite = <any>num.toFixed(2)

        if(this.handlingFeeDetails) {
          let num = parseFloat(this.totalSite.toString());
          this.totalSite = <any>num.toFixed(2);
          this.totalHandlingFees = num + parseFloat(this.handlingFeeDetails.toString());
          this.totalHandlingFees = <any>this.totalHandlingFees.toFixed(2);
        }
      }
    });
  }

  // it will remove all items of cart
  // method : POST
  // params : TRUE , need to send TOKEN
  cancelOrder() {
    this.onlineOrderingSummaryService.removeDataFromCart(this.jobBagID).subscribe((res: any) => {
      if (res.statusCode === 200) {
        this.onlineOrderingPreviewService.setCartTotal('');
        this.translate.get('ItemCancelSuccessfully').subscribe((res: string) => {
          this.successMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
        this.router.navigate(['onlineOrdering/select'])
      }
    });
  }

  sendOrder() {
    let data = [];
    this.cartSummaryArray.map(res => {
      data.push({
        product_id: Number(res.itemCode),
        quantity: res.qtys[0],
        option: {},
        jTemplateID: res.jTemplateID,
        content: {},
        highResPdfUrl: res.highResPdfUrl
      })
    })
    console.log(this.cartSummaryData);
    //
    this.onlineOrderingSummaryService.checkout(data, this.cartSummaryData.jobBagID).subscribe((res: any) => {
      if (res) {
        if (res.statusCode === 200) {
          this.translate.get('CheckoutSuccessfully').subscribe((res: string) => {
            this.successMessage = res;
          });
          this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
          this.router.navigate(['/onlineOrdering/done/' + this.cartSummaryData.jobBagID])
          this.onlineOrderingPreviewService.setCartTotal('');
        }
      }
    });


    //
  }




}
