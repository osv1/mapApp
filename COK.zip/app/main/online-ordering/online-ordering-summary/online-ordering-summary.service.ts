import {Injectable} from '@angular/core';
import {CommonService} from '../../../common/common.service';
import {from, Observable, Subject} from "rxjs";

@Injectable()
export class OnlineOrderingSummaryService {


  private subject = new Subject<any>();


  constructor(private commonService: CommonService) {
  }

  getCartSummaryDetails(): Observable<any> {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag', '', 'get', true));
    return observable;
  }

  getJobBag(jobBagId): Observable<any> {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/' + jobBagId, '', 'get', true));
    return observable;
  }

  removeDataFromCart(jobBagId) {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/clear/' + jobBagId, '', 'post', true));
    return observable;
  }

  checkout(data, jobbagId) {
    const observable = from(this.commonService.callApi('commerceService/v1/checkout/' + jobbagId, data, 'post', true));
    return observable;
  }

  getHandlingFee() {
    const observable = from(this.commonService.callApi('commerceService/v1/handlingFee/', '', 'get', true));
    return observable;
  }
  getUnitPriceAndTotal(data){
    const observable = from(this.commonService.callApi('commerceService/v1/unitPriceAndTotal/', data, 'post', true));
    return observable;
  }
}
