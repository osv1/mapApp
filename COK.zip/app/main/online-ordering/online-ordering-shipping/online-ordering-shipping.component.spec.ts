import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingShippingComponent } from './online-ordering-shipping.component';

describe('OnlineOrderingShippingComponent', () => {
  let component: OnlineOrderingShippingComponent;
  let fixture: ComponentFixture<OnlineOrderingShippingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingShippingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingShippingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
