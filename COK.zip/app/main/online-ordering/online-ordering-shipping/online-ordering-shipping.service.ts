// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {CommonService} from '../../../common/common.service';
import {from, Observable} from "rxjs";
@Injectable()
export class OnlineOrderingShippingService {


  constructor(private commonService : CommonService) {
  }



  getShippingMethods(){
    const observable = from(this.commonService.callApi('commerceService/v1/shipping/methods/', '', 'get', true));
    return observable;
  }


  removeShippingAddress(shippingAddress){
    const observable = from(this.commonService.callApi('commerceService/v1/shipping/', shippingAddress, 'post', true));
    return observable;
  }


  getShippingInformation(){
    const observable = from(this.commonService.callApi('commerceService/v1/shipping/', '', 'get', true));
    return observable;
  }


  saveNewShippingDetails(shippingDetails){
    const observable = from(this.commonService.callApi('commerceService/v1/shipping/', shippingDetails, 'post', true));
    return observable;
  }


  saveExistingShippingDetails(shippingAddress){
    const observable = from(this.commonService.callApi('commerceService/v1/shipping/', shippingAddress, 'post', true));
    return observable;
  }


  getJobBag(){
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag', '', 'get', true));
    return observable;
  }

  updateJobBag(cartJobBag,address) : Observable<any>{
    let gowCommerceShippingDetails : any = {
      userDetails : {
        firstName : address.firstname,
        lastName : address.lastname,
        email : address.email
      },
      shippingAccountDetails : {
        shipAccNumber : address.shipAccNumber,
        shipAccPostalCode : address.shipAccPostalCode,
        shipMethod : address.shipMethod
      },
      orderNotes: address.orderNotes,
      commerceAddresses : {
        attn : address.attn,
        company : address.company,
        address_id : address.address_id,
        address_1 : address.address_1,
        address_2 : address.address_2,
        city : address.city,
        stateOrProvince : address.stateOrProvince,
        zone : address.zone,
        country : address.country,
        zone_code : address.zone_code,
        zone_id : address.zone_id,
        iso_code_2 : address.iso_code_2,
        iso_code_3 : address.iso_code_3,
        postcode :address.postcode
      }
    };

    cartJobBag.instance.gowCommerceShippingDetails = gowCommerceShippingDetails;

    console.log(gowCommerceShippingDetails);
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/'+cartJobBag.instance.jobBagID, cartJobBag.instance, 'put', true))
    return observable;
  }

}
