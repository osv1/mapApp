import {Component, OnInit, Injector, Input, Output, EventEmitter} from '@angular/core';
import {BaseComponent} from "../../../../common/commonComponent";
import {OnlineOrderingShippingService} from '../online-ordering-shipping.service';
import {OnlineOrderingCustomizationService} from "../../online-ordering-customize/online-ordering-customization.service";

@Component({
  selector: 'app-add-new-shipping',
  templateUrl: './add-new-shipping.component.html',
  styleUrls: ['./add-new-shipping.component.css']
})
export class AddNewShippingComponent extends BaseComponent implements OnInit {

  public gowCommerceShippingDetails: any = {
    userDetails: {},
    shippingAccountDetails: {},
    orderNotes: '',
    commerceAddresses: {}
  };
  public errorMessage: any;
  public successMessage: any;
  public gowShippingDetails: any = {};
  public shippingMethods: any = {};
  @Input() isEdit;
  @Input() shippingDetails;
  @Output() updateShippingDetails: EventEmitter<any> = new EventEmitter();
  @Output() createShipping: EventEmitter<any> = new EventEmitter();
  countries: any;
  zoneList: any;

  constructor(inj: Injector, private onlineOrderingShippingService: OnlineOrderingShippingService, private onlineOrderingCustomizationService: OnlineOrderingCustomizationService) {
    super(inj);
  }

  ngOnInit() {
    this.getCountry();
    this.getExistingShippingMethods();
    this.gowCommerceShippingDetails = {
      userDetails: {},
      shippingAccountDetails: {},
      orderNotes: '',
      commerceAddresses: {}
    };
    this.gowShippingDetails = {};
    if (this.isEdit) {
      this.gowShippingDetails = this.shippingDetails;
      if (this.gowShippingDetails) {
        this.gowShippingDetails.country_id = this.shippingDetails.country_id;
        this.gowShippingDetails.zone_id = this.shippingDetails.zone_id;
      }
      this.gowShippingDetails.shipMethod = this.shippingDetails.shipMethod;
    }


  }

  getCountry() {
    this.onlineOrderingCustomizationService.getCountryList().subscribe((res: any) => {
      this.countries = res;
      if (!this.isEdit) {
        this.gowShippingDetails.country_id = '223';
        this.gowShippingDetails.country = 'United States';
        this.getZone(this.gowShippingDetails.country_id);
        // this.gowShippingDetails.country = this.countries[0].name
      }

      if (this.isEdit) {
        this.gowShippingDetails.country_id = this.shippingDetails.country_id;
        this.getZone(this.shippingDetails.country_id);
      }
    })
  }

  getZone(country_id) {
    this.onlineOrderingCustomizationService.getZoneList(country_id).subscribe((res: any) => {
      if (res) {
        this.zoneList = res;
      }
      if (!this.isEdit) {
        if (this.zoneList) {
          this.gowShippingDetails.zone = this.zoneList[0].name;
          this.gowShippingDetails.zone_id = this.zoneList[0].zone_id;
        }
      } else {
        this.gowShippingDetails.country_id = this.shippingDetails.country_id;
        this.gowShippingDetails.zone_id = this.shippingDetails.zone_id;

      }
    })
  }

  addNewShipping() {
    if (!this.gowShippingDetails.shipAccNumber) {
      this.translate.get('ShippingAccountNumberIsRequired').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    if (!this.gowShippingDetails.shipAccPostalCode) {
      this.translate.get('ShippingPostalCodeIsRequired').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    if (this.gowShippingDetails.shipMethod === "" || this.gowShippingDetails.shipMethod === "undefined" || !this.gowShippingDetails.shipMethod) {
      this.translate.get('ShippingMethodIsRequired').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    let regx = new RegExp('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$');
    let isValidEmail = regx.test(this.gowShippingDetails.email)
    if (!isValidEmail) {
      this.translate.get('InvalidEmail').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }

    this.gowShippingDetails.action = 'create';
    this.gowShippingDetails.address_id = '';
    this.gowShippingDetails.tax_id = "",
      this.gowShippingDetails.zone = "",
      this.gowShippingDetails.zone_code = "",
      // this.gowShippingDetails.zone_id = "",
      this.gowShippingDetails.address_format = "",
      this.gowShippingDetails.company_id = "",
      this.gowShippingDetails.country = "",
      // this.gowShippingDetails.country_id =  "",
      this.gowShippingDetails.iso_code_2 = "",
      this.gowShippingDetails.iso_code_3 = "",
      this.gowShippingDetails.email = this.gowShippingDetails.email.toLowerCase();


    this.gowShippingDetails.shipMethod = this.gowShippingDetails.shipMethod ? this.gowShippingDetails.shipMethod : "";
    if (this.gowShippingDetails.shipMethod === "undefined") {
      this.gowShippingDetails.shipMethod = "";
    }
    // console.log(this.gowShippingDetails);
    this.onlineOrderingShippingService.saveNewShippingDetails(this.gowShippingDetails).subscribe((res: any) => {
      if (res.statusCode === 200) {
        this.translate.get('ShippingAddressAddedSuccessfully').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_ERROR, this.successMessage);
        this.createShipping.emit(this.gowShippingDetails);
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message)
      }
    });
    // console.log(JSON.stringify(this.gowCommerceShippingDetails));
  }

  getExistingShippingMethods() {
    this.onlineOrderingShippingService.getShippingMethods().subscribe((res: any) => {
      this.shippingMethods = res;
    })
  }


  saveChanges() {

    if (!this.gowShippingDetails.shipAccNumber) {
      this.translate.get('ShippingAccountNumberIsRequired').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    if (!this.gowShippingDetails.shipAccPostalCode) {
      this.translate.get('ShippingPostalCodeIsRequired').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    if (this.gowShippingDetails.shipMethod === "" || this.gowShippingDetails.shipMethod === "undefined" || !this.gowShippingDetails.shipMethod) {
      this.translate.get('ShippingMethodIsRequired').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    let regx = new RegExp('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$');
    let isValidEmail = regx.test(this.gowShippingDetails.email)
    if (!isValidEmail) {
      this.translate.get('InvalidEmail').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      return;
    }
    this.gowShippingDetails.action = 'update';
    this.gowShippingDetails.email = this.gowShippingDetails.email.toLowerCase();
    this.gowShippingDetails.shipMethod = this.gowShippingDetails.shipMethod ? this.gowShippingDetails.shipMethod : "";
    if (this.gowShippingDetails.shipMethod === "undefined") {
      this.gowShippingDetails.shipMethod = "";
    }
    console.log(this.gowShippingDetails);


    this.onlineOrderingShippingService.saveExistingShippingDetails(this.gowShippingDetails).subscribe((res: any) => {

      if (res.statusCode === 200) {
        this.isEdit = false;
        this.translate.get('ShippingAddressEditedSuccessfully').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, this.successMessage);
        this.updateShippingDetails.emit(this.gowShippingDetails)
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message)
      }
    })
  }

}

