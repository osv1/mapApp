// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {CommonService} from '../../../../common/common.service';
import {from, Observable} from "rxjs";
@Injectable()
export class OnlineOrderingCustomizationService {


  constructor(private commonService : CommonService) {
  }

  createJobTemplateStamp() : Observable<any>{
    let data = {
      templateID : 1360,
    }
    const observable = from(this.commonService.callApi('TemplateService/v1/jobTemplateStamp', data, 'post', true));
    return observable;
  }


  getShippingDetails(){
    const observable = from(this.commonService.callApi('commerceService/v1/shipping/methods/', '', 'get', true));
    return observable;
  }
  

}
