import { Component, OnInit,Injector } from '@angular/core';
import {OnlineOrderingShippingService} from './online-ordering-shipping.service'
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingSummaryService} from '../online-ordering-summary/online-ordering-summary.service';
import {OnlineOrderingPreviewService} from '../online-ordering-preview/online-ordering-preview.service';
@Component({
  selector: 'app-online-ordering-shipping',
  templateUrl: './online-ordering-shipping.component.html',
  styleUrls: ['./online-ordering-shipping.component.css']
})
export class OnlineOrderingShippingComponent extends BaseComponent implements OnInit {

  public isEditShippingDetails : boolean = false;
  public isAddNewDetails : boolean = false;
  public exisitingShippingDetails = [];
  public isLoaded: boolean = true;
  public exisitingShippingMethods = [];
  public userDetails : any = {};
  public selectedShippingDetails : any ={};
  public jobBagDetails :any ={};
  public editIndex;
  public jobBagID;
  public successMessage: any;
  public errorMessage: any;
  constructor(inj: Injector,private  onlineOrderingShippingService : OnlineOrderingShippingService,private onlineOrderingSummaryService:OnlineOrderingSummaryService,
              private  onlineOrderingPreviewService:OnlineOrderingPreviewService) {
    super(inj);
  }

  ngOnInit() {
    this.userDetails = JSON.parse(localStorage.getItem('userDetail'));
    this.getExistingShippingInformation();
    // this.getExistingShippingMethods();
    this.getExisitingJobBag();
  }



  getExisitingJobBag(){
    this.onlineOrderingShippingService.getJobBag().subscribe((res :any) => {
      this.jobBagDetails = res;
      if(res.instance){
        this.jobBagID = res.instance.jobBagID;
      }
      // console.log(this.jobBagDetails);
    })
  }



  getExistingShippingInformation(){
    this.onlineOrderingShippingService.getShippingInformation().subscribe((res :any) =>{
      if(res.statusCode === 200) {
      this.exisitingShippingDetails = res.instance.addresses;
        this.isLoaded = false;
        } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR,res.message)
      }
    })

  }


  // it will remove all items of cart
  // method : POST
  // params : TRUE , need to send TOKEN
  cancelOrder(){
    this.onlineOrderingSummaryService.removeDataFromCart(this.jobBagID).subscribe((res: any) => {
      if(res.statusCode === 200){
        this.onlineOrderingPreviewService.setCartTotal('');
        this.translate.get('ItemCancelSuccessfully').subscribe((res: string) => {
          this.successMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS , this.successMessage);
        this.router.navigate(['onlineOrdering/select'])
      }
    });
  }

  getExistingShippingMethods(){
    this.onlineOrderingShippingService.getShippingMethods().subscribe((res :any) =>{
      console.log(res);
      this.exisitingShippingMethods = res;
    })
  }


  orderSummary(shipping){
    this.selectedShippingDetails = shipping;
  }

  removeShippingAddress(shippingDetails){
    shippingDetails.action = "delete"
    this.onlineOrderingShippingService.removeShippingAddress(shippingDetails).subscribe((res :any) => {

      if(res.statusCode === 200) {
        this.getExistingShippingInformation();
        this.translate.get('ShippingAddressRemovedSuccessfully').subscribe((res: string) => {
          this.successMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS , this.successMessage);
      } else  {
        this.commonService.displayToaster(this.constants.TOAST_ERROR,res.message)
      }

    })
  }

  toggleForm(index){
    this.isEditShippingDetails = index;
    this.editIndex = index;
    this.isAddNewDetails = false

  }


  continueToSummary(){
    if(this.selectedShippingDetails.firstname){
      this.onlineOrderingShippingService.updateJobBag(this.jobBagDetails,this.selectedShippingDetails).subscribe((res :any) => {
        this.router.navigate(['/onlineOrdering/summary']);
      })
    } else {
      this.translate.get('PleaseSelectAnyShippingAddress').subscribe((res: string) => {
        this.errorMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_ERROR , this.errorMessage);
    }

  }

  updateExistingDetails(shippingData){
    this.isEditShippingDetails = undefined;
    this.isAddNewDetails = false;
    this.getExistingShippingInformation();
  }

  createNewShipping(shippingData){
    this.getExistingShippingInformation();
    this.isEditShippingDetails = undefined;
    this.isAddNewDetails = false;
  }
}
