// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';
import {CommonService} from '../../../common/common.service';
import {from, Observable, Subject} from "rxjs";
import * as constants from '../../../common/constants';

@Injectable()
export class OnlineOrderingService {
  public token: any;
  public commerceJobTemplateId;
  isViewProductDetail = false;
  public jTemplateID: any;
  public product_id: any;
  public templateID: any;
  public item: any;
  public isViewCart = false;
  public isCartView = false;
  public isProductView = false;
  public action: any;
  public isCustomizeCart = false;

  constructor(private commonService: CommonService) {

  }

  public jtemplateIDData = new BehaviorSubject<any>([]);
  itemJtemplateID = this.jtemplateIDData.asObservable();
  private restrictions = new Subject<any>();
  setJtemplateIDData(data: any) {
    this.jtemplateIDData.next(data);
  }

  setBreadCrumbsRestrictions(price) {
    this.restrictions.next(price)
  }

  getBreadCrumbsRestrictions(): Observable<any> {
    return this.restrictions.asObservable();
  }

  getAllCategories() {
    const observable = from(this.commonService.callApi('commerceService/v1/categories', '', 'get', true));
    return observable;
  }

  getUserDetails() {
    const observable = from(this.commonService.callApi('UserService/v1/user/', '', 'get', true, false, true));
    return observable;

  }

  getUserUploadedImage(uid: any) {
    const observable = from(this.commonService.callApi('UserService/v1/user/avatar/' + uid, '', 'get', true, false, true));
    return observable;
  }


  getS3UserImage(uid: any){
    const observable = from(this.commonService.callApi('UserService/v1/user/avatars3/' + uid, '', 'get', true, false, true));
    return observable;
  }

  getProductDetails(productID) {
    const observable = from(this.commonService.callApi('commerceService/v1/products/' + productID + '/', '', 'get', true));
    return observable;
  }

  loadMoreOnlineProduct(categoryDetails) {
    const observable = from(this.commonService.callApi('commerceService/v1/categories/' + categoryDetails.categoryID + '/products' + '?page=' + categoryDetails.page + '&fetchSize=' + categoryDetails.fetchSize + '&order=' + categoryDetails.order + '&dir=' + categoryDetails.dir + '&search=' + (categoryDetails.searchText ? categoryDetails.searchText : ''), '', 'get', true))
    return observable;
  }

// ?page='+pagination.page + '&fetchSize='+ pagination.fetchSize ,

  getPdfPreviewDetails(templateId) {
    const observable = from(this.commonService.callApi('TemplateService/v1/templateS3Cache/' + templateId + '?', '', 'get', true));
    return observable;
  }

  getProductQuantity() {
    const observable = from(this.commonService.callApi('commerceService/v1/qtys/', '', 'get', true));
    return observable;
  }
  checkCatalogeHideStatus(){
    const observable = from(this.commonService.callApi('UserService/v1/user/tourStatus/', '', 'get', true));
    return observable;
  }

  hideCatalogeGuide(status){
    const observable = from(this.commonService.callApi('UserService/v1/user/tourStatus/?&statusID=' + status ,'', 'post', true));
    return observable;
  }

}
