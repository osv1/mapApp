import {ChangeDetectorRef, Component, ElementRef, Injector, OnInit, ViewChild} from '@angular/core';
import {BaseComponent} from '../../../common/commonComponent';
import {Title} from '@angular/platform-browser';
import {DecimalPipe} from '@angular/common';
import {OnlineOrderingService} from './online-ordering.service';
import {environment} from '../../../../environments/environment';
import { OnlineOrderingCustomizationService} from '../online-ordering-customize/online-ordering-customization.service';
import {OnlineOrderingPreviewService} from '../online-ordering-preview/online-ordering-preview.service';
import {OnlineOrderingShippingService} from '../online-ordering-shipping/online-ordering-shipping.service';

declare var jQuery: any;


@Component({
  selector: 'app-online-ordering-select',
  templateUrl: './online-ordering-select.component.html',
  styleUrls: ['./online-ordering-select.component.css'],
  providers: [DecimalPipe]
})
export class OnlineOrderingSelectComponent extends BaseComponent implements OnInit {
  [x: string]: any;

  public style1;
  @ViewChild('fileInput') fileInput: ElementRef;
  public hasBaseDropZoneOver = false;
  files: any = [];
  productSearch: any;
  uploadInProgress = false;
  uploader: any;
  filesProgressByName: any = {};
  fileMetaList = [];
  filesUploaded: any = [];
  filesProgress: any = [];
  projectFilesUploaded: any = [];
  totalFiles: any;
  specTemplateIconUrl = '../../previewService/get/specTemplateCode';  // display spec template code
  productsPage: any = {page: 1, fetchSize: 12, categoryID: 0, order: 'alpha', dir: 'asc'};
  productsPageFilter: any = {page: 1, fetchSize: 12, categoryID: 0, order: 'alpha', dir: 'asc'};
  products: any = [];
  isLoaded: boolean = true;
  CurrentPersonaliseItem: any;
  cart: any = {};
  activeCategory: any = {};
  isCategoryView: boolean = true;
  isProductListView: boolean = false;
  isProductDetailView: boolean = false;
  isSpecBreifView: boolean = false;         //write a brief
  isSpecTemplateView: boolean = false;      //spec template
  productDetail: any = {};
  cartProductQuantity: any = 1;
  relatedProducts: any = [];
  noMoreOnlineProducts = false;
  quantityLimit: any = 10;
  breadcrumbs: any = [];
  minQuantity: any = 1;
  maxQuantity: any = 10;
  searchText: any = '';
  userDateFormat: any;
  currentState: any;
  shipmentDetails: any;
  activatedIndex: number = 0;
  errorMessage: any;
  initPersonalisationOfCartURL = '/rest_v2/jobbagService/v1/jobbag/item/personalise/';
  adworksURLParamName = '/?commerceParameters=';
  slides: any = [
    'https://loremflickr.com/320/240',
    'https://loremflickr.com/320/240',
    'https://loremflickr.com/320/240'
  ];
  downloadPDFArtworkData: any = {
    'UID': 1010, 'clientSessionID': 'LETMEINNOW123', 'jTemplateID': 0,
    'optParams': {'printBackground': 'true', 'lowRes': true},
    'token': ''
  };


  assetPreviewUrl = this.imageUrl + '/previewService/get/assetpreview';
  activeTab = 'design-brief';  // initially active tab

  selectedOption: any = {};
  selectedOptionDropDown: any = {};
  selectedOptionList: any = [];
  specDetails: any;
  specModelLoader = false;
  totalCount: number;
  jobBagItemOptionsTemplate: any = {
    'product_option_id': 0,
    'product_option_value_id': 0,
    'product_option_price_prefix': '+',
    'product_option_price': 0
  };
  jobBagItemTemplate: any = {
    'type': '', 'itemID': 0, 'itemCode': '', 'name': '', 'qtys': [],
    'specifications': '', 'files': [], 'templateID': 0, 'jTemplateID': 0, 'thumbnail': '', 'jobBagItemOptions': []
  };
  CurrentJobBagTemplate: any = {
    'jobBagID': '', 'uid': '', 'name': '', 'clientID': '', 'crBy': '', 'crDate': '',
    'modBy': '', 'modDate': '', 'campaignID': '', 'lastEdited': '', 'items': []
  };
  searchString: any = '';
  filterMap: any = {'search': this.searchString ? this.searchString : ''};
  featuredProducts: any = [];
  currentProductDetail: any = {};

  currentJobBagItem: any;
  JOBBAG_ITEM_COMMERCE: any = 'commerce';
  JOBBAG_ITEM_SPECTYPE: any = 'specType';
  JOBBAG_ITEM_SPECTEMPLATE: any = 'specTemplate';
  JOBBAG_ADWORKS: any = 'adworks';
  CurrentJobBag: any = [];
  restUploadUrl: string;
  restUserCreate: any;
  status403Counter: number;
  jobbagServiceUrl: any = 'jobbagService/v1';
  jobbagUrl: any = '/jobbag';
  jobbagItemUrl = '/item';
  jobbagPersonaliseItemUrl = '/personalise';
  downloadPDFArtworkURL = '//FileService/downloadPDFArtwork';
  SPEC_Ergo_Retail_Display: any = 'Ergo Retail Display';
  SPEC_Design: any = 'Design';
  SPEC_Print_Product: any = 'Print Product';
  SPEC_Custom_Goods_and_Services: 'Custom Goods and Services';
  selectedOptionTemp: any;
  desingBrief: any;
  nooshSpecTypes: any = [];
  designBrief: any = {};
  printProductBrief: any = {};
  retailDisplayBrief: any = {};
  META_Project: any = 'Project';
  META_Campaign: any = 'Campaign';
  META_DesignSpec: any = 'DesignSpec';
  META_RetailSpec: any = 'RetailSpec';
  META_JobStage: any = 'JobStage';
  META_PrintProductSpec: any = 'PrintProductSpec';
  META_CGSSpec: any = 'CGSSpec';
  META_ProductRequest: any = 'product_request';
  META_PhotographyRequest: any = 'Photography_request';
  currentURL = window.location.hostname == 'localhost' ? 'http://' + window.location.hostname + ':8080' : 'http://' + window.location.hostname;
  AdworksLiteURL: any;
  totalCartItems: number;
  displayMessage: string;
  totalCartAmount: number;
  totalCartItemAmount: number;
  templateBrief: any = {};
  nooshProdTypes: any = [];
  checkoutCampaign: any = {metaList: []};
  checkoutInProgress: boolean = false;
  nooshItemInJobBag: boolean;
  categories: any = [];
  recentBriefs: any = [];
  recentBriefsSearch: any = '';
  searchingSpecs: boolean = false;
  noMoreAssets = true;
  isAssetsSearched = false;
  assetSearchLoading = false;
  assetLisItems = [];
  assetSearchIn = '';
  commerceItemInJobBag = false;
  NOOSH_COMPANY_NAME = 'PMU';
  listPage = {
    rows: [],
    page: 0,
    pageSize: 20,
    totalSize: 0,
    sort: '',
    dir: 'down',
    search: '',
    uid: 0,
    catalogue: ''
  };

  public templateBaseUrl = 'http://54.206.16.72/rest_v2/OrderService';
  copyJobResponse;
  projectAssetFiles: any;
  data: { shipmentData: any; specDetails: any; specData: any; };
  selectPriceArray: any = [];
  count = 0;
  imagePreview: any = '';
  itemList: any;
  pageDetails: any;
  imageDescription: any;
  shortByValue: any[];
  fetchSize = this.constants.pageValue[0];
  sortDetails: any;
  pageValue: any;
  allItems: any = {};
  productQuantity: any;
  qty: any;
  searchFields: any;
  public hiddenCatalogePage: boolean = true;
  guideStatus: any;
  sortName: any;
  helpGuideStatus: boolean = false;
  heinekenCssFlag: boolean = false;
  dmhCssFlag: boolean = false;
    isCCEP_Env = false;
  constructor(inj: Injector, public titleService: Title, public changeDetector: ChangeDetectorRef,
              public decimalPipe: DecimalPipe, public onlineOrderingService: OnlineOrderingService,
              private onlineOrderingCustomizationService : OnlineOrderingCustomizationService,
              private onlineOrderingPreviewService:OnlineOrderingPreviewService,
              private onlineOrderingShippingService : OnlineOrderingShippingService) {
    super(inj);
    this.style1 = this.sanitizer.bypassSecurityTrustResourceUrl('assets/css/ordeing-style.css');
  }


  ngOnInit() {

    if (environment.envnName === this.constants.enviromentValues.heineken) {
      this.shortByValue = this.constants.shortByValueHnkCataloge;
      this.sortName = this.constants.shortByValueHnkCataloge[0];
      this.checkCatalogeHideStatus();
      this.userDetails = JSON.parse(this.getToken('userDetail'));
      this.heinekenCssFlag = true;
    } else if (environment.envnName === this.constants.enviromentValues.DMH) {
      this.shortByValue = this.constants.shortByValueDmhCataloge;
      this.sortName = this.constants.shortByValueDmhCataloge[0];
      this.checkCatalogeHideStatus();
      this.dmhCssFlag = true;
    } else if (environment.envnName === this.constants.enviromentValues.cokeMain) {
        this.isCCEP_Env = true;
      this.shortByValue = this.constants.shortByValueDmhCataloge;
      this.sortName = this.constants.shortByValueDmhCataloge[0];
      this.checkCatalogeHideStatus();

    }
    this.pageValue = this.constants.pageValue;
    this.designBrief.files = [];
    this.printProductBrief.files = [];
    this.retailDisplayBrief.files = [];
    this.restUploadUrl = '';
    this.getUserdetail();
    this.getProductQuantity();
    let item = this.getToken('ItemId');
    if (item) {
      this.removeToken('ItemId');
    }
    let event = {
      event_id: this.constants.CATALOG_VIEW.event_id,
      event_desc: this.constants.CATALOG_VIEW.event_desc
    };
    this.logService.createLog(event);

  }

  getAllCategories(hiddenCatalogePage) {
    this.hiddenCatalogePage = hiddenCatalogePage;
    this.onlineOrderingService.getAllCategories().subscribe((categoryList: any) => {
      if (categoryList) {
        this.categories = categoryList;
        this.categories.sort((a, b) => a.sort_order - b.sort_order);
        if (environment.envnName === this.constants.enviromentValues.heineken) {
          this.allItems = this.categories.filter(data => data.name === 'All Products')[0];
          this.categories = this.categories.filter(data => data.name !== 'All Products');
          if (this.allItems) {
            this.helpGuideStatus = true;
            this.getCategoryProducts(this.allItems.category_id, 'All Products',);

          }
        } else if (environment.envnName === this.constants.enviromentValues.DMH) {
          this.allItems = this.categories.filter(data => data.name === 'All Items')[0];
          this.categories = this.categories.filter(data => data.name !== 'All Items');
          if (this.allItems) {
            this.helpGuideStatus = true;
            this.getCategoryProducts(this.allItems.category_id, 'All Items',);
          }
        } else if (environment.envnName === this.constants.enviromentValues.cokeMain) {
          this.allItems = this.categories.filter(data => data.name === 'All Items')[0];
          this.categories = this.categories.filter(data => data.name !== 'All Items');
          if (this.allItems) {
            this.helpGuideStatus = true;
            this.getCategoryProducts(this.allItems.category_id, 'All Items',);
          }
        }


      }
    });
  }


  checkCatalogeHideStatus() {
    this.onlineOrderingService.checkCatalogeHideStatus().subscribe((res: any) => {
      if (res) {
        this.statusId = res.instance;
        if (res.instance === 0) {
          this.hiddenCatalogePage = false;
          this.getAllCategories(false);
        } else {
          this.hiddenCatalogePage = true;
          this.getAllCategories(true);
        }
      }
    });
  }

  proceedToCatalog() {
    this.hiddenCatalogePage = true;
  }

  hideCatalogeGuide() {
    if (this.statusId === 1) {
      this.guideStatus = 0;
    } else {
      this.guideStatus = 1;
    }
    this.onlineOrderingService.hideCatalogeGuide(this.guideStatus).subscribe((res: any) => {
      if (res) {
        this.checkCatalogeAndAssign();
        this.proceedToCatalog();
      }
    });
  }

  checkCatalogeAndAssign() {
    this.onlineOrderingService.checkCatalogeHideStatus().subscribe((res: any) => {
      if (res) {
        this.statusId = res.instance;
      }
    });
  }

  ngAfterViewInit() {
    // Mobile search filter
    jQuery('.search-filter .filter').click((e) => {
      e.preventDefault();
      jQuery('.search-filter .categories').toggleClass('active');
    });


    // Normal Modal
    jQuery('.popup-gallery').magnificPopup({
      delegate: 'a.popup-link',
      type: 'image',
      tLoading: 'Loading image #%curr%...',
      mainClass: 'mfp-img-mobile',
      gallery: {
        enabled: true,
        navigateByImgClick: true,
        preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
      },
      image: {
        tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
      }
    });

    // Gallery Popup
    jQuery('.popup-gallery').magnificPopup({
      delegate: 'a.popup-link',
      type: 'image',
      tLoading: 'Loading image #%curr%...',
      mainClass: 'mobile-gallery-modal',
      gallery: {
        enabled: true,
        navigateByImgClick: true,
        preload: [0, 1] // Will preload 0 - before current, and 1 after the current image
      },
      image: {
        tError: '<a href="%url%">The image #%curr%</a> could not be loaded.'
      }
    });

    // Customization
    jQuery('#exclude_contact').click((e) => {
      jQuery('#customization .choose').toggle();
      jQuery('#customization .branding').toggle();
    });
  }

  // it will get user details
  // method : GET
  // params : TRUE
  // data : user Details
  // localStorage  : userDetails
  //todo : need to change hard code user id

  getUserdetail() {
    this.onlineOrderingService.getUserDetails().subscribe((res: any) => {
      if (res.statusCode === 200) {
        let userDetail = JSON.stringify(res.instance);
        this.setToken('userDetail', userDetail);
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
      }
    });
  }

  // it will get Product Quantity
  // method : GET
  // params : TRUE
  // data : Product Quantity

  getProductQuantity() {
    this.onlineOrderingService.getProductQuantity().subscribe((res: any) => {
      if (res) {
        console.log("res------", res);
        this.productQuantity = res;
      }
    });
  }

  addEventLogs() {
    let event = {
      event_id: this.constants.REODER_COLLETREL.event_id,
      event_desc: this.constants.REODER_COLLETREL.event_desc,
    };
    this.logService.createLog(event);
    this.router.navigate(['/account']);
  }

  // Open Category details in fancy box

  openPreview(imagePreview) {
    let event = {
      event_id: this.constants.PRODUCT_MORE_INFO.event_id,
      event_desc: this.constants.PRODUCT_MORE_INFO.event_desc,
      productId: imagePreview.product_id,
      categoryId: this.productsPageFilter.categoryID,
      model: imagePreview.model

    };
    this.logService.createLog(event);
    if (environment.envnName === this.constants.enviromentValues.heineken) {
      this.router.navigate(['onlineOrdering/select-preview/' + imagePreview.product_id]);
    } else if (environment.envnName === this.constants.enviromentValues.DMH) {
      let imageExist = this.getFileExtension(imagePreview.image);
      if (!imageExist) {
        this.imagePreview = 'assets/images/default-228x228.jpg'; // imagePreview.image;
      } else {
        this.imagePreview = imagePreview.image;
      }
      this.imageDescription = imagePreview;
      this.$('#commonModal').modal('show');
    }
  }

  closePopup() {
    this.$('#commonModal').modal('hide');
  }

  getFileExtension(file) {
    var regexp = /\.([0-9a-z]+)(?:[\?#]|$)/i;
    var extension = file.match(regexp);
    return extension && extension[1];
  }

// todo: need to change hard code template id
  pdfPreview(ProductDetail) {
    this.activatedIndex = 0;
    if (environment.envnName === this.constants.enviromentValues.heineken) {
      this.productsResponese = ProductDetail.product.custom_fields.en;
      this.pdfUrl = this.productsResponese.filter(data => data.name === 'PDF URL')[0];
      if (this.pdfUrl != null) {
        window.open(this.pdfUrl.text);
      } else {
        this.translate.get('PdfNotFound').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      }
    } else if (environment.envnName === this.constants.enviromentValues.DMH || environment.envnName === this.constants.enviromentValues.cokeMain) {
      if (ProductDetail.product.templates.length != 0) {
        let tempId = ProductDetail.product.templates[0].template_id;
        this.onlineOrderingService.getPdfPreviewDetails(tempId).subscribe((res: any) => {
          if (res) {
            if (res.highResS3 != null) {
              window.open(res.highResS3);
            } else {
              this.translate.get('PdfNotFound').subscribe((res: string) => {
                this.errorMessage = res;
              });
              this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
            }
          } else {
            this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
          }
        });
      } else {
        // Customization Not Available
        this.translate.get('CustomizationNotAvailable').subscribe((res: string) => {
          this.errorMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
      }
    }

  }

  //show backword and forword cart details on popUp


  showItemDetails(index, directions) {
    if (this.itemList.length == this.activatedIndex + 1 && directions == 'next') {
      return false;
    }
    if (this.activatedIndex == 0 && directions == 'prev') {
      return false;
    }
    directions == 'next' ? this.activatedIndex++ : this.activatedIndex--;
  }

// it will get product details
  // method : GET
  // params : TRUE
  // data : item
  // localStorage  : qty

  getProductDetails(ProductDetail, qtyValue) {
    var productID = '0';
    if (ProductDetail.product) {
      productID = JSON.stringify(ProductDetail.product.product_id);
    } else {
      productID = ProductDetail.itemCode;
    }
    this.onlineOrderingService.getProductDetails(productID).subscribe((res: any) => {
      if (res) {
        if (res.templates.length != 0) {
          this.setToken('templateId', res.templates[0].template_id);
          this.router.navigate(['onlineOrdering/customization/' + ProductDetail.product.product_id]);
          this.setToken('qty', qtyValue);
          this.stepArray.push(1);
          this.setToken('stepCount', this.stepArray);
        } else {
          this.translate.get('CustomizationNotAvailable').subscribe((res: string) => {
            this.errorMessage = res;
          });
          this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
        }
      }
    });
  }


  // it will get single product details
  // method : GET
  // params : TRUE
  // data : item

  viewProductDetail(ProductDetail) {
    var productID = '0';
    if (ProductDetail.product) {
      productID = JSON.stringify(ProductDetail.product.product_id);
    } else {
      productID = ProductDetail.itemCode;
    }
    this.onlineOrderingService.getProductDetails(productID).subscribe((res: any) => {
      if (res) {
        var item = {'name': res.name, 'type': this.constants.PRODUCT_DETAILS_TYPE, 'product': res};
        this.currentProductDetail = item;
        this.currentProductDetail.prodQuantity = 1;
        if (this.currentProductDetail.template != null) {
          this.currentProductDetail.template = this.currentProductDetail.product.templates[1];
        }
        this.onlineOrderingService.isViewProductDetail = true;
        this.onlineOrderingService.isViewCart = false;
      }
    });
  }

  // it will get category product details
  // method : GET

  getCategoryProducts(commerceCategoryID, activename, guideValue?) {
    if (guideValue) {
      this.hiddenCatalogePage = guideValue;
    }
    this.currentState = activename;
    this.initOrAddNode();
    this.productsPageFilter.page = 1;
    this.recursiveFilter(this.categories, commerceCategoryID);
    this.onlineOrderingService.isViewCart = false;
    this.onlineOrderingService.isViewProductDetail = false;
    this.onlineOrderingService.isCustomizeCart = false;
    if (commerceCategoryID === 0) {
      this.isProductListView = false;
      this.isProductDetailView = false;
      this.isCategoryView = true;
    } else {
      //getCartProduct();     // TODO don't think we need to get cart details from commerce since jobbag is replacing cart

      this.productsPage.categoryID = commerceCategoryID;
      this.productsPageFilter.categoryID = commerceCategoryID;
      let event = {
        event_id: this.constants.CATEGORY_VIEW.event_id,
        event_desc: this.constants.CATEGORY_VIEW.event_desc,
        categoryId: this.productsPageFilter.categoryID
      };
      this.logService.createLog(event);
      this.loadMoreOnlineProducts(true);
    }
  };

  initOrAddNode(node?) {
    var flag = true;

    if (node) {
      if (node.id === -1) {
        this.translate.get('Home').subscribe(res => {
          this.breadcrumbs = [{'id': 0, 'displayName': res}];
        });
      }
      this.breadcrumbs.forEach((val, key) => {
        if (val.id === node.id) {
          flag = false;
          return;
        }
      });
      if (flag) {
        this.breadcrumbs.push(node);
      }

    } else {
      this.translate.get('Home').subscribe(res => {
        this.breadcrumbs = [{'id': 0, 'displayName': res}];
      });

    }
  }

  recursiveFilter(items, categoryId) {
    items.forEach((item) => {
      if (item.category_id === categoryId) {
        this.recursiveFilter(this.categories, item.parent_id);
        this.initOrAddNode({'id': item.category_id, 'displayName': item.name});
      }
      if (item.categories && item.categories.length > 0) {
        this.recursiveFilter(item.categories, categoryId);
      }
    });
  };

  next() {
    this.productsPageFilter.page = this.productsPageFilter.page + 1;
    this.loadMoreOnlineProducts();
  }

  prev() {
    this.productsPageFilter.page = this.productsPageFilter.page - 1;
    this.loadMoreOnlineProducts();
  }

  sortBy(data, key) {
    console.log('data', data);
    this.sortDetails = data;
    if (key == 'sortby') {
      this.productsPageFilter.dir = data.dir;
      this.productsPageFilter.order = data.order;
    }
    if (key == 'show') {
      this.productsPageFilter.fetchSize = data.size;
    }
    setTimeout(() => {
      this.loadMoreOnlineProducts();
    }, 300);

  }

  searchProduct(searchString) {
    this.productsPageFilter.page = 1;
    this.productsPageFilter.searchText = searchString;
    let event = {
      event_id: this.constants.SEARCH.event_id,
      event_desc: this.constants.SEARCH.event_desc,
      categoryId: this.productsPageFilter.categoryID,
      attributes: this.productsPageFilter.searchText
    };
    this.logService.createLog(event);
    this.loadMoreOnlineProducts();
  }

  // scrolling needs to invoke new page loading
  loadMoreOnlineProducts(startFresh?) {
    this.isLoaded = true;
    if (startFresh) {
      this.products = [];
      this.productsPageFilter.page = 1;
    }

    this.onlineOrderingService.loadMoreOnlineProduct(this.productsPageFilter).subscribe((productsPage: any) => {
      if (productsPage) {
        this.productsPage = productsPage;
        this.products = productsPage.rows;
        this.totalCount = Math.ceil(productsPage.totalSize / productsPage.pageSize);
        this.isCategoryView = false;
        this.isProductDetailView = false;
        this.isProductListView = true;
        this.isSpecBreifView = false;
        this.isSpecTemplateView = false;
        this.isLoaded = false;
        if (productsPage.rows && productsPage.rows.length > 0) {

          for (var i = 0; i < productsPage.rows.length; i++) {
            var onlineProduct = productsPage.rows[i];
            if (onlineProduct.type === 'specTemplate') {
              var specTemplateCode = '';
              if (onlineProduct.product.custom_fields != null) {
                if (onlineProduct.product.custom_fields.spec != null) {
                  for (var m = 0; m < onlineProduct.product.custom_fields.spec.length; m++) {
                    if (onlineProduct.product.custom_fields.spec[m].param_name == 'SPEC_TEMPLATE_CODE_STR') {
                      specTemplateCode = onlineProduct.product.custom_fields.spec[m].string_value;
                      break;
                    }
                  }
                }
              }
              onlineProduct.product.image = this.specTemplateIconUrl + '?fileName=' + specTemplateCode;
            }
          }
          if(onlineProduct.product.discounts.length > 0 && onlineProduct.product.discounts[0].tiers.length > 0 ){
            for (var i = 0; i < this.products.length; i++) {
              this.products[i].qty = onlineProduct.product.discounts[0].tiers[0].quantity;
            }
          }


          //buildMasonry();
          // this.productsPage.page = this.productsPage.page + 1;
        } else {
          this.noMoreOnlineProducts = true;
          this.productsPage.currentPage = this.productsPage.totalPages;
        }
        this.isLoaded = false;
      }
    });
    this.noMoreOnlineProducts = false;
  }


  // -------------end-------------
  checkSubCategories(categories, id) {
    if (JSON.stringify(categories).includes(id)) {
      return true;
    }
    return false;
  }

    // redirect to ccep module

  // ----------------------------------------------------- CCEP -----------------------------------------------
  // -----------------------------------------------------------------------------------------------------------
  // -----------------------------------------------------------------------------------------------------------

    public ccepProductData;
    public ccepModel;
    public ccepProductDetails;
    public ccepItemList;
    public ccepqty
    public ccepqtyarray;
    public ccepObj :any = {};
    public ccepmatchExistingItemId;
    public ccepSelectedButton;
    customCCEPTemplate(onlineProduct: any,qty,option): void {
      this.ccepSelectedButton = option;
      if(option === 'add'){
          this.getAddToCartProductDetails(onlineProduct,qty);
      }else if (option === 'create'){
          this.getCokeProductDetails(onlineProduct,qty);
      }
      this.getExisitingJobBag();
      this.ccepProductData = onlineProduct;
    }

    getAddToCartProductDetails(ProductDetail,qtyValue){
        var productID = '0';
        if (ProductDetail.product) {
            productID = JSON.stringify(ProductDetail.product.product_id);
        } else {
            productID = ProductDetail.itemCode;
        }
        this.onlineOrderingService.getProductDetails(productID).subscribe((res: any) => {
            if (res) {
                var item = {"name": res.name, "type": this.constants.PRODUCT_DETAILS_TYPE, "product": res};
                this.ccepProductDetails = res;
                this.ccepProductData = item;
                this.ccepModel = res.model
                this.setToken('qty', qtyValue);
                this.stepArray.push(1);
                this.setToken('stepCount', this.stepArray);
                this.addToCart();
            }
        })
    }
  // it will get product details
  // method : GET
  // params : TRUE
  // data : item
  // localStorage  : qty
  getCokeProductDetails(ProductDetail, qtyValue) {
    var productID = '0';
    if (ProductDetail.product) {
      productID = JSON.stringify(ProductDetail.product.product_id);
    } else {
      productID = ProductDetail.itemCode;
    }
    this.onlineOrderingService.getProductDetails(productID).subscribe((res: any) => {
      if (res) {
        if (res.templates.length != 0) {
          this.setToken('templateId', res.templates[0].template_id);
          var item = {"name": res.name, "type": this.constants.PRODUCT_DETAILS_TYPE, "product": res};
          this.ccepProductDetails = res;
          this.ccepProductData = item;
          this.ccepModel = res.model
          this.setToken('qty', qtyValue);
          this.stepArray.push(1);
          this.setToken('stepCount', this.stepArray);
          this.createTemplateStampforCoke(ProductDetail)
        } else {
          this.translate.get('CustomizationNotAvailable').subscribe((res: string) => {
            this.errorMessage = res;
          });
          this.commonService.displayToaster(this.constants.TOAST_ERROR, this.errorMessage);
        }
      }
    });
  }


    createTemplateStampforCoke(onlineProduct) {
        let templateId = this.getToken('templateId');
        this.ccepObj.templateId = templateId;
        this.onlineOrderingCustomizationService.createJobTemplateStamp(templateId).subscribe((res: any) => {
            if (res) {
                this.ccepObj.jtemplateID = res.jtemplateID;
                this.getCartPreview();

                if (this.ccepSelectedButton === 'create') {
                    this.router.navigate(['/customiseMenu'], {
                        queryParams: {
                            categoryId: this.ccepProductData.product.categoryId || 0,
                            jTemplateId: this.ccepObj.jtemplateID || 0,
                            productCategoryID: this.ccepProductData.product.productCategoryId || 0,
                            baseTemplateId: this.ccepProductData.product.templates[0].template_id || 0,
                            productID: this.ccepProductData.product.product_id || 0,
                            token: this.getToken('accessToken')
                        }
                    });
                    console.log(this.customization);
                    if (res.statusCode === 200) {
                    } else {
                        this.commonService.displayToaster('error', res.message);
                    }
                }
            }
        }, () => { // Temp changes once all templates migrated please remove this code
            if (this.ccepSelectedButton === 'create') {
                this.router.navigate(['/customiseMenu'], {
                    queryParams: {
                        categoryId: this.ccepProductData.product.categoryId || 0,
                        jTemplateId: this.ccepObj.jtemplateID || 23552,
                        productCategoryID: this.ccepProductData.product.productCategoryId || 0,
                        baseTemplateId: this.ccepProductData.product.templates[0].template_id || 0,
                        productID: this.ccepProductData.product.product_id || 0,
                        token: this.getToken('accessToken')
                    }
                });
            }
        });
    }

  // Add to Job bag(if job bag already exist then only get otherwise add to new job bag)
  addToCart(){
    this.onlineOrderingPreviewService.checkJobBag().subscribe((res:any) =>{
      if (res.instance) {
        this.ccepObj.jobBagId = res.instance.jobBagID;
        this.ccepObj.CurrentJobBag = res.instance;
        this.insertJobBag();
      } else {
        this.onlineOrderingPreviewService.addToCart().subscribe((res:any) =>{
          this.ccepObj.jobBagId = res.instance.jobBagID;
          this.ccepObj.CurrentJobBag = res.instance;
          this.insertJobBag();
        })
      }
    })
  }

  // it will get all cart preview
  // method : GET
  // params : TRUE
  // data : item List

  getCartPreview() {
    this.onlineOrderingPreviewService.getCartPreview(this.ccepObj.jtemplateID).subscribe((res:any) =>{
      if (res) {
        this.ccepObj.pdfResponse = res.lowResS3;
        this.ccepObj.highPdfResponse = res.highResS3;
        this.ccepItemList = JSON.parse(res.pagePreviews);
        this.addToCart();
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.message);
      }
    })
  }

  public ccepItemData;
  public ccepCurrentJobBag;
  getExisitingJobBag(){
    this.onlineOrderingShippingService.getJobBag().subscribe((res :any) => {
      if(res.instance){
        this.cartJobBag = res.instance;
        this.ccepObj.jobBagID = res.instance.jobBagID;
        this.ccepItemData = res.instance.items;
        console.log(this.jobBagID);
      }
    })
  }

  // insert item in job bag based on job bag object
  // method : POST

  insertJobBag(){
    this.ccepqtyarray = [];
    this.ccepqty = JSON.parse(this.getToken('qty'))
    this.ccepqtyarray.push(this.ccepqty)
    let data = {
      token: this.getToken('accessToken')
    }
    let jobBagItem = {
      "jobBagItem": {
        "type": this.ccepProductData.type,
        "itemID": 0,
        "itemCode": this.ccepProductData.product.product_id,
        "name": this.ccepProductData.name,
        "qtys": this.ccepqtyarray,
        "model":this.ccepModel,
        "specifications": "",
        "files": [],
        "assets": [],
        "templateID": 0,
        "jTemplateID": this.ccepObj.jtemplateID ? parseInt(this.ccepObj.jtemplateID) : 0,
        "thumbnail": this.ccepItemList ? (this.ccepItemList[0].s3Path ? this.ccepItemList[0].s3Path : '') : '',
        "pdfPreview": this.ccepObj.pdfResponse ? this.ccepObj.pdfResponse : '',
        "highResPdfUrl":this.ccepObj.highPdfResponse ? this.ccepObj.highPdfResponse : '',
        "productTypeID": "0",
        "price": this.ccepProductData.product.price,
        "discounts" : this.ccepProductDetails.discounts ? this.ccepProductDetails.discounts : [],
        "jobBagItemOptions": [],
        "template": {},
        "metadata": []
      }
    }
    let item =this.getToken('ItemId')
    if(item) {
      this.ccepItemData.map(res => {
        if (res.itemID === Number(item)) {
          this.ccepmatchExistingItemId = true;
        }
      })
    }
    let successMessage
    if(this.ccepmatchExistingItemId){
      this.setStorageValues();
      this.translate.get('CartItemUpdatedSuccessfully').subscribe((res: string) => {
        successMessage = res;
      });
      this.commonService.displayToaster(this.constants.TOAST_SUCCESS, successMessage);
    } else {
      let userDetail = JSON.parse(this.getToken('userDetail'))
      this.onlineOrderingPreviewService.insertCartToJobBag(this.ccepObj.jobBagId, userDetail.defaultClientID, jobBagItem, data.token).subscribe((res: any) => {
        this.ccepCurrentJobBag = res.instance;
        this.setStorageValues();
        this.translate.get('ItemAddedToCartSuccessfully').subscribe((res: string) => {
          successMessage = res;
        });
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, successMessage);
      })
    }
  }

  setStorageValues(){
    this.onlineOrderingPreviewService.setCartTotal('');
    this.setToken("stepCount", this.stepArray);
  }

}

