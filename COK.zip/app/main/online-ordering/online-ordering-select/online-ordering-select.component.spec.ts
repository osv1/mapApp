import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingSelectComponent } from './online-ordering-select.component';

describe('OnlineOrderingSelectComponent', () => {
  let component: OnlineOrderingSelectComponent;
  let fixture: ComponentFixture<OnlineOrderingSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
