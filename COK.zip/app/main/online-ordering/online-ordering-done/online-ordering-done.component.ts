import { Component, OnInit,Injector } from '@angular/core';
import {BaseComponent} from "../../../common/commonComponent";
import {OnlineOrderingDoneService} from "./online-ordering-done.service";
import {LoginService} from "../../../public/login/login.service";

@Component({
  selector: 'app-online-ordering-done',
  templateUrl: './online-ordering-done.component.html',
  styleUrls: ['./online-ordering-done.component.css']
})
export class OnlineOrderingDoneComponent extends BaseComponent implements OnInit {

  public jobBagId;
  public orderReceived :any = {};
  public cartSummaryArray = [];
  constructor(inj: Injector,private onlineOrderingDoneService : OnlineOrderingDoneService,private loginService:LoginService) {
    super(inj);
    this.jobBagId = this.activatedRoute.snapshot.params['id'];

  }

  ngOnInit() {
    this.getOrderReceivedDetails();
  }

  getOrderReceivedDetails(){
    this.onlineOrderingDoneService.getJobBag(this.jobBagId).subscribe((res :any) => {
      this.orderReceived = res.instance;
      console.log("this.orderReceived",this.orderReceived);
      var array =  this.orderReceived.orderDate.split(".");
      this.orderReceived.orderDate = array[1]+'/'+array[2]+'/'+array[0];
      this.cartSummaryArray = res.instance.items;
      this.checkJobBag();
    })
  }
  checkJobBag(){
    this.loginService.checkJobBag().subscribe((res:any) =>{
      if (res.instance) {
      } else {
        this.loginService.createNewJobBag().subscribe((res:any) =>{
        })
      }
    })
  }
  fixDecimals(value: number) {
    value = Math.ceil(value)
    return value;
  }

}
