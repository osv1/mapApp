import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnlineOrderingDoneComponent } from './online-ordering-done.component';

describe('OnlineOrderingDoneComponent', () => {
  let component: OnlineOrderingDoneComponent;
  let fixture: ComponentFixture<OnlineOrderingDoneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnlineOrderingDoneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnlineOrderingDoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
