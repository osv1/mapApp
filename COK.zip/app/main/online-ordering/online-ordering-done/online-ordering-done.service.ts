import {Injectable} from '@angular/core';
import {CommonService} from '../../../common/common.service';
import {from, Observable, Subject} from "rxjs";

@Injectable()
export class OnlineOrderingDoneService {


  private subject = new Subject<any>();


  constructor(private commonService: CommonService) {
  }

  getJobBag(jobBagId): Observable<any> {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag/'+jobBagId, '', 'get', true));
    return observable;
  }

  checkout(data,jobbagId){
    const observable = from(this.commonService.callApi('commerceService/v1/checkout/'+jobbagId, data, 'post', true));
    return observable;
  }

}
