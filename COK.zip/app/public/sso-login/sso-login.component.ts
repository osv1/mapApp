import { Component, OnInit,Injector } from '@angular/core';
import {BaseComponent} from "../../common/commonComponent";
import { LoginService } from '../login/login.service';
@Component({
  selector: 'app-sso-login',
  templateUrl: './sso-login.component.html',
  styleUrls: ['./sso-login.component.css']
})
export class SsoLoginComponent extends BaseComponent implements OnInit {


  ssoToken;
  showSsoError : boolean;
  constructor(inj: Injector,private loginService: LoginService) {
    super(inj);
    this.ssoToken = this.activatedRoute.snapshot.params['params'];
  }

  ngOnInit() {

    this.showSsoError = false;
    this.ssoToken = atob(this.ssoToken);
    this.getUserDetails(this.ssoToken);
  }


  getParamValue(name, url) {
    //if (!url) return false;
    url="&"+url;
    name = name.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
    var regexS = "[\\?|&]"+name+"=([^&#]*)";//(\?|&)parameterName\=([^&]*)/
    var regex = new RegExp(regexS);
    var results = regex.exec(url);
    return results == null ? '' : results[1];
  }


  getUserDetails(ssoToken){
    this.loginService.getUserDetails(ssoToken).subscribe((res : any) => {
      if(res.statusCode === 200 && res.instance){
        let userDetail = JSON.stringify(res.instance);
        let event = {
          event_id : this.constants.USER_LOGIN.event_id,
          event_desc : this.constants.USER_LOGIN.event_desc
        }
        this.logService.createLog(event);
        let token = this.getParamValue('token',this.ssoToken)
        this.setToken('accessToken',token);
        this.setToken("userDetail", userDetail);
        this.getSsoLoginDetails(res.instance.userID)
        this.router.navigate(['/homepage']);
      } else {
        this.showSsoError = true;
      }
    } , error => {
      this.showSsoError = true;
      this.commonService.displayToaster(this.constants.TOAST_ERROR, this.constants.SomethingWentWrong);
    })
  }

  getSsoLoginDetails(userId){
    this.loginService.getSsoUserDetails(userId).subscribe((res:any) => {
      console.log(res.instance.RoleName.split(','));
      let roles = [];
      roles = res.instance.RoleName.split(',')
      roles.map(adminRole => {
        if(adminRole ===  'Admin'){
          console.log('Admin')
          this.setToken("isSsoAdmin", 'true');
        }
      })
    })
  }

}
