// This service is used for interaction between all Asset Tile components

import {Injectable} from '@angular/core';
import {from, Observable, Subject} from "rxjs";
import {CommonService} from "../../common/common.service";

@Injectable()
export class LoginService {


  constructor(private commonService: CommonService) {
  }

  private subject = new Subject<any>();

  setUser(message: any) {
    this.subject.next({ text: message });
  }


  getUserName(){
    return this.subject.asObservable();
  }

  login(data) {
    const observable = from(this.commonService.callApi('RegisterService/register_username', data, 'post', false,false,true));
    return observable;
  }

  checkJobBag() {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag', '', 'get', true ,false, true));
    return observable;
  }

  createNewJobBag() {
    const observable = from(this.commonService.callApi('jobbagService/v1/jobbag', '', 'post', true , false, true));
    return observable;
  }

  getUserDetails(ssoToken) {
    const observable = from(this.commonService.callApi('UserService/v1/user/?'+ssoToken, '', 'get', false, false, true));
    return observable;

  }
  getMenuItems(){
    const observable = from(this.commonService.callApi('commerceService/v1/menu/', '', 'get', true));
    return observable;
  }
  unRegister(data){
    const observable = from(this.commonService.callApi('RegisterService/unregister/', data, 'post', false , false, true));
    return observable;
  }
  getBreadcrumbData(){
    const observable = from(this.commonService.callApi('commerceService/v1/breadcrumbMenu/', '', 'get', true , false, true));
    return observable;
  }


  getSsoUserDetails(userID){
    const observable = from(this.commonService.callApi('UserService/v1/user/' + userID + '/ssodetails', '', 'get', true ));
    return observable;
  }

}

