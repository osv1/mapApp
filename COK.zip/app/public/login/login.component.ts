import {Component, OnInit, OnDestroy, Injector} from '@angular/core';
import {BaseComponent} from 'src/app/common/commonComponent';
import {Router} from '@angular/router';
import {LoginService} from "./login.service";
import {OnlineOrderingService} from '../../main/online-ordering/online-ordering-select/online-ordering.service';
import {environment} from  '../../../environments/environment';
import { UpdatePasswordComponent} from '../update-password/update-password.component';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent extends BaseComponent implements OnInit, OnDestroy {
  submitted: boolean;
  public user: any = {};
  public signupFlag = true;
  public message: any ={};
  public envn = environment.envnName;
  public passwordFromUrl;
  constructor(inj: Injector, public router: Router, public loginService: LoginService, private onlineOrderingService: OnlineOrderingService) {
    super(inj);
    this.passwordFromUrl = this.activatedRoute.snapshot.params['id'];
  }

  ngOnInit() {
    if(this.passwordFromUrl){
      this.convertComponentToDom(UpdatePasswordComponent,'updateUserPassword-modal');
    }
    this.submitted = true;


    this.$("body").css("background-image", "url(assets/images/login-background.jpg)");
    this.$("body").css("background-size", "cover");
    this.$('body').addClass('login-page');
  }

  ngOnDestroy() {
    this.$("body").css("background-image", "none");
    this.$("body").css("background-size", "cover");
    this.$('body').removeClass('login-page');
  }

  login() {
    // this:password":"goworks1!","username":"chris.florijn@indicia.com

    let data = {
      // authInput: 'klgfdgdgdg',
      // password: this.user.password,
      // "clientID": this.constants.CLIENT_ID,
      // "groupID": this.constants.GROUP_ID,
      // "portalUserID": this.constants.PORTAL_USER_ID,
      // "moduleID": this.constants.MODULE_ID,
      // "fields": this.constants.FIELDS,
      "username": this.user.authInput,
      "password": this.user.password
    }
    this.loginService.login(data).subscribe((success: any) => {
      if (success.statusCode == 200) {
        this.setToken('accessToken', success.key);
        this.getUserdetail();
        this.checkJobBag();
        let event = {
          event_id : this.constants.USER_LOGIN.event_id,
          event_desc : this.constants.USER_LOGIN.event_desc
        }
        this.logService.createLog(event);
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS, success.message);

        this.router.navigate(['/homepage']);

      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, success.message);
      }
    });
  }


  openForgottenModal(){
    this.convertComponentToDom(UpdatePasswordComponent,'updateUserPassword-modal');
    // this.$('#updateUserPassword-modal').modal('show');
  }



  // it will get user details
  // method : GET
  // params : TRUE
  // data : user Details
  // localStorage  : userDetails
  //todo : need to change hard code user id

  getUserdetail() {
    this.onlineOrderingService.getUserDetails().subscribe((res: any) => {
      if (res.statusCode === 200) {
        let userDetail = JSON.stringify(res.instance);
        this.setToken("userDetail", userDetail);
        this.loginService.setUser(userDetail);
        if(environment.envnName === this.constants.enviromentValues.DMH) {
          this.getSsoLoginDetails(res.instance.userID)
        }
      } else {
        this.commonService.displayToaster('error', res.message);
      }
    })
  }


  getSsoLoginDetails(userId){
    this.loginService.getSsoUserDetails(userId).subscribe((res:any) => {
      console.log(res.instance.RoleName.split(','));
      let roles = [];
      roles = res.instance.RoleName.split(',')
      roles.map(adminRole => {
        if(adminRole ===  'Admin'){
          console.log('Admin')
          this.setToken("isSsoAdmin", 'true');
        }
      })
    })
  }

  checkJobBag() {
    this.loginService.checkJobBag().subscribe((res: any) => {
      if (res.instance) {
      } else {
        this.loginService.createNewJobBag().subscribe((res: any) => {
        })
      }
    })
  }

}


