import { Component, OnInit,Injector } from '@angular/core';
import {BaseComponent} from './../../common/commonComponent';
import {UpdatePasswordService} from './update-password.service';
@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent extends BaseComponent implements OnInit {

  public showPwdUpdateFields = true;
  public showUserNameField = false;
  public retrieveUser : any  = {};
  public retrivePassword : any = {};
  public isPassowordEnabled;
  public submitted;
  public isLoggedIn;
  public message;
  public passwordFromUrl;
  public isInvalidUserNameError = false

  constructor(inj: Injector,private updatePasswordService : UpdatePasswordService) {
    super(inj)
    this.passwordFromUrl = this.activatedRoute.snapshot.params['id'];
  }

  ngOnInit() {

    if(this.passwordFromUrl){
      this.getUserInformation();
    }
    this.submitted = true;
    this.showUserNameField = true;
    this.showPwdUpdateFields = true;
    this.retrieveUser.username="";

    this.isLoggedIn = this.getToken('accessToken');
    if(this.isLoggedIn){
      this.showUserNameField = false;
      this.isPassowordEnabled = true;
      this.getPassword();
      // this.retrieveUser.userName = JSON.parse(JSON.stringify(this.getToken('userDetail'))).userName;
    }
  }

  getUserInformation(){
    this.updatePasswordService.getEmailPasswordResetData(this.passwordFromUrl).subscribe((res:any) => {
      if(res.statusCode === 200 && res.instance){
        this.retrieveUser.userNameFromApi = res.instance.userName;
        this.retrieveUser.uid = res.instance.uid;
        this.retrieveUser.passwordResetId  = res.instance.passwordResetId;
        this.getPassword()
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR,res.message);
      }
    })
  }

  getPassword(){
    let data = {
      clientID : 2078
    }
    this.updatePasswordService.getPasswordReq(data).subscribe((res1:any) => {
      if(res1.statusCode === 200) {
        this.retrieveUser.passwordValidMsg = res1.instance;
        // this.retrieveUser.password1 = {"passwordMinimumLength":4,"passwordMinimumUppercaseCharacter":0,"passwordMinimumLowercaseCharacter":0,"passwordMinimumDigit":0,"passwordMinimumSymbol":0,"prevPasswordsReuseLimitation":5}
      }else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR,res1.messsage);
      }
    })
  }



  changePassword(){
    let data = {
      uid :this.retrieveUser.uid,
      clientID : 2078,
      pwdUpdateId:this.retrieveUser.passwordResetId,
      password : this.retrivePassword.newPassword
    }
    this.updatePasswordService.changePassword(data).subscribe((res : any) => {
      if(res.statusCode === 200){
        this.commonService.displayToaster(this.constants.TOAST_SUCCESS,res.message);
        this.closeModel();
      } else {
        if(res.instance && res.instance.newPasswordFailedReason) {
          this.retrieveUser.errorMessage = [];
          this.retrieveUser.errorMessage = res.instance.newPasswordFailedReason;
        }
        this.commonService.displayToaster(this.constants.TOAST_ERROR,res.message)
      }
    })
  }

  validateUserName(){
    // this.retrieveUser.password1 = {"passwordMinimumLength":4,"passwordMinimumUppercaseCharacter":0,"passwordMinimumLowercaseCharacter":0,"passwordMinimumDigit":0,"passwordMinimumSymbol":0,"prevPasswordsReuseLimitation":5}

    // this.isInvalidUserNameError = false;
    // this.isPassowordEnabled = true;
    if(this.retrieveUser.userNameFromApi === this.retrieveUser.userName) {
      this.isInvalidUserNameError = false;
      this.isPassowordEnabled = true;
    } else {
      this.isInvalidUserNameError = true;
    }
  }

  retriveEmail(userName){
    console.log(userName);
    this.updatePasswordService.retriveUsername(userName).subscribe((res :any) => {
      if(res.statusCode === 200){
        // this.isPassowordEnabled = true;
        this.message = res.message;
      } else {
        this.commonService.displayToaster(this.constants.TOAST_ERROR, res.instance)
      }
    })
  }

}
