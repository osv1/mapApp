import {Injectable} from '@angular/core';
import {from, Observable, Subject} from "rxjs";
import {CommonService} from "../../common/common.service";

@Injectable()
export class UpdatePasswordService {


  constructor(private commonService: CommonService) {
  }

  retriveUsername(email){
    let serverUrlDetail = window.location.href;
    let data = {
      email : email,
      serverUrlDetail:serverUrlDetail
    }
    const observable = from(this.commonService.callApi('UserService/v1/retrievePassword', data, 'post', false,false,true));
    return observable;
  }

  getEmailPasswordResetData(params){
    let data = {
      pwdUpdateId : params,
    }
    const observable = from(this.commonService.callApi('UserService/v1/getEmailPasswordResetData', data, 'post', false,false,true));
    return observable;
  }

  getPasswordReq(data){
    const observable = from(this.commonService.callApi('UserService/v1/getPasswordComplexityRequirements', data, 'post', false,false,true));
    return observable;
  }

  changePassword(data){
    const observable = from(this.commonService.callApi('UserService/v1/changePwdForRetrievePwdByEmail', data, 'post', false,false,true));
    return observable;
  }
}

