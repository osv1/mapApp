import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HnkSsoLoginComponent } from './hnk-sso-login.component';

describe('HnkSsoLoginComponent', () => {
  let component: HnkSsoLoginComponent;
  let fixture: ComponentFixture<HnkSsoLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HnkSsoLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HnkSsoLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
