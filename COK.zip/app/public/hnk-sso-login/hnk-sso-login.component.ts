import {Component, Inject, Injector, OnInit, PLATFORM_ID} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import {BaseComponent} from '../../common/commonComponent';
@Component({
  selector: 'app-hnk-sso-login',
  templateUrl: './hnk-sso-login.component.html',
  styleUrls: ['./hnk-sso-login.component.css']
})
export class HnkSsoLoginComponent extends BaseComponent implements OnInit {
  public _landingUrl;
  constructor( ing: Injector, public _http: HttpClient, public router: Router) {
    super(ing);
  }

  ngOnInit() {
    this._landingUrl = this.router.url;
    console.log('this._landingUrl: ' , this._landingUrl);
    this._http.get<any>(this._landingUrl, {observe: 'response'}).subscribe(request => {
      // encoded_jwt = headers.dict['x-amzn-oidc-data']
      console.log('request: ' , request);
      const X_AMZN_OIDC_DATA = request.headers.get(this.constants.X_AMZN_OIDC_DATA);
      const X_AMZN_OIDC_ACCESSTOKEN = request.headers.get(this.constants.X_AMZN_OIDC_ACCESSTOKEN);
      const X_AMZN_OIDC_IDENTITY = request.headers.get(this.constants.X_AMZN_OIDC_IDENTITY);
      // jwt_headers = encoded_jwt.split('.')[0]
      console.log(X_AMZN_OIDC_DATA);
      console.log(X_AMZN_OIDC_ACCESSTOKEN);
      console.log(X_AMZN_OIDC_IDENTITY);
    });
  }

}
