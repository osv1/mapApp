import {Component, Injector} from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import {environment} from "../environments/environment";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'DMH';
  constructor( public router:Router) {
  }
  ngOnInit() {
    let a :any
    a= document.getElementById('dynamicLink');
    a.href = "src/assets/css/brand-hnk.css";
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        if (typeof window != 'undefined') {
          window.scrollTo(0, 0);
        }
      }
    });
  }
}
