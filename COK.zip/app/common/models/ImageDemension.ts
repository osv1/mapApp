/** will keep map of tmatrix, clip, imagebounds, mask */
export class ImageDimension {
  // location
  x: string;
  y: string;

  // size
  width: string;
  height: string;

  // rotation
  angle: string;       // TODO how to get it back from database

  // for <mask ...>
  orientation: string;

  // for tmatrix - a & d value has the same zoom value
  zoom: string;    // 1: 100%  e.g. 0.05344
}
