import {xmlText} from './xmlText'

export class TextBlock {
  align: string;
  extraParagraphSpacing: string;
  id: string;
  firstLineIndent: string;
  keepTogether: string;
  leading: string;
  leftIndent: string;
  rightIndent: string;
  spaceAfter: string;
  spaceBefore: string;
  tabStops?: string;
  xmlText?: Array<xmlText>;
}
