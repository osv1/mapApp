import {TabStop} from './TabStop';
import {XmlId} from './XmlId';
import {XmlTMatrix} from './XmlTMatrix';
import {XmlClip} from './XmlClip';
import {XmlImageBounds} from './XmlImageBounds';
import {Constraint} from "./Constraint";

export class vfield {
  display: string;
  editRowHeight: string;
  editable: string;
  id: string;     // unique id value will be set when it is part of brand new textRegion
  index: string;
  name: string;
  type: string;
  value: string;
  styleID: string;    // TODO may use this to refer fieldID on fieldRules to apply constraint after textRegion is saved to backend
  elementIndex: string;
  visible: string;

  // constraints from fieldRule - will be used to determine rules on this field e.g. maxLength...
  constraints?: Constraint[];

  // elements below only used for Image
  xmlId?: XmlId;
  tmatrix?: XmlTMatrix;
  clip?: XmlClip;
  imagebounds?: XmlImageBounds;
}
