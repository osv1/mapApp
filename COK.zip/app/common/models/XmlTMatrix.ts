/* zooming percentage (a & d)
 <tmatrix a="0.7113377772170183" b="0.0" c="0.0" d="0.7113377772170183" e="0.0" f="0.0"/> */
export class XmlTMatrix {
  a: string;
  b: string;
  c: string;
  d: string;
  e: string;
  f: string;
}
