export class TemplateColourPalette {
  templateColourPaletteID: number;
  paletteName: string
  clientID: number;
  colours: string[];
}
