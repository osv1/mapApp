// user deitals on commerce clickthru user creation via restful serice
export class RestLoginFields {
  // call back details to return
  customiseReferrer?: string;
  source?: string;
  errorURL?: string;
  templateID?: string;
  jTemplateID?: string;

  // details to create new user - username is mandatory
  username: string;
  name?: string;
  email?: string;
  country?: string;
  department?: string;
  division?: string;
  mail?: string;
  state?: string;
  mobile?: string;
  phone?: string;
  telephoneNumber?: string;
  postalCode?: string;
  postcode?: string;
  streetAddress?: string;
  address1?: string;
  address2?: string;
  address3?: string;
}
