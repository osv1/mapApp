import {vfield} from "./vfield";
import {EditRules} from './EditRules';

/** <image zindex="0" y="766.0657958984375" x="271.1402893066406" width="52.9949951171875" shape="rect" id="1397" height="47.4775390625" angle="0.000000"> */
export class XmlImage {
  id: string;

  // location
  x: string;
  y: string;

  // size
  width: string;
  height: string;

  // rotation
  angle: string;

  shape: string;
  zindex: string;

  vfield?: vfield[];

  // Edit rules
  editRules?: EditRules;
}
