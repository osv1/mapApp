/** represents template-wise style rules */
export class TemplateStyleRule {
    templateStyleRuleID: number;
    templateID: number;
    templateEditRule: TemplateEditRule = new TemplateEditRule();     // keeps the actual edit rules for template
    svgDefinition?: string;
}

/** different from textRegion/image editRules */
export class TemplateEditRule {
    imageRegionsOnly: string = '0';   // "1" or "0" - does not allow image selection from images tab
    uploadAllowed: string = '1';      // "1" or "0" - allows an image to be uploaded as an asset
}