import {TextRegion} from "./TextRegion";

export class TemplateTextStyleSvg {
  templateTextStyleSvgID: number;
  templateID: number;
  styleName: string;
  preTextRegion?: TextRegion;
  textRegions: Array<TextRegion>;
  svgDefinition?: string;
}
