import {TextBlock} from './TextBlock'
import {EditRules} from './EditRules';

export class TextRegion {
  angle: string;
  baselineFirstOffsetMetric: string;
  baselineMinFirstOffset: string;
  firstBaselineOffset: string;
  height: string;
  id: string;
  shape: string;
  textBlocks?: Array<TextBlock>;
  textInset: string;
  valign: string;
  vJInterParaSpace: string;
  width: string;
  x: string;
  y: string;
  parent?: string;     // null,undefined,0,-1: no grouping, >0: grouping with text regions with the same value - will be used when new base template is created
  snapTextRegionId?: string;      // front-end snapInRegion needs to be saved onto back-end - will be used when new base template is created
  firstLineInGroup?: boolean;  // front-end: flag to set if it is the 1st line text within the same grouped style
  preSpaceAfter?: number;    // spaceAfter value from previous item
  prePositionY?: number;    // y position value from previous item
  preEditRowHeight?: number; // number of lines allowed for previous line text - needs to be used to adjust top position of text since fabric text height is different from pointsize
  lineNo?: number;    // 0 based line number in the same text style group
  totalNoOfRows?: number;     // how many text rows consists of this style
  editRules?: Array<EditRules>;
  isStyledText?: boolean;     // true: added from texts tab
}
