/* <imagebounds height="1207.43994140625" width="858.9600219726562" x="0.6363977762353556" y="5.6843418860808015E-14"/> */
export class XmlImageBounds {
  // x, y position is relevant to allocated image area
  x: string;
  y: string;
  // the original size of chosen image
  height: string;
  width: string;
}
