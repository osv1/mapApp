import {vfield} from "./vfield";
import {TabStop} from "./TabStop";
import {EditRules} from "./EditRules";

export class xmlText {
  baselineShift: string;
  characterStyle: string;
  color: string;
  font: string;
  horizontalScale: string;
  pointsize: string;
  vfield?: Array<vfield>;
  // for convenience
  tabStop?: TabStop;
}
