import {Asset} from "./Asset";

/** use it for pagination */
export class Page<T> {
  page: number = 1;
  pageSize: number = 20;
  dir?: string;
  sort?: string;
  search: string = '';
  rows: T[] = [];     // list of items with type T

  noMore: boolean = false;    //reached the end of items
  inProgress: boolean = false;    // in progress of fetching items
}
