/* <clip height="858.8976440429686" width="611.0107127483105" x="0.6363977762353556" y="5.684341886080801"/> */
export class XmlClip {
  x: string;
  y: string;
  height: string;
  width: string;
}
