import {Fields} from "./Fields";

export class AdworksPage {
  pageNumber:string;
  fields:Array<Fields> ;
}
