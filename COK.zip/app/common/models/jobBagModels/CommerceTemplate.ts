export class CommerceTemplate {
  template_id: string;
  template_name: string;
  language_id: string;
  language_name: string;
}
