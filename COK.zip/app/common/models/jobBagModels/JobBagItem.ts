import {JobBagFile} from "./JobBagFile";
import {JobBagAsset} from "./JobBagAsset";
import {JobBagItemOptions} from "./JobBagItemOptions";
import {CommerceTemplate} from "./CommerceTemplate";
import {AdworksResponse} from "./AdworksResponse";

export class JobBagItem {
  type:string;    // commerce, specType or specTemplate
  itemID:number;    // sequence number
  itemCode:string;    // commerce product_id, specTpe specTypeId, specTemplate spec_template_id
  name:string;    //":"First Job Commerce Item",
  qtys:Array<number>;//":[1,2,3],
  specifications:string;//":"lorum Ipsum",
  files:Array<JobBagFile>;//":[{"Path":"s3storage"},{"Path":"s3storage"}],
  assets:Array<JobBagAsset>;   //Filestor assets
  templateID:number;//":0,
  jTemplateID:number;//":1000,
  thumbnail:string;//":"s3storage"
  productTypeID:string;       // for Noosh entities - make it
  price:number;
  jobBagItemOptions:Array<JobBagItemOptions>;
  template:CommerceTemplate;
  adworksResponse:AdworksResponse;
  pdfPreview:string;
  highResPdfUrl:string;
  model:string;
  discounts:Array<Map<String, Object>>;
}
