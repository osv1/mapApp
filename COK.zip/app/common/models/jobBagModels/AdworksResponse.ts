import {AdworksPage} from "./AdworksPage";

export class AdworksResponse {
  content:Array<AdworksPage>;
  product_id: number;
  jTemplateID: number;
  templateid: number;
  success: string;
}
