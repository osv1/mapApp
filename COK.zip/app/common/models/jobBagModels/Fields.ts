export class Fields {
  key: string;
  value: string;
}
