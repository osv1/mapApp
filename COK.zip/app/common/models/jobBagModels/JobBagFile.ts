export class JobBagFile {
  path:string;
  fileName:string;
  uploadedFileName:string;
  fileType:string;    //content type
  fileSize:number;    //length, in bytes
}
