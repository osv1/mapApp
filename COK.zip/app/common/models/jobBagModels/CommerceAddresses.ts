export class CommerceAddresses {
  shipAccNumber: string;
  shipAccPostalCode: string;
  shipMethod: string;
  orderNotes: string;
  attn: string;
  address_id: string;
  firstname: string;
  lastname: string;
  company: string;
  company_id: string;
  tax_id: string;
  address_1: string;
  address_2: string;
  postcode: string;
  city: string;
  zone_id: string;
  zone: string;
  zone_code: string;
  country_id: string;
  country: string;
  iso_code_2: string;
  iso_code_3: string;
  address_format: string;
  email: string;
  action: string ;//create update delete
}
