export class NameAndValue {
  name: string;
  value: string;
  type: string;
}
