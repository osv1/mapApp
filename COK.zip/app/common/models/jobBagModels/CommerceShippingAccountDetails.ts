export class CommerceShippingAccountDetails {
  shipAccNumber: string;
  shipAccPostalCode: string;
  shipMethod: string;
}
