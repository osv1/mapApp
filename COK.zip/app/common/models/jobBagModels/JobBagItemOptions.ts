export class JobBagItemOptions {
  product_option_id: number;
  product_option_value_id: number;
  product_option_price_prefix: string;
  product_option_price: number;
}
