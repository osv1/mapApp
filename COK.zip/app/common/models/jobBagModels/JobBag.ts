import {JobBagItem} from './JobBagItem';
import {GowCommerceShippingDetails} from "./GowCommerceShippingDetails";

export class JobBag {
  jobBagID: number;
  uid: number;
  name: string;
  clientID: number;
  crBy: number;
  crDate: string;
  modBy: number;
  modDate: string;
  campaignID: number;
  lastEdited: string;
  items:Array<JobBagItem>;
  isCheckout: boolean;
  gowCommerceShippingDetails:GowCommerceShippingDetails;
  orderNo: string;
  orderDate: string;
  orderTotal: string;
}
