export class CommerceUserDetails {
  firstName: string;
  lastName: string;
  email: string;
}
