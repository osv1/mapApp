import {CommerceUserDetails} from './CommerceUserDetails';
import {CommerceShippingAccountDetails} from './CommerceShippingAccountDetails';
import {CommerceAddresses} from './CommerceAddresses';

export class GowCommerceShippingDetails {
  userDetails: CommerceUserDetails;
  shippingAccountDetails: CommerceShippingAccountDetails;
  commerceAddresses: CommerceAddresses;
  orderNotes: string;
}
