/** represent datasource response */
export class FieldValueResponse {
  fieldID: string;    // grid fieldID e.g. 640:75
  fieldValue: string;
}
