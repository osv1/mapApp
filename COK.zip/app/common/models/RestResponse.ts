// response from resstful serice have this fomat in most cases - add any fields necessary
export class RestResponse {
  statusCode: number; // e.g. http status code 200
  statusText: string; // e.g. "success"
  message?: string;   // e.g. "successful update"
  key?: string;      // e.g. id of the item
  instance?: any;     // updated/insert instance

  extraMsg?: string;
}
