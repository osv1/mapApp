export class FieldDataSourceAction {
  type: string;
  order: number;
  field: string;

}
