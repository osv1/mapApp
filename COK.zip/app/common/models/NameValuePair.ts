/** simple name & value pair */
export class NameValuePair {
  key: string;
  value: string;
}
