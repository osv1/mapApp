import {NameValuePair} from './NameValuePair';

/** represent GridFieldDTO */
export class GridField {
  gridID: number;
  elementIndex: string;
  fieldName: string;    // !!! this field holds numeric id e.g. 1110:5
  fieldValue: string;
  fieldType: number;
  fieldIndex: number;
  editRowHeight: number;
  charLength: number;
  regionID: string;
  staticField: boolean;
  visible: boolean;
  fieldID: string;
  display: boolean;
  gridRuleFieldName: string;

  // to make things easier for image type
  assetID: string;
  catalogue: string;

  // to make things easier for text type
  displayType: string;     // text, date, checkbox ...
  pattern?: string;         // hold date pattern or any other necessary info to be used in client side
  optionList?: NameValuePair[];

  reqDataSourceAction: boolean;    // when selection from dropdown needs to trigger pre-fill of other fields with data fetched from datasource
  rules: string;   //primary rules
  rules2?: string;  //dollar rules
  rules3?: string;  //cent rules

  imageDimenstions?: any;
  thumbUrl?: string;
  originalImage?: any;
}
