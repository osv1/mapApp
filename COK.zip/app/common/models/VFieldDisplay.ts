/*** use this class to display input fields - static class declarred for type safe and convenience */
export class VFieldDisplay {
  default: string; //"Name",
  fieldConstraints?: {
    maxLength: string; // "25"
  };
  editable: string; // "1",
  name: string;  //"Insert Name",
  format?: string; //E ??? (E followed by a tab);\r\n\t\tvar firstVal = value;if (value == null || value.length == 0) return value;var testVal = '<b>E<\/b>\\t' + value;return testVal;,
  gridID: string;  //"1",
  id: string;  //"1111:0",
  editRowHeight: string;  //"1",
  type: string;  //"text",
  validation?: {
    enforced: string; // "0",
    expression: string; //"//E ??? (E followed by a tab);\r\n\t\tvar firstVal = field.value; if (firstVal == null || firstVal.length == 0) { return true; } var index = firstVal.indexOf('@'); return (index > 0) ? true : false;",
    message: {}
  };
  dataSource?: {
    column: string; //"Location",
    name: string; //"Heineken",
    table: string; //"BC"
  };
  order: string; // "1"
}
