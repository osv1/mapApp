// constraint details on field - e.g.  maxLength & 50
export class Constraint {
  constraintName: string;     //The name of the constraint
  constraintValue: string;    //The value of the constraint
}
