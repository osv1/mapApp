/* <id catalogue="ERGO" palette="color" s3="true">https://s3....</id> */
export class XmlId {
  catalogue?: string;
  palette?: string;
  s3?: string;        //true or false/undefined
  filesafe?: string;  //true or false/undefined
  value: string;
}
