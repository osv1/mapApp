/** will keep map of tmatrix, clip, imagebounds, mask */
export class JobTemplateSaveRequest {
  base: number;
  categoryID: number;
  name: string;
}
