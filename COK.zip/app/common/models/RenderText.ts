/** represent text image block in canvas */
export class RenderText {
  templateId: number;
  gridName: string;

  // used to get png text image
  height: number;   // needs to be integer to submit
  width: number;  // needs to be integer to submit
  text: string;
  font: string;
  fontSize: number;
  fontColour: string;
  vfieldId?: string;
  vfieldIds?: string[];
  align: string;
  fontWeight: string;
  fontFamily: string;
  fontStyle: string;
  textDecoration: string;
  textX?: number;  //x location
  textY?: number;  //y location

  // need to keep these as reference
  textRegionId: string;   // textregion is used to identify relocate a group of text fields
  pointSize: string;  // original font size without scaling
  canvasIndex: number;  // which canvas it belongs to
}
