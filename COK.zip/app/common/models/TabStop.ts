// used to hold textBlock's tab stop details for child text instance  1\340.157\right
export class TabStop {
  index: number;
  left: number;
  align: string;
  symbol?: string;
}
