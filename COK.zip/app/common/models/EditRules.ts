export class EditRules {
  editable: string = '1';
  deletable: string = '1';
  movable: string = '1';
  resizable: string = '1';

  // text only rules
  //allowFontColourChange?: string;
  minLength?: string;       // min characters required
  maxLength?: string;       // maximum characters allowed - it used to set as constraint in old adworks
  formatMask?: string;      // when masking is required
}
