export class RuleListItem {
  listLabel: string;  //The display label for the list item
  listValue: string;  //The value of the list item
}
