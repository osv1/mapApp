/** simplified version of AssetSimple class from backend to represent Filestor asset */
export class Asset {
  assetID: string;      // ID__
  assetName: string;   // F_AssetName
  assetType: string;   // Type - 'Link' or 'Asset'
  fileName: string;    // F_AssetName
  filePath?: string;    // F_AssetRefStr
  fileFormat: string;  // F_FileFormat
  datasize: string;    // F_DataSize
  catalogue: string;   // Catalogue
  cid?: string;         // CID
  categoryPath?: string;// CategoryPath
  crBy?: string;
  crDate?: string;      // F_AssetCreated
  modBy?: string;
  modDate?: string;     // F_AssetModified
  interfaceID?: string; // InterfaceID to be used by Xbase ElementImage
  selected?: boolean;   // flag - selected by the user or not
  pageCount?: string;
  assetThumbnailPath?: string;
  assetS3PreviewPath?: string;
  expiryDate?: string;
  recordName?: string;
  width?: string;
  height?: string;
}
