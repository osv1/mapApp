export class FieldDataSourceRule {
  name: string;    //Name of the data source
  clientID: number; //ID of the client that the data source belongs to
  columnName: string;  //The name of the column inside the data source that matching this field.
  sort: string; //The order in which to sort the values, if there are more than one.
  tableName: string;   //The name of the table inside the data source.
  alternateColumns?: string[];  // Alternate columns names also involved in lookup
}
