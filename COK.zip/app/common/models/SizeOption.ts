/** options for available template size list */
export class SizeOption {
    name: string;      // e.g. A3, A4...
    description: string;
    height: string;
    width: string;
    selected: string;
}