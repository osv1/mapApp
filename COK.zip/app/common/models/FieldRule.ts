import {Constraint} from './Constraint'
import {RuleListItem} from './RuleListItem'
import {FieldDataSourceRule} from './FieldDataSourceRule'
import {FieldDataSourceAction} from './FieldDataSourceAction'

// field implementation details for template/text-style fields - e.g. maxLength, defaultValue ...
export class FieldRule {
  fieldID: string;
  fieldName: string;  //The display name of the field
  constraints: Constraint[];	//The constraints applied to the field
  listItems: RuleListItem[];	// If the field is of type listbox, these are the list items for the field
  ruleDefinition: string;	// The definition of the field rule in XML format
  fieldType: string; //The type of field that this rule is controlling
  defaultValue: string;	//The default value of the field.  If the field is of type listbox, this may either be the label value of one of the list items or the value of oe of the list items.
  editRowHeight: number;	//The number of rows displayed for the field
  order: number;	// The order in which this field will appear in a collection with other fields
  fieldGroup: number; //The field group that this field belongs to.
  gridID: number; //The id of the grid that this field belongs to (as specified in the XML definition of the grid)
  status: number;  //The mandatory status of the field, 0 is optional and 1 is mandatory
  editable: number;	//Indicates whether the field is editable, 0 is not editable and 1 is editable
  clientID: number;
  dataSource?: FieldDataSourceRule;
  dataSourceActions?: FieldDataSourceAction[];
  displayFormat: string;
  validator: string[];
  formatScript: string;
  scalable?: number;
  moveable?: number;
  cropable?: number;
  allowUserSelectFromLibrary?: number;
  nameValuePairs?: string;
}
