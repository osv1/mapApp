export class CreateBaseTemplateRequest {
  name: string; // new base template name
  categoryID: number; // add to a category for adworks template
  productCategoryID: string; // add to a category for commerce product
  xmlName: string; // already uploaded xml file name
  pdfName: string; // already uploaded pdf file name
  sizeOptions: Array<string>;
}
