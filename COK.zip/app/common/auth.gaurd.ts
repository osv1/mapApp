import {Injectable, Injector, APP_ID, PLATFORM_ID} from '@angular/core';
import {isPlatformBrowser, isPlatformServer} from '@angular/common';
import {BaseComponent} from './commonComponent';
import {
    Router,
    CanActivate,
    ActivatedRouteSnapshot,
    RouterStateSnapshot,
    CanActivateChild,
    CanDeactivate
} from '@angular/router';
import {Observable} from 'rxjs';
import {environment} from "../../environments/environment";

/****************************************************************************
 @PURPOSE      : To allow public pages can be activated. (After Login)
 @PARAMETERS   : N/A
 @RETURN       : <boolean>
 /****************************************************************************/
@Injectable()
export class CanLoginActivate extends BaseComponent implements CanActivate {
    constructor(inj: Injector) {
        super(inj);
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        // console.log('can login activate called', this.getToken("accessToken"))
        if (!this.getToken('accessToken')) {
            // console.log('returning true', this.getToken("accessToken"))
            return true;
        }
        this.router.navigate(['homepage']);
        return false;
    }
}

/****************************************************************************/

/****************************************************************************
 @PURPOSE      : To allow authorized pages can be activated. (Before Login)
 @PARAMETERS   : N/A
 @RETURN       : <boolean>
 /****************************************************************************/
@Injectable()
export class CanAuthActivate extends BaseComponent implements CanActivate {
    constructor(inj: Injector) {
        super(inj);
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this.getToken('accessToken')) {
            // console.log('returning true', this.getToken("accessToken"))
            return true;
        }
        // console.log('returning false', this.getToken("accessToken"))

      if (environment.envnName === this.constants.enviromentValues.DMH) {
        window.location.href = 'https://www.mykonicaminolta.com';
      } else {
        // window.location.href = 'https://www.mykonicaminolta.com';
        this.router.navigate(['login']);
      }
        return false;
    }
}

/****************************************************************************/
