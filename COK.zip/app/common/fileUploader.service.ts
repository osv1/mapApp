import {PLATFORM_ID, Injectable, Inject, OnInit, ViewChild, ElementRef, Injector} from '@angular/core';
import {isPlatformBrowser} from '@angular/common';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import {config} from '../../assets/config/configs';
import {Router} from '@angular/router';
import {Broadcaster} from './BroadCaster';
import {FileUploader} from "ng2-file-upload";
import {ToastrService} from "ngx-toastr";
import {CommonService} from "../common/common.service";
import {environment} from '../../environments/environment';


declare var $: any;

@Injectable({
    providedIn: 'root'
})

export class FileUploaderService implements OnInit {
    @ViewChild('fileInput') fileInput: ElementRef;
    public _CM_Url;
    public config = (<any>environment);
    public _imageUrl;
    //public uploadApi = 'uploadService/upload';
    public uploadApi = 'AssetService/v1/asset/upload?';
    public uploader: any;
    public totalFiles: any;
    public uploadInProgress = false;
    public filesProgressByName: any = {};

    public filesUploaded: any = [];
    public filesProgress: any = [];
    public projectFilesUploaded: any = [];
    public files: any = [];
    public fileMetaList = [];
    public hasBaseDropZoneOver = false;
    public toastrService: ToastrService;
    public urlpoint;
    public platformId: any;

    constructor(public injector: Injector, public _http: HttpClient, public router: Router, public broadcaster: Broadcaster, public commonService: CommonService) {
        this.platformId = injector.get(PLATFORM_ID);
        this._imageUrl = this.config.apiUrl;
        this._CM_Url = this.config.apiUrl;
        this.broadcaster.on<boolean>('fileMetaListClear').subscribe((success: any) => {
            this.fileMetaList = [];
        });
    }

    public getToken(key) {
        if (isPlatformBrowser(this.platformId)) {
            return window.localStorage.getItem(key);
        }
    }

    ngOnInit() {
        this.urlpoint = this._imageUrl + this.uploadApi + 'token=' + this.getToken('accessToken');
        if (this.commonService.isUploadLocal) {
            //this.urlpoint = this.commonS  ervice._CM_Url + this.uploadApi; //coming from commonService for local environment
            this.urlpoint = this._CM_Url + this.uploadApi; //coming from commonService for dev environment
        }

        // else if(this.commonService.restUser.restUploadUrl) {
        //     this.urlpoint = this.commonService.restUser.restUploadUrl; //coming from taskListService ngOnInit()
        // }
        this.uploader = new FileUploader({
            url: this.urlpoint,
            itemAlias: 'file'
        });
        this.uploader.onAfterAddingFile = (file) => {
            file.withCredentials = false;
        };
        this.files = [];
        this.fileMetaList = [];
    }

    // check if the file is in blocked file types
    public isBlockedFileType(fielName) {
        const dotIdx = fielName.lastIndexOf('.');
        const ext = fielName.substring(dotIdx, fielName.length).toLowerCase();
        // if ( blockedFileTypes.indexOf(ext) != -1 ) {
        // return true;
        // }
        return false;
    }

    public setFileMetaListSingle(fileUploaded) {
        if (fileUploaded) {
            // now allow multiple
            if (!this.alreadyInFileList(this.fileMetaList, fileUploaded)) {
                //this.fileMetaList.push(fileUploaded);
                this.fileMetaList = fileUploaded;
            }
        }
    }

    public alreadyInFileList(files, file) {
        for (let i = 0; i < files.length; i++) {
            if (files[i].fileName === file.fileName) {
                return true;
            }
        }
        return false;
    }

    public openFileUpload() {
        this.fileInput.nativeElement.click();
    }

    public fileOverBase(e: any): void {
        this.hasBaseDropZoneOver = e;
    }

    public removeFile(f, fileIndex?, pindex?) {
        var filesIndex = 0;
        // find matching index - NOTE passing index from view is not valid in this case
        for (var i = 0; i < this.files.length; i++) {
            if (f.$$hashKey == this.files[i].$$hashKey) {
                filesIndex = i;
                /*f.upload.abort();     //may need to abort
                 f.upload.aborted = true;*/
                break;
            }
        }
        this.files.splice(filesIndex, 1);

        var filesUploadedIndex = 0;
        for (var j = 0; j < this.filesUploaded.length; j++) {
            if (f.name === this.filesUploaded[j].fileName) {
                filesUploadedIndex = j;
                break;
            }
        }
        this.filesUploaded.splice(filesUploadedIndex, 1);

        var filesProgressIndex = 0;
        // find matching index - NOTE passing index from view is not valid in this case
        for (var k = 0; k < this.filesProgress.length; k++) {
            if (f.$$hashKey == this.filesProgress[k].$$hashKey) {
                filesProgressIndex = k;
                break;
            }
        }
        this.filesProgress.splice(filesProgressIndex, 1);

        if (this.projectFilesUploaded != undefined) {
            this.projectFilesUploaded = this.filesUploaded;//.splice(index,1);
        }
        this.broadcaster.broadcast('fileMetaListClear', {event: pindex, fileUploaded: filesIndex})
        // this.$emit('fileMetaListClear', pindex, filesIndex);
    }

    public removeAllFiles() {
        this.files = [];
        this.filesUploaded = [];
        this.filesProgress = [];
        if (this.projectFilesUploaded !== undefined) {
            this.projectFilesUploaded = [];
        }
        this.broadcaster.broadcast('fileMetaListClear', {})
        // $scope.$emit('fileMetaListClear');
    }

    public uploadFiles(files, extraInfo?) {
        let imageType = this.getImageTypeAliasByFieldName(this.commonService.artworkFieldName);
        if (files.length > 0) {
            if (files[0].type) {
                this.totalFiles = [];
                if (files != null && files.length > 0) {
                    this.totalFiles = files.length;
                    this.uploadInProgress = true;  // progress bar will replace ajaxloading
                }

                // clear related list before get new ones EXCEPT $scope.files
                this.filesUploaded = [];
                this.filesProgress = [];
                this.filesProgressByName = {};
                if (this.projectFilesUploaded !== undefined) {
                    this.projectFilesUploaded = [];
                }
                // const file: any = files[0];
                this.files.push(files[0]);
                this.files.forEach((file, idx) => {
                    if (!file.uploaded) {
                        if (!this.isBlockedFileType(file.name)) {
                            if (file) {
                                file.inProgress = true;
                                this.uploader.uploadAll();
                                file.progress = 0;
                                this.uploader.onProgressItem = (fileItem: any, progress: any) => {
                                    // this.changeDetector.detectChanges();
                                    file.progress = progress;
                                };
                                this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
                                    // file.progress = 100;
                                    response = JSON.parse(response);
                                    file.inProgress = false;
                                    this.totalFiles = this.totalFiles - 1;
                                    file.uploaded = true;
                                    if (!file.result) {
                                        file.imageType = imageType;
                                        file.fieldName = this.commonService.artworkFieldName;
                                    }
                                    file.result = response;
                                    if (response.status > 0) {
                                        file.errorMsg = response.status + ' ' + response.statusText;
                                        file.inProgress = false;
                                        file.uploaded = true;
                                    }
                                    this.setFileMetaListSingle(file.result);
                                    // this.setAssetFileMetaListSingle(file.result);
                                    this.broadcaster.broadcast('fileupload');
                                };
                            } else {
                                if (file.$error === 'pattern') {
                                    this.displayToaster('warning', [file.$errorParam + ' only']);
                                    this.uploadInProgress = false;
                                    this.files = [];
                                }
                            }


                        } else {
                            file.errorMsg = 'error' + ': ' + 'blocked file type!';
                            this.uploadInProgress = false;
                            // sharedService.displayToaster(FIELD_WARNING, [ typeError ]);
                        }
                    }
                });
            } else {
                this.commonService.displayToaster('error', 'Invalid File Type');
            }
        }

    }
    public uploadDragFiles(files, extraInfo?) {
        console.log("url " + this.urlpoint);
        let imageType = this.getImageTypeAliasByFieldName(this.commonService.artworkFieldName);
        if (files.length > 0) {
            this.totalFiles = [];
            if (files != null && files.length > 0) {
                this.totalFiles = files.length;
                this.uploadInProgress = true;  // progress bar will replace ajaxloading
            }

            // clear related list before get new ones EXCEPT $scope.files
            this.filesUploaded = [];
            this.filesProgress = [];
            this.filesProgressByName = {};
            if (this.projectFilesUploaded !== undefined) {
                this.projectFilesUploaded = [];
            }
            // const file: any = files[0];
            this.files.push(files[0]);
            this.files.forEach((file, idx) => {
                if (!file.uploaded) {
                    if (!this.isBlockedFileType(file.name)) {
                        if (file) {
                            file.inProgress = true;
                            this.uploader.uploadAll();
                            file.progress = 0;
                            this.uploader.onProgressItem = (fileItem: any, progress: any) => {
                                // this.changeDetector.detectChanges();
                                file.progress = progress;
                            };
                            this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
                                // file.progress = 100;
                                this.uploadInProgress = false;
                                console.log(response)
                                response = JSON.parse(response);
                                file.inProgress = false;
                                this.totalFiles = this.totalFiles - 1;
                                file.uploaded = true;
                                if (!file.result) {
                                    file.imageType = imageType;
                                    file.fieldName = this.commonService.artworkFieldName;
                                }
                                file.result = response;
                                if (response.status > 0) {
                                    file.errorMsg = response.status + ' ' + response.statusText;
                                    file.inProgress = false;
                                    file.uploaded = true;
                                }
                                this.setAssetFileMetaListSingle(file.result);
                            };
                        } else {
                            if (file.$error === 'pattern') {
                                this.displayToaster('warning', [file.$errorParam + ' only']);
                                this.uploadInProgress = false;
                                this.files = [];
                            }
                        }

                    } else {
                        file.errorMsg = 'error' + ': ' + 'blocked file type!';
                        this.uploadInProgress = false;
                        // sharedService.displayToaster(FIELD_WARNING, [ typeError ]);
                    }
                }
            });

        }

    }
    public setAssetFileMetaListSingle(fileUploaded) {

        if (fileUploaded) {
            // now allow multiple

            this.fileMetaList.push(fileUploaded);
            // this.fileMetaList=fileUploaded;
            this.broadcaster.broadcast('saveProcurementFile', {fileUploaded: fileUploaded[0]});
            this.broadcaster.broadcast('fileupload', [fileUploaded]);
        }
    }

    /* Upload Assets Files */
    public uploadAssetFiles(files, extraInfo?) {
        const imageType = this.getImageTypeAliasByFieldName(this.commonService.artworkFieldName);
        if (files.length > 0) {
            this.totalFiles = [];
            if (files != null && files.length > 0) {
                this.totalFiles = files.length;
                this.uploadInProgress = true;  // progress bar will replace ajaxloading
            }

            // clear related list before get new ones EXCEPT $scope.files
            this.filesUploaded = [];
            this.filesProgress = [];
            this.filesProgressByName = {};
            if (this.projectFilesUploaded !== undefined) {
                this.projectFilesUploaded = [];
            }
            // const file: any = files[0];
            this.files.push(files[0]);
            this.files.forEach((file, idx) => {
                if (!file.uploaded) {
                    if (!this.isBlockedFileType(file.name)) {
                        if (file) {
                            file.inProgress = true;
                            this.uploader.uploadAll();
                            file.progress = 0;
                            this.uploader.onProgressItem = (fileItem: any, progress: any) => {
                                // this.changeDetector.detectChanges();
                                file.progress = progress;
                            };
                            this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
                                // file.progress = 100;
                                this.uploadInProgress = false;
                                response = JSON.parse(response);
                                file.inProgress = false;
                                this.totalFiles = this.totalFiles - 1;
                                file.uploaded = true;
                                if (!file.result) {
                                    file.imageType = imageType;
                                    file.fieldName = this.commonService.artworkFieldName;
                                }
                                file.result = response;
                                if (response.status > 0) {
                                    file.errorMsg = response.status + ' ' + response.statusText;
                                    file.inProgress = false;
                                    file.uploaded = true;
                                }
                                this.setAssetFileMetaListSingle(file.result);
                            };
                        } else {
                            if (file.$error === 'pattern') {
                                this.displayToaster('warning', [file.$errorParam + ' only']);
                                this.uploadInProgress = false;
                                this.files = [];
                            }
                        }

                    } else {
                        file.errorMsg = 'error' + ': ' + 'blocked file type!';
                        this.uploadInProgress = false;
                        // sharedService.displayToaster(FIELD_WARNING, [ typeError ]);
                    }
                }
            });

        }

    }

    // find matching alias name from fieldName
    getImageTypeAliasByFieldName(fieldName) {
        let match = this.commonService.imageTypeFields.find((type) => {
            return fieldName == type.key;
        });

        return !!match ? match.displayName : '';
    }

    public displayToaster(type, messages, timeout?, customTitle?) {
        if (!timeout) {
            timeout = 5000;
        }
        if (!customTitle) {
            customTitle = '';
        }
        if (messages.length > 0) {
            if (timeout === undefined) {
                timeout = 5000;
            }
            let messageBody = `<ul>`;
            for (let i = 0; i < messages.length; i++) {
                messageBody += `<li>` + messages[i] + `</li>`;
            }
            messageBody += `</ul>`;
            const title = customTitle;
            if (type === 'success') {
                this.toastrService.success(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
            } else if (type === 'error') {
                this.toastrService.error(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
            } else if (type === 'warning') {
                this.toastrService.warning(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
            } else if (type === 'info') {
                this.toastrService.info(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
            } else if (type === 'wait') {    // with loading gif
                this.toastrService.warning(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
            }
        }
    }
    setFileUploadUrl(url){
        this.uploader.onBeforeUploadItem = (item) => {
            item.url = url
        }
    }

}


