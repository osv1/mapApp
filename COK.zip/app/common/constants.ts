const ASSETS_CREATED = 'AssetCreated';
const TIME = 'Time';

const ASSETS_NAME = 'AssetName';
const ORDER_ALPHA = 'alpha';
const ORDER_PRICE = 'price';
const ORDER_MODEL = 'model';
const FIELDVALUE = 'FieldValue';
export const constants = {
  TOAST_SUCCESS: "success",
  TOAST_ERROR: "error",
  ASSETS_CREATED: 'AssetCreated',
  F_ASSETS_CREATED: 'F_AssetCreated',
  F_ASSETS_MODIFIED: 'F_AssetModified',
  F_ASSETS_NAME: 'F_AssetName',
  //LOGIN COMPONENT
  CLIENT_ID: 2057,
  GROUP_ID: 272,
  PORTAL_USER_ID: 2,
  MODULE_ID: 3,
  FIELDS: [],
  USER_ID: 3379,
  X_AMZN_OIDC_IDENTITY: 'x-amzn-oidc-identity',
  X_AMZN_OIDC_ACCESSTOKEN: 'x-amzn-oidc-accesstoken',
  X_AMZN_OIDC_DATA: 'x-amzn-oidc-data',

  //SELECT COMPONENT
  TEMPLATE_ID: 1341,
  PRODUCT_DETAILS_TYPE: "commerce",

  //CUSTOMIZE COMPONENT
  LABEL_CONTACT: "Contact:",
  LABEL_MOBILE: "Mobile:",
  LABEL_PHONE: "Phone:",
  LABEL_FAX: "Fax:",
  LABEL_PLUS_SYMBOL: "+",
  AMP_REGISTER_URL: "https://c.partnerbusiness.solutions/?uEYW.dkmt8Xr3iTvydcyIMRVEzr6Hscdu",
  IS_ADMIN_VALUE: 'reporting',

  SUCCESS_CODE: 200,

  categoryFetchSize: 100,
  f_assetsName: 'F_RecordName',
  defaultDirection: 'up',

  //ResponseMessages
  //


  ASSETS: 'assets',

  LOG_ALL_ITEM : 'All Item',
  // CATALOG_VIEW :'Catalog view',
  CATALOG_PDF_PREVIEW: 'Catalog - PDF preview',
  CATALOG_MORE_INFO: 'Catalog - more info/preview',

  CATALOG_VIEW: {event_id: 1, event_desc: 'Catalog view'},
  CATEGORY_VIEW: {event_id: 2, event_desc: 'Category/SubCategory view'},
  PRODUCT_VIEW: {event_id: 3, event_desc: 'Product view'},
  PRODUCT_MORE_INFO: {event_id: 4, event_desc: 'Product more info'},
  CUSTOMIZE_PRODUCT: {event_id: 6, event_desc: 'Customize product'},
  CUSTOMIZE_PRODUCT_VIEW: {event_id: 7, event_desc: 'Customize product review'},
  CANCEL_ORDER: {event_id: 8, event_desc: 'Cancel order'},
  DOWNLOAD_PDF_PROOF: {event_id: 9, event_desc: 'Download PDF proof'},
  ABANDONED_CART: {event_id: 10, event_desc: 'Abandoned cart'},
  REODER_COLLETREL: {event_id: 11, event_desc: 'Re-order collateral'},
  USER_LOGIN: {event_id: 12, event_desc: 'User Login'},
  SEARCH: {event_id: 13, event_desc: 'Search'},
  ASSET_VIEW: {event_id: 15, event_desc: 'Asset view'},
  ASSET_DOWNLOAD: {event_id: 16, event_desc: 'Asset download'},
  ASSET_SEARCH: {event_id: 17, event_desc: 'Asset search'},
  ASSET_CATEGORY: {event_id: 18, event_desc: 'Asset Category/SubCategory view'},
  ASSET_LATEST_NEWS: {event_id: 19, event_desc: 'Asset view latest news'},
  // events : [
  //   {event_id: 1, event_desc : 'Catalog view'},
  //   {event_id: 2, event_desc : 'Category/SubCategory view'},
  //   {event_id: 3, event_desc : 'Product view'},
  //   {event_id: 4, event_desc : 'Product more info'},
  //   {event_id: 5, event_desc : 'Product pdf preview'},
  //   {event_id: 6, event_desc : 'Customize product'},
  //   {event_id: 7, event_desc : 'Customize product review'},
  //   {event_id: 8, event_desc : 'Cancel order'},
  //   {event_id: 9, event_desc : 'Download PDF proof'},
  //   {event_id: 10, event_desc : 'Abandoned cart'},
  //   {event_id: 11, event_desc : 'Re-order collateral'}
  //   ],

  shortByValueDmhCataloge: [
    {
      name: "Name (A - Z)", order: ORDER_ALPHA, dir: 'asc'
    },
    {
      name: "Name (Z - A)", order: ORDER_ALPHA, dir: 'desc'
    },
    {
      name: "Price (Low - High)", order: ORDER_PRICE, dir: 'asc'
    }
    , {
      name: "Price (High - Low)", order: ORDER_PRICE, dir: 'desc'
    }
    ,
    {
      name: "Model (A - Z)", order: ORDER_MODEL, dir: 'asc'
    }
    , {
      name: "Model (Z - A)", order: ORDER_MODEL, dir: 'desc'
    }
  ],

  shortByValueHnkCataloge: [
    {
      name: "Name (A - Z)", order: ORDER_ALPHA, dir: 'asc'
    },
    {
      name: "Name (Z - A)", order: ORDER_ALPHA, dir: 'desc'
    }
  ],

  shortByValueAssetsTiles: [
    {
      name: "Name (A - Z)", order: ORDER_ALPHA, dir: 'up'
    },
    {
      name: "Name (Z - A)", order: ORDER_ALPHA, dir: 'down'
    }
  ],

  price : "0.00",

  shortByValuePublication: [
    {
      name: "Latest First", order: ASSETS_CREATED, dir: 'down'
    },
    {
      name: "Oldest First", order: ASSETS_CREATED, dir: 'up',  //AssetModified
    },
    {
      name: "Name (A - Z)", order: ASSETS_NAME, dir: 'up'
    },
    {
      name: "Name (Z - A)", order: ASSETS_NAME, dir: 'down'
    },

  ],


  shortByValueAllDownload: [
    {
      name: "Latest First", order: TIME, dir: 'down'
    },
    {
      name: "Oldest First", order: TIME, dir: 'up',  //AssetModified
    },
    {
      name: "Name (A - Z)", order: FIELDVALUE, dir: 'up'
    },
    {
      name: "Name (Z - A)", order: FIELDVALUE, dir: 'down'
    },

  ],

  pageValue: [
    {
      size: "12"
    },
    {
      size: "24",
    },
    {
      size: "36",
    }
  ],

  languageArray: [
    {
      languageType: "en", languageName: "English"
    },
    {
      languageType: "zh", languageName: "Chinese"
    }

  ],

  menuRoutes: [
    {
      name: "Home", pathName: 'homepage'
    },
    {
      name: "Catalog", pathName: 'onlineOrdering/select'
    },
    {
      name: "Automated Marketing", pathName: 'automatedMarketing'
    },
    {
      name: "Publications", pathName: 'publications'
    },
    {
      name: "Reporting", pathName: 'reporting'
    }

  ],

  // TODO : to be changed to get catalog from init API
  // ASSETS_CATALOUGUE : 'GOWORKS',
  ASSETS_CATALOUGUE_KMBS: 'KMBS',
    ASSETS_CATALOUGUE_COKE: 'COKE',
  HK_CATALOUGE:'HEINEKEN',
  LATEST_HK_CATALOUGE_PAGESIZE: 3,

  publicationService: {
    getAssetCategoryTreeItems: 'getAssetCategoryTreeItems',
    categories: 'categories',
    category: 'category',
    token: 'token',
    categoryID: 'categoryID',
    catalogue: 'catalogue',
    assetMetaData: 'assetMetaData',
    original: 'original',
    thumbnail: 'thumbnail',
    getAssetMetaDataListWithoutValue: 'getAssetMetaDataListWithoutValue',
    uid: 'uid',
    search: 'search',
    all: 'all'
  },
  method: {
    post: 'post',
    get: 'get',
    put: 'put',
    delete: 'delete'
  },

  enviromentValues: {
    heineken: 'hnk-main',
    DMH: 'km',
    cokeMain: 'coke-main'
  },

  cartSelectedPath: '/onlineOrdering',
  assetsSelectedPath: '/assets-tiles'
}


