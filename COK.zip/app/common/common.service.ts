import { PLATFORM_ID, Injectable, Inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { Broadcaster } from './BroadCaster';
import { ToastrService } from 'ngx-toastr';
import {catchError, map} from "rxjs/operators";
import {from, Observable} from 'rxjs';
import 'rxjs/add/operator/retryWhen';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/take';
import {constants} from "./constants";

declare var $: any;

@Injectable({
  providedIn: 'root'
})

export class CommonService {
  authorised: any = false;

  constructor(public _http: HttpClient, @Inject(PLATFORM_ID) platformId: Object, public router: Router, public broadcaster: Broadcaster,
              private toastrService: ToastrService ) {
    this.platformId = platformId;
    this._apiUrl = this.config.apiUrl;
    this._imageUrl = this.config.imageUrl;
    this._authUrl = this.config.authUrl;
    this._landingUrl = this.config.landingUrl;
    this._REMOTE_PAYMENT_APIKEY = this.config.REMOTE_PAYMENT_APIKEY;
    this._restv2api = this.config.restv2api;
    this._downloadUrl = this.config.downloadUrl;
    this._CM_Url = this.config.CM_URL;
    this._frontUrl = this.config.frontUrl;
  }

  public _frontUrl;
  public _CM_Url;
  public _restv2api;
  public _landingUrl;
  public _authUrl;
  public _REMOTE_PAYMENT_APIKEY;
  public config = (<any>environment);
  public _imageUrl = 'https://goworks.ergoengineering.com/CM/CM/';
  public _apiUrl;
  public platformId;
  public _downloadUrl;
  public isUploadLocal = false;
  public showProduct = true;  // used for product request button hide/show from illustrator.
  public isPageManger = true; // used for illustrator dropdown hide/show from Page Manager.
  public artworkFieldName;
  public imageTypeFields;
  public restUser: any = {};
  public assetHistoryDetails: any = [];
  apiRetryDelay: number = 1000;
  apiRetryCount: number = 3;

  public getToken(key) {
    if (isPlatformBrowser(this.platformId)) {
      return window.localStorage.getItem(key);
    }
  }

  public setToken(key, value) {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.setItem(key, value);
    }
  }

  public clearToken() {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.clear();
    }
  }

  getCookie(key) {
    const value = '; ' + document.cookie;
    const parts = value.split('; ' + key + '=');
    if (parts.length === 2) {
      return parts.pop().split(';').shift();
    } else {
      return '';
    }
  }

  /*******************************************************************************************
   @PURPOSE        :    Call api.
   @Parameters    :    {
            url : <url of api>
            data : <data object (JSON)>
            method : String (get, post)
            isForm (Optional) : Boolean - to call api with form data
            isPublic (Optional) : Boolean - to call api without auth header
          }
   /*****************************************************************************************/
  public callApi(url, data, method,params?, isForm?, isPublic?) {

    let headers;
    const self = this;
    if (isPublic) {
      headers = new HttpHeaders({ 'Content-Type': 'application/json;charset=UTF-8' });
    } else {
      if(!isForm) {
        headers = new HttpHeaders({
          'Content-Type': 'application/json',
          'emailId': JSON.parse(localStorage.getItem('userDetail')) ? JSON.parse(localStorage.getItem('userDetail')).email : ''
          // 'X-XSRF-TOKEN': this.getCookie('XSRF-TOKEN'),
        });
      } else {
        headers = new HttpHeaders({
          'emailId': JSON.parse(localStorage.getItem('userDetail')) ? JSON.parse(localStorage.getItem('userDetail')).email: ''
          // 'X-XSRF-TOKEN': this.getCookie('XSRF-TOKEN'),
        });
      }
    }

    if (isForm) {
      // headers = new HttpHeaders({ 'enctype': 'multipart/form-data; boundary=----WebKitFormBoundaryez7NSx18wd7jy6Yj' });
    }

    return new Promise((resolve, reject) => {
      if (method === 'post') {

        if(params) {
          let token;
          if (data.token) {
            token = {
              token : data.token
            }
            delete data.token;
          }
          this._http.post(this._apiUrl + url, data, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
              reject(error);
            }
          );
        } else {
          this._http.post(this._apiUrl + url, data, {headers: headers}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      } else if (method === 'put') {

        if(params) {
          let token;
          if (data.token) {
            token = {
              token : data.token
            }
            delete data.token;
          }
          this._http.put(this._apiUrl + url, data, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else {
          this._http.put(this._apiUrl + url, data, {headers: headers}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      } else if (method === 'delete') {

        if(params) {
          this._http.delete(this._apiUrl + url, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else {
          this._http.delete(this._apiUrl + url, {headers: headers}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      }else if (method === 'get') {
        // let params: { appid: 'id1234', cnt: '5' }
        // let params = new HttpParams();
        // Object.keys(data).forEach(function (key) {
        //     params = params.set(key, data[key]);
        // });
        if(params) {
          this._http.get(this._apiUrl + url, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
        else {
          this._http.get(this._apiUrl + url).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      }
    });
  }
  public callApiWithoutBase(url, data, method,params?, isForm?, isPublic?) {

    let headers;
    const self = this;
    if (isPublic) {
      headers = new HttpHeaders({ 'Content-Type': 'application/json;charset=UTF-8' });
    } else {
      if(!isForm) {
        headers = new HttpHeaders({
          'Content-Type': 'application/json',
          'emailId': JSON.parse(localStorage.getItem('userDetail')) ? JSON.parse(localStorage.getItem('userDetail')).email : ''
          // 'X-XSRF-TOKEN': this.getCookie('XSRF-TOKEN'),
        });
      } else {
        headers = new HttpHeaders({
          'emailId': JSON.parse(localStorage.getItem('userDetail')) ? JSON.parse(localStorage.getItem('userDetail')).email: ''
          // 'X-XSRF-TOKEN': this.getCookie('XSRF-TOKEN'),
        });
      }
    }

    if (isForm) {
      // headers = new HttpHeaders({ 'enctype': 'multipart/form-data; boundary=----WebKitFormBoundaryez7NSx18wd7jy6Yj' });
    }

    return new Promise((resolve, reject) => {
      if (method === 'post') {

        if(params) {
          let token;
          if (data.token) {
            token = {
              token : data.token
            }
            delete data.token;
          }
          this._http.post(this._imageUrl + url, data, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else {
          this._http.post(this._imageUrl + url, data, {headers: headers}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      } else if (method === 'put') {

        if(params) {
          let token;
          if (data.token) {
            token = {
              token : data.token
            }
            delete data.token;
          }
          this._http.put(this._imageUrl + url, data, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else {
          this._http.put(this._imageUrl + url, data, {headers: headers}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      } else if (method === 'delete') {

        if(params) {
          this._http.delete(this._imageUrl + url, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else {
          this._http.delete(this._imageUrl + url, {headers: headers}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      }else if (method === 'get') {
        // let params: { appid: 'id1234', cnt: '5' }
        // let params = new HttpParams();
        // Object.keys(data).forEach(function (key) {
        //     params = params.set(key, data[key]);
        // });
        if(params) {
          this._http.get(this._imageUrl + url, {headers: headers, params: {token :this.getToken('accessToken')}}).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
        else {
          this._http.get(this._apiUrl + url).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        }
      }
    });
  }

  public callApiRestV2(url, data, method, isForm?, isPublic?) {

    let headers;
    const self = this;
    if (isPublic) {
      headers = new HttpHeaders({'Content-Type': 'application/json;charset=UTF-8'});
    } else {
      headers = new HttpHeaders({'Content-Type': 'application/json; charset=UTF-8'});
    }
    if (isForm) {
      headers = new HttpHeaders({'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryRe0enSh66PyAdIBr'});
    }

    console.log(this._restv2api)

    return new Promise((resolve, reject) => {
        if (method === 'post') {
          headers.append('Access-Control-Allow-Origin', '*');
          this._http.post(this._restv2api + url, data, headers).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else if (method === 'put') {
          // let params: { appid: 'id1234', cnt: '5' }

          headers.append('Access-Control-Allow-Origin', '*');
          this._http.put(this._restv2api + url, data, headers).subscribe(
            data1 => {
              resolve(data1);
            },
            error => {
              this.showServerError(error);
            }
          );
        } else if (method === 'delete') {
          // let params: { appid: 'id1234', cnt: '5' }
          if (data) {
            let params = new HttpParams();
            Object.keys(data).forEach((key) => {
              params = params.set(key, data[key]);
            });
            this._http.delete(this._restv2api + url, {headers: headers, params}).subscribe(
              data1 => {
                resolve(data1);
              },
              error => {
                this.showServerError(error);
              }
            );
          } else {
            this._http.delete(this._restv2api + url, {headers}).subscribe(
              data1 => {
                resolve(data1);
              },
              error => {
                this.showServerError(error);
              }
            );
          }

        } else if (method === 'get') {
          // let params: { appid: 'id1234', cnt: '5' }

          if (data) {
            let params = new HttpParams();
            Object.keys(data).forEach((key) => {
              params = params.set(key, data[key]);
            });
            this._http.get(this._restv2api + url, {headers: headers, params}).subscribe(
              data1 => {
                resolve(data1);
              },
              error => {
                this.showServerError(error);
              }
            );
          } else {
            this._http.get(this._restv2api + url).subscribe(
              data1 => {
                resolve(data1);
              },
              error => {
                this.showServerError(error);
              }
            );
          }
        }
      }
    );
  }

  /*****************************************************************************************/
  public callApiObservable(url, data, method, isForm?, isPublic?): Observable<any> {

    let headers;
    const self = this;
    if (isPublic) {
      headers = new HttpHeaders({'Content-Type': 'application/json;charset=UTF-8'});
    } else {
      headers = new HttpHeaders({'Content-Type': 'application/json; charset=UTF-8'});
    }
    if (isForm) {
      headers = new HttpHeaders({'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryRe0enSh66PyAdIBr'});
    }

    let apiCount = 1;
    if (method === 'post') {
      headers.append('Access-Control-Allow-Origin', '*');
      return this._http.post(this._restv2api + url, data, headers).pipe(
        map(response => response),
        catchError((e: any) => {
          //do your processing here
          if (e.status !== 400) {
            this.showServerError(e)
          }
          if (apiCount === this.apiRetryCount) {
            this.showServerError(e)
          }
          return Observable.throw(e);
        }),
      ).retryWhen((errors) => {
        return errors
          .mergeMap((error) => {
            apiCount++;
            if (error && error.status === 400) {
              return Observable.of(error)
            } else {

              return Observable.throw(error)
            }
          })
          .delay(this.apiRetryDelay)
          .take(this.apiRetryCount);
      })
    } else if (method === 'put') {
      // let params: { appid: 'id1234', cnt: '5' }

      headers.append('Access-Control-Allow-Origin', '*');
      return this._http.put(this._restv2api + url, data, headers).pipe(
        map(response => response),
        catchError((e: any) => {
          //do your processing here
          if (e.status !== 400) {
            this.showServerError(e)
          }
          if (apiCount === this.apiRetryCount) {
            this.showServerError(e)
          }
          return Observable.throw(e);
        }),
      ).retryWhen((errors) => {
        return errors
          .mergeMap((error) => {
            apiCount++;
            if (error && error.status === 400) {
              return Observable.of(error)
            } else {
              return Observable.throw(error)
            }
          })
          .delay(this.apiRetryDelay)
          .take(this.apiRetryCount);
      })
    } else if (method === 'delete') {
      // let params: { appid: 'id1234', cnt: '5' }
      if (data) {
        let params = new HttpParams();
        Object.keys(data).forEach((key) => {
          params = params.set(key, data[key]);
        });
        return this._http.delete(this._restv2api + url, {headers: headers, params}).pipe(
          map(response => response),
          catchError((e: any) => {
            //do your processing here
            if (e.status !== 400) {
              this.showServerError(e)
            }
            if (apiCount === this.apiRetryCount) {
              this.showServerError(e)
            }
            return Observable.throw(e);
          }),
        ).retryWhen((errors) => {
          return errors
            .mergeMap((error) => {
              apiCount++;
              if (error && error.status === 400) {
                return Observable.of(error)
              } else {

                return Observable.throw(error)
              }
              // return ?  Observable.of(error) : Observable.throw(error)
            })
            .delay(this.apiRetryDelay)
            .take(this.apiRetryCount);
        })
      } else {
        return this._http.delete(this._restv2api + url, {headers}).pipe(
          map(response => response),
          catchError((e: any) => {
            //do your processing here
            if (e.status !== 400) {
              this.showServerError(e)
            }
            if (apiCount === this.apiRetryCount) {
              this.showServerError(e)
            }
            return Observable.throw(e);
          }),
        ).retryWhen((errors) => {
          return errors
            .mergeMap((error) => {
              apiCount++;
              if (error && error.status === 400) {
                return Observable.of(error)
              } else {

                return Observable.throw(error)
              }
            })
            .delay(this.apiRetryDelay)
            .take(this.apiRetryCount);
        })
      }

    } else if (method === 'get') {
      // let params: { appid: 'id1234', cnt: '0' }

      if (data) {
        let queryParams = {};
        Object.keys(data).forEach((key) => {
          queryParams[key] = data[key];
        });
        return this._http.get(this._restv2api + url, {headers: headers, params: queryParams}).pipe(
          map(response => response),
          catchError((e: any) => {
            //do your processing here
            if (e.status !== 400) {
              this.showServerError(e)
            }
            if (apiCount === this.apiRetryCount) {
              this.showServerError(e)
            }
            return Observable.throw(e);
          }),
        ).retryWhen((errors) => {
          return errors
            .mergeMap((error) => {
              apiCount++;
              if (error && error.status === 400) {
                return Observable.of(error)
              } else {

                return Observable.throw(error)
              }
            })
            .delay(this.apiRetryDelay)
            .take(this.apiRetryCount);
        })
      } else {
        return this._http.get(this._restv2api + url).pipe(
          map(response => response),
          catchError((e: any) => {
            //do your processing here
            if (e.status !== 400) {
              this.showServerError(e)
            }
            if (apiCount === this.apiRetryCount) {
              this.showServerError(e)
            }
            return Observable.throw(e);
          }),
        ).retryWhen((errors) => {
          return errors
            .mergeMap((error) => {
              apiCount++;
              if (error && error.status === 400) {
                return Observable.of(error)
              } else {

                return Observable.throw(error)
              }
            })
            .delay(this.apiRetryDelay)
            .take(this.apiRetryCount);
        })
      }
    }
  }

  displayToaster(type, messages, timeout?, customTitle?) {
    if (!timeout) {
      timeout = 5000;
    }
    if (!customTitle) {
      customTitle = '';
    }

    if (messages) {
      if (messages.length > 0) {
        if (timeout === undefined) {
          timeout = 5000;
        }
        // let messageBody = `<ul>`;
        // for (let i = 0; i < messages.length; i++) {
        //     messageBody += `<li>` + messages[i] + `</li>`;
        // }
        let messageBody = messages;
        // messageBody += `</ul>`;
        const title = customTitle;
        if (type === 'success') {
          this.toastrService.success(messageBody, title, { enableHtml: true, closeButton: true, timeOut: timeout });
        } else if (type === 'error') {
          this.toastrService.error(messageBody, title, { enableHtml: true, closeButton: true, timeOut: timeout });
        } else if (type === 'warning') {
          this.toastrService.warning(messageBody, title, { enableHtml: true, closeButton: true, timeOut: timeout });
        } else if (type === 'info') {
          this.toastrService.info(messageBody, title, { enableHtml: true, closeButton: true, timeOut: timeout });
        } else if (type === 'wait') {    // with loading gif
          this.toastrService.warning(messageBody, title, { enableHtml: true, closeButton: true, timeOut: timeout });
        }
      }
    }
  }


  count = 0;
  login(){
    let data = {
      // authInput: this.user.authInput,
      // password: this.user.password
      "clientID":1047, "groupID":272, "portalUserID":2, "moduleID":3, "fields":[], "username":"dasdas"
    }
    this.callApi('RegisterService/register_create', data, 'post', false, false).then((success:any) => {
      // console.log("after login api getting data is", success);
      if(success){
        this.count = 0;
        this.setToken('accessToken',success.key);
        this.router.navigate(['onlineOrdering/select']);
      }
    });
  }
  /*****************************************************************************************/
  // @PURPOSE      	: 	To show server error
  /*****************************************************************************************/
  public showServerError(error) {
    this.count = 0;
    // if(error.status === 403 && this.count < 3){
    //   this.login();
    //   this.count++;
    // } else {
    //
    // }
    if(error.status === 403){
      this.clearToken();
      // this.router.navigate(['']);
      if (environment.envnName === constants.enviromentValues.DMH) {
        window.location.href = 'https://www.mykonicaminolta.com';
      } else {
        this.router.navigate([window.location.host]);
      }
      this.displayToaster('error','Something went wrong');
      return
    }
    if(error.message) {
      this.displayToaster('error','Something went wrong');
    }
    // this.broadcaster.broadcast('stopChat', true);
    // $('#reLoginModal').modal('show');
  }

  /****************************************************************************/
  getMyAccount(friendUser?) {
    var userID = 0; if(friendUser) userID = friendUser.userID;
    let data = {
      userID : userID, moduleID: 0
    }
    const observable = from(this.callApiRestV2('shared/getUser', data, 'post'));
    return observable;
  }

  setSecurePath(token?) {
    if (token === undefined || token.length === 0) {
      return 'do';
    }
    return '';
  }

  attachToken(dataObj, token?) {
    if (token === undefined || token.length === 0) {
      return dataObj;
    }
    return Object.assign({}, dataObj, {token: token});
  }

    isCCEP(): string {
        if (environment.envnName === constants.enviromentValues.DMH) {
            return constants.ASSETS_CATALOUGUE_KMBS;
        } else  if (environment.envnName === constants.enviromentValues.cokeMain) {
            return constants.ASSETS_CATALOUGUE_COKE;
        }
    }

  /****************************************************************************/

}
