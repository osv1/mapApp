import {Pipe, PipeTransform} from '@angular/core';

declare var moment: any;

@Pipe({
  name: 'utcFilter'
})
export class UTCFilterPipe implements PipeTransform {
  transform(input: any, format?: string): any {
    if (!format) {
      format = 'DD/MM/YYYY';
    }
    const newDate = new Date();
    newDate.setTime(input);
    const dateString = newDate.toUTCString();
    // return timeService.utcToLocalWithFormat(dateString, format);
    let momentTime;
    if (!dateString) {              // time in string format
      if (dateString.indexOf('+0000') === -1) {
        momentTime = moment(dateString).add(moment(dateString).utcOffset(), 'm');
        // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
      } else {
        momentTime = moment(dateString);
        // utc date/time format "2016-08-19T13:53:25.000+0000" will be converted to local time automatically
      }
    } else {
      // millisecond time - when the date/time value has right timezone set there is no need to do timezone here
      momentTime = moment(dateString);
    }
    const formattedLocalTime = momentTime.format(format);
    return formattedLocalTime;
  }
}
