import { TestBed, fakeAsync, tick, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { BaseComponent } from './commonComponent';
import { DataService } from './DataService';
describe('DataService', () => {
    let dataService: DataService;
    const data = { orderID: 8796, orderItemID: 22773, jtemplateID: 10333 };
    beforeEach(() => {
        dataService = new DataService();
        dataService.setCustomizeItemData(data);
    });
    it('should have return data', () => {
        let responseData;
        dataService.itemData.subscribe(sucess => {
            responseData = sucess;
        });
        expect(responseData).toEqual(data);
    });
});
