import {
  Component,
  OnInit,
  PLATFORM_ID,
  Injector,
  NgZone,
  APP_ID,
  ViewContainerRef,
  EmbeddedViewRef, ComponentFactoryResolver, ApplicationRef
} from '@angular/core';
import {Title, Meta, DomSanitizer} from '@angular/platform-browser';
import {LogService} from './log.service';
import {isPlatformBrowser} from '@angular/common';
import {Router, ActivatedRoute, NavigationEnd} from '@angular/router';
import {CommonService} from './common.service';
import {ErrorMessages} from './errorMessages';
import {HttpClient} from '@angular/common/http';
import {ToastrService} from 'ngx-toastr';
import {DataService} from './DataService';
import {TranslateService, TranslationChangeEvent} from '@ngx-translate/core';
import swal from 'sweetalert2';
import {Broadcaster} from './BroadCaster';
import {LocationStrategy} from '@angular/common';

import * as constants from './constants';
import {FileUploaderService} from "./fileUploader.service";
import {environment} from "../../environments/environment";



declare var moment: any;
declare var $: any;

@Component({
  selector: 'app-parent-comp',
  template: ``,
  providers: []
})

export class BaseComponent implements OnInit {
  defultInputFormat = 'DD/MM/YYYY HH:mm';

  constructor(public injector: Injector) {
    this.router = injector.get(Router);
    // this.swal = injector.get(swal);
    this.swal = swal;
    this.componentFactoryResolver = injector.get(ComponentFactoryResolver);
    this.platformId = injector.get(PLATFORM_ID);
    this.logService = injector.get(LogService);
    this.appId = injector.get(APP_ID);
    this.fileUploaderService = injector.get(FileUploaderService);
    this.commonService = injector.get(CommonService);
    this.http = injector.get(HttpClient);
    this.titleService = injector.get(Title);
    this.metaService = injector.get(Meta);
    this.activatedRoute = injector.get(ActivatedRoute);
    this.baseUrl = this.commonService._apiUrl;
    this.imageUrl = this.commonService._imageUrl;
    this.authUrl = this.commonService._authUrl;
    this.broadcaster = injector.get(Broadcaster);
    this.landingUrl = this.commonService._landingUrl;
    this.REMOTE_PAYMENT_APIKEY = this.commonService._REMOTE_PAYMENT_APIKEY;
    this.errorMessage = injector.get(ErrorMessages);
    this.DataService = injector.get(DataService);
    this.translate = injector.get(TranslateService);
    this.constants = constants.constants;
    this.downloadUrl = this.commonService._downloadUrl;
    this.appRef = injector.get(ApplicationRef);
    this.sanitizer = injector.get(DomSanitizer);
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.routeUrl = event.urlAfterRedirects;
      }
    });
    this.$ = $;
    this.moment = moment;
    this.location = injector.get<LocationStrategy>(LocationStrategy as any);
    this.toastrService = injector.get(ToastrService);
    this.translate.setDefaultLang('messages');
    this.translate.onTranslationChange.subscribe((event: TranslationChangeEvent) => {
      // console.log(event);
    });
    if (this.getCookie('SSGLang')) {
      this.langCode = this.getCookie('SSGLang');
      this.languageName = this.getCookie('languageName')
      this.language = 'messages_' + this.langCode;
      this.translate.setDefaultLang(this.language);
    } else {
      this.language = 'messages';
      this.translate.setDefaultLang(this.language);
    }
    this.CM_Url = this.commonService._CM_Url;
    this.frontUrl = this.commonService._frontUrl;
  }

  public logService;
  public stepArray = [];
  public frontUrl;
  public activeCampaignjobID;
  public moment: any;
  public CM_Url;
  public $: any;
  public budgetServiceUrlMain = '/BudgetService/v1';
  public budgetsURL = '/budgets';
  public constants;
  public componentFactoryResolver;
  public landingUrl;
  public authUrl;
  public sanitizer;
  public appRef;
  public broadcaster: Broadcaster;
  public location;
  public swal: any;
  public imageUrl;
  public langCode = 'en';
  public languageName = 'English';
  public language = 'messages';
  public defaultFormat = 'YYYY-MM-DD HH:mm';
  public translate: TranslateService;
  public REMOTE_PAYMENT_APIKEY;
  public routeUrl;
  public toastrService: ToastrService;
  public activatedRoute: ActivatedRoute;
  public errorMessage: ErrorMessages;
  public titleService: Title;
  public metaService: Meta;
  public platformId: any;
  public appId: any;
  public DataService: DataService;
  public http;
  public router: Router;
  public commonService: CommonService;
  public cookieService;
  public baseUrl;
  public downloadUrl;
  public userDateFormatAng: any = '';
  public fileUploaderService: FileUploaderService;


  ngOnInit() {
    this.updateDatePrefs();
  }

  // *************************************************************//
  // @Purpose : We can use following function to use localstorage
  // *************************************************************//

  setCookie(key, value) {
    document.cookie = key + '=' + value + ';path=/';
  }

  setCookiePath(key, value) {
    document.cookie = key + '=' + value + ';path=/CM/CM/viewService/display';
  }

  getCookie(key) {
    const value = '; ' + document.cookie;
    const parts = value.split('; ' + key + '=');
    if (parts.length === 2) {
      return parts.pop().split(';').shift();
    } else {
      return '';
    }
  }
  removeCookie(key) {
    this.cookieService.delete(key);
  }

  updateDatePrefs() {
    // var ret = sharedService.getUserPreferenceOptions();
    this.commonService.callApi(this.setSecurePath() + '/shared/getUserPreferenceOptions', this.attachToken({userID: 0}), 'post').then(
      (res: any) => {
        if (res.statusCode == 200) {
          let userDateFormat: any = res.instance.userdateformat.value;
          if (userDateFormat) {
            this.userDateFormatAng = userDateFormat.replace("aa", "a");
          }
        }
      }
    );
  }

  public getToken(key) {
    if (isPlatformBrowser(this.platformId)) {
      return window.localStorage.getItem(key);
    }
  }

  public setToken(key, value) {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.setItem(key, value);
    }
  }

  public getSession(key) {
    if (isPlatformBrowser(this.platformId)) {
      return window.sessionStorage.getItem(key);
    }
  }

  public setSession(key, value) {
    if (isPlatformBrowser(this.platformId)) {
      window.sessionStorage.setItem(key, value);
    }
  }

  public removeSession(key) {
    if (isPlatformBrowser(this.platformId)) {
      window.sessionStorage.removeItem(key);
    }
  }

  removeToken(key) {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.removeItem(key);
    }
  }

  clearToken() {
    if (isPlatformBrowser(this.platformId)) {
      window.localStorage.clear();
    }
  }

  // *************************************************************//

  // *************************************************************//
  // @Purpose : We can use following function to use Toaster Service.
  // *************************************************************//


  displayToaster(type, messages, timeout?, customTitle?) {
    if (!timeout) {
      timeout = 5000;
    }
    if (!customTitle) {
      customTitle = '';
    }
    if (messages.length > 0) {
      if (timeout === undefined) {
        timeout = 5000;
      }
      let messageBody = `<ul>`;
      for (let i = 0; i < messages.length; i++) {
        messageBody += `<li>` + messages[i] + `</li>`;
      }
      messageBody += `</ul>`;
      const title = customTitle;
      if (type === 'success') {
        this.toastrService.success(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
      } else if (type === 'error') {
        this.toastrService.error(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
      } else if (type === 'warning') {
        this.toastrService.warning(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
      } else if (type === 'info') {
        this.toastrService.info(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
      } else if (type === 'wait') {    // with loading gif
        this.toastrService.warning(messageBody, title, {enableHtml: true, closeButton: true, timeOut: timeout});
      }
    }
  }

  logout() {
    document.cookie.split(';').forEach(function (c) {
      document.cookie = c.replace(/^ +/, '').replace(/=.*/, '=;expires=' + new Date().toUTCString() + ';path=/');
    });
    this.router.navigate(['/form/combinedList']);
  }

  /****************************************************************************
   @PURPOSE      : To restrict or allow some values in input.
   @PARAMETERS   : $event
   @RETURN       : Boolen
   ****************************************************************************/
  RestrictSpace(e) {
    if (e.keyCode == 32) {
      return false;
    } else {
      return true;
    }
  }

  /****************************************************************************
   @PURPOSE      : To show validation message
   @PARAMETERS   : <field_name, errorObj?>
   @RETURN       : error message.
   ****************************************************************************/
  showError(field, errorObj?) {
    return this.errorMessage.getError(field, errorObj);
  }

  changeLanguage(langCode) {
    console.log("langCode", langCode.languageType);
    if (langCode.languageType) {
      this.setCookie('SSGLang', langCode.languageType);
      this.setCookie('languageName', langCode.languageName);
      this.setCookiePath('languageName', langCode.languageName);
      this.setCookiePath('SSGLang', langCode.languageType);
      this.languageName = langCode.languageName;
      this.langCode = langCode.languageType;
      this.language = 'messages_' + langCode.languageType;
      this.translate.setDefaultLang(this.language);
      this.router.navigate([this.routeUrl]);
    } else {
      this.langCode = 'en';
      this.setCookie('SSGLang', 'en');
      this.setCookiePath('SSGLang', 'en');
      this.setCookie('languageName', 'English');
      this.setCookiePath('languageName', 'English');
      this.languageName = 'English';
      this.language = 'messages_en';
      this.translate.setDefaultLang(this.language);
      this.router.navigate([this.routeUrl]);
    }
  }

  checkActiveLink(url) {
    if (this.routeUrl) {
      if (this.routeUrl.includes(url)) {
        return 'active';
      } else {
        return 'Inactive';
      }
    }
    return 'Inactive';
  }

  setSecurePath(token?) {
    if (token === undefined || token.length === 0) {
      return 'do';
    }
    return '';
  }

  attachToken(dataObj, token?) {
    if (token === undefined || token.length === 0) {
      return dataObj;
    }
    return Object.assign({}, dataObj, {token: token});
  }

  getDefaultDateFormat() {
    return this.defultInputFormat;
  }

  utcToLocalDate(strUtcDateTimeOrTimeInMils) {
    if (strUtcDateTimeOrTimeInMils === null) {
      return '';
    }
    let momentTime;
    if (isNaN(strUtcDateTimeOrTimeInMils)) {              // time in string format
      if (strUtcDateTimeOrTimeInMils.indexOf('+0000') === -1) {
        momentTime = moment(strUtcDateTimeOrTimeInMils).add(moment(strUtcDateTimeOrTimeInMils).utcOffset(), 'm');
        // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
      } else {
        momentTime = moment(strUtcDateTimeOrTimeInMils);
        // utc date/time format "2016-08-19T13:53:25.000+0000" will be converted to local time automatically
      }
    } else {
      // millisecond time - when the date/time value has right timezone set there is no need to do timezone here
      momentTime = moment(strUtcDateTimeOrTimeInMils);
    }
    const localTime = momentTime.toDate();    // return as javascript Date obj
    return localTime;
  }

  toFixedValue(num, qty) {
    if (num * qty) {
      let amount = num * qty
      let num1 = parseFloat(amount.toString());
      return num1.toFixed(2)
    }
  }


  setSelectPriceWithDiscount(onlineProduct, qty) {
    // console.log(onlineProduct)
    let isFound = false;
    if (onlineProduct.discounts) {
      if (onlineProduct.discounts.length) {
        let price = 0;
        if (onlineProduct.discounts[0].tiers.length) {
          // console.log("onlineProduct.discounts[0].tiers",onlineProduct.discounts[0].tiers);
          onlineProduct.discounts[0].tiers.map(res => {
            if (!isFound) {
              // console.log("----", Number(qty) <= Number(res.quantity));
              if (Number(qty) <= Number(res.quantity)) {
                //console.log("----",res.quantity);
                price = res.price;
                isFound = true;

              }
            }
          });
          //console.log("----",price);
          let amount = price * qty;
          //console.log("amount",amount);
          let num1 = parseFloat(amount.toString());
          return num1.toFixed(2)
        }
      }
    } else {
      if (onlineProduct.price * qty) {
        let amount = onlineProduct.price * qty
        let num1 = parseFloat(amount.toString());
        return num1.toFixed(2)
      }
    }
  }

  /*********************************************/
  /*               utc to LOCAL                */
  /*********************************************/

  // return String - UTC datetime to local datetime - when fetching dates from the server
  utcToLocal(strUtcDateTimeOrTimeInMils) {
    let momentTime;
    if (isNaN(strUtcDateTimeOrTimeInMils)) {              // time in string format
      if (strUtcDateTimeOrTimeInMils.indexOf('+0000') == -1) {
        momentTime = moment(strUtcDateTimeOrTimeInMils).add(moment(strUtcDateTimeOrTimeInMils).utcOffset(), 'm');
      } else {
        momentTime = moment(strUtcDateTimeOrTimeInMils);    // utc date/time format "2016-08-19T13:53:25.000+0000" will be converted to local time automatically
      }
    } else {
      // millisecond time - when the date/time value has right timezone set there is no need to do timezone here
      momentTime = moment(strUtcDateTimeOrTimeInMils);//.add( moment(strUtcDateTimeOrTimeInMils).utcOffset(), 'm' );
    }
    var formattedLocalTime = momentTime.format(this.defaultFormat);
    return formattedLocalTime;
  }

  localToUtc(strLocalDateTime) {
    // utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
    const momentTime = moment(strLocalDateTime).subtract(moment(strLocalDateTime).utcOffset(), 'm');
    const formattedUtcDateTime = momentTime.format(this.defaultFormat);
    return formattedUtcDateTime;
  }

  convertComponentToDom(component, modalId?, ModalContentId?) {
    const componentRef = this.componentFactoryResolver
      .resolveComponentFactory(component)
      .create(this.injector);
    // Attach component to the appRef so that it's inside the ng component tree
    this.appRef.attachView(componentRef.hostView);
    const domElem: any = (componentRef.hostView as EmbeddedViewRef<any>)
      .rootNodes[0] as HTMLElement;
    if (modalId && ModalContentId) {
      this.openModal(domElem, modalId, ModalContentId)
    } else {
      this.openModal(domElem)
    }
  }

  openModal(content, modalId?, ModalContentId?) {
    if (modalId && ModalContentId) {
      $('#' + modalId).modal('show');
      document.getElementById(ModalContentId).innerHTML = '';
      document.getElementById(ModalContentId).appendChild(content);
    } else {
      $('#parentLargeModal').modal('show');
      document.getElementById("modalContent").innerHTML = '';
      document.getElementById("modalContent").appendChild(content);
    }
  }

  closeModel(id?) {
    if (id) {
      $('#' + id).modal('hide');
    } else {
      $('#parentLargeModal').modal('hide');
    }
  }

  // get checked options for multipleselect field - different from fieldValue
  setFlaggedValeForMultiselect(metadadaList) {
    var selectedOptions;
    metadadaList.map(function (meta) {

      if (meta.fieldDisplayType.toLowerCase() == 'multipleselect') {
        setTimeout(function () {
          $('.multi-test-dd').on('click', function (e) {
            e.stopPropagation();
          });
        }, 2000);

        selectedOptions = [];
        meta.multiValues.filter(function (option) {
          if (option.flag) {
            selectedOptions.push(option.displayName)
          }
        })

        // when there is any checked option, set flaggedValue for display
        if (selectedOptions.length > 0) {
          meta.flaggedValue = selectedOptions.join(', ');
          if (meta.flaggedValue.length >= 45) {
            meta.flaggedValue = meta.flaggedValue.substring(0, 45) + '...';
          }

          // when alll items are checked
          if (selectedOptions.length == meta.multiValues.length) {
            meta.all = true;
          }
        }
      }
    });
  }

  display(type, messages) {
    if (messages.length > 0) {
      var title = "";

      if (type == 'error')
        title = "Error";
      else if (type == 'Warning')
        title = "Warning";
      else if (type == 'info')
        title = "Information";

      var messageBody = "<ul>";
      for (let i = 0; i < messages.length; i++) {
        messageBody += "<li>" + messages[i] + "</li>";
      }
      messageBody += "</ul>";
      if (type === 'success') {
        this.toastrService.success(messageBody, title, {enableHtml: true, closeButton: true, timeOut: 300000});
      } else if (type === 'Error') {
        this.toastrService.error(messageBody, title, {enableHtml: true, closeButton: true, timeOut: 300000});
      } else if (type === 'Warning') {
        this.toastrService.warning(messageBody, title, {enableHtml: true, closeButton: true, timeOut: 300000});
      } else if (type === 'Information') {
        this.toastrService.info(messageBody, title, {enableHtml: true, closeButton: true, timeOut: 300000});
      } else if (type === 'wait') {    // with loading gif
        this.toastrService.warning(messageBody, title, {enableHtml: true, closeButton: true, timeOut: 300000});
      }
      // toaster.pop({
      //     type: type,
      //     title: title,
      //     body: messageBody,
      //     timeout: 300000,
      //     bodyOutputType: 'trustedHtml',
      //     showCloseButton: true
      // });
      return false;
    } else {
      return true;
    }
  }

  AllowNumbers(e) {
    var input;
    if (e.metaKey || e.ctrlKey) {
      return true;
    }
    if (e.which === 32) {
      return false;
    }
    if (e.which === 0) {
      return true;
    }
    if (e.which < 33) {
      return true;
    }
    if (e.which === 43 || e.which === 45) {
      return true;
    }
    if (e.which === 36 || e.which === 35) {
      return true;
    }
    if (e.which === 37 || e.which === 39) {
      return true;
    }
    input = String.fromCharCode(e.which);
    return !!/[\d\s]/.test(input);
  }

  // common function used for Campaign/Job/JobStage to get string input of metadata fields - 'fieldID|,|fieldValue' pairs
  prepMetadataForSubmission(metaList, id, isPressJob?, isAddAsset?, isTaskCopy?, isProcurement?, addNooshProjectId?) { //isPressJob used to allow noneditable fields to get values
    // create a array of string 'fieldID|,|fieldValue' pairs  TODO may just pass changed values by keeping a copy of original
    var metaIdValuePairs = [];
    //angular.forEach(metaList, function (meta, index) {
    if (metaList != null || metaList != undefined) {
      for (var index = 0; index < metaList.length; index++) {     // use for loop to break out of looping
        var meta = metaList[index];
        // extra care for date and other spcial display types
        if (meta.fieldDisplayType.toLowerCase().indexOf('noneditable') == -1 || isPressJob || (addNooshProjectId && addNooshProjectId == true && meta.fieldName == 'NooshProjectID') || (meta.fieldName == this.constants.METADATA_PROJECT_NAME_FIELD_NAME)) {  // Press job needs to allow noneditable fields to be updated

          if (meta.fieldDisplayType == this.constants.FIELD_DISPLAY_DATE) { // update date format to make the field eligible for database insert
            if (meta.fieldValue != '') {
              meta.fieldValue = this.localToUtcWithInputFormat(meta.fieldValue);
            }
            // jquery plugin version
            /*meta.fieldValue = $('#date-' + id + '-' + meta.fieldID).val();
             if ( meta.fieldValue == undefined ) {
             meta.fieldValue = '';
             }*/
          } else if (meta.fieldDisplayType == this.constants.FIELD_DISPLAY_MULTIPLE_SELECT) {
            if (isAddAsset) {
              if (meta.fieldValue) {
                meta.fieldValue = meta.fieldValue.toString();
              }
            } else {
              var checked = '';
              meta.multiValues.forEach((selectOpt, index) => {
                if (selectOpt.selected != '') {
                  checked = checked + ',' + selectOpt.selected;
                }
              });
              meta.fieldValue = checked.substring(1);
            }
          }

          // mandatory field checkup
          if (meta.mandatory && (meta.fieldValue === '' || meta.fieldValue == null || (meta.fieldDisplayType == 'file' && meta.fieldValue == 0))) {
            // updated to use fieldName
            if (isProcurement && meta.fieldName.toLowerCase() == 'contact' /*meta.fieldID=='62'*/) {//skip checking ergo contact ID if procurement channel is added after import
            } else {
              return null;
            }

          }

          //metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);

          if (isTaskCopy) {
            metaIdValuePairs.push(meta.fieldID + '_' + meta.jobMetaDataID /*taskCopyUD*/ + '|-|' + meta.fieldValue + '|,|');

          } else {

            if (meta.fieldID == undefined) {  // Filestor 3.7 metadata
              metaIdValuePairs.push(meta.fieldName + '|=|' + meta.fieldValue);
            } else {                            // JAS metadata
              if (meta.fieldValue.id == undefined) {
                metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue);
              } else {  // in case of id is used for value
                metaIdValuePairs.push(meta.fieldID + '|,|' + meta.fieldValue.id);
              }
            }
          }
        }
      }
    }
    //});
    return metaIdValuePairs;
  }

  // to convert object to query params
  serialize(obj) {
    var str = [];
    for (var p in obj)
      if (obj.hasOwnProperty(p)) {
        str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
      }
    return str.join("&");
  }


  /*********************************************/
  /*               local to UTC                */
  /*********************************************/
  // return String - local datetime to UTC datetime - when submitting dates to the server
  // input format - e.g DD/MM/YYYY HH:mm
  localToUtcWithInputFormat(strLocalDateTime, inputFormat?) {
    // when input format is not set use default
    if (!inputFormat) {
      inputFormat = this.defultInputFormat;//'DD/MM/YYYY HH:mm';
    }

    //utc offset depending on the date - daylight saving will add +1 hour on top of normal offset
    // var momentTime = this.moment(strLocalDateTime, inputFormat).subtract(this.moment(strLocalDateTime, inputFormat).utcOffset(), 'm');
    const momentTime = moment(strLocalDateTime).subtract(moment(strLocalDateTime).utcOffset(), 'm');
    var formattedUtcDateTime = momentTime.format(this.defaultFormat);
    return formattedUtcDateTime;
  }

  getTranslateWord(key){
    let message = '';
    this.translate.get(key).subscribe((res: string) => {
      message = res;
    });
    return message;
  }
    isCCEP(): string {
        if (environment.envnName === this.constants.enviromentValues.DMH) {
            return this.constants.ASSETS_CATALOUGUE_KMBS;
        } else  if (environment.envnName === this.constants.enviromentValues.cokeMain) {
            return this.constants.ASSETS_CATALOUGUE_COKE;
        }
    }

}
