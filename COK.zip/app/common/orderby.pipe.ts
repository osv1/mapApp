import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
    name: 'orderBy'
})
export class OrderByPipe implements PipeTransform {
    transform(array: any, field: string,decending?): any[] {
        if (!Array.isArray(array)) {
            return;
        }
        if(decending){
            array.sort((a: any, b: any) => {
                if (b[field] === undefined) {
                    return b[field];
                } else if (a[field] === undefined) {
                    return a[field];
                } else if (b[field].toLowerCase() < a[field].toLowerCase()) {
                    return -1;
                } else if (b[field].toLowerCase() > a[field].toLowerCase()) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }else {
            array.sort((a: any, b: any) => {
                if (a[field] === undefined) {
                    return a[field];
                } else if (b[field] === undefined) {
                    return b[field];
                } else if (a[field].toLowerCase() < b[field].toLowerCase()) {
                    return -1;
                } else if (a[field].toLowerCase() > b[field].toLowerCase()) {
                    return 1;
                } else {
                    return 0;
                }
            });
        }
        return array;
    }
}
