import { ErrorMessages } from './errorMessages';
import { TestBed } from '@angular/core/testing';
describe('ErrorMessages', () => {
    let errorMessageHelper: ErrorMessages;
    beforeEach(() => {
        errorMessageHelper = TestBed.get(ErrorMessages);
    });
    it('should create the Error Message Helper', () => {
        expect(errorMessageHelper).toBeTruthy();
    });
    it('should have getError function', () => {
        expect(errorMessageHelper.getError).toBeTruthy();
    });
    it('should have return error Enter email address', () => {
        expect(errorMessageHelper.getError('email', { required: true })).toEqual('Enter email address');
    });
});
