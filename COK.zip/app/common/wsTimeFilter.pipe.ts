import {Pipe, PipeTransform} from '@angular/core';
import {DatePipe} from '@angular/common';

@Pipe({
  name: 'wsTimeFilter'
})
export class WsTimeFilterPipe implements PipeTransform {
  transform(input: any, format?: string): any {
    if (!format) {
      format = 'h:mma';
    }


    const offset = new Date().getTimezoneOffset();
    const o = Math.abs(offset);
    const timezone = (offset < 0 ? '+' : '-') + ('00' + Math.floor(o / 60)).slice(-2) + ':' + ('00' + (o % 60)).slice(-2);
    const datePipe = new DatePipe('en-US');
    return datePipe.transform(input, format, timezone);
  }
}
