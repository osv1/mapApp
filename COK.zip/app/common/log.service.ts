import {Injectable} from '@angular/core';
import {from, Observable} from "rxjs";
import * as constants from './constants';
import { CommonService } from './common.service';
import { HttpClient } from '@angular/common/http';
// import * as ip from 'ip';

@Injectable()
export class LogService {


  constructor(private commonService : CommonService , private _http:HttpClient){
  }











  createLog(events){
    let ipInfo : any = {};
    this._http.get('https://api.ipify.org?format=json').subscribe((res) => {
      console.log(res);
      ipInfo.ip = (<any>res).ip;
      let data ={
        "attributes": events.attributes ? events.attributes : '',
        "categoryId": events.categoryId ? events.categoryId : '',
        "model":events.model ? events.model : '',
        "eventTypeId":events.event_id,
        "event_desc" : events.event_desc,
        "deviceUsed": window.navigator.userAgent,
        "geographicalLocation": "",
        "ipAddress": ipInfo.ip,
        "jTemplateId": events.jTemplateId ? events.jTemplateId : '',
        "message": events.message ? events.message : '',
        "productId": events.productId ? events.productId : '',
        "templateId": events.templateId ? events.templateId : '',
        "CompanyName" :  events.companyName ? events.companyName : '',
        "Territory" : events.territory ? events.territory : '',
        "Region" : events.region ? events.region : '',
        "RoleName" : events.roleName ? events.roleName : '',
      }
      const observable = from(this.commonService.callApi('commerceService/v1/event/log/',data,'post',true));
      return observable;
    });

  }
}
