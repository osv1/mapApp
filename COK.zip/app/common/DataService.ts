import {Injectable} from '@angular/core';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';

@Injectable()
export class DataService {


    constructor() {
    }

    private customizeItemData = new BehaviorSubject<any>([]);
    itemData = this.customizeItemData.asObservable();

    setCustomizeItemData(data: any) {
        this.customizeItemData.next(data);
    }
}
