import {BrowserModule} from '@angular/platform-browser';
import {NgModule, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {AppComponent} from './app.component';


import {ToastrModule} from 'ngx-toastr';
import {TranslateModule, TranslateLoader} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';
import {LoadingBarHttpClientModule} from '@ngx-loading-bar/http-client';
import {ImageCropperModule} from 'ngx-image-cropper';
import {NgxMaskModule, IConfig} from 'ngx-mask';
// import { HighchartsChartModule } from 'highcharts-angular';
import {NgCircleProgressModule} from 'ng-circle-progress';

export const options: Partial<IConfig> | (() => Partial<IConfig>) = {};

// Common

import {BaseComponent} from './common/commonComponent';
import {CanLoginActivate, CanAuthActivate} from './common/auth.gaurd';
import {DataService} from './common/DataService';
import {SmartSearchPipe} from './common/smart-search.pipe';
import {EmojiPipe} from './common/emoji.pipe';
import {OrderByPipe} from './common/orderby.pipe';
import {UTCFilterPipe} from './common/utcFilter.pipe';
import {WsTimeFilterPipe} from './common/wsTimeFilter.pipe';
import {ToArrayPipe} from './common/toArray.pipe';
import {TruncatePipe} from './common/limitTo.pipe';
import {Broadcaster} from './common/BroadCaster';
import {GroupByPipe} from './common/groupBy.pipe';
import {MapToIterable} from './common/iterable.pipe';
import {LoginComponent} from './public/login/login.component';
import {OnlineOrderingService} from './main/online-ordering/online-ordering-select/online-ordering.service';
import {DmhHeaderComponent} from './main/dmh-header/dmh-header.component';
import {DmhFooterComponent} from './main/dmh-footer/dmh-footer.component';
import {MainComponent} from './main/main.component';
import {UserdetailComponent} from './main/userdetail/userdetail.component';
import {AppRoute} from '../environments/general/approutes';
import {HelpAndSupportComponent} from './main/help-and-support/help-and-support.component';
import {OnlineOrderingCustomizeComponent} from './main/online-ordering/online-ordering-customize/online-ordering-customize.component';
import {OnlineOrderingPreviewComponent} from './main/online-ordering/online-ordering-preview/online-ordering-preview.component';
import {OnlineOrderingPreviewService} from './main/online-ordering/online-ordering-preview/online-ordering-preview.service';

import {OnlineOrderingSelectComponent} from './main/online-ordering/online-ordering-select/online-ordering-select.component';
import {BreadcrumbsComponent} from './main/online-ordering/breadcrumbs/breadcrumbs.component';
import {OnlineOrderingCartComponent} from './main/online-ordering/online-ordering-cart/online-ordering-cart.component';
import {OnlineOrderingCartService} from './main/online-ordering/online-ordering-cart/online-ordering-cart.service';
import {OnlineOrderingCustomizationService} from './main/online-ordering/online-ordering-customize/online-ordering-customization.service';
import {LoginService} from './public/login/login.service';
import {DmhHompageComponent} from './main/dmh-hompage/dmh-hompage.component';
import {OnlineOrderingDoneComponent} from './main/online-ordering/online-ordering-done/online-ordering-done.component';
import {OnlineOrderingShippingComponent} from './main/online-ordering/online-ordering-shipping/online-ordering-shipping.component';
import {OnlineOrderingSummaryComponent} from './main/online-ordering/online-ordering-summary/online-ordering-summary.component';
import {AccountComponent} from './main/account/account.component';
import {AddNewShippingComponent} from './main/online-ordering/online-ordering-shipping/add-new-shipping/add-new-shipping.component';
import {OnlineOrderingShippingService} from './main/online-ordering/online-ordering-shipping/online-ordering-shipping.service';
import {AccountService} from './main/account/account.service';
import {OnlineOrderingDoneService} from './main/online-ordering/online-ordering-done/online-ordering-done.service';
import {OnlineOrderingSummaryService} from './main/online-ordering/online-ordering-summary/online-ordering-summary.service';
import {LegalPolicyComponent} from './main/legal-policy/legal-policy.component';
import {ReportingComponent} from './main/reporting/reporting.component';
import {PublicationsComponent} from './main/publications/publications.component';


import {SsoLoginComponent} from './public/sso-login/sso-login.component';
import {HnkSsoLoginComponent} from './public/hnk-sso-login/hnk-sso-login.component';
import {OnlineOrderingSelectPreviewComponent} from './main/online-ordering/online-ordering-select-preview/online-ordering-select-preview.component';
import {OnlineOrderingSelectPreviewService} from './main/online-ordering/online-ordering-select-preview/online-ordering-select-preview.service';

import {ReportingService} from './main/reporting/reporting.service';

import {LogService} from './common/log.service';
import {PublicationService} from './main/publications/publication.service';
import {AddPublicationsAssetsComponent} from './main/publications/add-publications-assets/add-publications-assets.component';
import {FileUploadModule} from 'ng2-file-upload';
import {AutomatedMarketingComponent} from './main/automated-marketing/automated-marketing.component';


//assets Tiles //
import {AddAssetModalComponent} from './main/asset-tiles/add-asset-modal/add-asset-modal.component';
import {AssetDetailModalComponent} from './main/asset-tiles/asset-detail-modal/asset-detail-modal.component';
import {AddCategoryModalComponent} from './main/asset-tiles/add-category-modal/add-category-modal.component';
import {CategoryPermissionModalComponent} from './main/asset-tiles/category-permission-modal/category-permission-modal.component';
import {ShareAssetModalComponent} from './main/asset-tiles/share-asset-modal/share-asset-modal.component';
import {AssetPublishModalComponent} from './main/asset-tiles/asset-publish-modal/asset-publish-modal.component';
import {EditAssetModalComponent} from './main/asset-tiles/edit-asset-modal/edit-asset-modal.component';
import {DownloadAssetModalComponent} from './main/asset-tiles/download-asset-modal/download-asset-modal.component';
import {AssetTilesService} from './main/asset-tiles/asset-tiles.service';
import {AssetTilesComponent} from './main/asset-tiles/asset-tiles.component';
import { BsDatepickerModule } from 'ngx-bootstrap';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { AssetsFolderComponent } from './main/assets-folder/assets-folder.component';
import {CategoryPermissionPipe} from './common/category-permission.pipe';

// CCEP
import {CustomiseMenuComponent} from './main/customise-menu/customise-menu.component';
import {DesignsTabComponent} from './main/customise-menu/designs-tab/designs-tab.component';
import {LayoutTabComponent} from './main/customise-menu/layout-tab/layout-tab.component';
import {BackgroundTabComponent} from './main/customise-menu/background-tab/background-tab.component';
import {ImagesTabComponent} from './main/customise-menu/images-tab/images-tab.component';
import {ImagesOverlayComponent} from './main/customise-menu/images-overlay/images-overlay.component';
import {ApprovalsTabComponent} from './main/customise-menu/approvals-tab/approvals-tab.component';
import {CustomiseMenuService} from './main/customise-menu/customise-menu.service';
import {ConfigEditorComponent} from './main/customise-menu/config-editor/config-editor.component';
import {TextEditorComponent} from './main/customise-menu/text-editor/text-editor.component';
import {ImageEditorComponent} from './main/customise-menu/image-editor/image-editor.component';
import {EditTextRulesComponent} from './main/customise-menu/edit-text-rules/edit-text-rules.component';
import {EditImageRulesComponent} from './main/customise-menu/edit-image-rules/edit-image-rules.component';
import {DownloadArtworkComponent} from './main/customise-menu/download-artwork/download-artwork.component';
import {ImageUploadComponent} from './main/customise-menu/image-upload/image-upload.component';
import {EditDesignsRuleComponent} from './main/customise-menu/edit-designs-rule/edit-designs-rule.component';
import {TermsAndConditionsComponent} from './main/customise-menu/terms-and-conditions/terms-and-conditions.component';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {ColorPickerModule} from 'ngx-color-picker';
import {TooltipModule} from 'ngx-tooltip';
import {NgSelectModule} from '@ng-select/ng-select';
import {UpdatePasswordComponent} from './public/update-password/update-password.component'
import {CalendarModule} from 'primeng/calendar';
import {TreeModule} from 'primeng/tree';
import { UpdatePasswordService}  from './public/update-password/update-password.service';
import {AssetsDownloadsComponent} from './main/asset-tiles/assets-downloads/assets-downloads.component';
import {AssestOrdersComponent} from "./main/assest-orders/assest-orders.component";
import { TemplateLibraryComponent} from './main/customise-menu/template-library/template-library.component';
import {NotFoundComponent} from './public/not-found/not-found.component';
export function createTranslateLoader(http: HttpClient) {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}


@NgModule({
  declarations: [
    AppComponent,
    BaseComponent,
    CanLoginActivate,
    CanAuthActivate,
    SmartSearchPipe,
    OrderByPipe,
    EmojiPipe,
    WsTimeFilterPipe,
    UTCFilterPipe,
    ToArrayPipe,
    GroupByPipe,
    TruncatePipe,
    MapToIterable,
    LoginComponent,
    OnlineOrderingPreviewComponent,
    OnlineOrderingCustomizeComponent,
    MainComponent,
    DmhHeaderComponent,
    DmhFooterComponent,
    UserdetailComponent,
    HelpAndSupportComponent,
    OnlineOrderingSelectComponent,
    BreadcrumbsComponent,
    AddNewShippingComponent,
    OnlineOrderingCartComponent,
    DmhHompageComponent,
    OnlineOrderingDoneComponent,
    OnlineOrderingShippingComponent,
    OnlineOrderingSummaryComponent,
    AccountComponent,
    LegalPolicyComponent,
    ReportingComponent,
    PublicationsComponent,
    AccountComponent,
    SsoLoginComponent,
    HnkSsoLoginComponent,
    OnlineOrderingSelectPreviewComponent,
    AddPublicationsAssetsComponent,
    AutomatedMarketingComponent,
    AddAssetModalComponent,
    AssetDetailModalComponent,
    AddCategoryModalComponent,
    CategoryPermissionModalComponent,
    ShareAssetModalComponent,
    AssetPublishModalComponent,
    EditAssetModalComponent,
    DownloadAssetModalComponent,
    AssetTilesComponent,
    CustomiseMenuComponent,
    DesignsTabComponent,
    LayoutTabComponent,
    BackgroundTabComponent,
    ImagesTabComponent,
    ApprovalsTabComponent,
    ConfigEditorComponent,
    TextEditorComponent,
    ImageEditorComponent,
    EditTextRulesComponent,
    EditImageRulesComponent,
    ImagesOverlayComponent,
    UpdatePasswordComponent,
    AssetsDownloadsComponent,
    DownloadArtworkComponent,
    ImageUploadComponent,
    AssestOrdersComponent,
    AssetsFolderComponent,
    CategoryPermissionPipe,
    EditDesignsRuleComponent,
    TermsAndConditionsComponent,
    TemplateLibraryComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoute,
    NgSelectModule,
    // AppRoutingModule,
    FormsModule,
    HttpClientModule,
    LoadingBarHttpClientModule,
    NgxMaskModule.forRoot(options),
    FileUploadModule,
    ImageCropperModule,
    BsDatepickerModule.forRoot(),
    // HighchartsChartModule,
    DragDropModule,
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: '#78C000',
      innerStrokeColor: '#C7E596',
      animationDuration: 300
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [HttpClient]
      }
    }),
    ToastrModule.forRoot(),
    CalendarModule,
    TreeModule,
    NgbModule,
    ColorPickerModule,
    TooltipModule
  ],
  entryComponents: [
    OnlineOrderingSelectComponent,
    AddCategoryModalComponent,
    AddAssetModalComponent,
    CategoryPermissionModalComponent,
    DownloadAssetModalComponent,
    EditAssetModalComponent,
    AssetDetailModalComponent,
    ShareAssetModalComponent,
    AssetPublishModalComponent,
    ImagesOverlayComponent,
    EditTextRulesComponent,
    EditImageRulesComponent,
    UpdatePasswordComponent,
    DmhHeaderComponent,
    ImageUploadComponent,
    EditDesignsRuleComponent,
    TermsAndConditionsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [Broadcaster,
    DataService,
    OnlineOrderingService,
    OnlineOrderingPreviewService,
    OnlineOrderingCartService,
    OnlineOrderingCustomizationService,
    LoginService,
    OnlineOrderingShippingService,
    AccountService,
    OnlineOrderingDoneService,
    LogService,
    OnlineOrderingSummaryService,
    CanAuthActivate,
    CanLoginActivate,
    OnlineOrderingSelectPreviewService,
    PublicationService,
    ReportingService,
    AssetTilesService,
    CustomiseMenuService,
    UpdatePasswordService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
