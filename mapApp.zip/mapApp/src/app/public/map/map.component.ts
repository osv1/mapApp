import { Component, OnInit, Injector } from '@angular/core';
import { BaseComponent } from './../../common/commonComponent'
declare var google;

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.css']
})
export class MapComponent extends BaseComponent implements OnInit {

  constructor(inj: Injector) {
    super(inj);
  }
  public user: any = {};
  map: any;
  ngOnInit() {
  }

  ngAfterViewInit() {

    this.initMaps();
    // For intitalise google autocomplete address
    this.autocompleteSearchBox();
  }


  // For google autocomplete address
  autocompleteSearchBox() {
    google.maps.event.addDomListener(window, 'load', function () {
      const places = new google.maps.places.Autocomplete(document.getElementById('txtPlaces'));
      google.maps.event.addListener(places, 'place_changed', function () {
        const place = places.getPlace();
        const address = place.formatted_address;
        const latitude = place.geometry.location.lat();
        const longitude = place.geometry.location.lng();
        let mesg = 'Address: ' + address;
        mesg += '\nLatitude: ' + latitude;
        mesg += '\nLongitude: ' + longitude;

        // Set Map
        this.map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: { lat: latitude, lng: longitude },
        });

      
        // Set Drawing
        const drawingManager = new google.maps.drawing.DrawingManager({
          drawingControl: true,
          drawingControlOptions: {
            position: google.maps.ControlPosition.TOP_CENTER,
            drawingModes: ['marker', 'polygon']
            // drawingModes: ['marker', 'circle', 'polygon', 'polyline', 'rectangle']
          },
          markerOptions: {
          },
          polygonOptions: {
            fillColor: '#e5ae35',
            fillOpacity: 0.5,
            strokeColor: '#e5ae35',
            strokeWeight: 2,
            clickable: true,
            editable: true,
            zIndex: 1
          },
        });
        drawingManager.setMap(this.map);
        // alert(mesg);
        let coordinatesArray;
        google.maps.event.addListener(drawingManager, 'overlaycomplete', function (polygon) {
         
          if (polygon.type === 'polygon') {
            console.log(polygon);
            coordinatesArray = polygon.overlay.getPath().getArray();
            console.log(coordinatesArray);
            for (let index = 0; index < coordinatesArray.length; index++) {
              console.log(coordinatesArray[index].lat());
              console.log(coordinatesArray[index].lng());
            }
          }

          
        });

        google.maps.event.addListener(drawingManager, 'markercomplete', function (marker) {
          console.log('yes');
          console.log(marker);
          console.log(marker.position.lat());
          console.log(marker.position.lng());
          marker.addListener('click', function () {
            console.log('yes');
            marker.infowindow.open(this.map, marker);
          });
        });
      });
    });
  }


  initMaps() {
    const route1 = [
      { lat: '21.601561408503567', lng: '71.22052215435338' },
      { lat: '21.601521507250652', lng: '71.22070454456639' },
      { lat: '21.60150155662007', lng: '71.22091912128758' },
      { lat: '21.601431729391365', lng: '71.22118734218907' },
      { lat: '21.601401803425887', lng: '71.22143410541844' },
      { lat: '21.601371877454234', lng: '71.22183107235264' },
      { lat: '21.601102543430752', lng: '71.22411631443333' },
      { lat: '21.601042691357453', lng: '71.22496389248204' },
      { lat: '21.60092298713661', lng: '71.22642301418614' },
      { lat: '21.600813258180498', lng: '71.22782849170994' },
      { lat: '21.600693767178438', lng: '71.23001227568795' }
    ];

    const route2 = [
      { lat: '21.59593786213135', lng: '71.22759250996114' },
      { lat: '21.596895526113062', lng: '71.2277105271578' },
      { lat: '21.597623745524672', lng: '71.22781781551839' },
      { lat: '21.59846169209459', lng: '71.22790364620687' },
      { lat: '21.5995689711919', lng: '71.22804312107564' },
      { lat: '21.60042685728032', lng: '71.22819332478048' },
      { lat: '21.600746069410302', lng: '71.22841863033773' },
      { lat: '21.600736094041906', lng: '71.22868685123922' },
      { lat: '21.600726118672807', lng: '71.22935203907491' },
      { lat: '21.600706167932557', lng: '71.23010305759908' }
    ];
    const route3 = [
      { lat: '21.59775963270447', lng: '71.22217091550908' },
      { lat: '21.59859757848761', lng: '71.2221923731812' },
      { lat: '21.599575175769303', lng: '71.22225674619756' },
      { lat: '21.599684905664205', lng: '71.22273954382024' },
      { lat: '21.600213603082523', lng: '71.22276100149236' },
      { lat: '21.601121362068923', lng: '71.22284683218084' },
      { lat: '21.601041559309422', lng: '71.22378024091802' },
      { lat: '21.601001657913148', lng: '71.22463854780278' },
      { lat: '21.600941805798133', lng: '71.22607621183477' },
      { lat: '21.600822101493826', lng: '71.22761043539128' },
      { lat: '21.600692421719074', lng: '71.23006733884893' }
    ];


    const waypts = [];
    const wayPintIcon = {
      url: 'assets/images/destinationmarker.png',
      // anchor: new google.maps.Point(destinationpoint.lat, destinationpoint.lng),
      scaledSize: new google.maps.Size(50, 50), // scaled size
    };
    const stop1 = new google.maps.LatLng(21.601401803425887, 71.22143410541844);
    waypts.push({
      location: stop1,
      stopover: true
    });
    const stop2 = new google.maps.LatLng(21.601102543430752, 71.22411631443333);
    waypts.push({
      location: stop2,
      stopover: true
    });
    const stop3 = new google.maps.LatLng(21.60092298713661, 71.22642301418614);
    waypts.push({
      location: stop3,
      stopover: true
    });

    const wayicon = {
      url: 'assets/images/waypointmarker.png', // url
      scaledSize: new google.maps.Size(30, 40), // scaled size
    };

    this.map = new google.maps.Map(document.getElementById('map'), {
      zoom: 15,
      center: { lat: 21.603456705342943, lng: 71.22244798042607 },
    });

    // tslint:disable-next-line:max-line-length
    this.setNewRoute({ lat: 21.596967677079146, lng: 71.22211146439713 }, { lat: 21.600738415530028, lng: 71.23007226075333 }, route3, 'yellow', [], 'BUS-C');
    // tslint:disable-next-line:max-line-length
    this.setNewRoute({ lat: 21.601561408503567, lng: 71.22052215435338 }, { lat: 21.600693767178438, lng: 71.23001227568795 }, route1, 'yellow', waypts, 'BUS-A');
    // tslint:disable-next-line:max-line-length
    this.setNewRoute({ lat: 21.595711586692527, lng: 71.22756561914343 }, { lat: 21.600693767178438, lng: 71.23001227568795 }, route2, 'blue', [], 'BUS-B');

       // Set Drawing
    const drawingManager = new google.maps.drawing.DrawingManager({
      drawingControl: true,
      drawingControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        drawingModes: ['marker', 'polygon']
        // drawingModes: ['marker', 'circle', 'polygon', 'polyline', 'rectangle']
      },
      markerOptions: {
      },
      polygonOptions: {
        fillColor: '#e5ae35',
        fillOpacity: 0.5,
        strokeColor: '#e5ae35',
        strokeWeight: 2,
        clickable: true,
        editable: true,
        zIndex: 1
      },
    });
    drawingManager.setMap(this.map);
    // alert(mesg);
    let coordinatesArray;
    google.maps.event.addListener(drawingManager, 'overlaycomplete', function (polygon) {
      if (polygon.type === 'polygon') {
        console.log(polygon);
        coordinatesArray = polygon.overlay.getPath().getArray();
        console.log(coordinatesArray);
        for (let index = 0; index < coordinatesArray.length; index++) {
          console.log(coordinatesArray[index].lat());
          console.log(coordinatesArray[index].lng());
        }
      }
    });

    google.maps.event.addListener(drawingManager, 'markercomplete', function (marker) {
      console.log('yes');
      console.log(marker);
      console.log(marker.position.lat());
      console.log(marker.position.lng());
      marker.addListener('click', function () {
        console.log('yes');
        marker.infowindow.open(this.map, marker);
      });
    });
  }

  setNewRoute(originpoint, destinationpoint, routepointarray, routecolor: string, pickuppoint, infoWindowText) {
    const directionsService = new google.maps.DirectionsService;
    // const directionsDisplay = new google.maps.DirectionsRenderer;
    const directionsDisplay = new google.maps.DirectionsRenderer;
    directionsDisplay.setMap(null);
    directionsDisplay.setOptions({
      polylineOptions: {
        strokeColor: routecolor,
        strokeOpacity: .8,
        strokeWeight: 5,
        strokeHeight: 5
      }, suppressMarkers: true
    });
    directionsDisplay.setMap(this.map);
    directionsService.route({
      origin: originpoint,
      destination: destinationpoint,
      // origin: { lat: 21.606243186208456, lng: 71.22562169740672 },
      // destination: { lat: 21.600693767178438, lng: 71.23001227568795 },
      waypoints: pickuppoint, // waypoint if have,
      optimizeWaypoints: true,
      travelMode: 'DRIVING',
      // travelMode: 'TRANSIT',
    }, function (response, status) {
      if (status === 'OK') {
        directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });

    // START : for set pickpoint icon
    const wayicon = {
      url: 'assets/images/pickuppointmarker.svg', // url
      scaledSize: new google.maps.Size(30, 40), // scaled size
    };
    for (let i = 0; i < pickuppoint.length; i++) {
      const mar = new google.maps.Marker({
        position: pickuppoint[i].location,
        map: this.map,
        icon: wayicon
      });
    }
    // END : for set pickpoint icon

    // START : for set origin and destination icon
    const originIcon = {
      url: 'assets/images/originmarker.png',
      // anchor: new google.maps.Point(originpoint.lat, originpoint.lng),
      scaledSize: new google.maps.Size(35, 50), // scaled size
    };

    const destinationIcon = {
      url: 'assets/images/destinationmarker.png',
      // anchor: new google.maps.Point(destinationpoint.lat, destinationpoint.lng),
      scaledSize: new google.maps.Size(50, 50), // scaled size
    };

    // Create the marker for origin
    const originMarker = new google.maps.Marker({
      position: originpoint,
      map: this.map,
      icon: originIcon
    });

    // Create the marker destination
    const destinationMarker = new google.maps.Marker({
      position: destinationpoint,
      map: this.map,
      icon: destinationIcon
    });
    // END : for set origin and destination icon

    // START : for set bus infowindow
    const infowindow = new google.maps.InfoWindow({
      content: infoWindowText,
    });
    // END : for set bus infowindow

    let count = 0;
    const icon: any = {
      url: 'assets/images/school-bus.png', // url
      // url: 'assets/images/map-marker.gif', // url
      scaledSize: new google.maps.Size(50, 50), // scaled size
    };

    const marker = new google.maps.Marker({
      position: originpoint,
      // position: { lat: 21.606243186208456, lng: 71.22562169740672 },
      map: this.map,
      // icon: icon,
      title: 'Hello World!'
    });
    infowindow.open(this.map, marker);
    setInterval(() => {
      count++;
      const prevPos = marker.getPosition();
      // console.log(prevPos);
      if (routepointarray[count]) {
        marker.animateTo(new google.maps.LatLng(routepointarray[count].lat, routepointarray[count].lng));
        const newPostion = new google.maps.LatLng(routepointarray[count].lat, routepointarray[count].lng);
        // marker.rotation = google.maps.geometry.spherical.computeHeading(prevPos, newPostion);
        marker.setIcon({
          // tslint:disable-next-line:max-line-length
          path: 'M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z',
          scale: .7,
          strokeColor: 'white',
          strokeWeight: .2,
          strokeHeight: .2,
          fillOpacity: 1,
          fillColor: '#404040',
          offset: '5%',
          rotation: google.maps.geometry.spherical.computeHeading(prevPos, newPostion)
        });

        // marker.setIcon(icon);
        // tslint:disable-next-line:max-line-length
        // marker.setPosition(letlngsrray[count]);
      }
    }, 1500);
  }
}
