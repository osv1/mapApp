import { BrowserModule, BrowserTransferStateModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatPaginatorModule, MatSlideToggleModule } from '@angular/material';

// Plugins
import { SocialLoginModule, AuthServiceConfig, GoogleLoginProvider, FacebookLoginProvider } from "angular5-social-login";
import { NgSelectModule } from '@ng-select/ng-select';
import { CKEditorModule } from 'ng2-ckeditor'; //1. https://github.com/chymz/ng2-ckeditor //2. https://ckeditor.com/ckeditor-4/download/
import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { PaginationModule } from 'ngx-bootstrap';
import { BnDatatableModule } from './common/bn-datatable/bn-datatable.module'
// Common
import { BaseComponent } from './common/commonComponent';
import { CommonService } from './common/common.service'
import { CanLoginActivate, CanAuthActivate } from './common/auth.gaurd'
import { ErrorMessages } from './common/errorMessages';

// public pages
import { MapComponent } from './public/map/map.component';

// main pages
import { MainComponent } from './main/main.component';
import { DashboardComponent } from './dashboard/dashboard.component';


//************************************************************************************************//
// @Purpose : Social Media Login//
//************************************************************************************************//
export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
    [
      {
        id: FacebookLoginProvider.PROVIDER_ID,
        provider: new FacebookLoginProvider("147316885915455")
      },
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider("125303558418-4j016lhttq89o8mic0dn8lkahf5tkhp4.apps.googleusercontent.com")
      },
    ]
  );
  return config;
}
//************************************************************************************************//

@NgModule({
  declarations: [
    AppComponent,
    MapComponent,
    MainComponent,
    BaseComponent,
    CanLoginActivate,
    CanAuthActivate,
    DashboardComponent,
   
  ],
  imports: [
    BnDatatableModule,
    NgSelectModule,
    PaginationModule.forRoot(),
    MatPaginatorModule, MatSlideToggleModule,
    LoadingBarHttpClientModule,
    SweetAlert2Module.forRoot(),
    BrowserAnimationsModule,
    CKEditorModule,
    SocialLoginModule,
    FormsModule,
    BrowserModule.withServerTransition({ appId: 'universal-demo-v5' }),
    HttpClientModule,
    BrowserTransferStateModule,
    RouterModule.forRoot([
      { path: '', component: MapComponent, pathMatch: 'full' },
      { path: '**', redirectTo: '/', pathMatch: 'full' }
    ])
  ],
  providers: [
    CanLoginActivate, CanAuthActivate, CommonService, ErrorMessages,
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    }],
  bootstrap: [AppComponent]
})

export class AppModule { }
