import { Component, OnInit, Injector } from '@angular/core';
import { BaseComponent } from './../common/commonComponent';

@Component({
	selector: 'app-main',
	templateUrl: './main.component.html'
})
export class MainComponent extends BaseComponent implements OnInit {

	constructor(inj: Injector) {
		super(inj)
		let id = this.getToken('Aid');
		this.getAdminProfile(id);
	}
	public admin: any = {}
	public sidebar = $('.sidebar');
	public imageData: any;
	ngOnInit() {
		$('[data-toggle="offcanvas"]').on("click", function () {
			$('.sidebar-offcanvas').toggleClass('active')
		});
	}
	/****************************************************************************
  @PURPOSE      : Get Admin profile
  /****************************************************************************/
	getAdminProfile(id) {
		console.log(id);
		let data = { 'id': id }
		this.commonService.callApi('adminProfile', data, 'post').then(success => {
			console.log(success);
			if (success.status == 1) {

				this.admin = success.data[0]
				console.log(this.admin)
				//this.imageChangedEvent = this.admin.profilePic
				// this.user.email = success.data.emailId
			} else {
				this.popToast('error', success.message)
			}
			console.log('success', success)
		})
	}
	/****************************************************************************/

}
